'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');

// Execute the shipped inline player with deterministic network and media events.
const html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8');
const script=html.split('<script>')[1].split('</script>')[0];
const instrumented=script.replace(/\}\)\(\);\s*$/,`globalThis.player={sync,poll,render,startMusic,onAir,manifestFresh,media,
 seed:value=>{manifest=value;manifestReceivedAt=performance.now();offset=value.serverTime-Date.now();},
 setWanted:value=>{wanted=value;},
 state:()=>({language,manifest,currentId,epoch,channelEpoch,pollJob,playbackJob,manifestReceivedAt,cacheSize:cache.size,musicSince})};})();`);

function deferred(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return{promise,resolve,reject};}
async function flush(){for(let i=0;i<20;i++)await Promise.resolve();}
function element(id=''){
 const listeners=new Map();
 return{id,textContent:'',hidden:false,dir:'',value:id==='volume'?'.9':'ar',max:1,children:[],style:{},options:[],
 classList:{toggle(){}},append(...items){this.children.push(...items)},replaceChildren(){this.children=[]},
 addEventListener(type,fn,options={}){if(!listeners.has(type))listeners.set(type,new Map());listeners.get(type).set(fn,options)},
 removeEventListener(type,fn){listeners.get(type)?.delete(fn)},
 listeners(type){return[...(listeners.get(type)?.keys()||[])]},
 dispatch(type){for(const[fn,options]of[...(listeners.get(type)||[])]){if(options.once)listeners.get(type).delete(fn);fn({type,target:this});}this['on'+type]?.({type,target:this});},
 removeAttribute(name){delete this[name]}};
}
function harness(){
 let perf=0,wall=Date.UTC(2026,9,23,12),counter=0,objectCounter=0;
 const timers=new Map(),requests=[],plays=[],revoked=[],nodes=new Map();
 const audio=element('audio');Object.assign(audio,{paused:true,ended:false,readyState:0,currentTime:0,currentSrc:'',nextPlay:null,
 play(){plays.push({src:this.src,volume:this.volume,at:perf});this.paused=false;this.ended=false;const result=this.nextPlay;this.nextPlay=null;return result?.promise||Promise.resolve();},
 pause(){this.paused=true},load(){this.readyState=0;this.currentSrc='';this.ended=false},
 metadata(url=this.src){this.currentSrc=url;this.readyState=2;this.dispatch('loadedmetadata')},
 finish(){this.paused=true;this.ended=true;this.dispatch('ended')}});
 let audioSource='';Object.defineProperty(audio,'src',{configurable:true,get(){return audioSource},set(value){audioSource=value;this.readyState=0;this.currentSrc='';this.ended=false;}});
 audio.removeAttribute=name=>{if(name==='src')audio.src='';};nodes.set('audio',audio);
 const node=id=>{if(!nodes.has(id))nodes.set(id,element(id));return nodes.get(id)};
 node('language').options=[{value:'ar'},{value:'en'}];
 class LocalDate extends Date{constructor(...values){super(...(values.length?values:[wall]));}static now(){return wall;}}
 class LocalURL extends URL{static createObjectURL(){return 'blob:player-'+(++objectCounter)}static revokeObjectURL(value){revoked.push(value)}}
 const context={console,document:{getElementById:node,createElement:element},Date:LocalDate,Math,Number,String,Array,Map,Set,Promise,URL:LocalURL,Error,AbortController,
 performance:{now:()=>perf},setInterval(){return ++counter;},setTimeout(fn,delay){const key=++counter;timers.set(key,{fn,at:perf+delay});return key;},clearTimeout(key){timers.delete(key)},
 fetch(url,options){const d=deferred();const request={url,options,...d};requests.push(request);return d.promise;}};
 vm.runInNewContext(instrumented,context);
 function advance(ms){const target=perf+ms;while(true){let next;for(const[key,value]of timers)if(value.at<=target&&(!next||value.at<next.value.at))next={key,value};if(!next)break;const delta=next.value.at-perf;perf=next.value.at;wall+=delta;timers.delete(next.key);next.value.fn();}wall+=target-perf;perf=target;}
 const programme=(queue=[],extra={})=>({language:node('language').value,languages:['ar','en'],queue,recent:[],status:'waiting',serverTime:wall,feedsReached:10,feedCount:10,freshStories:0,unreadFreshStories:0,...extra});
 const clip=(id='a',lang=node('language').value,extra={})=>({id:id.repeat(32),language:lang,kind:'news',audioUrl:'/audio/'+id.repeat(32)+'.wav',headline:'A public report',source:'Publisher',sourceUrl:'https://example.org/news',speechText:lang==='ar'?'هذا نص الخبر.':'This is the spoken report.',startsAt:wall-1000,endsAt:wall+40000,publishedAt:wall-30000,firstSeenAt:wall-20000,...extra});
 const response=value=>({ok:true,json:async()=>value});
 const wave=()=>({ok:true,headers:{get:name=>name==='content-type'?'audio/wav':name==='content-length'?'100':null},blob:async()=>({size:100})});
 const requestFor=url=>requests.findLast(r=>r.url===url);
 const acceptInitial=async()=>{requests[0].resolve(response(programme()));await flush();};
 const changeLanguage=value=>{node('language').value=value;node('language').onchange();};
 return{player:context.player,audio,node,requests,plays,revoked,timers,advance,programme,clip,response,wave,requestFor,acceptInitial,changeLanguage,now:()=>wall,perf:()=>perf};
}
async function prepareSpeech(h,q){h.player.seed(h.programme([q]));h.player.setWanted(true);const pending=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await pending;return h.audio.src;}

test('waiting music loops beyond eight seconds without restarting on repeated sync',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);const hang=deferred();h.audio.nextPlay=hang;
 const starting=h.player.startMusic({unlock:true});assert.equal(h.plays.length,1,'same element play is called within the gesture');assert.equal(h.audio.src,'/station-relax-v2.wav');assert.equal(h.audio.loop,true);
 h.advance(180000);await h.player.sync();await h.player.sync();assert.equal(h.audio.paused,false);assert.equal(h.plays.length,1,'one seamless bed continues across repeated checks');
 hang.resolve();await starting;assert.equal(h.audio.paused,false,'late play completion leaves the waiting music running');
 h.player.render();assert.equal(h.node('badgeText').textContent,'WAITING MUSIC');assert.match(h.node('source').textContent,/fills the wait/);assert.doesNotMatch(h.node('source').textContent,/eight|short/i);
});

test('music accepts only fixed station assets and preserves shared position',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);h.player.seed(h.programme([],{music:{audioUrl:'https://outside.example/track.mp3',durationSeconds:120}}));await h.player.startMusic();assert.equal(h.audio.src,'/station-relax-v2.wav');h.audio.metadata();assert.ok(h.audio.currentTime>=0&&h.audio.currentTime<120);
 h.node('join').onclick();assert.equal(h.audio.paused,true);assert.equal(h.audio.loop,false);assert.equal(h.player.state().currentId,'');
 h.player.seed(h.programme([],{music:{audioUrl:'/station-bed-v1.wav',durationSeconds:32}}));h.node('join').onclick();assert.equal(h.audio.src,'/station-bed-v1.wav','prior fixed station asset remains compatible');
});

for(const outcome of ['late response','late error'])test('language poll is replaced immediately; '+outcome+' cannot overwrite it',async()=>{
 const h=harness(),old=h.requests[0];h.changeLanguage('en');assert.equal(old.options.signal.aborted,true);const current=h.requestFor('/radio.json?language=en');assert.ok(current,'English request starts without waiting for Arabic');
 current.resolve(h.response(h.programme([],{production:{preparing:true,kind:'market',queuedSeconds:0}})));await flush();assert.equal(h.player.state().manifest.language,'en');const status=h.node('status').textContent;
 if(outcome==='late response')old.resolve(h.response(h.programme([],{language:'ar'})));else old.reject(Error('old network error'));await flush();assert.equal(h.player.state().manifest.language,'en');assert.equal(h.node('status').textContent,status);assert.equal(h.player.state().pollJob,null);
});

test('language switch aborts old audio and old job cannot release the new metadata lock',async()=>{
 const h=harness();await h.acceptInitial();const arabic=h.clip('a','ar');h.player.seed(h.programme([arabic]));h.player.setWanted(true);const oldJob=h.player.sync();const oldAudio=h.requestFor(arabic.audioUrl);
 h.changeLanguage('en');assert.equal(oldAudio.options.signal.aborted,true);
 const english=h.clip('b','en');h.requestFor('/radio.json?language=en').resolve(h.response(h.programme([english])));await flush();h.requestFor(english.audioUrl).resolve(h.wave());await flush();const target=h.audio.src;assert.equal(h.player.state().playbackJob.id,english.id);
 oldAudio.resolve(h.wave());await oldJob;await flush();assert.equal(h.player.state().playbackJob.id,english.id,'old finally cannot release the newer job');assert.equal(h.audio.src,target);
 h.audio.metadata(target);await flush();assert.equal(h.player.state().currentId,english.id);assert.equal(h.player.state().language,'en');assert.equal(h.plays.at(-1).src,target);
});

test('cancelled metadata listeners are removed and stale events cannot complete new speech',async()=>{
 const h=harness();await h.acceptInitial();const ar=h.clip('a','ar');h.player.seed(h.programme([ar]));h.player.setWanted(true);const first=h.player.sync();h.requestFor(ar.audioUrl).resolve(h.wave());await flush();const oldListeners=h.audio.listeners('loadedmetadata');assert.ok(oldListeners.length);
 h.advance(500);h.changeLanguage('en');await first;const en=h.clip('b','en');h.requestFor('/radio.json?language=en').resolve(h.response(h.programme([en])));await flush();h.requestFor(en.audioUrl).resolve(h.wave());await flush();const newUrl=h.audio.src;
 for(const listener of oldListeners)listener({type:'loadedmetadata',target:h.audio});h.audio.dispatch('loadedmetadata');await flush();assert.equal(h.player.state().playbackJob.id,en.id,'an event before new-source metadata is ready must be ignored');
 h.audio.metadata(newUrl);await flush();assert.equal(h.player.state().playbackJob,null);assert.equal(h.player.state().currentId,en.id);assert.equal(h.audio.listeners('loadedmetadata').length,0);
});

test('metadata timeout removes listeners and automatically retries after bounded backoff',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();h.player.seed(h.programme([q]));h.player.setWanted(true);const first=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();
 h.advance(10000);await first;assert.equal(h.player.state().playbackJob,null);assert.equal(h.player.state().currentId,'music');assert.equal(h.audio.paused,false,'waiting music resumes while speech retries');assert.equal(h.audio.listeners('loadedmetadata').length,1,'only the music cue remains');assert.match(h.node('status').textContent,/retrying/i);
 await h.player.sync();assert.equal(h.player.state().playbackJob,null,'no tight reload loop');h.advance(2000);const retry=h.player.sync();await flush();assert.equal(h.player.state().playbackJob.id,q.id);h.audio.metadata();await retry;assert.equal(h.audio.paused,false);assert.equal(h.player.state().currentId,q.id);
});

test('a stalled speech play promise times out and cannot release a newer retry',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();h.player.seed(h.programme([q]));h.player.setWanted(true);
 const first=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();const pendingPlay=deferred();h.audio.nextPlay=pendingPlay;h.audio.metadata();await flush();
 h.advance(5000);await first;assert.equal(h.player.state().playbackJob,null);assert.equal(h.player.state().currentId,'music');assert.equal(h.audio.paused,false,'waiting music covers speech play retry');assert.match(h.node('status').textContent,/retrying/);
 h.advance(2000);const retry=h.player.sync();await flush();assert.equal(h.player.state().playbackJob.id,q.id);
 pendingPlay.resolve();await flush();assert.equal(h.player.state().playbackJob.id,q.id,'old play completion must not release the new metadata job');h.audio.metadata();await retry;assert.equal(h.audio.paused,false);
});

test('ready speech immediately replaces waiting music on the same element',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);await h.player.startMusic();h.advance(30000);const musicSource=h.audio.src;
 const q=h.clip();h.player.seed(h.programme([q]));const ready=h.player.sync();assert.equal(h.audio.src,musicSource,'music continues while the speech file downloads');assert.equal(h.audio.paused,false);
 h.requestFor(q.audioUrl).resolve(h.wave());await flush();assert.notEqual(h.audio.src,musicSource);assert.equal(h.audio.loop,false);assert.equal(h.audio.paused,true,'same element stops music before loading speech');
 h.audio.metadata();await ready;assert.equal(h.player.state().currentId,q.id);assert.equal(h.audio.paused,false);assert.equal(h.audio.volume,.9);assert.equal(h.plays.filter(x=>x.src.startsWith('blob:')).length,1);
 await h.player.startMusic();assert.equal(h.player.state().currentId,q.id,'a stray gap request cannot interrupt speech');
 h.audio.finish();await flush();assert.equal(h.player.state().currentId,'music');assert.equal(h.audio.loop,true);assert.equal(h.audio.paused,false);
 h.node('join').onclick();h.advance(60000);await h.player.sync();assert.equal(h.audio.paused,true,'Pause stops both music and speech until a new gesture');assert.equal(h.audio.loop,false);
});

test('old programme cannot start queued speech after an outage; a fresh response recovers',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{startsAt:h.now()+20000,endsAt:h.now()+40000});h.player.seed(h.programme([q]));h.player.setWanted(true);h.advance(21000);await h.player.sync();assert.equal(h.player.onAir(),null);assert.equal(h.requestFor(q.audioUrl),undefined,'do not start a future clip from a stale manifest');
 h.player.render();assert.match(h.node('checked').textContent,/Connection retrying/);
 const polling=h.player.poll();h.requestFor('/radio.json?language=ar').resolve(h.response(h.programme([q])));await polling;await flush();assert.ok(h.requestFor(q.audioUrl));h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await flush();assert.equal(h.player.state().currentId,q.id);assert.ok(h.audio.currentTime>=1,'join at the current shared point, not its beginning');
});

test('already playing speech may finish during outage but cannot replay from the stale programme',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();await prepareSpeech(h,q);const wavePlays=h.plays.length;h.advance(16000);await h.player.sync();assert.equal(h.audio.paused,false);assert.equal(h.player.onAir().id,q.id);
 h.audio.finish();await flush();assert.equal(h.player.onAir(),null);await h.player.sync();assert.equal(h.plays.filter(x=>x.src.startsWith('blob:')).length,1);assert.ok(h.plays.length>=wavePlays);
});

for(const delta of [-1000,0])test('a '+(delta===0?'repeated':'regressing')+' server clock cannot refresh an old programme',async()=>{
 const h=harness();await h.acceptInitial();const accepted=h.player.state().manifest.serverTime;h.advance(4000);
 const pending=h.player.poll();h.requestFor('/radio.json?language=ar').resolve(h.response(h.programme([],{serverTime:accepted+delta})));await pending;
 assert.equal(h.player.state().manifest.serverTime,accepted);assert.equal(h.player.state().manifestReceivedAt,0);assert.match(h.node('status').textContent,/connection interrupted/i);
});

test('market and discussion labels show transcript and grounded source clocks',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{kind:'market',caption:'Gold API collected 12:00; separate from chart.',speechText:'رصد سعر الذهب.'});h.player.seed(h.programme([q],{lastCollectionAt:h.now()-3000,market:{status:'stale',sourceAt:h.now()-120000},production:{preparing:true,kind:'market',queuedSeconds:13}}));h.player.render();
 assert.equal(h.node('badgeText').textContent,'GOLD UPDATE');assert.equal(h.node('source').textContent,q.caption);assert.equal(h.node('transcript').textContent,q.speechText);assert.equal(h.node('spoken').hidden,false);assert.match(h.node('freshness').textContent,/120 sec old · stale/);assert.match(h.node('freshness').textContent,/13 sec of speech queued/);
 q.kind='discussion';q.caption='Conditional discussion based on the published news window.';h.player.render();assert.equal(h.node('badgeText').textContent,'DISCUSSION');assert.equal(h.node('source').textContent,q.caption);assert.equal(h.node('source').children.length,0);
});

test('cloud news status shows the selected 70 percent and independent hosting only when declared',async()=>{
 const h=harness();await h.acceptInitial();h.player.seed(h.programme([],{mode:'cloud-news',dependencies:{pcRequired:false},freshStories:20,newsSelection:{fraction:.7,freshCount:20,relevantCount:10,selectedCount:7,unreadSelectedCount:3,method:'grounded relevance ranking'}}));h.player.render();
 assert.match(h.node('hosting').textContent,/computer switched off/);
 assert.equal(h.node('selection').textContent,'Top 70% of relevant fresh reports · 7 selected from 10 relevant · 3 awaiting speech');
 assert.equal(h.node('collection').textContent,'10/10 publisher feeds reached · 20 fresh headlines');
 assert.doesNotMatch(h.node('selection').textContent,/grounded relevance ranking/,'implementation method stays out of the listening UI');
 h.player.seed(h.programme([],{mode:'cloud-news',dependencies:{pcRequired:true},newsSelection:{fraction:.7,freshCount:20,relevantCount:10,selectedCount:7,unreadSelectedCount:-2}}));h.player.render();
 assert.doesNotMatch(h.node('hosting').textContent,/computer switched off/);
 assert.equal(h.node('selection').textContent,'Selecting the most relevant fresh reports…');
});


test('earlier reports keep their publication time and never display the live-news label',async()=>{
 const h=harness();await h.acceptInitial();const published=h.now()-1800000;
 const q=h.clip('a','ar',{recency:'earlier',publishedAt:published,firstSeenAt:h.now()-1200000,headline:'An unplayed report from earlier this hour',speechText:'تقرير سابق نُشر في الساعة الحادية عشرة والنصف.'});
 h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'EARLIER REPORT');assert.equal(h.node('voice').textContent,'ARABIC 2 · RECENT NEWS ROUNDUP');
 assert.match(h.node('source').textContent,/Publisher · Earlier report · Published/);assert.ok(h.node('source').textContent.includes(new Date(published).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'})),'caption preserves the actual publisher clock in the browser timezone');assert.match(h.node('source').textContent,/Collected/);
 assert.equal(h.node('transcript').textContent,q.speechText);assert.match(h.node('schedule').children[0].children[1].textContent,/Earlier report/);
 q.recency='fresh';q.publishedAt=h.now()-30000;h.player.render();assert.equal(h.node('badgeText').textContent,'LIVE NEWS');assert.doesNotMatch(h.node('source').textContent,/Earlier report/);
});

test('validated earlier-news backlog prepares speech and adds one concise waiting count',async()=>{
 const h=harness();await h.acceptInitial();const earlier={windowSeconds:3600,minimumAgeSeconds:601,freshCount:12,relevantCount:8,selectedCount:6,unreadSelectedCount:4};
 h.player.seed(h.programme([],{earlierNewsSelection:earlier,newsSelection:{fraction:.7,freshCount:0,relevantCount:0,selectedCount:0,unreadSelectedCount:0}}));h.player.render();
 assert.equal(h.node('badgeText').textContent,'PREPARING SPEECH');assert.match(h.node('schedule').children[0].textContent,/being prepared/);
 assert.equal(h.node('selection').textContent,'Top 70% of relevant fresh reports · 0 selected from 0 relevant · 0 awaiting speech · 4 earlier reports awaiting speech');
 for(const invalid of [{...earlier,unreadSelectedCount:-1},{...earlier,windowSeconds:7200},{...earlier,minimumAgeSeconds:0}]){
  h.player.seed(h.programme([],{earlierNewsSelection:invalid}));h.player.render();assert.equal(h.node('badgeText').textContent,'WAITING FOR UPDATE');assert.doesNotMatch(h.node('selection').textContent,/earlier reports/);
 }
 assert.match(html,/The latest ten minutes come first/);assert.match(html,/original publication time/);
});

test('fresh public social speech keeps its attribution and author clock separate from collection',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{social:true,platform:'Telegram',source:'Public publisher channel',sourceUrl:'https://t.me/example/12',publishedAt:h.now()-120000,firstSeenAt:h.now()-10000,speechText:'منشور عام غير متحقق منه، من قناة إخبارية.'});
 h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'SOCIAL POST');assert.equal(h.node('voice').textContent,'ARABIC 2 · PUBLIC SOCIAL DESK');
 assert.match(h.node('source').textContent,/Public publisher channel · Public post · Author-reported time/);assert.match(h.node('source').textContent,/Collected/);assert.doesNotMatch(h.node('source').textContent,/Published/);
 assert.equal(h.node('sourceLink').textContent,'Open public post ↗');assert.equal(h.node('sourceLink').href,q.sourceUrl);assert.equal(h.node('transcript').textContent,q.speechText);
 assert.match(h.node('schedule').children[0].children[1].textContent,/Public social post/);assert.doesNotMatch(h.node('badgeText').textContent,/LIVE|BREAKING|VERIFIED/);
});

test('earlier public social posts cannot appear as live news and render post text safely',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');const q=h.clip('b','en',{sourceKind:'social',platform:'Bluesky',recency:'earlier',publishedAt:h.now()-1800000,headline:'<img src=x onerror=alert(1)> Public post',source:'<b>Publisher</b>',speechText:'A public social post, not independently verified.'});
 h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'EARLIER SOCIAL POST');assert.equal(h.node('voice').textContent,'ENGLISH · PUBLIC SOCIAL DESK');assert.match(h.node('source').textContent,/Public post · Earlier post · Author-reported time/);
 assert.equal(h.node('headline').textContent,q.headline);assert.equal(h.node('headline').children.length,0);assert.equal(h.node('source').children.length,0);assert.match(h.node('schedule').children[0].children[1].textContent,/Earlier public post/);assert.doesNotMatch(h.node('badgeText').textContent,/LIVE NEWS/);
});

test('cloud social diagnostics show bounded source totals without changing publisher feed counts',async()=>{
 const h=harness();await h.acceptInitial();h.player.seed(h.programme([],{socialSources:{sourceCount:8,readySources:6},freshStories:15}));h.player.render();
 assert.equal(h.node('collection').textContent,'10/10 publisher feeds reached · 6/8 public social sources reached · 15 fresh headlines');
 for(const invalid of [{sourceCount:8,readySources:9},{sourceCount:8,readySources:-1},{sourceCount:8,readySources:'6'},{sourceCount:0,readySources:0}]){
  h.player.seed(h.programme([],{socialSources:invalid}));h.player.render();assert.doesNotMatch(h.node('collection').textContent,/public social sources/);
 }
 assert.match(html,/Public publisher-channel posts are attributed and remain unverified/);assert.match(html,/Social posts are unverified statements/);
});

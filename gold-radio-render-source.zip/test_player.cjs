'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');

// Execute the shipped inline player with deterministic network and media events.
const html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8');
const script=html.split('<script>')[1].split('</script>')[0];
const instrumented=script.replace(/\}\)\(\);\s*$/,`globalThis.player={sync,poll,render,startMusic,onAir,manifestFresh,media,waitStatus,
 seed:value=>{manifest=value;manifestReceivedAt=performance.now();offset=value.serverTime-Date.now();},
 setWanted:value=>{wanted=value;},
 state:()=>({language,manifest,currentId,epoch,channelEpoch,pollJob,playbackJob,manifestReceivedAt,cacheSize:cache.size,musicSince})};})();`);

function deferred(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return{promise,resolve,reject};}
async function flush(){for(let i=0;i<20;i++)await Promise.resolve();}
function element(id=''){
 const listeners=new Map();
 return{id,textContent:'',hidden:false,dir:'',value:id==='volume'?'.9':'ar',max:1,children:[],style:{},options:[],
 classList:{toggle(){}},append(...items){this.children.push(...items)},replaceChildren(){this.children=[]},
 addEventListener(type,fn,options={}){if(!listeners.has(type))listeners.set(type,new Map());listeners.get(type).set(fn,options)},
 removeEventListener(type,fn){listeners.get(type)?.delete(fn)},
 listeners(type){return[...(listeners.get(type)?.keys()||[])]},
 dispatch(type){for(const[fn,options]of[...(listeners.get(type)||[])]){if(options.once)listeners.get(type).delete(fn);fn({type,target:this});}this['on'+type]?.({type,target:this});},
 removeAttribute(name){delete this[name]}};
}
function harness(){
 let perf=0,wall=Date.UTC(2026,9,23,12),counter=0,objectCounter=0;
 const timers=new Map(),requests=[],plays=[],revoked=[],nodes=new Map();
 const audio=element('audio');Object.assign(audio,{paused:true,ended:false,readyState:0,currentTime:0,currentSrc:'',nextPlay:null,
 play(){plays.push({src:this.src,volume:this.volume,at:perf});this.paused=false;this.ended=false;const result=this.nextPlay;this.nextPlay=null;return result?.promise||Promise.resolve();},
 pause(){this.paused=true},load(){this.readyState=0;this.currentSrc='';this.ended=false},
 metadata(url=this.src){this.currentSrc=url;this.readyState=2;this.dispatch('loadedmetadata')},
 finish(){this.paused=true;this.ended=true;this.dispatch('ended')}});
 let audioSource='';Object.defineProperty(audio,'src',{configurable:true,get(){return audioSource},set(value){audioSource=value;this.readyState=0;this.currentSrc='';this.ended=false;}});
 audio.removeAttribute=name=>{if(name==='src')audio.src='';};nodes.set('audio',audio);
 const node=id=>{if(!nodes.has(id))nodes.set(id,element(id));return nodes.get(id)};
 node('language').options=[{value:'ar'},{value:'en'}];
 class LocalDate extends Date{constructor(...values){super(...(values.length?values:[wall]));}static now(){return wall;}}
 class LocalURL extends URL{static createObjectURL(){return 'blob:player-'+(++objectCounter)}static revokeObjectURL(value){revoked.push(value)}}
 const context={console,document:{getElementById:node,createElement:element},Date:LocalDate,Math,Number,String,Array,Map,Set,Promise,URL:LocalURL,Error,AbortController,
 performance:{now:()=>perf},setInterval(){return ++counter;},setTimeout(fn,delay){const key=++counter;timers.set(key,{fn,at:perf+delay});return key;},clearTimeout(key){timers.delete(key)},
 fetch(url,options){const d=deferred();const request={url,options,...d};requests.push(request);return d.promise;}};
 vm.runInNewContext(instrumented,context);
 function advance(ms){const target=perf+ms;while(true){let next;for(const[key,value]of timers)if(value.at<=target&&(!next||value.at<next.value.at))next={key,value};if(!next)break;const delta=next.value.at-perf;perf=next.value.at;wall+=delta;timers.delete(next.key);next.value.fn();}wall+=target-perf;perf=target;}
 const programme=(queue=[],extra={})=>({language:node('language').value,languages:['ar','en'],queue,recent:[],status:'waiting',serverTime:wall,feedsReached:10,feedCount:10,freshStories:0,unreadFreshStories:0,...extra});
 const clip=(id='a',lang=node('language').value,extra={})=>({id:id.repeat(32),language:lang,kind:'news',audioUrl:'/audio/'+id.repeat(32)+'.wav',headline:'A public report',source:'Publisher',sourceUrl:'https://example.org/news',speechText:lang==='ar'?'هذا نص الخبر.':'This is the spoken report.',startsAt:wall-1000,endsAt:wall+40000,publishedAt:wall-30000,firstSeenAt:wall-20000,...extra});
 const response=value=>({ok:true,json:async()=>value});
 const wave=()=>({ok:true,headers:{get:name=>name==='content-type'?'audio/wav':name==='content-length'?'100':null},blob:async()=>({size:100})});
 const requestFor=url=>requests.findLast(r=>r.url===url);
 const acceptInitial=async()=>{requests[0].resolve(response(programme()));await flush();};
 const changeLanguage=value=>{node('language').value=value;node('language').onchange();};
 return{player:context.player,audio,node,requests,plays,revoked,timers,advance,programme,clip,response,wave,requestFor,acceptInitial,changeLanguage,now:()=>wall,perf:()=>perf};
}
async function prepareSpeech(h,q){h.player.seed(h.programme([q]));h.player.setWanted(true);const pending=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await pending;return h.audio.src;}

test('waiting music loops beyond eight seconds without restarting on repeated sync',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);const hang=deferred();h.audio.nextPlay=hang;
 const starting=h.player.startMusic({unlock:true});assert.equal(h.plays.length,1,'same element play is called within the gesture');assert.equal(h.audio.src,'/station-relax-v2.wav');assert.equal(h.audio.loop,true);
 h.advance(180000);await h.player.sync();await h.player.sync();assert.equal(h.audio.paused,false);assert.equal(h.plays.length,1,'one seamless bed continues across repeated checks');
 hang.resolve();await starting;assert.equal(h.audio.paused,false,'late play completion leaves the waiting music running');
 h.player.render();assert.equal(h.node('badgeText').textContent,'WAITING MUSIC');assert.match(h.node('source').textContent,/fills the wait/);assert.doesNotMatch(h.node('source').textContent,/eight|short/i);
});

test('music accepts only fixed station assets and preserves shared position',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);h.player.seed(h.programme([],{music:{audioUrl:'https://outside.example/track.mp3',durationSeconds:120}}));await h.player.startMusic();assert.equal(h.audio.src,'/station-relax-v2.wav');h.audio.metadata();assert.ok(h.audio.currentTime>=0&&h.audio.currentTime<120);
 h.node('join').onclick();assert.equal(h.audio.paused,true);assert.equal(h.audio.loop,false);assert.equal(h.player.state().currentId,'');
 h.player.seed(h.programme([],{music:{audioUrl:'/station-bed-v1.wav',durationSeconds:32}}));h.node('join').onclick();assert.equal(h.audio.src,'/station-bed-v1.wav','prior fixed station asset remains compatible');
});

for(const outcome of ['late response','late error'])test('language poll is replaced immediately; '+outcome+' cannot overwrite it',async()=>{
 const h=harness(),old=h.requests[0];h.changeLanguage('en');assert.equal(old.options.signal.aborted,true);const current=h.requestFor('/radio.json?language=en');assert.ok(current,'English request starts without waiting for Arabic');
 current.resolve(h.response(h.programme([],{production:{preparing:true,kind:'market',queuedSeconds:0}})));await flush();assert.equal(h.player.state().manifest.language,'en');const status=h.node('status').textContent;
 if(outcome==='late response')old.resolve(h.response(h.programme([],{language:'ar'})));else old.reject(Error('old network error'));await flush();assert.equal(h.player.state().manifest.language,'en');assert.equal(h.node('status').textContent,status);assert.equal(h.player.state().pollJob,null);
});

test('language switch aborts old audio and old job cannot release the new metadata lock',async()=>{
 const h=harness();await h.acceptInitial();const arabic=h.clip('a','ar');h.player.seed(h.programme([arabic]));h.player.setWanted(true);const oldJob=h.player.sync();const oldAudio=h.requestFor(arabic.audioUrl);
 h.changeLanguage('en');assert.equal(oldAudio.options.signal.aborted,true);
 const english=h.clip('b','en');h.requestFor('/radio.json?language=en').resolve(h.response(h.programme([english])));await flush();h.requestFor(english.audioUrl).resolve(h.wave());await flush();const target=h.audio.src;assert.equal(h.player.state().playbackJob.id,english.id);
 oldAudio.resolve(h.wave());await oldJob;await flush();assert.equal(h.player.state().playbackJob.id,english.id,'old finally cannot release the newer job');assert.equal(h.audio.src,target);
 h.audio.metadata(target);await flush();assert.equal(h.player.state().currentId,english.id);assert.equal(h.player.state().language,'en');assert.equal(h.plays.at(-1).src,target);
});

test('cancelled metadata listeners are removed and stale events cannot complete new speech',async()=>{
 const h=harness();await h.acceptInitial();const ar=h.clip('a','ar');h.player.seed(h.programme([ar]));h.player.setWanted(true);const first=h.player.sync();h.requestFor(ar.audioUrl).resolve(h.wave());await flush();const oldListeners=h.audio.listeners('loadedmetadata');assert.ok(oldListeners.length);
 h.advance(500);h.changeLanguage('en');await first;const en=h.clip('b','en');h.requestFor('/radio.json?language=en').resolve(h.response(h.programme([en])));await flush();h.requestFor(en.audioUrl).resolve(h.wave());await flush();const newUrl=h.audio.src;
 for(const listener of oldListeners)listener({type:'loadedmetadata',target:h.audio});h.audio.dispatch('loadedmetadata');await flush();assert.equal(h.player.state().playbackJob.id,en.id,'an event before new-source metadata is ready must be ignored');
 h.audio.metadata(newUrl);await flush();assert.equal(h.player.state().playbackJob,null);assert.equal(h.player.state().currentId,en.id);assert.equal(h.audio.listeners('loadedmetadata').length,0);
});

test('metadata timeout removes listeners and automatically retries after bounded backoff',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();h.player.seed(h.programme([q]));h.player.setWanted(true);const first=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();
 h.advance(10000);await first;assert.equal(h.player.state().playbackJob,null);assert.equal(h.player.state().currentId,'music');assert.equal(h.audio.paused,false,'waiting music resumes while speech retries');assert.equal(h.audio.listeners('loadedmetadata').length,1,'only the music cue remains');assert.match(h.node('status').textContent,/retrying/i);
 await h.player.sync();assert.equal(h.player.state().playbackJob,null,'no tight reload loop');h.advance(2000);const retry=h.player.sync();await flush();assert.equal(h.player.state().playbackJob.id,q.id);h.audio.metadata();await retry;assert.equal(h.audio.paused,false);assert.equal(h.player.state().currentId,q.id);
});

test('a stalled speech play promise times out and cannot release a newer retry',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();h.player.seed(h.programme([q]));h.player.setWanted(true);
 const first=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();const pendingPlay=deferred();h.audio.nextPlay=pendingPlay;h.audio.metadata();await flush();
 h.advance(5000);await first;assert.equal(h.player.state().playbackJob,null);assert.equal(h.player.state().currentId,'music');assert.equal(h.audio.paused,false,'waiting music covers speech play retry');assert.match(h.node('status').textContent,/retrying/);
 h.advance(2000);const retry=h.player.sync();await flush();assert.equal(h.player.state().playbackJob.id,q.id);
 pendingPlay.resolve();await flush();assert.equal(h.player.state().playbackJob.id,q.id,'old play completion must not release the new metadata job');h.audio.metadata();await retry;assert.equal(h.audio.paused,false);
});

test('ready speech immediately replaces waiting music on the same element',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);await h.player.startMusic();h.advance(30000);const musicSource=h.audio.src;
 const q=h.clip();h.player.seed(h.programme([q]));const ready=h.player.sync();assert.equal(h.audio.src,musicSource,'music continues while the speech file downloads');assert.equal(h.audio.paused,false);
 h.requestFor(q.audioUrl).resolve(h.wave());await flush();assert.notEqual(h.audio.src,musicSource);assert.equal(h.audio.loop,false);assert.equal(h.audio.paused,true,'same element stops music before loading speech');
 h.audio.metadata();await ready;assert.equal(h.player.state().currentId,q.id);assert.equal(h.audio.paused,false);assert.equal(h.audio.volume,.9);assert.equal(h.plays.filter(x=>x.src.startsWith('blob:')).length,1);
 await h.player.startMusic();assert.equal(h.player.state().currentId,q.id,'a stray gap request cannot interrupt speech');
 h.audio.finish();await flush();assert.equal(h.player.state().currentId,'music');assert.equal(h.audio.loop,true);assert.equal(h.audio.paused,false);
 h.node('join').onclick();h.advance(60000);await h.player.sync();assert.equal(h.audio.paused,true,'Pause stops both music and speech until a new gesture');assert.equal(h.audio.loop,false);
});

test('old programme cannot start queued speech after an outage; a fresh response recovers',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{startsAt:h.now()+20000,endsAt:h.now()+40000});h.player.seed(h.programme([q]));h.player.setWanted(true);h.advance(21000);await h.player.sync();assert.equal(h.player.onAir(),null);assert.equal(h.requestFor(q.audioUrl),undefined,'do not start a future clip from a stale manifest');
 h.player.render();assert.match(h.node('checked').textContent,/Connection retrying/);
 const polling=h.player.poll();h.requestFor('/radio.json?language=ar').resolve(h.response(h.programme([q])));await polling;await flush();assert.ok(h.requestFor(q.audioUrl));h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await flush();assert.equal(h.player.state().currentId,q.id);assert.ok(h.audio.currentTime>=1,'join at the current shared point, not its beginning');
});

test('already playing speech may finish during outage but cannot replay from the stale programme',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();await prepareSpeech(h,q);const wavePlays=h.plays.length;h.advance(16000);await h.player.sync();assert.equal(h.audio.paused,false);assert.equal(h.player.onAir().id,q.id);
 h.audio.finish();await flush();assert.equal(h.player.onAir(),null);await h.player.sync();assert.equal(h.plays.filter(x=>x.src.startsWith('blob:')).length,1);assert.ok(h.plays.length>=wavePlays);
});

for(const delta of [-1000,0])test('a '+(delta===0?'repeated':'regressing')+' server clock cannot refresh an old programme',async()=>{
 const h=harness();await h.acceptInitial();const accepted=h.player.state().manifest.serverTime;h.advance(4000);
 const pending=h.player.poll();h.requestFor('/radio.json?language=ar').resolve(h.response(h.programme([],{serverTime:accepted+delta})));await pending;
 assert.equal(h.player.state().manifest.serverTime,accepted);assert.equal(h.player.state().manifestReceivedAt,0);assert.match(h.node('status').textContent,/connection interrupted/i);
});

test('market and discussion labels show transcript and grounded source clocks',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{kind:'market',caption:'Gold API collected 12:00; separate from chart.',speechText:'رصد سعر الذهب.'});h.player.seed(h.programme([q],{lastCollectionAt:h.now()-3000,market:{status:'stale',sourceAt:h.now()-120000},production:{preparing:true,kind:'market',queuedSeconds:13}}));h.player.render();
 assert.equal(h.node('badgeText').textContent,'GOLD UPDATE');assert.equal(h.node('source').textContent,q.caption);assert.equal(h.node('transcript').textContent,q.speechText);assert.equal(h.node('spoken').hidden,false);assert.match(h.node('freshness').textContent,/120 sec old · stale/);assert.match(h.node('freshness').textContent,/13 sec of speech queued/);
 q.kind='discussion';q.caption='Conditional discussion based on the published news window.';h.player.render();assert.equal(h.node('badgeText').textContent,'DISCUSSION');assert.equal(h.node('source').textContent,q.caption);assert.equal(h.node('source').children.length,0);
});

for(const language of ['ar','en'])test(language+' complete spoken news accepts a 90-second clip and retains the final sentence',async()=>{
 const h=harness();await h.acceptInitial();if(language==='en')h.changeLanguage('en');else h.advance(1);
 const transcript=language==='ar'?'أعلنت الجهة الخبر كاملاً. هذه الجملة الأخيرة تشرح النتيجة المعلنة.':'The publisher reported the complete development. This final sentence explains the reported outcome.';
 const q=h.clip('c',language,{endsAt:h.now()+89000,speechText:transcript});
 const invalid=h.clip('d',language,{endsAt:h.now()+89001});
 const pending=language==='en'?null:h.player.poll();
 h.requestFor('/radio.json?language='+language).resolve(h.response(h.programme([q,invalid])));if(pending)await pending;await flush();
 assert.equal(h.player.state().manifest.queue.length,1,'the 90-second bound is inclusive and an overlong clip is rejected');
 assert.equal(h.player.state().manifest.queue[0].id,q.id);h.player.render();assert.equal(h.node('transcript').textContent,transcript);
 assert.equal(h.node('transcript').dir,language==='ar'?'rtl':'ltr');assert.equal(h.node('duration').textContent,'1:30');
});

test('observed gold briefing has its own label and preserves its grounded caption and transcript',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('e','ar',{kind:'analysis',source:'Gold Pulse',caption:'Gold API observed 12:00 UTC; no causal claim.',speechText:'رصد الذهب عند الساعة الثانية عشرة. الربط بالأخبار مشروط ولا يثبت السببية.'});
 h.player.seed(h.programme([q]));h.player.render();assert.equal(h.node('badgeText').textContent,'MARKET ANALYSIS');assert.equal(h.node('voice').textContent,'ARABIC · GOLD BRIEFING');
 assert.equal(h.node('source').textContent,q.caption);assert.equal(h.node('transcript').textContent,q.speechText);assert.match(h.node('schedule').children[0].children[1].textContent,/Gold briefing/);
 h.player.seed(h.programme([],{production:{preparing:true,kind:'analysis',queuedSeconds:0}}));assert.match(h.player.waitStatus(),/Preparing the next gold briefing/);
});

test('cloud news status shows the selective quota from the manifest and independent hosting only when declared',async()=>{
 const h=harness();await h.acceptInitial();h.player.seed(h.programme([],{mode:'cloud-news',dependencies:{pcRequired:false},freshStories:20,newsSelection:{fraction:.4,freshCount:20,relevantCount:10,selectedCount:4,unreadSelectedCount:3,method:'grounded relevance ranking'}}));h.player.render();
 assert.match(h.node('hosting').textContent,/computer switched off/);
 assert.equal(h.node('selection').textContent,'Top 40% of relevant fresh reports · 4 selected from 10 relevant · 3 awaiting speech');
 assert.equal(h.node('collection').textContent,'10/10 publisher feeds reached · 20 fresh headlines');
 assert.doesNotMatch(h.node('selection').textContent,/grounded relevance ranking/,'implementation method stays out of the listening UI');
 h.player.seed(h.programme([],{newsSelection:{fraction:.25,freshCount:20,relevantCount:12,selectedCount:3,unreadSelectedCount:1}}));h.player.render();
 assert.equal(h.node('selection').textContent,'Top 25% of relevant fresh reports · 3 selected from 12 relevant · 1 awaiting speech','quota is read from the current station manifest');
 h.player.seed(h.programme([],{mode:'cloud-news',dependencies:{pcRequired:true},newsSelection:{fraction:.4,freshCount:20,relevantCount:10,selectedCount:4,unreadSelectedCount:-2}}));h.player.render();
 assert.doesNotMatch(h.node('hosting').textContent,/computer switched off/);
 assert.equal(h.node('selection').textContent,'Selecting the most relevant fresh reports…');
});


test('earlier reports keep their publication time and never display the live-news label',async()=>{
 const h=harness();await h.acceptInitial();const published=h.now()-1800000;
 const q=h.clip('a','ar',{recency:'earlier',publishedAt:published,firstSeenAt:h.now()-1200000,headline:'An unplayed report from earlier this hour',speechText:'تقرير سابق نُشر في الساعة الحادية عشرة والنصف.'});
 h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'EARLIER REPORT');assert.equal(h.node('voice').textContent,'ARABIC · RECENT NEWS ROUNDUP');
 assert.match(h.node('source').textContent,/Publisher · Earlier report · Published/);assert.ok(h.node('source').textContent.includes(new Date(published).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'})),'caption preserves the actual publisher clock in the browser timezone');assert.match(h.node('source').textContent,/Collected/);
 assert.equal(h.node('transcript').textContent,q.speechText);assert.match(h.node('schedule').children[0].children[1].textContent,/Earlier report/);
 q.recency='fresh';q.publishedAt=h.now()-30000;h.player.render();assert.equal(h.node('badgeText').textContent,'LIVE NEWS');assert.doesNotMatch(h.node('source').textContent,/Earlier report/);
});

test('discovery speech labels the aggregator clock without claiming live publisher news',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 const q=h.clip('b','en',{sourceKind:'publisher-aggregator',clockBasis:'aggregator-rss-publication',publishedAt:h.now()-30000});
 h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'DISCOVERED REPORT');
 assert.match(h.node('source').textContent,/News index time/);
 assert.match(h.node('source').textContent,/Original publication time unverified/);
 assert.doesNotMatch(h.node('source').textContent,/Published/);
 h.changeLanguage('ar');q.language='ar';h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'عنوان من فهرس الأخبار');
 assert.match(h.node('source').textContent,/وقت النشر الأصلي غير متحقق منه/);
});

test('validated earlier-news backlog prepares speech and adds one concise waiting count',async()=>{
 const h=harness();await h.acceptInitial();const earlier={windowSeconds:3600,minimumAgeSeconds:601,freshCount:12,relevantCount:8,selectedCount:4,unreadSelectedCount:4};
 h.player.seed(h.programme([],{earlierNewsSelection:earlier,newsSelection:{fraction:.4,freshCount:0,relevantCount:0,selectedCount:0,unreadSelectedCount:0}}));h.player.render();
 assert.equal(h.node('badgeText').textContent,'PREPARING SPEECH');assert.match(h.node('schedule').children[0].textContent,/being prepared/);
 assert.equal(h.node('selection').textContent,'Top 40% of relevant fresh reports · 0 selected from 0 relevant · 0 awaiting speech · 4 earlier reports awaiting speech');
 for(const invalid of [{...earlier,unreadSelectedCount:-1},{...earlier,windowSeconds:7201},{...earlier,minimumAgeSeconds:0}]){
  h.player.seed(h.programme([],{earlierNewsSelection:invalid}));h.player.render();assert.equal(h.node('badgeText').textContent,'WAITING FOR UPDATE');assert.doesNotMatch(h.node('selection').textContent,/earlier reports/);
 }
 assert.match(html,/The latest ten minutes come first/);assert.match(html,/original publication time/);
});

test('fresh public social speech keeps its attribution and author clock separate from collection',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{social:true,platform:'Telegram',source:'Public publisher channel',sourceUrl:'https://t.me/example/12',publishedAt:h.now()-120000,firstSeenAt:h.now()-10000,speechText:'منشور عام غير متحقق منه، من قناة إخبارية.'});
 h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'SOCIAL POST');assert.equal(h.node('voice').textContent,'ARABIC · PUBLIC SOCIAL DESK');
 assert.match(h.node('source').textContent,/Public publisher channel · Public post · Author-reported time/);assert.match(h.node('source').textContent,/Collected/);assert.doesNotMatch(h.node('source').textContent,/Published/);
 assert.equal(h.node('sourceLink').textContent,'Open public post ↗');assert.equal(h.node('sourceLink').href,q.sourceUrl);assert.equal(h.node('transcript').textContent,q.speechText);
 assert.match(h.node('schedule').children[0].children[1].textContent,/Public social post/);assert.doesNotMatch(h.node('badgeText').textContent,/LIVE|BREAKING|VERIFIED/);
});

test('earlier public social posts cannot appear as live news and render post text safely',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');const q=h.clip('b','en',{sourceKind:'social',platform:'Bluesky',recency:'earlier',publishedAt:h.now()-1800000,headline:'<img src=x onerror=alert(1)> Public post',source:'<b>Publisher</b>',speechText:'A public social post, not independently verified.'});
 h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,'EARLIER SOCIAL POST');assert.equal(h.node('voice').textContent,'ENGLISH · PUBLIC SOCIAL DESK');assert.match(h.node('source').textContent,/Public post · Earlier post · Author-reported time/);
 assert.equal(h.node('headline').textContent,q.headline);assert.equal(h.node('headline').children.length,0);assert.equal(h.node('source').children.length,0);assert.match(h.node('schedule').children[0].children[1].textContent,/Earlier public post/);assert.doesNotMatch(h.node('badgeText').textContent,/LIVE NEWS/);
});

test('cloud social diagnostics show bounded source totals without changing publisher feed counts',async()=>{
 const h=harness();await h.acceptInitial();h.player.seed(h.programme([],{socialSources:{sourceCount:8,readySources:6},freshStories:15}));h.player.render();
 assert.equal(h.node('collection').textContent,'10/10 publisher feeds reached · 6/8 public social sources reached · 15 fresh headlines');
 for(const invalid of [{sourceCount:8,readySources:9},{sourceCount:8,readySources:-1},{sourceCount:8,readySources:'6'},{sourceCount:0,readySources:0}]){
  h.player.seed(h.programme([],{socialSources:invalid}));h.player.render();assert.doesNotMatch(h.node('collection').textContent,/public social sources/);
 }
 assert.match(html,/Public publisher-channel posts are attributed and remain unverified/);assert.match(html,/Social posts are unverified statements/);
});

test('economic discovery searches have separate validated totals and static policy has no old quota',async()=>{
 const h=harness();await h.acceptInitial();h.player.seed(h.programme([],{feedsReached:24,feedCount:25,socialSources:{sourceCount:9,readySources:8},economicFeeds:{sourceCount:6,readySources:4},freshStories:15}));h.player.render();
 assert.equal(h.node('collection').textContent,'24/25 publisher feeds reached · 8/9 public social sources reached · 4/6 economic discovery searches reached · 15 fresh headlines');
 for(const invalid of [{sourceCount:6,readySources:7},{sourceCount:6,readySources:-1},{sourceCount:6,readySources:'4'},{sourceCount:0,readySources:0},{sourceCount:101,readySources:1}]){
  h.player.seed(h.programme([],{economicFeeds:invalid}));h.player.render();assert.doesNotMatch(h.node('collection').textContent,/economic discovery/);assert.match(h.node('collection').textContent,/10\/10 publisher feeds reached/);
 }
 assert.match(html,/selects all eligible gold, economic, oil and major world reports, prioritizing the newest items/);assert.doesNotMatch(html,/40%/);
});

function observedMarket(now,extra={}){
 const sourceAt=now-10000;
 return{status:'ready',provider:'Gold API',price:4123.456789,priceText:'4123.456789',sourceAt,receivedAt:now-5000,
  changes:{'1':{usd:1.25,usdText:'1.25',direction:'up',fromAt:sourceAt-60000,toAt:sourceAt},'5':{usd:-2.5,usdText:'2.50',direction:'down',fromAt:sourceAt-315000,toAt:sourceAt}},...extra};
}

test('gold reference strip presents cents while retaining raw provider precision and observed matched moves',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');const market=observedMarket(h.now());h.player.seed(h.programme([],{market}));h.player.render();
 assert.equal(h.node('marketPrice').textContent,'$4,123.46');assert.equal(h.node('marketStatus').textContent,'RECENT OBSERVATION');assert.equal(market.priceText,'4123.456789');assert.equal(market.price,4123.456789,'presentation rounding never changes source or model data');
 assert.equal(h.node('marketMove1').textContent,'↗ +$1.25');assert.equal(h.node('marketMove5').textContent,'↘ −$2.50');
 assert.equal(h.node('marketMove10').textContent,'—');assert.equal(h.node('marketMoveLabel10').textContent,'No matched samples','missing history never becomes a zero-dollar move');
 assert.match(h.node('marketClock').textContent,/Source .*10 sec ago/);assert.match(h.node('marketNote').textContent,/Independent of the TradingView \/ OANDA chart/);
 assert.equal(h.node('marketPrice').children.length,0);assert.match(html,/<section class="market-strip" id="marketStrip" aria-label="Gold API reference quote">/);
});

test('reference price and all moves disappear when its own source clock or station clock expires',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');const m=observedMarket(h.now(),{sourceAt:h.now()-90000,receivedAt:h.now()-1000,changes:{}});
 h.player.seed(h.programme([],{market:m}));h.player.render();assert.equal(h.node('marketStatus').textContent,'RECENT OBSERVATION','the 90-second source bound is inclusive');
 h.advance(1);h.player.render();assert.equal(h.node('marketPrice').textContent,'—');assert.equal(h.node('marketStatus').textContent,'STALE QUOTE');
 h.player.seed(h.programme([],{market:observedMarket(h.now())}));h.player.render();assert.equal(h.node('marketMove1').textContent,'↗ +$1.25');
 h.advance(15001);h.player.render();assert.equal(h.node('marketPrice').textContent,'—');assert.equal(h.node('marketMove1').textContent,'—');assert.equal(h.node('marketStatus').textContent,'STALE QUOTE','a stale programme cannot retain apparently current quote numbers');
 h.player.seed(h.programme([],{market:observedMarket(h.now(),{status:'stale'})}));h.player.render();assert.equal(h.node('marketPrice').textContent,'—');
});

test('malformed quotes and inconsistent delta clocks cannot appear as valid observations',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 for(const invalid of [{price:-1},{price:Infinity},{price:'4123.45'},{sourceAt:h.now()+1},{receivedAt:h.now()+1},{status:'unavailable'}]){
  h.player.seed(h.programme([],{market:observedMarket(h.now(),invalid)}));h.player.render();assert.equal(h.node('marketPrice').textContent,'—');assert.equal(h.node('marketStatus').textContent,'QUOTE UNAVAILABLE');assert.equal(h.node('marketMove1').textContent,'—');
 }
 const m=observedMarket(h.now());m.changes['1'].direction='down';m.changes['5'].toAt=m.sourceAt-1;
 h.player.seed(h.programme([],{market:m}));h.player.render();assert.equal(h.node('marketPrice').textContent,'$4,123.46');assert.equal(h.node('marketMove1').textContent,'—');assert.equal(h.node('marketMove5').textContent,'—');
 m.priceText='<img src=x onerror=alert(1)>';h.player.render();assert.equal(h.node('marketPrice').textContent,'$4,123.46');assert.equal(h.node('marketPrice').children.length,0,'untrusted formatting text is never markup');
});

test('price and curve cadence shows actual due clocks separately from source freshness and target intervals',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');const priceDue=h.now()+120000,curveDue=h.now()-65000;
 h.player.seed(h.programme([],{market:observedMarket(h.now()),programmeMix:{marketCadenceSeconds:600,analysisIntervalSeconds:240,priceChangeCooldownSeconds:15},marketSchedule:{priceDueAt:priceDue,analysisDueAt:curveDue,lastPriceAt:h.now()-480000,lastAnalysisAt:h.now()-305000}}));h.player.render();
 assert.match(h.node('marketCadence').textContent,/Broadcast targets: price ≤10 min · curve 4 min/);assert.ok(h.node('marketCadence').textContent.includes(new Date(priceDue).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'})));assert.match(h.node('marketCadence').textContent,/curve due overdue 1:05/);
 assert.doesNotMatch(h.node('marketCadence').textContent,/ML|forecast|poll|every 15/);assert.match(h.node('marketClock').textContent,/10 sec ago/);
 h.player.seed(h.programme([],{market:observedMarket(h.now(),{status:'stale'}),programmeMix:{marketCadenceSeconds:600,analysisIntervalSeconds:240},marketSchedule:{priceDueAt:null,analysisDueAt:null}}));h.player.render();
 assert.match(h.node('marketCadence').textContent,/price due not set · curve due not set · waiting for a fresh reference quote/);assert.equal(h.node('marketPrice').textContent,'—');
});

test('invalid or disconnected schedules never present an invented next broadcast',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 for(const mix of [{marketCadenceSeconds:601,analysisIntervalSeconds:240},{marketCadenceSeconds:600,analysisIntervalSeconds:NaN},{marketCadenceSeconds:0,analysisIntervalSeconds:240}]){
  h.player.seed(h.programme([],{programmeMix:mix,marketSchedule:{priceDueAt:h.now()+60000,analysisDueAt:h.now()+60000}}));h.player.render();assert.equal(h.node('marketCadence').textContent,'Waiting for the price and curve broadcast schedule.');
 }
 h.player.seed(h.programme([],{market:observedMarket(h.now()),programmeMix:{marketCadenceSeconds:600,analysisIntervalSeconds:240},marketSchedule:{priceDueAt:h.now()+60000,analysisDueAt:h.now()+60000}}));h.advance(15001);h.player.render();assert.equal(h.node('marketCadence').textContent,'Waiting for the price and curve broadcast schedule.');
});

test('complete transcript remains readable in a native disclosure after playback controls',async()=>{
 const h=harness();await h.acceptInitial();const last='هذه الجملة الأخيرة تكمل الخبر بكل تفاصيله.';
 const q=h.clip('a','ar',{headline:'عنوان كامل للخبر الطويل',speechText:'أعزائي المستمعين. '+last});h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('spoken').hidden,false);assert.equal(h.node('transcript').textContent,q.speechText);assert.ok(h.node('transcript').textContent.endsWith(last));assert.equal(h.node('transcriptHeadline').textContent,q.headline);assert.equal(h.node('transcriptHeadline').hidden,false);
 assert.equal(h.node('transcriptLabel').textContent,'اقرأ النص الصوتي كاملاً');
 assert.match(html,/<details class="spoken" id="spoken" hidden><summary id="transcriptLabel">/);assert.ok(html.indexOf('id="join"')<html.indexOf('id="spoken"'),'long text follows the join control');
 h.changeLanguage('en');h.player.seed(h.programme([h.clip('b','en',{speechText:'Complete English bulletin, including the final sentence.'})]));h.player.render();assert.equal(h.node('transcriptLabel').textContent,'Read the full spoken update');assert.equal(h.node('transcript').dir,'ltr');
});

function playlistMusic(now,extra={}){return{audioUrl:'/music/calm-piano.mp3',durationSeconds:180,epochMs:0,gain:.45,trackId:'calm-piano',title:'Calm piano',artist:'Public creator',license:'CC0',sourceUrl:'https://example.org/music-source',positionSeconds:41,asOfServerTime:now,playing:true,...extra};}

test('shared playlist pauses its position for speech and resumes the same track at that position',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);h.player.seed(h.programme([],{music:playlistMusic(h.now())}));
 await h.player.startMusic();h.audio.metadata();assert.equal(h.audio.currentTime,41);assert.equal(h.audio.loop,false);
 h.advance(2000);await h.player.sync();assert.equal(h.audio.currentTime,43);assert.equal(h.plays.length,1,'same-track synchronization seeks without restarting the file');
 const q=h.clip('a','ar',{startsAt:h.now(),endsAt:h.now()+10000});h.player.seed(h.programme([q],{music:playlistMusic(h.now(),{positionSeconds:43,playing:false})}));
 const spoken=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await spoken;assert.ok(h.audio.src.startsWith('blob:'));assert.equal(h.audio.loop,false);
 h.advance(10000);h.player.seed(h.programme([],{music:playlistMusic(h.now(),{positionSeconds:43})}));h.audio.finish();await flush();h.audio.metadata();
 assert.equal(h.audio.src,'/music/calm-piano.mp3');assert.equal(h.audio.currentTime,43,'spoken seconds are not added to the music clock');assert.equal(h.audio.loop,false);
 await h.player.sync();await h.player.sync();assert.equal(h.plays.filter(x=>x.src==='/music/calm-piano.mp3').length,2,'one start before speech and one resume afterwards');
});

test('playlist music streams directly and late music events cannot interrupt ready news',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);h.player.seed(h.programme([],{music:playlistMusic(h.now())}));
 const slowMusicPlay=deferred();h.audio.nextPlay=slowMusicPlay;const musicStarted=h.player.startMusic();const musicUrl=h.audio.src,oldCues=h.audio.listeners('loadedmetadata');
 assert.equal(musicUrl,'/music/calm-piano.mp3');assert.equal(h.requests.filter(x=>x.url.startsWith('/music/')).length,0,'native media loading uses HTTP Range instead of a whole-file fetch/blob');assert.equal(h.player.state().cacheSize,0);
 const q=h.clip('a','ar');h.player.seed(h.programme([q],{music:playlistMusic(h.now(),{playing:false})}));const spoken=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();const speechUrl=h.audio.src;
 assert.ok(speechUrl.startsWith('blob:'));assert.equal(h.player.state().cacheSize,1,'only the complete speech WAV enters the blob cache');
 h.audio.metadata(musicUrl);for(const cue of oldCues)cue();await flush();assert.equal(h.player.state().playbackJob.id,q.id,'music metadata cannot release the new speech lock');
 h.audio.metadata(speechUrl);await spoken;slowMusicPlay.reject(Error('The previous music load was interrupted'));await assert.rejects(musicStarted,/interrupted/);
 assert.equal(h.audio.src,speechUrl);assert.equal(h.audio.paused,false);assert.equal(h.player.state().currentId,q.id,'a late music play rejection cannot pause the news');assert.equal(h.player.state().playbackJob,null);
});

test('a completed playlist track never loops while waiting for the next shuffled track manifest',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);h.player.seed(h.programme([],{music:playlistMusic(h.now(),{durationSeconds:60,positionSeconds:59})}));
 await h.player.startMusic();h.audio.metadata();h.audio.finish();await flush();await h.player.sync();assert.equal(h.audio.paused,true);assert.equal(h.plays.length,1,'do not replay the ended track from its old manifest');
 h.advance(4000);h.player.seed(h.programme([],{music:playlistMusic(h.now(),{audioUrl:'/music/evening.wav',trackId:'evening',title:'Evening',positionSeconds:0,artist:'<b>Creator</b>'})}));
 await h.player.sync();h.audio.metadata();h.player.render();assert.equal(h.audio.src,'/music/evening.wav');assert.equal(h.audio.currentTime,0);assert.equal(h.audio.loop,false);assert.equal(h.plays.length,2);
 assert.equal(h.node('headline').textContent,'Evening');assert.match(h.node('source').textContent,/<b>Creator<\/b> · CC0/);assert.equal(h.node('source').children.length,0);assert.equal(h.node('sourceLink').href,'https://example.org/music-source');
 h.advance(2000);await h.player.sync();assert.equal(h.plays.length,2,'the next track also keeps playing through repeated checks');
});

test('playlist audio accepts only a bounded matching local route and never a remote music URL',async()=>{
 for(const invalid of [{audioUrl:'https://outside.example/music.mp3'},{audioUrl:'/music/../private.wav'},{audioUrl:'/music/different.mp3'},{durationSeconds:1801},{positionSeconds:-1}]){
  const h=harness();await h.acceptInitial();h.player.setWanted(true);h.player.seed(h.programme([],{music:playlistMusic(h.now(),invalid)}));await h.player.startMusic();
  assert.equal(h.audio.src,'/station-relax-v2.wav');assert.equal(h.audio.loop,true,'the known original asset remains a safe legacy fallback');
 }
});

test('language switching cancels an old music cue before applying the new channel music position',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);h.player.seed(h.programme([],{music:playlistMusic(h.now(),{positionSeconds:80})}));await h.player.startMusic();const oldCues=h.audio.listeners('loadedmetadata');
 h.changeLanguage('en');h.requestFor('/radio.json?language=en').resolve(h.response(h.programme([],{music:playlistMusic(h.now(),{trackId:'english-calm',audioUrl:'/music/english-calm.wav',positionSeconds:17})})));await flush();
 for(const cue of oldCues)cue();h.audio.metadata();await flush();assert.equal(h.player.state().language,'en');assert.equal(h.audio.src,'/music/english-calm.wav');assert.equal(h.audio.currentTime,17);assert.equal(h.audio.loop,false);
});

for(const language of ['ar','en'])test(language+' educational podcast is distinct from current news and keeps the complete transcript',async()=>{
 const h=harness();await h.acceptInitial();if(language==='en')h.changeLanguage('en');
 const speechText=language==='ar'?'هذا بودكاست تعليمي عن الذهب. هذه الجملة الأخيرة تكمل الشرح.':'This educational gold podcast explains a concept. Its final sentence completes the explanation.';
 const q=h.clip('f',language,{kind:'podcast',source:'Gold Pulse',caption:'Educational discussion; not a current news report.',speechText});h.player.seed(h.programme([q]));h.player.render();
 assert.equal(h.node('badgeText').textContent,language==='ar'?'بودكاست تعليمي':'EDUCATIONAL PODCAST');assert.doesNotMatch(h.node('badgeText').textContent,/LIVE NEWS|BREAKING/);assert.equal(h.node('source').textContent,q.caption);
 assert.equal(h.node('transcript').textContent,speechText);assert.equal(h.node('spoken').hidden,false);assert.match(h.node('schedule').children[0].children[1].textContent,language==='ar'?/بودكاست تعليمي/:/Educational podcast/);
 h.player.seed(h.programme([],{production:{preparing:true,kind:'podcast'}}));assert.match(h.player.waitStatus(),language==='ar'?/البودكاست التعليمي/:/educational gold podcast/);
});

test('programme targets remain separate from observed station airtime including a music overrun',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 const mix={contentTargetPercent:80,musicTargetPercent:20,observed:{windowSeconds:600,elapsedSeconds:100,speechSeconds:30,musicSeconds:70,spokenPercent:30,musicPercent:70}};
 h.player.seed(h.programme([],{programmeMix:mix}));h.player.render();assert.equal(h.node('programmeTarget').textContent,'Target: 80% speech · 20% music · news target 60% of speech when available');
 assert.equal(h.node('programmeObserved').textContent,'Observed station schedule (1:40 / 10:00): 30.0% spoken · 70.0% music');assert.doesNotMatch(h.node('programmeObserved').textContent,/80\.0% spoken/);
 h.advance(16000);h.player.render();assert.match(h.node('programmeObserved').textContent,/^Last reported station schedule/);
 for(const invalid of [{...mix.observed,elapsedSeconds:0},{...mix.observed,spokenPercent:80},{...mix.observed,musicSeconds:101},{...mix.observed,windowSeconds:NaN}]){
  h.player.seed(h.programme([],{programmeMix:{...mix,observed:invalid}}));h.player.render();assert.match(h.node('programmeObserved').textContent,/not available yet/);assert.doesNotMatch(h.node('programmeObserved').textContent,/30\.0%|80\.0%/);
 }
});

test('genuine news share is shown separately from all spoken programmes',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 const mix={contentTargetPercent:80,musicTargetPercent:20,observed:{windowSeconds:600,elapsedSeconds:100,speechSeconds:80,musicSeconds:20,spokenPercent:80,musicPercent:20,newsSeconds:50,newsShareOfSpeechPercent:62.5}};
 h.player.seed(h.programme([],{programmeMix:mix}));h.player.render();
 assert.match(h.node('programmeObserved').textContent,/News, social and report roundups: 0:50 \/ 1:20 \(62\.5% of speech\)/);
});

for(const language of ['ar','en'])test(language+' podcast turns identify the actual female host and male analyst without engine names',async()=>{
 const h=harness();await h.acceptInitial();if(language==='en')h.changeLanguage('en');
 const names=language==='ar'?['مايا','عمر']:['Maia','Omar'];
 const cast=(profile,index)=>({language,profile,speaker:names[index],gender:index?'Male':'Female',pitchShifted:false,network:true,voice:index?'actual-male-neural-engine':'actual-female-neural-engine'});
 const host=h.clip('a',language,{kind:'podcast',speaker:'Legacy label',cast:cast('host',0),endsAt:h.now()+10000,speechText:language==='ar'?'شرح مايا الكامل، مع الجملة الأخيرة.':'The complete host turn, including its final sentence.'});
 const analyst=h.clip('b',language,{kind:'podcast',cast:cast('analyst',1),startsAt:h.now()+10000,endsAt:h.now()+30000});
 h.player.seed(h.programme([host,analyst]));h.player.render();
 assert.equal(h.node('voice').textContent,language==='ar'?'مايا · صوت نسائي اصطناعي':'Maia · Female synthetic voice');assert.match(h.node('voice').className,/cast-voice/);assert.equal(h.node('transcript').textContent,host.speechText);
 assert.ok(h.node('schedule').children[1].children[1].textContent.includes(names[1]));assert.doesNotMatch(h.node('voice').textContent,/ARABIC 2|Legacy label|neural-engine/);
 h.advance(10001);h.player.render();assert.equal(h.node('voice').textContent,language==='ar'?'عمر · صوت رجالي اصطناعي':'Omar · Male synthetic voice');assert.match(h.node('voice').className,/cast-analyst/);assert.equal(h.node('voice').dir,language==='ar'?'rtl':'ltr');
});

test('unconfirmed or mismatched cast metadata cannot invent a gender and legacy speakers remain readable',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 const q=h.clip('c','en',{kind:'podcast',speaker:'Maia',cast:{language:'ar',profile:'host',speaker:'مايا',gender:'Female',pitchShifted:false}});
 h.player.seed(h.programme([q]));h.player.render();assert.equal(h.node('voice').textContent,'Maia · Synthetic voice');assert.doesNotMatch(h.node('voice').textContent,/Female|Male/);
 q.cast={language:'en',profile:'analyst',speaker:'Omar',gender:'Male',pitchShifted:true};h.player.render();assert.equal(h.node('voice').textContent,'Maia · Synthetic voice','a pitch-shift label is not confirmed male-cast evidence');
 q.speaker='<b>Maia</b>';q.cast.speaker='<img src=x>';q.cast.pitchShifted=false;h.player.render();assert.equal(h.node('voice').textContent,'ENGLISH · GOLD LEARNING PODCAST');assert.equal(h.node('voice').children.length,0);assert.equal(h.node('voice').className,'voice');
 assert.match(html,/reports published within the past hour/);assert.doesNotMatch(html,/reports from the past hour/);assert.match(html,/Licensed vocal songs and relaxing instrumentals/);
});

test('Arabic channel labels describe network news with CPU fallback without altering the spoken transcript',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{speechText:'مايا: هذا نص الخبر الكامل كما قدّمه الخادم.'});
 h.player.seed(h.programme([q]));h.player.render();assert.equal(h.node('voice').textContent,'ARABIC · NEWS DESK');assert.equal(h.node('transcript').textContent,q.speechText,'spoken-name handling belongs to the producer, not the display');
 assert.match(html,/<option value="ar" lang="ar">العربية<\/option>/);assert.doesNotMatch(html,/العربية 2|ARABIC 2|Arabic news is generated on this server/);
 assert.match(html,/Arabic news uses a server-requested network voice, with local CPU speech as a fallback/);assert.doesNotMatch(h.node('voice').textContent,/Nabra|Zariyah|Salma|Neural|native|CPU/i);
});

for(const language of ['ar','en'])test(language+' playing recorded discussion explicitly reports quiet news without counting the podcast as news',async()=>{
 const h=harness();await h.acceptInitial();if(language==='en')h.changeLanguage('en');
 const mix={contentTargetPercent:80,musicTargetPercent:20,podcastNewsPolicy:'news-priority-with-quiet-podcast-fallback',newsSupplyState:'quiet',quietPodcastFallback:true,
  observed:{windowSeconds:600,elapsedSeconds:100,speechSeconds:30,musicSeconds:70,spokenPercent:30,musicPercent:70,newsSeconds:0,newsShareOfSpeechPercent:0}};
 const q=h.clip('f',language,{kind:'podcast',caption:'Recorded gold discussion; not current news.'});h.player.seed(h.programme([q],{programmeMix:mix}));h.player.setWanted(true);
 const spoken=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await spoken;h.player.render();
 assert.equal(h.node('status').textContent,language==='ar'?'لا يوجد تقرير جديد مؤهل؛ نتابع مناقشة مسجلة عن الذهب.':'No new eligible report; continuing a recorded gold discussion.');
 assert.equal(h.node('programmeSupply').hidden,false);assert.match(h.node('programmeSupply').textContent,language==='ar'?/تُحسب منفصلة عن الأخبار/:/counted separately from news/);
 assert.match(h.node('programmeObserved').textContent,language==='ar'?/0:00 \/ 0:30 \(0\.0٪ من الكلام\)/:/0:00 \/ 0:30 \(0\.0% of speech\)/);
 assert.equal(h.node('transcript').textContent,q.speechText);assert.doesNotMatch(h.node('badgeText').textContent,/LIVE NEWS/);
 h.player.seed(h.programme([q],{programmeMix:{...mix,newsSupplyState:'available'}}));h.player.render();
 assert.doesNotMatch(h.node('status').textContent,/No new eligible|لا يوجد تقرير/);assert.match(h.node('programmeSupply').textContent,language==='ar'?/الأولوية للأخبار/:/news has priority/);
});

test('quiet supply without ready speech does not claim a new report is being prepared',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');h.player.seed(h.programme([],{freshStories:0,unreadFreshStories:0,programmeMix:{podcastNewsPolicy:'news-priority-with-quiet-podcast-fallback',newsSupplyState:'quiet'}}));h.player.render();
 assert.equal(h.node('headline').textContent,'Quiet news period; awaiting the next recorded programme');assert.equal(h.player.waitStatus(),'No new eligible report. The next recorded programme starts automatically when ready.');
 h.player.seed(h.programme([]));h.player.render();assert.equal(h.node('programmeSupply').hidden,true);assert.equal(h.node('programmeSupply').textContent,'');
 assert.match(html,/news target is 60% of speech when eligible reports are available/);assert.match(html,/Gold discussions fill quiet periods and are never counted as news/);
});

function cloudWriter(h,changes={}){return {enabled:true,mode:'cloud-llm',modelId:'gold-radio-lfm25-350m',status:'ready',
 preparing:false,lastGeneratedAt:h.now()-10000,generatedEpisodes:1,publishedTurns:0,pendingTurns:2,
 lastGenerationSeconds:12.5,lastError:null,recordedArchive:false,pcRequired:false,scriptTtlSeconds:300,...changes};}
const cloudMix={cloudLlmPodcasts:true,recordedEducationalPodcasts:false,podcastNewsPolicy:'news-priority-with-quiet-podcast-fallback',newsSupplyState:'quiet'};
function generatedDiscussion(h,language='ar',changes={}){return h.clip('e',language,{kind:'cloud-discussion',source:'Gold Pulse',
 caption:'A legacy recorded caption must not label a newly generated script.',
 programme:{mode:'cloud-llm',modelId:'gold-radio-lfm25-350m',generatedAt:h.now()-10000,contextCapturedAt:h.now()-15000,
 sourceGrounded:true,educational:false,currentNews:false,forecast:false,speakerRole:'host'},...changes});}

for(const language of ['ar','en'])test(language+' cloud discussion shows actual generation provenance, full text and distinct cast',async()=>{
 const h=harness();await h.acceptInitial();if(language==='en')h.changeLanguage('en');
 const names=language==='ar'?['مايا','عمر']:['Maia','Omar'];
 const cast=(profile,index)=>({language,profile,speaker:names[index],gender:index?'Male':'Female',pitchShifted:false});
 const host=generatedDiscussion(h,language,{speaker:'Maia',cast:cast('host',0),endsAt:h.now()+10000});
 const analyst={...host,id:'f'.repeat(32),audioUrl:'/audio/'+'f'.repeat(32)+'.wav',speaker:'Omar',cast:cast('analyst',1),startsAt:h.now()+10000,endsAt:h.now()+30000};
 h.player.seed(h.programme([host,analyst],{programmeMix:cloudMix,cloudWriter:cloudWriter(h)}));h.player.render();
 assert.equal(h.node('badgeText').textContent,language==='ar'?'حوار بالذكاء الاصطناعي':'AI DISCUSSION');
 assert.equal(h.node('voice').textContent,names[0]+(language==='ar'?' · صوت نسائي اصطناعي':' · Female synthetic voice'));
 assert.equal(h.node('transcript').textContent,host.speechText);assert.ok(h.node('source').textContent.includes(host.programme.modelId));
 assert.match(h.node('source').textContent,language==='ar'?/التُقط السياق/:/Context captured/);
 assert.doesNotMatch(h.node('source').textContent,/legacy|recorded|archive|replay/i);
 assert.match(h.node('schedule').children[0].children[1].textContent,language==='ar'?/مولّد سحابياً/:/Cloud-generated discussion/);
 assert.ok(h.node('schedule').children[1].children[1].textContent.includes(names[1]));
 assert.equal(h.node('cloudWriterStatus').hidden,false);assert.ok(h.node('cloudWriterMeta').textContent.includes(host.programme.modelId));
 assert.match(h.node('cloudWriterMeta').textContent,/12\.5/);
 h.advance(10001);h.player.render();assert.equal(h.node('voice').textContent,names[1]+(language==='ar'?' · صوت رجالي اصطناعي':' · Male synthetic voice'));
 assert.match(h.node('voice').className,/cast-analyst/);
});

test('cloud writer lifecycle distinguishes startup, active generation, a completed script, failures and a stale connection',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 const show=writer=>{h.player.seed(h.programme([],{programmeMix:cloudMix,cloudWriter:writer}));h.player.render();};
 show(cloudWriter(h,{status:'starting',lastGeneratedAt:0,generatedEpisodes:0,pendingTurns:0,lastGenerationSeconds:null}));
 assert.match(h.node('cloudWriterStatus').textContent,/starting; no new script is ready/);
 assert.match(h.node('cloudWriterMeta').textContent,/Configured model .*No completed script confirmed/);
 show(cloudWriter(h,{status:'generating',preparing:true,lastGeneratedAt:0,generatedEpisodes:0}));
 assert.match(h.node('cloudWriterStatus').textContent,/Writing the next script/);assert.match(h.player.waitStatus(),/cloud model is writing/);
 show(cloudWriter(h));assert.match(h.node('cloudWriterStatus').textContent,/Model-written script confirmed/);
 assert.match(h.node('cloudWriterMeta').textContent,/Last script generated .*12\.5 s writing/);
 show(cloudWriter(h,{status:'unavailable',lastError:'safe-failure',preparing:true}));assert.match(h.node('cloudWriterStatus').textContent,/generation is unavailable; retrying/);
 assert.doesNotMatch(h.node('cloudWriterStatus').textContent,/Writing|confirmed/);
 show(cloudWriter(h));h.advance(15001);h.player.render();assert.match(h.node('cloudWriterStatus').textContent,/connection interrupted/);
 assert.doesNotMatch(h.node('cloudWriterStatus').textContent,/confirmed|Writing/);
});

test('fictional Competition reveals the computed winner only when the result is due',async()=>{
 const h=harness();await h.acceptInitial();
 for(const language of ['en','ar']){
  h.changeLanguage(language);
  const p={enabled:true,fictional:true,realPrize:false,questionCount:5,due:true,active:false,completed:true,winner:language==='en'?'Sam':'سامر',scores:{'player-a':4,'player-b':3},resultStartsAt:h.now()+10000};
  h.player.seed(h.programme([],{competition:p}));h.player.render();
  assert.equal(h.node('competitionPanel').hidden,false);
  assert.match(h.node('competitionRules').textContent,language==='en'?/imaginary ounce of gold/:/أونصة ذهب خيالية/);
  assert.equal(h.node('competitionWinner').textContent,'');
  h.player.seed(h.programme([],{competition:{...p,resultStartsAt:h.now()-1000}}));h.player.render();
  assert.match(h.node('competitionWinner').textContent,language==='en'?/Bravo, Sam!/:/برافو سامر!/);
  assert.match(h.node('competitionWinner').textContent,/4.*3/);
  h.advance(15001);h.player.render();assert.equal(h.node('competitionWinner').textContent,'');
 }
});

test('named people segment shows its target, authentic attribution and empty supply honestly',async()=>{
 const h=harness();await h.acceptInitial();
 for(const language of ['en','ar']){
  h.changeLanguage(language);
  const people={targetSeconds:120,intervalSeconds:600,due:true,active:false,eligibleNow:false,scheduledSeconds:0,emittedPosts:0,nextDueAt:null};
  h.player.seed(h.programme([],{peopleNow:people}));h.player.render();
  assert.equal(h.node('peopleNowPanel').hidden,false);
  assert.match(h.node('peopleNowStatus').textContent,language==='en'?/No eligible comments/:/لا تتوفر تعليقات مؤهلة/);
  assert.match(h.node('peopleNowPolicy').textContent,language==='en'?/two minutes every ten/:/دقيقتين كل 10/);
  const q=h.clip('d',language,{kind:'people-now',social:true,sourceKind:'social-reaction',
   peopleNow:{authorName:'Public Display',authorHandle:'listener@mastodon.social',originalPublishedAt:Math.floor((h.now()-20000)/1000),factualContextEligible:false},
   sources:[{title:'A genuine collected account quote.'}]});
  h.player.seed(h.programme([q],{peopleNow:{...people,active:true,emittedPosts:1,scheduledSeconds:18},nowPlaying:q}));h.player.render();
  assert.match(h.node('peopleNowStatus').textContent,language==='en'?/On air/:/على الهواء/);
  assert.match(h.node('peopleNowPosts').textContent,/Public Display · @listener@mastodon.social/);
  assert.match(h.node('peopleNowPosts').textContent,/A genuine collected account quote/);
  assert.match(h.node('badgeText').textContent,language==='en'?/WHAT PEOPLE SAY NOW/:/ماذا يقول الناس الآن/);
  assert.doesNotMatch(h.node('peopleNowPolicy').textContent,/verified identity|public consensus/);
 }
});

test('Arabic people quotes label machine translation and retain the unmodified English original safely',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('ar');
 const original='An original English opinion <img src=x onerror=alert(1)>.',translated='هذا رأي مترجم آلياً، وليس نص الحساب الأصلي.';
 const q=h.clip('e','ar',{kind:'people-now',peopleNow:{authorHandle:'fixture@mastodon.social',originalPublishedAt:Math.floor(h.now()/1000),factualContextEligible:false,machineTranslation:true},sources:[{title:original,machineTranslations:{ar:{text:translated}}}]});
 h.player.seed(h.programme([q],{peopleNow:{targetSeconds:120,intervalSeconds:600},nowPlaying:q}));h.player.render();
 assert.match(h.node('peopleNowPosts').textContent,/ترجمة آلية غير متحقق منها/);
 assert.ok(h.node('peopleNowPosts').textContent.includes(translated));
 assert.ok(h.node('peopleNowPosts').textContent.includes(original));
 assert.equal(h.node('peopleNowPosts').innerHTML,undefined);
 assert.match(h.node('peopleNowPolicy').textContent,/آخر ساعة/);
});

test('script rejection is distinguished from provider unavailability without claiming ready speech',async()=>{
 const h=harness();await h.acceptInitial();
 for(const language of ['en','ar']){
  h.changeLanguage(language);
  const writer=cloudWriter(h,{status:'unavailable',failureKind:'script-validation',pendingTurns:0});
  h.player.seed(h.programme([],{programmeMix:cloudMix,cloudWriter:writer,cloudLlm:{provider:'nvidia-build',available:true}}));h.player.render();
  assert.match(h.node('cloudWriterStatus').textContent,language==='en'?/failed content checks; another script/:/لم يجتز نص الحوار الأخير فحوص المحتوى/);
  assert.doesNotMatch(h.node('cloudWriterStatus').textContent,/generation is unavailable|غير متاح|confirmed|اكتمل توليد/);
  h.player.seed(h.programme([],{programmeMix:cloudMix,cloudWriter:{...writer,failureKind:'provider'}}));h.player.render();
  assert.match(h.node('cloudWriterStatus').textContent,language==='en'?/generation is unavailable/:/غير متاح/);
 }
});

test('an unconfigured cloud account awaits station setup instead of promising an automatic retry',async()=>{
 const h=harness();await h.acceptInitial();
 for(const provider of ['cloudflare-workers-ai','nvidia-build']){
 for(const language of ['en','ar']){
  if(language==='en')h.changeLanguage('en');else h.changeLanguage('ar');
  const writer=cloudWriter(h,{status:'generating',preparing:true,lastGeneratedAt:0,generatedEpisodes:0});
  const remote={provider,available:false};
  h.player.seed(h.programme([],{programmeMix:cloudMix,cloudWriter:writer,cloudLlm:remote}));h.player.render();
  assert.match(h.node('cloudWriterStatus').textContent,language==='en'?/awaits station setup/:/بانتظار إعداد/);
  assert.doesNotMatch(h.node('cloudWriterStatus').textContent,/retrying|Writing|confirmed|جارٍ إنشاء/);
  assert.match(h.player.waitStatus(),language==='en'?/News and price updates continue/:/تستمر الأخبار/);
  h.player.seed(h.programme([],{programmeMix:cloudMix,cloudWriter:{...writer,status:'unavailable'},cloudLlm:{...remote,available:true}}));h.player.render();
  assert.match(h.node('cloudWriterStatus').textContent,language==='en'?/unavailable; retrying/:/غير متاح/);
 }
 }
});

test('cloud enable flags, future completion clocks and malformed model metadata never invent a ready model or transcript',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 h.player.seed(h.programme([],{programmeMix:cloudMix}));h.player.render();
 assert.match(h.node('cloudWriterStatus').textContent,/Waiting for confirmed/);assert.match(h.node('cloudWriterMeta').textContent,/Model not reported/);
 assert.doesNotMatch(h.player.waitStatus(),/recorded|archive|replay/i);
 for(const writer of [cloudWriter(h,{generatedEpisodes:0,lastGeneratedAt:0}),cloudWriter(h,{lastGeneratedAt:h.now()+1000}),
  cloudWriter(h,{modelId:'<img src=x onerror=alert(1)>'})]){
  h.player.seed(h.programme([],{programmeMix:cloudMix,cloudWriter:writer}));h.player.render();
  assert.match(h.node('cloudWriterStatus').textContent,/No completed model-written discussion is confirmed/);
  assert.doesNotMatch(h.node('cloudWriterMeta').textContent,/Last script generated|<img/);
 }
 const invalid=generatedDiscussion(h,'en');invalid.programme.generatedAt=h.now()+2000;
 h.player.seed(h.programme([invalid],{programmeMix:cloudMix}));h.player.render();assert.equal(h.node('badgeText').textContent,'SPOKEN UPDATE');assert.equal(h.node('source').textContent,'Discussion generation details are unavailable.');
 h.player.seed(h.programme([]));h.player.render();assert.equal(h.node('cloudWriterStatus').hidden,true);assert.equal(h.node('cloudWriterMeta').textContent,'');
 assert.match(html,/id="cloudWriterStatus"/);assert.match(html,/id="cloudWriterMeta"/);
});

for(const language of ['ar','en'])test(language+' cloud quiet-period speech is labelled generated, never an archive replay or a news report',async()=>{
 const h=harness();await h.acceptInitial();if(language==='en')h.changeLanguage('en');const q=generatedDiscussion(h,language);
 h.player.seed(h.programme([q],{programmeMix:cloudMix,cloudWriter:cloudWriter(h)}));h.player.setWanted(true);
 const pending=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await pending;h.player.render();
 assert.match(h.node('status').textContent,language==='ar'?/ولّده النموذج السحابي/:/cloud-generated gold discussion/);
 for(const id of ['status','programmeSupply','source'])assert.doesNotMatch(h.node(id).textContent,/recorded|archive|replay|مسجلة|المسجل/);
 assert.doesNotMatch(h.node('badgeText').textContent,/LIVE NEWS|BREAKING/);assert.equal(h.audio.paused,false);
 h.player.seed(h.programme([q],{programmeMix:cloudMix,cloudWriter:cloudWriter(h,{status:'unavailable'})}));h.player.render();
 assert.match(h.node('cloudWriterStatus').textContent,language==='ar'?/غير متاح/:/unavailable/);
 assert.equal(h.audio.paused,false,'already prepared speech remains playable when the next generation fails');
});

test('music gaps report a failed cloud writer honestly and recover into newly generated speech',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');h.player.setWanted(true);
 h.player.seed(h.programme([],{programmeMix:cloudMix,cloudWriter:cloudWriter(h,{status:'unavailable',lastGeneratedAt:0,generatedEpisodes:0})}));
 await h.player.sync();h.player.render();assert.equal(h.audio.paused,false);assert.equal(h.player.state().currentId,'music');
 assert.match(h.node('status').textContent,/generation is unavailable/);assert.doesNotMatch(h.node('status').textContent,/recorded|is prepared/);
 const q=generatedDiscussion(h,'en');await prepareSpeech(h,q);h.player.render();assert.equal(h.player.state().currentId,q.id);assert.equal(h.audio.paused,false);
 assert.equal(h.node('badgeText').textContent,'AI DISCUSSION');h.audio.finish();await flush();assert.equal(h.player.state().currentId,'music');
});


test('publication age uses the original publisher clock and does not relabel discovery',async()=>{
 const h=harness();await h.acceptInitial();h.changeLanguage('en');
 const q=h.clip('a','en',{kind:'news',sourceKind:'publisher-rss',clockBasis:'publisher-rss-publication',originalPublicationVerified:true,publicationField:'pubdate'});
 q.originalPublishedAt=Math.floor(q.publishedAt/1000);h.player.seed(h.programme([q]));h.player.render();assert.match(h.node('source').textContent,/Published 30 sec ago/);
 q.originalPublicationVerified=false;h.player.seed(h.programme([q]));h.player.render();assert.doesNotMatch(h.node('source').textContent,/Published 30 sec ago/);
});

'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');

// Execute the shipped inline player with deterministic network and media events.
const html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8');
const script=html.split('<script>')[1].split('</script>')[0];
const instrumented=script.replace(/\}\)\(\);\s*$/,`globalThis.player={sync,poll,render,startMusic,onAir,manifestFresh,media,
 seed:value=>{manifest=value;manifestReceivedAt=performance.now();offset=value.serverTime-Date.now();},
 setWanted:value=>{wanted=value;},
 state:()=>({language,manifest,currentId,epoch,channelEpoch,pollJob,playbackJob,manifestReceivedAt,cacheSize:cache.size,gap:gap()})};})();`);

function deferred(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return{promise,resolve,reject};}
async function flush(){for(let i=0;i<20;i++)await Promise.resolve();}
function element(id=''){
 const listeners=new Map();
 return{id,textContent:'',hidden:false,dir:'',value:id==='volume'?'.9':'ar',max:1,children:[],style:{},options:[],
 classList:{toggle(){}},append(...items){this.children.push(...items)},replaceChildren(){this.children=[]},
 addEventListener(type,fn,options={}){if(!listeners.has(type))listeners.set(type,new Map());listeners.get(type).set(fn,options)},
 removeEventListener(type,fn){listeners.get(type)?.delete(fn)},
 listeners(type){return[...(listeners.get(type)?.keys()||[])]},
 dispatch(type){for(const[fn,options]of[...(listeners.get(type)||[])]){if(options.once)listeners.get(type).delete(fn);fn({type,target:this});}this['on'+type]?.({type,target:this});},
 removeAttribute(name){delete this[name]}};
}
function harness(){
 let perf=0,wall=Date.UTC(2026,9,23,12),counter=0,objectCounter=0;
 const timers=new Map(),requests=[],plays=[],revoked=[],nodes=new Map();
 const audio=element('audio');Object.assign(audio,{paused:true,ended:false,readyState:0,currentTime:0,currentSrc:'',nextPlay:null,
 play(){plays.push({src:this.src,volume:this.volume,at:perf});this.paused=false;this.ended=false;const result=this.nextPlay;this.nextPlay=null;return result?.promise||Promise.resolve();},
 pause(){this.paused=true},load(){this.readyState=0;this.currentSrc='';this.ended=false},
 metadata(url=this.src){this.currentSrc=url;this.readyState=2;this.dispatch('loadedmetadata')},
 finish(){this.paused=true;this.ended=true;this.dispatch('ended')}});
 let audioSource='';Object.defineProperty(audio,'src',{configurable:true,get(){return audioSource},set(value){audioSource=value;this.readyState=0;this.currentSrc='';this.ended=false;}});
 audio.removeAttribute=name=>{if(name==='src')audio.src='';};nodes.set('audio',audio);
 const node=id=>{if(!nodes.has(id))nodes.set(id,element(id));return nodes.get(id)};
 node('language').options=[{value:'ar'},{value:'en'}];
 class LocalDate extends Date{constructor(...values){super(...(values.length?values:[wall]));}static now(){return wall;}}
 class LocalURL extends URL{static createObjectURL(){return 'blob:player-'+(++objectCounter)}static revokeObjectURL(value){revoked.push(value)}}
 const context={console,document:{getElementById:node,createElement:element},Date:LocalDate,Math,Number,String,Array,Map,Set,Promise,URL:LocalURL,Error,AbortController,
 performance:{now:()=>perf},setInterval(){return ++counter;},setTimeout(fn,delay){const key=++counter;timers.set(key,{fn,at:perf+delay});return key;},clearTimeout(key){timers.delete(key)},
 fetch(url,options){const d=deferred();const request={url,options,...d};requests.push(request);return d.promise;}};
 vm.runInNewContext(instrumented,context);
 function advance(ms){const target=perf+ms;while(true){let next;for(const[key,value]of timers)if(value.at<=target&&(!next||value.at<next.value.at))next={key,value};if(!next)break;const delta=next.value.at-perf;perf=next.value.at;wall+=delta;timers.delete(next.key);next.value.fn();}wall+=target-perf;perf=target;}
 const programme=(queue=[],extra={})=>({language:node('language').value,languages:['ar','en'],queue,recent:[],status:'waiting',serverTime:wall,feedsReached:10,feedCount:10,freshStories:0,unreadFreshStories:0,...extra});
 const clip=(id='a',lang=node('language').value,extra={})=>({id:id.repeat(32),language:lang,kind:'news',audioUrl:'/audio/'+id.repeat(32)+'.wav',headline:'A public report',source:'Publisher',sourceUrl:'https://example.org/news',speechText:lang==='ar'?'هذا نص الخبر.':'This is the spoken report.',startsAt:wall-1000,endsAt:wall+40000,publishedAt:wall-30000,firstSeenAt:wall-20000,...extra});
 const response=value=>({ok:true,json:async()=>value});
 const wave=()=>({ok:true,headers:{get:name=>name==='content-type'?'audio/wav':name==='content-length'?'100':null},blob:async()=>({size:100})});
 const requestFor=url=>requests.findLast(r=>r.url===url);
 const acceptInitial=async()=>{requests[0].resolve(response(programme()));await flush();};
 const changeLanguage=value=>{node('language').value=value;node('language').onchange();};
 return{player:context.player,audio,node,requests,plays,revoked,timers,advance,programme,clip,response,wave,requestFor,acceptInitial,changeLanguage,now:()=>wall,perf:()=>perf};
}
async function prepareSpeech(h,q){h.player.seed(h.programme([q]));h.player.setWanted(true);const pending=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await pending;return h.audio.src;}

test('music has one eight-second budget, even when play hangs or sync repeats',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);const hang=deferred();h.audio.nextPlay=hang;
 const starting=h.player.startMusic({unlock:true});assert.equal(h.plays.length,1,'same element play is called within the gesture');const until=h.player.state().gap.until;
 h.advance(4000);await h.player.sync();assert.equal(h.player.state().gap.until,until);
 h.advance(4000);assert.equal(h.audio.paused,true);await h.player.sync();await h.player.sync();assert.equal(h.plays.length,1,'expired gap cannot restart from a timer');
 hang.resolve();await starting;assert.equal(h.audio.paused,true,'late play completion cannot restart capped music');
 await h.player.startMusic({unlock:true});assert.equal(h.plays.length,2,'a new gesture can still unlock the element');assert.equal(h.audio.paused,true,'expired-gap unlock stays silent');
});

for(const outcome of ['late response','late error'])test('language poll is replaced immediately; '+outcome+' cannot overwrite it',async()=>{
 const h=harness(),old=h.requests[0];h.changeLanguage('en');assert.equal(old.options.signal.aborted,true);const current=h.requestFor('/radio.json?language=en');assert.ok(current,'English request starts without waiting for Arabic');
 current.resolve(h.response(h.programme([],{production:{preparing:true,kind:'market',queuedSeconds:0}})));await flush();assert.equal(h.player.state().manifest.language,'en');const status=h.node('status').textContent;
 if(outcome==='late response')old.resolve(h.response(h.programme([],{language:'ar'})));else old.reject(Error('old network error'));await flush();assert.equal(h.player.state().manifest.language,'en');assert.equal(h.node('status').textContent,status);assert.equal(h.player.state().pollJob,null);
});

test('language switch aborts old audio and old job cannot release the new metadata lock',async()=>{
 const h=harness();await h.acceptInitial();const arabic=h.clip('a','ar');h.player.seed(h.programme([arabic]));h.player.setWanted(true);const oldJob=h.player.sync();const oldAudio=h.requestFor(arabic.audioUrl);
 h.changeLanguage('en');assert.equal(oldAudio.options.signal.aborted,true);
 const english=h.clip('b','en');h.requestFor('/radio.json?language=en').resolve(h.response(h.programme([english])));await flush();h.requestFor(english.audioUrl).resolve(h.wave());await flush();const target=h.audio.src;assert.equal(h.player.state().playbackJob.id,english.id);
 oldAudio.resolve(h.wave());await oldJob;await flush();assert.equal(h.player.state().playbackJob.id,english.id,'old finally cannot release the newer job');assert.equal(h.audio.src,target);
 h.audio.metadata(target);await flush();assert.equal(h.player.state().currentId,english.id);assert.equal(h.player.state().language,'en');assert.equal(h.plays.at(-1).src,target);
});

test('cancelled metadata listeners are removed and stale events cannot complete new speech',async()=>{
 const h=harness();await h.acceptInitial();const ar=h.clip('a','ar');h.player.seed(h.programme([ar]));h.player.setWanted(true);const first=h.player.sync();h.requestFor(ar.audioUrl).resolve(h.wave());await flush();const oldListeners=h.audio.listeners('loadedmetadata');assert.ok(oldListeners.length);
 h.advance(500);h.changeLanguage('en');await first;const en=h.clip('b','en');h.requestFor('/radio.json?language=en').resolve(h.response(h.programme([en])));await flush();h.requestFor(en.audioUrl).resolve(h.wave());await flush();const newUrl=h.audio.src;
 for(const listener of oldListeners)listener({type:'loadedmetadata',target:h.audio});h.audio.dispatch('loadedmetadata');await flush();assert.equal(h.player.state().playbackJob.id,en.id,'an event before new-source metadata is ready must be ignored');
 h.audio.metadata(newUrl);await flush();assert.equal(h.player.state().playbackJob,null);assert.equal(h.player.state().currentId,en.id);assert.equal(h.audio.listeners('loadedmetadata').length,0);
});

test('metadata timeout removes listeners and automatically retries after bounded backoff',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();h.player.seed(h.programme([q]));h.player.setWanted(true);const first=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();
 h.advance(10000);await first;assert.equal(h.player.state().playbackJob,null);assert.equal(h.audio.paused,true);assert.equal(h.audio.listeners('loadedmetadata').length,0);assert.match(h.node('status').textContent,/retrying/i);
 await h.player.sync();assert.equal(h.player.state().playbackJob,null,'no tight reload loop');h.advance(2000);const retry=h.player.sync();await flush();assert.equal(h.player.state().playbackJob.id,q.id);h.audio.metadata();await retry;assert.equal(h.audio.paused,false);assert.equal(h.player.state().currentId,q.id);
});

test('a stalled speech play promise times out and cannot release a newer retry',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();h.player.seed(h.programme([q]));h.player.setWanted(true);
 const first=h.player.sync();h.requestFor(q.audioUrl).resolve(h.wave());await flush();const pendingPlay=deferred();h.audio.nextPlay=pendingPlay;h.audio.metadata();await flush();
 h.advance(5000);await first;assert.equal(h.player.state().playbackJob,null);assert.equal(h.audio.paused,true);assert.match(h.node('status').textContent,/retrying/);
 h.advance(2000);const retry=h.player.sync();await flush();assert.equal(h.player.state().playbackJob.id,q.id);
 pendingPlay.resolve();await flush();assert.equal(h.player.state().playbackJob.id,q.id,'old play completion must not release the new metadata job');h.audio.metadata();await retry;assert.equal(h.audio.paused,false);
});

test('announcing a new clip cannot erase the active music gap deadline',async()=>{
 const h=harness();await h.acceptInitial();h.player.setWanted(true);await h.player.startMusic();h.advance(3000);
 const q=h.clip();h.player.seed(h.programme([q]));h.player.render();h.advance(5000);assert.equal(h.audio.paused,true);assert.equal(h.plays.length,1);
});

test('old programme cannot start queued speech after an outage; a fresh response recovers',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{startsAt:h.now()+20000,endsAt:h.now()+40000});h.player.seed(h.programme([q]));h.player.setWanted(true);h.advance(21000);await h.player.sync();assert.equal(h.player.onAir(),null);assert.equal(h.requestFor(q.audioUrl),undefined,'do not start a future clip from a stale manifest');
 h.player.render();assert.match(h.node('checked').textContent,/Connection retrying/);
 const polling=h.player.poll();h.requestFor('/radio.json?language=ar').resolve(h.response(h.programme([q])));await polling;await flush();assert.ok(h.requestFor(q.audioUrl));h.requestFor(q.audioUrl).resolve(h.wave());await flush();h.audio.metadata();await flush();assert.equal(h.player.state().currentId,q.id);assert.ok(h.audio.currentTime>=1,'join at the current shared point, not its beginning');
});

test('already playing speech may finish during outage but cannot replay from the stale programme',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip();await prepareSpeech(h,q);const wavePlays=h.plays.length;h.advance(16000);await h.player.sync();assert.equal(h.audio.paused,false);assert.equal(h.player.onAir().id,q.id);
 h.audio.finish();await flush();assert.equal(h.player.onAir(),null);await h.player.sync();assert.equal(h.plays.filter(x=>x.src.startsWith('blob:')).length,1);assert.ok(h.plays.length>=wavePlays);
});

for(const delta of [-1000,0])test('a '+(delta===0?'repeated':'regressing')+' server clock cannot refresh an old programme',async()=>{
 const h=harness();await h.acceptInitial();const accepted=h.player.state().manifest.serverTime;h.advance(4000);
 const pending=h.player.poll();h.requestFor('/radio.json?language=ar').resolve(h.response(h.programme([],{serverTime:accepted+delta})));await pending;
 assert.equal(h.player.state().manifest.serverTime,accepted);assert.equal(h.player.state().manifestReceivedAt,0);assert.match(h.node('status').textContent,/connection interrupted/i);
});

test('market and discussion labels show transcript and grounded source clocks',async()=>{
 const h=harness();await h.acceptInitial();const q=h.clip('a','ar',{kind:'market',caption:'Gold API collected 12:00; separate from chart.',speechText:'رصد سعر الذهب.'});h.player.seed(h.programme([q],{lastCollectionAt:h.now()-3000,market:{status:'stale',sourceAt:h.now()-120000},production:{preparing:true,kind:'market',queuedSeconds:13}}));h.player.render();
 assert.equal(h.node('badgeText').textContent,'GOLD UPDATE');assert.equal(h.node('source').textContent,q.caption);assert.equal(h.node('transcript').textContent,q.speechText);assert.equal(h.node('spoken').hidden,false);assert.match(h.node('freshness').textContent,/120 sec old · stale/);assert.match(h.node('freshness').textContent,/13 sec of speech queued/);
 q.kind='discussion';q.caption='Conditional discussion based on the published news window.';h.player.render();assert.equal(h.node('badgeText').textContent,'DISCUSSION');assert.equal(h.node('source').textContent,q.caption);assert.equal(h.node('source').children.length,0);
});

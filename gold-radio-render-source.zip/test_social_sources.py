import json
import unittest
from datetime import datetime, timezone

from social_sources import (ALLOWED_URLS, MAX_BYTES, SOURCES, Response, SocialCollector,
                            _next_delay, clean_text, fetch_public, parse_bluesky, parse_telegram)

NOW = 1792759500
AR = SOURCES[0]
EN = SOURCES[1]


def iso(stamp):
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat()


def telegram(text='ارتفاع أسعار النفط بعد تعطل إمدادات الطاقة العالمية', stamp=None, extra='', channel=None, number=123):
    actor = channel or AR.actor
    return (f'<div class="tgme_widget_message_wrap"><div class="tgme_widget_message js-widget_message" '
            f'data-post="{actor}/{number}"><div class="tgme_widget_message_bubble">{extra}'
            f'<div class="tgme_widget_message_text js-message_text" dir="auto">{text}</div>'
            f'<a class="tgme_widget_message_date" href="https://t.me/{actor}/{number}">'
            f'<time datetime="{stamp if stamp is not None else iso(NOW - 40)}">12:00</time></a>'
            '</div></div></div>').encode()


def bluesky(text='Sterling edges higher as bond yields fall after inflation report', **updates):
    record = {'$type': 'app.bsky.feed.post', 'createdAt': iso(NOW - 20), 'text': text}
    item = {'post': {'uri': f'at://{EN.did}/app.bsky.feed.post/abc123',
                     'author': {'did': EN.did, 'handle': EN.actor}, 'record': record, 'indexedAt': iso(NOW - 1)}}
    for key, value in updates.items():
        if key == 'record':
            record.update(value)
        else:
            item['post'][key] = value
    return json.dumps({'feed': [item]}).encode()


class ParsingTests(unittest.TestCase):
    def test_arabic_original_text_and_clocks(self):
        rows = parse_telegram(telegram('عاجل | أسعار <b>النفط</b> ترتفع بعد أزمة الإمدادات<br>https://example.org/x'), AR, NOW)
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row['publishedAt'], NOW - 40)
        self.assertEqual(row['firstSeenAt'], NOW)
        self.assertTrue(row['social'])
        self.assertEqual(row['timeKind'], 'published')
        self.assertEqual(row['clockBasis'], 'author-reported')
        self.assertEqual(row['sourceKind'], 'social')
        self.assertEqual(row['url'], 'https://t.me/AlArabiya/123')
        self.assertIn('أسعار النفط ترتفع', row['title'])
        self.assertNotIn('example', row['title'])

    def test_reject_forwarded_edited_missing_clocks_wrong_identity(self):
        for kwargs in ({'extra': '<div class="tgme_widget_message_forwarded_from">Another account</div>'},
                       {'extra': '<span class="tgme_widget_message_updated">edited</span>'},
                       {'stamp': 'yesterday'}, {'stamp': '2026-10-23T12:00:00'},
                       {'stamp': iso(NOW + 1)}, {'stamp': iso(NOW - 3601)}):
            with self.subTest(kwargs=kwargs):
                self.assertEqual(parse_telegram(telegram(**kwargs), AR, NOW), [])
        with self.assertRaises(ValueError):
            parse_telegram(telegram(channel='UnknownChannel'), AR, NOW)

    def test_boundaries_and_post_date_link_required(self):
        self.assertEqual(len(parse_telegram(telegram(stamp=iso(NOW - 3600)), AR, NOW)), 1)
        body = telegram().replace(b'href="https://t.me/AlArabiya/123"', b'href="https://evil.test/123"')
        self.assertEqual(parse_telegram(body, AR, NOW), [])

    def test_no_media_only_or_unmatched_language(self):
        self.assertEqual(parse_telegram(telegram(''), AR, NOW), [])
        self.assertEqual(parse_telegram(telegram('The oil price climbed after disruption to supplies'), AR, NOW), [])
        with self.assertRaises(ValueError):
            parse_telegram(b'<html><title>Telegram landing page</title></html>', AR, NOW)

    def test_bluesky_no_index_clock_rejuvenation(self):
        row = parse_bluesky(bluesky(), EN, NOW)[0]
        self.assertEqual(row['publishedAt'], NOW - 20)
        self.assertEqual(row['platform'], 'Bluesky')
        self.assertIn(EN.did, row['url'])
        self.assertEqual(parse_bluesky(bluesky(record={'createdAt': iso(NOW - 5000)}), EN, NOW), [])

    def test_pinned_identity_replies_quotes_and_labels(self):
        for kwargs in ({'author': {'did': 'did:plc:imposter', 'handle': EN.actor}},
                       {'author': {'did': EN.did, 'handle': 'other.example'}}, {'labels': [{'val': 'spam'}]},
                       {'record': {'reply': {'root': {}}}},
                       {'record': {'embed': {'$type': 'app.bsky.embed.record', 'record': {}}}}):
            with self.subTest(kwargs=kwargs):
                self.assertEqual(parse_bluesky(bluesky(**kwargs), EN, NOW), [])
        data = json.loads(bluesky())
        data['feed'][0]['reason'] = {'$type': 'app.bsky.feed.defs#reasonRepost'}
        self.assertEqual(parse_bluesky(json.dumps(data).encode(), EN, NOW), [])

    def test_promo_controls_links_and_source_limits(self):
        self.assertEqual(parse_bluesky(bluesky('Join Telegram for guaranteed profits from gold trading'), EN, NOW), [])
        self.assertEqual(clean_text('Gold rises #markets @scammer https://example.org/x'), 'Gold rises markets')
        self.assertEqual(clean_text('x' * 500), '')
        self.assertEqual(clean_text('A complete sentence. ' + 'x' * 500), 'A complete sentence.')
        for parse, source in ((parse_telegram, AR), (parse_bluesky, EN)):
            with self.assertRaises(ValueError):
                parse(b'x' * (MAX_BYTES + 1), source, NOW)

    def test_stable_post_identity_across_delivery(self):
        first = parse_telegram(telegram(), AR, NOW)[0]
        second = parse_telegram(telegram(), AR, NOW + 10)[0]
        self.assertEqual(first['id'], second['id'])
        self.assertEqual(first['publishedAt'], second['publishedAt'])

    def test_empty_api_result_is_not_ready_and_quoted_teaser_not_used(self):
        with self.assertRaises(ValueError):
            parse_bluesky(b'{"feed":[]}', EN, NOW)
        data = json.loads(bluesky())
        data['feed'][0]['post']['embed'] = {'record': {'value': {'text': 'An unrelated quoted opinion'}}}
        rows = parse_bluesky(json.dumps(data).encode(), EN, NOW)
        self.assertEqual(len(rows), 1)
        self.assertNotIn('unrelated', rows[0]['title'])


class CollectorTests(unittest.TestCase):
    def test_curated_static_allowlist(self):
        self.assertEqual(len(ALLOWED_URLS), len(SOURCES))
        for bad in ('http://127.0.0.1/', 'https://t.me/s/Unknown',
                    'https://public.api.bsky.app/xrpc/app.bsky.feed.searchPosts?q=gold'):
            with self.assertRaises(ValueError):
                fetch_public(bad, {}, 1)

    def test_actual_pipeline_receipt_preservation_and_poll_budget(self):
        calls = []
        def fetch(url, headers, timeout):
            calls.append(url)
            source = next(s for s in SOURCES if s.url == url)
            body = telegram(channel=source.actor) if source.platform == 'Telegram' else bluesky()
            return Response(200, {'content-type': 'text/html' if source.platform == 'Telegram' else 'application/json'}, body, url)
        collector = SocialCollector(fetch)
        try:
            rows = [row for offset in range(5) for row in collector.collect(NOW + offset)]
            self.assertEqual(len(rows), 6)  # Five Arabic channels and one pinned Reuters fixture.
            self.assertEqual(collector.status()['readySources'], 9)
            self.assertEqual(collector.collect(NOW + 30), [])
            self.assertEqual(len(calls), 9)
            first_receipts = {row['id']: row['firstSeenAt'] for row in rows}
            again = [row for offset in range(5) for row in collector.collect(NOW + 60 + offset)]
            self.assertEqual(len(again), 6)
            self.assertTrue(all(row['firstSeenAt'] == first_receipts[row['id']] for row in again))
        finally:
            collector._pool.shutdown(wait=True)

    def test_denials_backoff_without_search_or_proxy_fallback(self):
        calls = []
        def fetch(url, headers, timeout):
            calls.append(url)
            return Response(403, {}, b'', url)
        collector = SocialCollector(fetch)
        try:
            for offset in range(5):
                self.assertEqual(collector.collect(NOW + offset), [])
            self.assertTrue(all(x['status'] == 'access_denied' for x in collector.status()['sources']))
            self.assertEqual(collector.collect(NOW + 600), [])
            self.assertEqual(len(calls), 9)
        finally:
            collector._pool.shutdown(wait=True)

    def test_fair_admission_does_not_fail_sources_waiting_their_turn(self):
        calls = []
        def fetch(url, headers, timeout):
            calls.append(url)
            return Response(403, {}, b'', url)
        collector = SocialCollector(fetch)
        try:
            collector.collect(NOW)
            states = collector.status()['sources']
            self.assertEqual(len(calls), 2)
            self.assertTrue(all(s['checkedAt'] == NOW * 1000 and s['failures'] == 1 for s in states[:2]))
            self.assertTrue(all(s['checkedAt'] == 0 and s['failures'] == 0 and s['status'] == 'starting' for s in states[2:]))
            for offset in range(1, 5):
                collector.collect(NOW + offset)
            self.assertEqual(len(calls), 9)
            self.assertTrue(all(s['checkedAt'] > 0 for s in collector.status()['sources']))
        finally:
            collector._pool.shutdown(wait=True)

    def test_retry_after_and_publisher_cache_honoured(self):
        self.assertEqual(_next_delay({'retry-after': '1200'}, NOW, 1, 429), 1200)
        self.assertEqual(_next_delay({'cache-control': 'public, max-age=120'}, NOW), 120)
        self.assertEqual(_next_delay({'cache-control': 'public, max-age=2'}, NOW), 60)
        self.assertGreaterEqual(_next_delay({}, NOW, 1, 403), 3600)

    def test_redirect_content_type_and_changed_publication_fail_closed(self):
        def fetch(url, headers, timeout):
            return Response(200, {'content-type': 'text/html'}, telegram(), 'https://evil.example/')
        collector = SocialCollector(fetch)
        try:
            self.assertEqual(collector.collect(NOW), [])
            self.assertEqual(collector.status()['readySources'], 0)
        finally:
            collector._pool.shutdown(wait=True)


if __name__ == '__main__':
    unittest.main()

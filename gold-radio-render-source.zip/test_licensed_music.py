from dataclasses import replace
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
import zipfile

import licensed_music as music


class LicensedMusicTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.data = {track.id: ('fixture-audio-' + track.id).encode('ascii') for track in music.TRACKS}
        self.tracks = tuple(replace(track, bytes=len(self.data[track.id]),
                                    sha256=hashlib.sha256(self.data[track.id]).hexdigest())
                            for track in music.TRACKS)
        self.patch = patch.object(music, 'TRACKS', self.tracks)
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def cached(self, tracks=None):
        directory = self.root / 'music'
        directory.mkdir(exist_ok=True)
        for track in tracks if tracks is not None else self.tracks:
            (directory / (track.id + '.mp3')).write_bytes(self.data[track.id])

    def archive(self, corrupt=None, duplicate=None):
        output = io.BytesIO()
        with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for track in self.tracks:
                data = self.data[track.id]
                if track.id == corrupt:
                    data = b'X' * len(data)
                archive.writestr(track.member, data)
                if track.id == duplicate:
                    archive.writestr(track.member, data)
            archive.writestr('../../unselected.txt', b'must never be extracted')
            archive.writestr('unselected-song.mp3', b'not a selected song')
        output.seek(0)
        return output

    def test_build_extracts_only_fixed_verified_members_and_public_credits(self):
        with patch.object(music, '_archive_source', return_value=self.archive()) as fetch:
            values = music.build(self.root)
        fetch.assert_called_once()
        self.assertEqual(len(values), 3)
        self.assertEqual({path.name for path in (self.root / 'music').iterdir()},
                         {track.id + '.mp3' for track in self.tracks} | {'ATTRIBUTION.json'})
        self.assertFalse((self.root.parent / 'unselected.txt').exists())
        credits = json.loads((self.root / 'music' / 'ATTRIBUTION.json').read_text('utf-8'))
        self.assertEqual(credits['artist'], 'HoliznaCC0')
        self.assertEqual(credits['license'], 'CC0 1.0')
        self.assertEqual(credits['sourceUrl'], music.SOURCE_URL)

    def test_valid_cache_does_not_download_again(self):
        self.cached()
        with patch.object(music, '_archive_source', side_effect=AssertionError('No download')):
            self.assertEqual(len(music.build(self.root)), 3)

    def test_corrupt_pinned_member_is_never_published(self):
        with patch.object(music, '_archive_source', return_value=self.archive(corrupt='night-driving')):
            with self.assertRaises(ValueError):
                music.build(self.root)
        self.assertFalse((self.root / 'music' / 'night-driving.mp3').exists())
        self.assertEqual(list((self.root / 'music').glob('*.tmp')), [])

    def test_missing_and_changed_assets_are_excluded_without_runtime_fetch(self):
        self.cached(self.tracks[:2])
        (self.root / 'music' / 'boredom.mp3').write_bytes(b'X' * self.tracks[1].bytes)
        with patch.object(music, '_archive_source', side_effect=AssertionError('Runtime cannot download')):
            library = music.MusicLibrary(self.root, seed='test')
        self.assertEqual([row.id for row in library.tracks], ['night-driving'])
        self.assertEqual(len(library.available), 1)

    def test_asset_lookup_is_exact_allowlist(self):
        self.cached()
        library = music.MusicLibrary(self.root, seed='test')
        self.assertEqual(library.asset('love'), self.root / 'music' / 'love.mp3')
        for identifier in ('../love', 'love.mp3', '/music/love.mp3', 'https://example.org/song.mp3', '', None):
            self.assertIsNone(library.asset(identifier))

    def test_selection_uses_music_elapsed_time_and_freezes_during_speech(self):
        self.cached()
        library = music.MusicLibrary(self.root, seed='test')
        first = library.selection(11_000, 100_000, True)
        paused = library.selection(11_000, 130_000, False)
        resumed = library.selection(11_000, 150_000, True)
        self.assertEqual((first['trackId'], first['positionSeconds']),
                         (paused['trackId'], paused['positionSeconds']))
        self.assertEqual((first['trackId'], first['positionSeconds']),
                         (resumed['trackId'], resumed['positionSeconds']))
        self.assertFalse(paused['playing'])
        self.assertEqual(resumed['asOfServerTime'], 150_000)
        self.assertEqual(resumed['positionSeconds'], 11)
        self.assertEqual(resumed['epochMs'], 0)
        self.assertEqual(resumed['gain'], .35)
        self.assertEqual(resumed['artist'], 'HoliznaCC0')

    def test_shuffle_is_repeatable_varied_and_no_adjacent_round_repeat(self):
        self.cached()
        first = music.MusicLibrary(self.root, seed='station-one')
        second = music.MusicLibrary(self.root, seed='station-one')
        last = None
        orders = set()
        for round_index in range(100):
            order = first._order(round_index)
            orders.add(tuple(track.id for track in order))
            offset = round_index * first._round_ms
            for track in order:
                left = first.selection(offset, 200_000, True)
                right = second.selection(offset, 200_000, True)
                self.assertEqual(left, right)
                self.assertEqual(left['trackId'], track.id)
                self.assertEqual(left['positionSeconds'], 0)
                self.assertNotEqual(last, track.id)
                last = track.id
                offset += track.duration_ms
        self.assertGreater(len(orders), 1)

    def test_large_elapsed_round_is_direct_not_stateful_iteration(self):
        self.cached()
        library = music.MusicLibrary(self.root, seed=12)
        value = library.selection(10 ** 14, 10 ** 14, True)
        self.assertGreaterEqual(value['positionSeconds'], 0)
        self.assertLess(value['positionSeconds'], value['durationSeconds'])

    def test_empty_library_returns_none_for_original_bed_fallback(self):
        library = music.MusicLibrary(self.root, seed='test')
        self.assertEqual(len(library), 0)
        self.assertIsNone(library.selection(0, 0, True))
        self.assertIsNone(library.asset('love'))

    def test_two_track_partial_library_remains_alternating(self):
        self.cached(self.tracks[:2])
        library = music.MusicLibrary(self.root, seed='test')
        previous = None
        for index in range(10):
            for track in library._order(index):
                self.assertNotEqual(track.id, previous)
                previous = track.id

    def test_download_checks_fixed_size_hash_and_bound_without_real_network(self):
        data = b'fixed-public-archive-fixture'
        response = io.BytesIO(data)
        response.status = 200
        opener = Mock()
        opener.open.return_value = response
        with patch.object(music, 'ARCHIVE_BYTES', len(data)), \
                patch.object(music, 'ARCHIVE_SHA256', hashlib.sha256(data).hexdigest()), \
                patch('licensed_music.urllib.request.build_opener', return_value=opener):
            with music._archive_source() as source:
                self.assertEqual(source.read(), data)
        request = opener.open.call_args.args[0]
        self.assertEqual(request.full_url, music.ARCHIVE_URL)
        self.assertEqual(opener.open.call_args.kwargs['timeout'], 30)
        for wrong_size, digest in ((len(data) - 1, hashlib.sha256(data).hexdigest()), (len(data), '0' * 64)):
            response = io.BytesIO(data)
            response.status = 200
            opener.open.return_value = response
            with patch.object(music, 'ARCHIVE_BYTES', wrong_size), \
                    patch.object(music, 'ARCHIVE_SHA256', digest), \
                    patch('licensed_music.urllib.request.build_opener', return_value=opener):
                with self.assertRaises(ValueError):
                    with music._archive_source():
                        self.fail('Changed archive was accepted')

    def test_private_paths_source_roots_and_bad_clock_are_rejected(self):
        with self.assertRaises(ValueError):
            music.build(Path(music.__file__).parent)
        with self.assertRaises(ValueError):
            music.MusicLibrary('https://example.org/music')
        library = music.MusicLibrary(self.root, seed='test')
        for args in ((True, 1, True), (-1, 1, True), (1, float('inf'), True), (1, 1, 'true')):
            with self.assertRaises(ValueError):
                library.selection(*args)


if __name__ == '__main__':
    unittest.main()

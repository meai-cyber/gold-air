import io
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import cloudflare_llm_runtime as runtime


ACCOUNT = '0123456789abcdef0123456789abcdef'
TOKEN = 'test_token_never_a_real_credential_123456789'


def answer(text='Oil costs can affect inflation expectations and demand for gold.', *, tokens=12, finish='stop'):
    return {'choices': [{'message': {'role': 'assistant', 'content': text}, 'finish_reason': finish}],
            'usage': {'prompt_tokens': 80, 'completion_tokens': tokens}}


class FakeResponse(io.BytesIO):
    status = 200
    def getheader(self, name):
        return None


class FakeConnection:
    def __init__(self, response=None):
        self.response = response or FakeResponse(json.dumps(answer()).encode())
        self.sock = None
        self.calls = []
        self.closed = False

    def connect(self):
        pass

    def request(self, *args, **kwargs):
        self.calls.append((args, kwargs))

    def getresponse(self):
        return self.response

    def close(self):
        self.closed = True


class CloudflareRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.environment = patch.dict(os.environ, {'CF_ACCOUNT_ID': ACCOUNT, 'CF_API_TOKEN': TOKEN,
            'RADIO_CF_FREE_PLAN_CONFIRMED': '1', 'RADIO_CLOUDFLARE_LLM': '1'})
        self.environment.start()
        self.instances = []

    def tearDown(self):
        for instance in self.instances:
            instance.close()
        self.environment.stop()
        self.temporary.cleanup()

    def instance(self, cls=runtime.CloudflareLlmRuntime, **options):
        instance = cls(self.temporary.name, **options)
        self.instances.append(instance)
        return instance

    def job(self, text='Public news about oil and inflation', **options):
        return runtime._Job(text, 'en', options.get('tokens', 64), time.monotonic() + options.get('timeout', 5))

    def test_disabled_missing_credentials_and_owner_plan_confirmation_fail_before_http(self):
        for changes, reason in (({'RADIO_CF_FREE_PLAN_CONFIRMED': ''}, 'owner-free-plan-unconfirmed'),
                                ({'CF_ACCOUNT_ID': 'https://evil.test/'}, 'credentials-missing'),
                                ({'CF_API_TOKEN': '\r\nmalicious'}, 'credentials-missing'),
                                ({'RADIO_CLOUDFLARE_LLM': '0'}, 'disabled')):
            with patch.dict(os.environ, changes):
                instance = self.instance()
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, reason):
                instance.generate('Public news')
            self.assertIsNone(instance._worker)
        self.assertFalse(Path(self.temporary.name, 'cloudflare-llm').exists())

    def test_fixed_tls_destination_no_redirect_proxy_or_public_api(self):
        instance, connection = self.instance(), FakeConnection()
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection) as factory, \
                patch.dict(os.environ, {'HTTPS_PROXY': 'http://malicious.test:8080'}):
            value = instance.generate('Public news', max_tokens=64, timeout=5)
        self.assertIn('Oil', value)
        self.assertEqual(factory.call_args.args, ('api.cloudflare.com',))
        self.assertEqual(factory.call_args.kwargs['port'], 443)
        context = factory.call_args.kwargs['context']
        self.assertTrue(context.check_hostname)
        self.assertEqual(context.verify_mode, runtime.ssl.CERT_REQUIRED)
        args, kwargs = connection.calls[0]
        self.assertEqual(args, ('POST', '/client/v4/accounts/' + ACCOUNT + '/ai/v1/chat/completions'))
        request = json.loads(kwargs['body'])
        self.assertEqual(request['model'], runtime.MODEL_ID)
        self.assertEqual(request['max_tokens'], 64)
        self.assertFalse(request['stream'])
        self.assertTrue(request['options']['rejectIfBusy'])
        self.assertIn('/no_think', request['messages'][-1]['content'])
        self.assertEqual(kwargs['headers']['Authorization'], 'Bearer ' + TOKEN)
        self.assertTrue(connection.closed)
        self.assertFalse(instance.status()['publicApi'])
        self.assertIsNone(instance.status()['lastFirstTokenSeconds'])
        self.assertEqual(instance.status()['lastOutputTokens'], 12)

    def test_other_hosts_cannot_receive_authentication(self):
        instance = self.instance()
        for url in ('https://evil.test/', 'http://api.cloudflare.com/',
                    'https://api.cloudflare.com:443/client/v4/',
                    'https://api.cloudflare.com/client/v4/?redirect=evil'):
            instance._endpoint = url
            with patch.object(runtime.http.client, 'HTTPSConnection') as factory:
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'invalid-endpoint'):
                    instance._request({}, self.job())
                factory.assert_not_called()

    def test_errors_never_echo_credentials_or_provider_body_and_do_not_retry(self):
        instance = self.instance()
        for status, reason in ((302, 'provider-redirect'), (429, 'rate-limited'),
                               (403, 'provider-auth'), (500, 'provider-error')):
            response = FakeResponse((TOKEN + ACCOUNT).encode()); response.status = status
            connection = FakeConnection(response)
            with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection) as factory:
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, reason) as raised:
                    instance._request({}, self.job())
                self.assertEqual(factory.call_count, 1)
                self.assertEqual(response.tell(), 0)
                self.assertNotIn(TOKEN, str(raised.exception))
        connection = FakeConnection()
        connection.getresponse = lambda: (_ for _ in ()).throw(TimeoutError(TOKEN))
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection) as factory:
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
                instance.generate('Public news', timeout=5)
            self.assertEqual(factory.call_count, 1)
        status_text = json.dumps(instance.status())
        self.assertNotIn(TOKEN, status_text)
        self.assertNotIn(ACCOUNT, status_text)
        for path in instance.directory.iterdir():
            self.assertNotIn(TOKEN, path.read_text())
            self.assertNotIn(ACCOUNT, path.read_text())

    def test_bounded_requests_schema_and_private_input_never_start_worker(self):
        instance = self.instance()
        cases = [('', {}), ('n' * 4801, {}), ('<|im_start|>', {}), ('news\x00', {}),
                 ('news', {'language': 'fr'}), ('news', {'max_tokens': 321}),
                 ('news', {'max_tokens': True}), ('news', {'timeout': 181}),
                 ('news', {'timeout': float('nan')}), ('news', {'schema': {}}), (TOKEN, {})]
        for prompt, options in cases:
            with self.assertRaises(runtime.CloudLlmUnavailable):
                instance.generate(prompt, **options)
        self.assertIsNone(instance._worker)

    def test_complete_output_only_no_reasoning_tools_or_secrets(self):
        instance = self.instance()
        for value in (answer('', finish='stop'), answer('partial', finish='length'),
                      answer('<think>private reasoning</think>Answer'), answer(TOKEN),
                      answer(tokens=64), {'choices': []}, {'error': {'message': TOKEN}},
                      {'choices': [{'finish_reason': 'stop', 'message': {'tool_calls': [{'name': 'shell'}]}}]}):
            with patch.object(instance, '_request', return_value=value):
                with self.assertRaises(runtime.CloudLlmUnavailable):
                    instance._complete(self.job())
        with patch.object(instance, '_request', return_value=answer('تكلفة النفط قد تؤثر في توقعات التضخم.')):
            self.assertIn('النفط', instance._complete(self.job()))

    def test_response_byte_limit_and_malformed_usage_fail_closed(self):
        instance = self.instance()
        connection = FakeConnection(FakeResponse(b'x' * (runtime.MAX_RESPONSE_BYTES + 1)))
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'response-limit'):
                instance._request({}, self.job())
        for usage in ({}, {'prompt_tokens': True, 'completion_tokens': 12},
                      {'prompt_tokens': 20, 'completion_tokens': -1}):
            value = answer(); value['usage'] = usage
            with patch.object(instance, '_request', return_value=value):
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'invalid-usage'):
                    instance._complete(self.job())

    def test_daily_budget_persists_failures_counts_utf8_and_resets_only_next_utc_day(self):
        instance = self.instance()
        instance._clock = lambda: 1792886400  # 25 October 2026 UTC
        english = instance._reservation([{'content': 'a' * 40}], 64)
        arabic = instance._reservation([{'content': 'ع' * 40}], 64)
        self.assertGreater(arabic[0], english[0])
        with patch.object(instance, '_request', side_effect=runtime.CloudLlmUnavailable('rate-limited')):
            with self.assertRaises(runtime.CloudLlmUnavailable): instance._complete(self.job())
        spent = instance.status()['budget']['reservedEstimatedNeurons']
        self.assertGreater(spent, 0)
        other = self.instance(); other._clock = instance._clock
        other._reserve_budget(runtime.DAILY_ESTIMATED_NEURON_CAP - spent)
        with patch.object(other, '_request') as request:
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'daily-estimate-budget'):
                other._complete(self.job())
            request.assert_not_called()
        other._clock = lambda: instance._clock() + 86400
        other._reserve_budget(5)
        self.assertEqual(other.status()['budget']['reservedEstimatedNeurons'], 5)
        instance._clock = lambda: 1
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'budget-state-unavailable'):
            instance._reserve_budget(5)

    def test_corrupt_budget_and_state_inside_repository_are_fail_closed(self):
        instance = self.instance()
        instance._reserve_budget(5)
        (instance.directory / 'budget.json').write_text('{broken')
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'budget-state-unavailable'):
            instance._reserve_budget(5)
        instance.directory = Path(__file__).resolve().parent / 'must-never-be-created'
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'budget-state-unavailable'):
            instance._reserve_budget(5)
        self.assertFalse(instance.directory.exists())

    def test_source_root_protects_flat_docker_and_nested_checkout_on_both_operating_systems(self):
        flat = PurePosixPath('/app/cloudflare_llm_runtime.py')
        self.assertEqual(runtime._source_root(flat), PurePosixPath('/app'))
        self.assertIn(runtime._source_root(flat), PurePosixPath('/app/private-state').parents)
        self.assertNotIn(runtime._source_root(flat), PurePosixPath('/tmp/gold-radio-data').parents)
        checkout = PurePosixPath('/workspace/gold/deployment/render-radio/cloudflare_llm_runtime.py')
        self.assertEqual(runtime._source_root(checkout), PurePosixPath('/workspace/gold'))
        windows = PureWindowsPath(r'C:\build\gold-pulse-local-codex\deployment\render-radio\cloudflare_llm_runtime.py')
        self.assertEqual(runtime._source_root(windows), PureWindowsPath(r'C:\build\gold-pulse-local-codex'))
        self.assertEqual(runtime._source_root(PureWindowsPath(r'C:\app\cloudflare_llm_runtime.py')),
                         PureWindowsPath(r'C:\app'))

    def test_provider_usage_over_requested_limit_exhausts_local_day(self):
        instance = self.instance()
        with patch.object(instance, '_request', return_value=answer(tokens=65)):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'provider-usage-over-bound'):
                instance._complete(self.job())
        self.assertEqual(instance.status()['budget']['reservedEstimatedNeurons'], 5000)
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'daily-estimate-budget'):
            instance._reserve_budget(1)

    def test_single_active_one_pending_and_pause_discards_late_result(self):
        entered, release = threading.Event(), threading.Event()
        class Slow(runtime.CloudflareLlmRuntime):
            def _complete(self, job):
                entered.set(); release.wait(3)
                return 'late output'
        instance, results = self.instance(Slow), {}
        def call(name):
            try: results[name] = instance.generate(name, timeout=3)
            except runtime.CloudLlmUnavailable as error: results[name] = error.reason
        first = threading.Thread(target=call, args=('first',)); first.start()
        self.assertTrue(entered.wait(1))
        second = threading.Thread(target=call, args=('second',)); second.start()
        end = time.monotonic() + 1
        while instance._jobs.qsize() != 1 and time.monotonic() < end:
            time.sleep(.005)
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'busy'):
            instance.generate('third', timeout=1)
        start = time.monotonic(); instance.pause(seconds=1)
        self.assertLess(time.monotonic() - start, .1)
        first.join(1); second.join(1)
        self.assertEqual(results, {'first': 'speech-priority', 'second': 'speech-priority'})
        self.assertIsNone(instance.status()['lastGenerationAt'])
        release.set()
        instance.close()
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'disabled'):
            instance.generate('closed')

    def test_blocked_http_does_not_hold_status_or_pause_and_caller_deadline_is_bounded(self):
        entered, release = threading.Event(), threading.Event()
        connection = FakeConnection()
        def wait_response():
            entered.set(); release.wait(3)
            return connection.response
        connection.getresponse = wait_response
        instance, results = self.instance(), []
        def call():
            try: results.append(instance.generate('Public news', timeout=1))
            except runtime.CloudLlmUnavailable as error: results.append(error.reason)
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            caller = threading.Thread(target=call); caller.start()
            self.assertTrue(entered.wait(1))
            start = time.monotonic()
            self.assertTrue(instance.status()['preparing'])
            self.assertLess(time.monotonic() - start, .1)
            caller.join(1.5)
            self.assertEqual(results, ['timeout'])
            start = time.monotonic()
            instance.pause(seconds=1)
            instance.close()
            self.assertLess(time.monotonic() - start, .1)
            release.set()
            instance._worker.join(1)
        self.assertIsNone(instance.status()['lastGenerationAt'])


if __name__ == '__main__':
    unittest.main()

"""Bounded, cloud-owned Al Jazeera public live-update collection.

Only the reviewed news index and two public GraphQL operations are requested.
Publisher data is decoded and parsed, never executed. The returned rows are
headlines, not full articles. Original publication/receipt clocks and stable
post identities survive unchanged HTTP responses and source refreshes.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import hashlib
from html.parser import HTMLParser
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from news_speech import complete_prefix
from source_policy import collection_url_allowed

ORIGIN = 'https://www.aljazeera.com'
INDEX = ORIGIN + '/news/'
SOURCE = 'Al Jazeera · live update'
MAX_BYTES = 600_000
WINDOW_SECONDS = 600
PARENT_QUERY = 'query ArchipelagoSingleLiveBlogQuery($name:String!,$postType:String,$preview:StringOrBoolean){article:post(postName:$name,options:{postType:$postType,preview:$preview}){id link postType:type children childrenMeta{id publishedTime keyEvent} modified_gmt}}'
CHILD_QUERY = 'query LiveBlogUpdateQuery($postID:Int!,$postType:String!,$preview:StringOrBoolean,$isAmp:Boolean){posts:postByID(id:$postID,options:{postType:$postType,preview:$preview,isAmp:$isAmp}){id link postType:type title date modified_gmt content}}'
OPERATIONS = {'ArchipelagoSingleLiveBlogQuery': PARENT_QUERY, 'LiveBlogUpdateQuery': CHILD_QUERY}


@dataclass(frozen=True)
class Parent:
    id: int
    path: str
    name: str


@dataclass(frozen=True)
class Response:
    status: int
    headers: dict
    body: bytes
    url: str


def _integer(value):
    return type(value) is int and 0 < value < 2_147_483_648


def _parent_path(value):
    if not isinstance(value, str) or len(value) > 512:
        return None
    url = urllib.parse.urlsplit(urllib.parse.urljoin(ORIGIN, value))
    if (url.scheme != 'https' or url.netloc != 'www.aljazeera.com' or
            url.username or url.password or url.query or url.fragment or
            not re.fullmatch(r'/news/liveblog/20\d{2}/\d{1,2}/\d{1,2}/[a-z0-9-]+/?', url.path)):
        return None
    return url.path.rstrip('/')


class _IndexData(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.inside = False
        self.parts = []
        self.payloads = []

    def handle_starttag(self, tag, attrs):
        if tag == 'script':
            self.inside, self.parts = True, []

    def handle_data(self, data):
        if self.inside:
            self.parts.append(data)

    def handle_endtag(self, tag):
        if tag == 'script' and self.inside:
            value = ''.join(self.parts)
            match = re.fullmatch(r'\s*window\.__APOLLO_STATE__\s*=\s*"([A-Za-z0-9+/=]{1,600000})"\s*;?\s*', value)
            if match:
                self.payloads.append(match.group(1))
            self.inside, self.parts = False, []


class _Plain(HTMLParser):
    BLOCKED = {'script', 'style', 'noscript', 'iframe'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.hidden, self.parts = [], []

    def handle_starttag(self, tag, attrs):
        if tag in self.BLOCKED:
            self.hidden.append(tag)
        elif not self.hidden:
            self.parts.append(' ')

    def handle_endtag(self, tag):
        if self.hidden:
            if tag == self.hidden[-1]:
                self.hidden.pop()
        else:
            self.parts.append(' ')

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def _plain(value, limit):
    if not isinstance(value, str) or len(value) > 200_000:
        raise ValueError('Invalid publisher text')
    parser = _Plain()
    parser.feed(value)
    text = re.sub(r'https?://\S+|www\.\S+', '', ''.join(parser.parts), flags=re.I)
    text = re.sub(r'\s+', ' ', text).strip()
    if re.search(r'[\x00-\x1f\x7f]', text):
        raise ValueError('Invalid publisher controls')
    return complete_prefix(text, limit)


def discover_parent(body, now_s):
    if not isinstance(body, bytes) or len(body) > MAX_BYTES or b'\x00' in body:
        raise ValueError('Publisher body limit')
    parser = _IndexData()
    parser.feed(body.decode('utf-8', errors='strict'))
    if len(parser.payloads) != 1:
        raise ValueError('Publisher index data missing or ambiguous')
    encoded = parser.payloads[0]
    decoded = base64.b64decode(encoded, validate=True)
    if base64.b64encode(decoded).decode('ascii') != encoded:
        raise ValueError('Invalid publisher data encoding')
    data = json.loads(decoded.decode('utf-8', errors='strict'))
    if (not isinstance(data, dict) or len(data) > 2000 or
            not isinstance(data.get('ROOT_QUERY'), dict) or data['ROOT_QUERY'].get('__typename') != 'Query'):
        raise ValueError('Invalid publisher index data')
    posts = [v for v in data.values() if isinstance(v, dict) and v.get('__typename') == 'Post']
    if not posts:
        raise ValueError('Publisher posts missing')
    for post in posts:
        if post.get('type') != 'liveblog' or post.get('isLive') is not True:
            continue
        path, raw_id = _parent_path(post.get('link')), post.get('id')
        if not path or not isinstance(raw_id, str) or not re.fullmatch(r'\d{1,10}', raw_id) or not _integer(int(raw_id)):
            raise ValueError('Invalid active publisher identity')
        date = re.match(r'/news/liveblog/(\d{4})/(\d{1,2})/(\d{1,2})/', path)
        start = datetime(*(int(v) for v in date.groups()), tzinfo=timezone.utc).timestamp()
        if start <= now_s and now_s - start <= 2 * 86400:
            return Parent(int(raw_id), path, path.rsplit('/', 1)[-1])
    return None


def parse_children(data, parent, now_s):
    if not isinstance(data, dict) or data.get('errors') or not isinstance(data.get('data'), dict):
        raise ValueError('Invalid publisher parent')
    row = data['data'].get('article')
    if (not isinstance(row, dict) or str(row.get('id')) != str(parent.id) or
            _parent_path(row.get('link')) != parent.path or row.get('postType') != 'liveblog'):
        raise ValueError('Publisher parent identity mismatch')
    children, metadata = row.get('children'), row.get('childrenMeta')
    if (not isinstance(children, list) or not isinstance(metadata, list) or len(children) > 500 or
            len(metadata) != len(children) or not all(_integer(v) for v in children) or len(set(children)) != len(children)):
        raise ValueError('Invalid publisher child identities')
    allowed, seen, result = set(children), set(), []
    for meta in metadata:
        if (not isinstance(meta, dict) or not isinstance(meta.get('id'), str) or
                not re.fullmatch(r'\d{1,10}', meta['id']) or not isinstance(meta.get('publishedTime'), str) or
                not re.fullmatch(r'\d{10}', meta['publishedTime'])):
            raise ValueError('Invalid publisher child clock')
        key, stamp = int(meta['id']), int(meta['publishedTime'])
        if key not in allowed or key in seen or stamp < 946684800 or stamp > now_s + 86400:
            raise ValueError('Invalid publisher child metadata')
        seen.add(key)
        if stamp <= now_s and now_s - stamp <= 86400:
            result.append({'id': key, 'publishedAt': stamp})
    if seen != allowed:
        raise ValueError('Missing publisher child metadata')
    return sorted(result, key=lambda v: (v['publishedAt'], v['id']), reverse=True)


def parse_update(data, parent, meta, received_s, startup):
    if not isinstance(data, dict) or data.get('errors') or not isinstance(data.get('data'), dict):
        raise ValueError('Invalid publisher update')
    row = data['data'].get('posts')
    expected = datetime.fromtimestamp(meta['publishedAt'], timezone.utc).isoformat()[:19]
    if (not isinstance(row, dict) or str(row.get('id')) != str(meta['id']) or
            _parent_path(row.get('link')) != parent.path or row.get('postType') != 'liveblog-update' or
            row.get('date') != expected or meta['publishedAt'] > received_s):
        raise ValueError('Publisher update identity or clock mismatch')
    title = _plain(row.get('title'), 230)
    # Retain only a small retrieved teaser. The announcer's combined title and
    # teaser word budget is enforced separately; full article text is omitted.
    summary = _plain(row.get('content'), 400)
    if not title or not summary:
        raise ValueError('Publisher update text missing')
    return {'id': hashlib.sha256(('aljazeera-live:' + str(meta['id'])).encode('ascii')).hexdigest()[:32],
            'title': title, 'summary': summary, 'source': SOURCE, 'language': 'en',
            'url': ORIGIN + parent.path + '?update=' + str(meta['id']),
            'publishedAt': meta['publishedAt'], 'firstSeenAt': received_s,
            'startupBackfill': bool(startup)}


def _graph(operation, variables):
    return ORIGIN + '/graphql?' + urllib.parse.urlencode({'wp-site': 'aje', 'operationName': operation,
        'variables': json.dumps(variables, separators=(',', ':')), 'query': OPERATIONS[operation]})


def _allowed_url(url):
    if url == INDEX:
        return True
    try:
        parsed = urllib.parse.urlsplit(url)
        if (parsed.scheme != 'https' or parsed.netloc != 'www.aljazeera.com' or
                parsed.path != '/graphql' or parsed.fragment):
            return False
        query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True, strict_parsing=True, max_num_fields=4)
        if set(query) != {'wp-site', 'operationName', 'variables', 'query'} or any(len(v) != 1 for v in query.values()):
            return False
        operation = query['operationName'][0]
        if query['wp-site'] != ['aje'] or query['query'] != [OPERATIONS.get(operation)]:
            return False
        variables = json.loads(query['variables'][0])
        if not isinstance(variables, dict) or variables.get('preview') != '':
            return False
        if operation == 'ArchipelagoSingleLiveBlogQuery':
            return (set(variables) == {'name', 'postType', 'preview'} and variables['postType'] == 'liveblog' and
                    isinstance(variables['name'], str) and bool(re.fullmatch('[a-z0-9-]{1,256}', variables['name'])))
        return (operation == 'LiveBlogUpdateQuery' and set(variables) == {'postID', 'postType', 'preview', 'isAmp'} and
                _integer(variables['postID']) and variables['postType'] == 'liveblog-update' and variables['isAmp'] is False)
    except (ValueError, TypeError, KeyError):
        return False


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_):
        return None


def fetch_public(url, headers, timeout):
    if not _allowed_url(url) or not collection_url_allowed(url):
        raise ValueError('Unsupported publisher request')
    request = urllib.request.Request(url, headers=headers)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    deadline = time.monotonic() + timeout
    try:
        response = opener.open(request, timeout=timeout)
    except urllib.error.HTTPError as error:
        # 304 and denial/rate-limit statuses are data for the cache/backoff code.
        return Response(error.code, dict(error.headers.items()), b'', url)
    with response:
        values = {k.lower(): v for k, v in response.headers.items()}
        size = values.get('content-length')
        if (values.get('content-encoding', 'identity') != 'identity' or
                size and (not size.isdecimal() or int(size) > MAX_BYTES)):
            raise ValueError('Publisher body limit')
        parts, size = [], 0
        # read1 avoids waiting to fill the complete advertised body while an
        # origin slowly trickles data. Check the shared request budget between
        # bounded reads as well as using the network's socket timeout.
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Publisher collection time limit')
            chunk = response.read1(min(65536, MAX_BYTES + 1 - size))
            if not chunk:
                break
            parts.append(chunk)
            size += len(chunk)
            if size > MAX_BYTES:
                raise ValueError('Publisher body limit')
        body = b''.join(parts)
        return Response(response.status, values, body, response.url)


def _cache_seconds(headers, minimum):
    match = re.search(r'(?:^|,)\s*max-age=(\d{1,8})(?:\s*,|\s*$)', headers.get('cache-control', ''), re.I)
    seconds = int(match.group(1)) if match else minimum
    if seconds > 86400:
        raise ValueError('Publisher cache interval exceeds supported bound')
    return max(minimum, seconds)


def _etag(headers):
    value = headers.get('etag')
    if value is None:
        return None
    if len(value) > 256 or re.search(r'[\x00-\x1f\x7f]', value):
        raise ValueError('Invalid publisher cache tag')
    return value


class _HttpUnavailable(Exception):
    def __init__(self, status, headers):
        self.status, self.headers = status, headers


class LiveUpdateCollector:
    def __init__(self, fetcher=None):
        self._fetcher = fetcher or fetch_public
        self._lock = threading.RLock()
        self._parent = None
        self._children, self._startup_ids, self._posts = [], set(), {}
        self._index_etag = self._parent_etag = None
        self._next_check = self._next_discovery = self._last_checked = self._last_success = 0
        self._failures, self._status, self._last_http = 0, 'starting', None

    def status(self):
        with self._lock:
            return {'status': self._status, 'checkedAt': self._last_checked * 1000,
                    'lastSuccessAt': self._last_success * 1000, 'nextCheckAt': self._next_check * 1000,
                    'activeLiveblog': self._parent is not None, 'cachedUpdates': len(self._posts),
                    'httpStatus': self._last_http, 'transport': 'Cloud HTTPS; fixed public publisher'}

    def _request(self, url, etag, json_body, deadline):
        if not _allowed_url(url):
            raise ValueError('Unsupported publisher request')
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Publisher collection time limit')
        headers = {'User-Agent': 'GoldPulse/1.0 public-news-collector',
                   'Accept': 'application/json' if json_body else 'text/html', 'Accept-Encoding': 'identity'}
        if etag:
            headers['If-None-Match'] = etag
        if json_body:
            headers.update({'wp-site': 'aje', 'original-domain': 'www.aljazeera.com'})
        response = self._fetcher(url, headers, min(8, remaining))
        if time.monotonic() > deadline:
            raise TimeoutError('Publisher collection time limit')
        if (not isinstance(response, Response) or response.url != url or not isinstance(response.body, bytes) or
                len(response.body) > MAX_BYTES):
            raise ValueError('Invalid publisher response')
        values = {k.lower(): v for k, v in response.headers.items()}
        self._last_http = response.status
        if response.status == 304:
            if not etag:
                raise ValueError('Uncached publisher response')
            return values, None
        if response.status != 200:
            raise _HttpUnavailable(response.status, values)
        expected = 'application/json' if json_body else 'text/html'
        if expected not in values.get('content-type', '').lower() or b'\x00' in response.body:
            raise ValueError('Unexpected publisher content type')
        return values, json.loads(response.body.decode('utf-8', errors='strict')) if json_body else response.body

    def collect(self, now_s=None):
        with self._lock:
            now_s = int(time.time()) if now_s is None else now_s
            if type(now_s) is not int or now_s <= 0:
                raise ValueError('A valid collection clock is required')
            if now_s < self._next_check:
                return []
            started, deadline = time.monotonic(), time.monotonic() + 8
            clock = lambda: now_s + int(time.monotonic() - started)
            self._last_checked = now_s
            try:
                parent, children, posts = self._parent, list(self._children), dict(self._posts)
                startup = set(self._startup_ids)
                index_etag, parent_etag = self._index_etag, self._parent_etag
                next_discovery = self._next_discovery
                changed_parent = False
                if now_s >= next_discovery:
                    headers, body = self._request(INDEX, index_etag, False, deadline)
                    next_discovery = clock() + _cache_seconds(headers, 240)
                    if body is not None:
                        discovered = discover_parent(body, clock())
                        changed_parent = discovered != parent
                        parent, index_etag = discovered, _etag(headers)
                        if changed_parent:
                            children, startup, posts, parent_etag = [], set(), {}, None
                interval = 60
                if parent:
                    url = _graph('ArchipelagoSingleLiveBlogQuery', {'name': parent.name, 'postType': 'liveblog', 'preview': ''})
                    headers, body = self._request(url, parent_etag, True, deadline)
                    interval = _cache_seconds(headers, 60)
                    if body is not None:
                        children = parse_children(body, parent, clock())
                        parent_etag = _etag(headers)
                        if changed_parent or self._parent is None:
                            startup = {meta['id'] for meta in children}
                    current = [m for m in children if 0 <= clock() - m['publishedAt'] <= WINDOW_SECONDS][:12]
                    wanted = ([m for m in current if m['id'] not in posts] +
                              [m for m in current if m['id'] in posts][:2])[:3]
                    for meta in wanted:
                        old = posts.get(meta['id'])
                        url = _graph('LiveBlogUpdateQuery', {'postID': meta['id'], 'postType': 'liveblog-update', 'preview': '', 'isAmp': False})
                        headers, body = self._request(url, old['etag'] if old else None, True, deadline)
                        if body is not None:
                            item = parse_update(body, parent, meta, clock(), meta['id'] in startup)
                            if old:
                                if old['item']['publishedAt'] != item['publishedAt']:
                                    raise ValueError('Changed publisher update clock')
                                item['firstSeenAt'] = old['item']['firstSeenAt']
                                item['startupBackfill'] = old['item']['startupBackfill']
                            posts[meta['id']] = {'etag': _etag(headers), 'item': item}
                        elif not old or old['item']['publishedAt'] != meta['publishedAt']:
                            raise ValueError('Uncached or incompatible publisher update')
                    posts = {m['id']: posts[m['id']] for m in current if m['id'] in posts}
                else:
                    interval = max(60, next_discovery - clock())
                    children, startup, posts = [], set(), {}
                # Publish state atomically. Partial, malformed or denied fetches
                # cannot refresh receipts or add an unverified headline.
                self._parent, self._children, self._posts, self._startup_ids = parent, children, posts, startup
                self._index_etag, self._parent_etag = index_etag, parent_etag
                self._next_discovery, self._next_check = next_discovery, clock() + interval
                self._last_success, self._failures, self._status = clock(), 0, 'ready'
                return [dict(p['item']) for p in posts.values()
                        if 0 <= clock() - p['item']['publishedAt'] <= WINDOW_SECONDS]
            except Exception as error:
                self._failures += 1
                status = error.status if isinstance(error, _HttpUnavailable) else None
                wait = 3600 if status in (401, 403) else min(1800, 60 * 2 ** min(self._failures, 8))
                if isinstance(error, _HttpUnavailable):
                    retry = error.headers.get('retry-after', '')
                    try:
                        delay = int(retry) if retry.isdecimal() else int(parsedate_to_datetime(retry).timestamp()) - clock()
                        wait = max(wait, min(86400, max(0, delay)))
                    except (ValueError, TypeError, OverflowError):
                        pass
                self._next_check = clock() + wait
                self._status = 'access_denied' if status in (401, 403) else 'rate_limited' if status == 429 else 'unavailable'
                return []

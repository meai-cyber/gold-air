"""Server-owned broadcast speech. Never expose this as a public synthesis API.

Arabic2 is resident Nabra FP32 CPU inference with matching offline G2P/vowels.
English supports pinned Phonon 40M CPU, with the existing network voice fallback.
"""
from __future__ import annotations
import asyncio
from dataclasses import dataclass
import gc
import hashlib
import importlib.util
import io
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
import wave

from bootstrap import VOWEL_FILES
from radio_nabra_tts import NabraNativeArabicTts
from station_cast import NEWS_ENGLISH_VOICE, cast_metadata, get_cast_voice, network_voice_allowed


@dataclass(frozen=True)
class Speech:
    wav: bytes
    duration_s: float
    engine: str
    language: str
    inference_s: float
    first_chunk_s: float | None = None
    cast: dict | None = None


def public_text(text, language):
    if not isinstance(text, str) or not 1 <= len(text) <= 1200 or language not in {"ar", "en"}:
        raise ValueError("A bounded public news bulletin is required")
    text = unicodedata.normalize("NFKC", text)
    if any(unicodedata.category(c) in {"Cc", "Cf"} and c not in "\n\r\t" for c in text):
        raise ValueError("Speech control characters are unsupported")
    text = " ".join(text.split())
    if (not text or re.search(r"[<>]|(?:https?://|[A-Za-z]:\\|/Users/|/home/|Bearer\s+)", text, re.I)
            or (language == "ar" and not re.search(r"[\u0621-\u064a]", text))
            or (language == "en" and any(c.isalpha() and "LATIN" not in unicodedata.name(c, "") for c in text))):
        raise ValueError("Unsupported plain public speech text")
    return text


def _vowels(root):
    import onnxruntime as ort
    directory = root / "tashkeel"
    for name, digest in VOWEL_FILES.items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != digest:
            raise ValueError("Changed Arabic vowel resource")
    spec = importlib.util.spec_from_file_location("_gold_pinned_tashkeel", directory / "__init__.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    def session(model):
        options = ort.SessionOptions()
        options.intra_op_num_threads = options.inter_op_num_threads = 1
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        options.add_session_config_entry("session.intra_op.allow_spinning", "0")
        return ort.InferenceSession(str(model), sess_options=options, providers=["CPUExecutionProvider"])
    module.InferenceSession = session
    return module.TashkeelDiacritizer(directory)


def pcm_wav(data):
    """ffmpeg's pipe WAV uses open-ended length fields: rewrite actual frames."""
    with wave.open(io.BytesIO(data), "rb") as audio:
        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate()) != (1, 2, 24000):
            raise ValueError("Unexpected English audio format")
        raw = audio.readframes(24000 * 90 + 1)
    frames = len(raw) // 2
    if len(raw) % 2 or not 0 < frames <= 24000 * 90 or not any(raw):
        raise ValueError("English audio is empty or exceeds its bound")
    result = io.BytesIO()
    with wave.open(result, "wb") as audio:
        audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
        audio.writeframes(raw)
    return result.getvalue(), frames / 24000


def _container_free_below(mebibytes):
    """Use the bounded Linux container quota, never the Windows host's RAM."""
    if not sys.platform.startswith("linux"):
        return False
    from phonon_runtime import container_memory
    budget = container_memory()
    if (not isinstance(budget, tuple) or len(budget) != 2 or
            any(type(value) is not int for value in budget) or
            not 0 < budget[0] <= budget[1] < 16 * 1024 ** 3):
        return False
    return budget[1] - budget[0] < mebibytes * 1024 ** 2


def _release_model_memory():
    """Release unused native model arenas after closing the other voice."""
    gc.collect()
    if sys.platform.startswith("linux"):
        try:
            import ctypes
            trim = getattr(ctypes.CDLL(None), "malloc_trim", None)
            if trim is not None:
                trim.argtypes = [ctypes.c_size_t]
                trim.restype = ctypes.c_int
                trim(0)
        except Exception:
            # Non-glibc Linux builds need only normal object collection.
            pass


class ServerTts:
    available_languages = ("ar", "en")
    engines = {"ar": "nabra7m-fp32-native-cpu", "en": "edge-network-jenny"}

    def __init__(self, runtime_dir=None):
        self.root = Path(runtime_dir or os.environ.get("RADIO_MODEL_DIR", "/opt/gold-radio-assets")).resolve()
        self.lock = threading.Lock()
        self.network_lock = threading.Lock()
        self.cast_arabic_lock = threading.Lock()
        self.arabic = None
        self.english = None
        self.english_disabled = False
        self.english_failure = None
        self.phonon_enabled = os.environ.get('RADIO_ENGLISH_TTS') == 'phonon40'
        self.engines = dict(type(self).engines)
        if self.phonon_enabled:
            self.engines['en'] = 'phonon40m-q8-native-cpu'
        self.ffmpeg = shutil.which("ffmpeg")
        self.node = shutil.which("node")
        if not self.node or not self.ffmpeg:
            raise RuntimeError("The server speech dependencies are unavailable")
        self.diacritizer = _vowels(self.root)

    @property
    def english_native_policy(self):
        return 'short-complete-bulletins' if self.phonon_enabled else 'off'

    def _arabic(self, text):
        if self.arabic is None:
            self.arabic = NabraNativeArabicTts(str(Path(self.node).resolve()), self.root,
                precision="fp32", threads=1, timeout=60, diacritizer=self.diacritizer)
        try:
            value = self.arabic.synthesize(text)
            return Speech(value.wav, value.duration_s, self.engines["ar"], "ar", value.inference_s)
        except Exception:
            self.arabic.close()
            self.arabic = None
            raise

    async def _edge(self, text):
        return await self._edge_voice(text, NEWS_ENGLISH_VOICE, '+0%')

    async def _edge_voice(self, text, voice, rate):
        if not network_voice_allowed(voice, rate):
            raise ValueError('Unsupported fixed network voice')
        import edge_tts
        output = bytearray()
        async def collect():
            # Only owner-defined cast profiles select these fixed voices/rates.
            # Feed text never selects a host, model, voice, pitch or file.
            async for part in edge_tts.Communicate(text, voice, rate=rate).stream():
                if part["type"] == "audio":
                    output.extend(part["data"])
                    if len(output) > 2_000_000:
                        raise ValueError("Network speech exceeds its byte bound")
        await asyncio.wait_for(collect(), timeout=35)
        return bytes(output)

    def _network_audio(self, compressed):
        result = subprocess.run([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
            "-protocol_whitelist", "pipe", "-f", "mp3", "-i", "pipe:0", "-vn", "-threads", "1",
            "-ac", "1", "-ar", "24000", "-t", "90.05", "-c:a", "pcm_s16le", "-f", "wav", "pipe:1"],
            input=compressed, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=20, check=True)
        return pcm_wav(result.stdout)

    def _cast_network(self, text, language, started, profile):
        selected = get_cast_voice(language, profile)
        # Each language keeps one network production slot. A genuine Arabic
        # male/female cast request never reloads or impersonates the news voice.
        lock = self.network_lock if language == 'en' else self.cast_arabic_lock
        with lock:
            compressed = asyncio.run(self._edge_voice(text, selected.voice, selected.rate))
            data, duration = self._network_audio(compressed)
            return Speech(data, duration, selected.engine, language, time.perf_counter() - started,
                          cast=cast_metadata(language, profile))

    def _english_network(self, text, started):
        # One bounded English request at a time. With native English disabled,
        # its network wait can overlap the separate Arabic CPU producer.
        with self.network_lock:
            self.engines['en'] = 'edge-network-jenny'
            compressed = asyncio.run(self._edge(text))
            data, duration = self._network_audio(compressed)
            return Speech(data, duration, self.engines['en'], 'en', time.perf_counter() - started)

    def synthesize(self, text, language="ar", voice_profile=None):
        text = public_text(text, language)
        started = time.perf_counter()
        if voice_profile is not None:
            # Cast requests fail rather than silently using the wrong person.
            get_cast_voice(language, voice_profile)
            return self._cast_network(text, language, started, voice_profile)
        if language == 'en' and not self.phonon_enabled:
            return self._english_network(text, started)
        with self.lock:
            if language == "ar":
                if self.english is not None and _container_free_below(160):
                    self.english.close()
                    self.english = None
                    _release_model_memory()
                return self._arabic(text)
            # The free CPU instance cannot finish long native reports inside
            # its deadline. Route the full item directly to the existing voice;
            # a size decision is not a native failure and never disables it.
            if (self.phonon_enabled and not self.english_disabled and
                    len(text) <= 120 and len(text.split()) <= 22):
                from phonon_runtime import PhononEnglishTts
                try:
                    if self.arabic is not None and _container_free_below(320):
                        self.arabic.close()
                        self.arabic = None
                        _release_model_memory()
                    if self.english is None:
                        self.english = PhononEnglishTts(self.root / 'phonon40')
                    speech = self.english.synthesize(text)
                    self.engines['en'] = 'phonon40m-q8-native-cpu'
                    return Speech(speech.wav, speech.duration_s, self.engines['en'], 'en',
                                  speech.inference_s, speech.first_chunk_s)
                except Exception as error:
                    # A native failure must not make both news channels wait
                    # through repeated reloads. Keep the working voice on air.
                    if self.english is not None:
                        self.english.close()
                        self.english = None
                    self.english_disabled = True
                    reason = getattr(error, 'reason', 'native-error')
                    self.english_failure = reason if isinstance(reason, str) and reason in {
                        'memory-start', 'memory-pressure', 'timeout', 'native-error',
                        'worker-failed', 'initialization', 'generation'} else 'native-error'
            return self._english_network(text, started)

    def close(self):
        if self.english:
            self.english.close()
            self.english = None
        if self.arabic:
            self.arabic.close()
            self.arabic = None

"""Waiting-bed audio contracts; these do not claim subjective listening quality."""
import io
import unittest
import wave

import numpy as np

from station_music import compose, MUSIC_FILE, MUSIC_SECONDS


class StationMusicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = compose()
        with wave.open(io.BytesIO(cls.data), 'rb') as audio:
            cls.params = audio.getparams()
            cls.pcm = np.frombuffer(audio.readframes(audio.getnframes()), dtype='<i2')

    def test_long_bounded_mono_pcm_asset(self):
        self.assertNotEqual(MUSIC_FILE, 'station-bed-v1.wav')
        self.assertEqual(self.params.nchannels, 1)
        self.assertEqual(self.params.sampwidth, 2)
        self.assertEqual(self.params.framerate, 24000)
        self.assertEqual(self.params.nframes, 24000 * MUSIC_SECONDS)
        self.assertGreaterEqual(MUSIC_SECONDS, 90)
        self.assertLess(len(self.data), 8 * 1024 * 1024)

    def test_smooth_loop_edges_and_peak_headroom(self):
        samples = self.pcm.astype(np.float64) / 32768
        self.assertLessEqual(np.max(np.abs(samples)), .301)
        self.assertLess(abs(samples[0]), .0001)
        self.assertLess(abs(samples[-1]), .0001)
        self.assertLess(np.max(np.abs(samples[:240])), .01)
        self.assertLess(np.max(np.abs(samples[-240:])), .01)
        self.assertLess(abs(float(np.mean(samples))), .001)

    def test_music_has_continuing_changing_tonal_energy(self):
        # Every interior second contains music, with gentle variation in level.
        seconds = self.pcm.astype(np.float64).reshape(MUSIC_SECONDS, 24000) / 32768
        rms = np.sqrt(np.mean(seconds ** 2, axis=1))
        self.assertGreater(float(np.min(rms[1:-1])), .01)
        self.assertGreater(float(np.std(rms[1:-1])), .002)
        # A pitched signal concentrates energy into note bands instead of hiss.
        chunk = seconds[4:8].ravel()
        spectrum = np.abs(np.fft.rfft(chunk * np.hanning(len(chunk)))) ** 2
        frequencies = np.fft.rfftfreq(len(chunk), 1 / 24000)
        self.assertLess(float(np.sum(spectrum[frequencies > 6000]) / np.sum(spectrum)), .001)
        strongest = np.sort(spectrum)[-40:]
        self.assertGreater(float(np.sum(strongest) / np.sum(spectrum)), .65)


if __name__ == '__main__':
    unittest.main()

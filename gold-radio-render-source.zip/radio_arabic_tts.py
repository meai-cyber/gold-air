"""Portable bounded PCM contract for the server's Nabra CPU reader."""
from dataclasses import dataclass
import io
import re
import unicodedata
import wave


@dataclass(frozen=True)
class ArabicSpeech:
    wav: bytes
    duration_s: float
    inference_s: float
    voice: str = "Nabra MSA"
    language: str = "ar"
    engine: str = "nabra7m-fp32-native-cpu-local-v1"


def validate_text(text):
    if not isinstance(text, str) or not 1 <= len(text) <= 1200:
        raise ValueError("A bounded Arabic bulletin is required")
    if any(unicodedata.category(c) in {"Cc", "Cf"} and c not in "\n\r\t" for c in text):
        raise ValueError("Unsupported speech control characters")
    clean = " ".join(text.split())
    if not re.search(r"[\u0621-\u064a\u066e-\u06d3]", clean) or re.search(r"[<>]", clean):
        raise ValueError("Plain Arabic speech is required")
    return clean


def convert_wav(data):
    if not isinstance(data, bytes) or not 44 < len(data) <= 4_321_000:
        raise ValueError("Invalid Arabic speech bytes")
    with wave.open(io.BytesIO(data), "rb") as audio:
        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate(), audio.getcomptype()) != (1, 2, 24000, "NONE"):
            raise ValueError("Arabic speech must be mono PCM16 at 24 kHz")
        frames = audio.getnframes()
        raw = audio.readframes(frames)
        if not 0 < frames / 24000 <= 90 or len(raw) != frames * 2 or not any(raw):
            raise ValueError("Empty or incomplete Arabic speech")
    return data, frames / 24000

import unittest

from news_speech import public_report_text


class CompleteNewsSpeechTests(unittest.TestCase):
    def story(self, **changes):
        return {'title': 'Gold prices rise', 'source': 'Public publisher', 'language': 'en',
                'publishedAt': 1792666860, **changes}

    def test_long_arabic_title_preserves_the_last_word_after_twenty_four(self):
        title = ('قال وزير الاقتصاد إن الأسواق تتابع اليوم تطورات أسعار الذهب والنفط والعملات '
                 'مع استمرار المحادثات الدولية وتراجع التوترات السياسية وزيادة الطلب على المعادن '
                 'الثمينة في الأسواق الآسيوية والأوروبية وانتظار بيانات التضخم الجديدة غداً')
        self.assertGreater(len(title.split()), 24)
        spoken = public_report_text(self.story(title=title, source='الجزيرة', language='ar'))
        self.assertIn(title, spoken)
        self.assertTrue(spoken.endswith('غداً.'))

    def test_full_english_title_keeps_quote_and_question_punctuation(self):
        title = 'Why did the minister ask, "Will the latest economic figures change the outlook for gold, oil, currencies and interest rates in the next few coming months?"'
        self.assertGreater(len(title.split()), 24)
        spoken = public_report_text(self.story(title=title))
        self.assertEqual(spoken, 'From Public publisher: ' + title)
        self.assertNotIn('".', spoken)

    def test_whole_summary_sentences_added_but_unfinished_tail_omitted(self):
        spoken = public_report_text(self.story(summary='Investors awaited the data. Oil rose 2.5%. The minister said that the'))
        self.assertIn('Investors awaited the data. Oil rose 2.5%.', spoken)
        self.assertNotIn('The minister said', spoken)

    def test_duplicate_title_prefix_removed_and_complete_summary_retained(self):
        spoken = public_report_text(self.story(summary='Gold prices rise. U.S. Treasury yields declined. Traders watched the next release.'))
        self.assertEqual(spoken.count('Gold prices rise'), 1)
        self.assertIn('U.S. Treasury yields declined.', spoken)
        self.assertIn('Traders watched the next release.', spoken)

    def test_extended_title_sentence_not_reduced_to_fragment(self):
        spoken = public_report_text(self.story(summary='Gold prices rise by two percent as yields fall.'))
        self.assertIn('Gold prices rise by two percent as yields fall.', spoken)
        self.assertNotIn('. by two percent', spoken)

    def test_abbreviations_quotes_decimals_and_comma_are_not_sentence_cuts(self):
        spoken = public_report_text(self.story(summary='Dr. Ali said the U.S. rate was 3.5%, and added "more data will follow." An unfinished clause, with no ending'))
        self.assertIn('Dr. Ali said the U.S. rate was 3.5%, and added "more data will follow."', spoken)
        self.assertNotIn('An unfinished', spoken)

    def test_arabic_teaser_has_complete_sentences_without_dangling_tail(self):
        spoken = public_report_text(self.story(title='أسعار الذهب اليوم', source='العربية', language='ar',
            summary='ارتفعت أسعار الذهب مع تراجع الدولار. ماذا ينتظر المستثمرون؟ وأشار الوزير إلى أن'))
        self.assertIn('ارتفعت أسعار الذهب مع تراجع الدولار. ماذا ينتظر المستثمرون؟', spoken)
        self.assertNotIn('وأشار الوزير', spoken)

    def test_source_body_is_bounded_without_cutting_title_or_sentence(self):
        title = 'Gold ' + 'markets ' * 45
        summary = 'A complete report ' + 'adds ' * 65 + 'detail. ' + 'Another whole sentence ' * 20 + 'ends.'
        spoken = public_report_text(self.story(title=title.strip(), summary=summary))
        self.assertIn(title.strip(), spoken)
        self.assertIn('detail.', spoken)
        self.assertNotIn('Another', spoken)
        self.assertLessEqual(len(spoken.removeprefix('From Public publisher: ')), 801)

    def test_markup_urls_and_controls_are_not_spoken(self):
        spoken = public_report_text(self.story(title='<b>Gold</b> rises https://example.org/a',
            source='<i>Publisher</i>', summary='<script>not a news report</script><p>Markets recovered.</p>\x00'))
        self.assertEqual(spoken, 'From Publisher: Gold rises. Markets recovered.')

    def test_earlier_publisher_and_social_prefixes_keep_original_utc_clock(self):
        report = public_report_text(self.story(recency='earlier'))
        self.assertTrue(report.startswith('Earlier report, published at 11:01 UTC. From Public publisher:'))
        post = public_report_text(self.story(recency='earlier', social=True, language='ar', source='العربية', title='ارتفاع سعر الذهب'))
        self.assertTrue(post.startswith('منشور سابق، وقته حسب المصدر 11:01 بالتوقيت العالمي. في منشور عام من العربية،'))

    def test_oversized_titles_fail_instead_of_chopping_a_word(self):
        with self.assertRaises(ValueError):
            public_report_text(self.story(title='a' * 401))
        with self.assertRaises(ValueError):
            public_report_text(self.story(recency='earlier', publishedAt=True))


if __name__ == '__main__':
    unittest.main()

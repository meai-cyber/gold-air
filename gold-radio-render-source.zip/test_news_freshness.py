import copy
import unittest

from news_freshness import (
    MAX_NEWS_AGE_S, PUBLISHER_CLOCK_BASIS, is_fresh_news, validated_news_publication,
)
from social_sources import SOURCES


NOW = 1792935000


def rss(**changes):
    published = NOW - 30
    return {
        'id': 'a' * 32, 'title': 'Gold markets respond to economic uncertainty',
        'source': 'BBC', 'url': 'https://www.bbc.com/news/example', 'language': 'en',
        'sourceKind': 'publisher-rss', 'social': False,
        'publishedAt': published, 'originalPublishedAt': published, 'firstSeenAt': NOW - 5,
        'clockBasis': PUBLISHER_CLOCK_BASIS, 'publicationField': 'pubdate',
        'originalPublicationVerified': True, **changes,
    }


def social(**changes):
    source = SOURCES[0]
    return {
        'id': 'b' * 32, 'title': 'A public publisher post about gold markets',
        'source': source.source, 'language': 'en',
        'url': 'https://bsky.app/profile/' + source.did + '/post/abc123',
        'publishedAt': NOW - 20, 'firstSeenAt': NOW - 4,
        'social': True, 'sourceKind': 'social', 'platform': 'Bluesky',
        'clockBasis': 'author-reported', 'timeKind': 'published',
        'verification': 'unverified-public-post', **changes,
    }


class NewsFreshnessTests(unittest.TestCase):
    def test_only_original_publisher_publication_fields_admit_news(self):
        for field in ('pubdate', 'published'):
            with self.subTest(field=field):
                row = rss(publicationField=field)
                original = copy.deepcopy(row)
                self.assertEqual(validated_news_publication(row, NOW), NOW - 30)
                self.assertTrue(is_fresh_news(row, NOW))
                self.assertEqual(row, original)
        for field in ('updated', 'modified', 'date', 'firstseen', 'PUBDATE', None, True):
            with self.subTest(field=field):
                self.assertIsNone(validated_news_publication(rss(publicationField=field), NOW))

    def test_fifteen_hour_original_is_not_renewed_by_update_or_receipt(self):
        old = NOW - 15 * 3600
        self.assertFalse(is_fresh_news(rss(publishedAt=old, originalPublishedAt=old,
            firstSeenAt=NOW, updatedAt=NOW, indexedAt=NOW), NOW))
        self.assertFalse(is_fresh_news(rss(originalPublishedAt=old, updatedAt=NOW), NOW))
        self.assertFalse(is_fresh_news(rss(publishedAt=NOW, originalPublishedAt=old), NOW))

    def test_exact_hour_is_boundary_and_window_cannot_be_enlarged(self):
        row = rss(publishedAt=NOW - MAX_NEWS_AGE_S, originalPublishedAt=NOW - MAX_NEWS_AGE_S)
        self.assertTrue(is_fresh_news(row, NOW))
        self.assertFalse(is_fresh_news(row, NOW + 1))
        for window in (3601, 7200, 0, -1, True, 600.0, '600', None):
            with self.subTest(window=window):
                self.assertFalse(is_fresh_news(rss(), NOW, max_age_s=window))
        self.assertTrue(is_fresh_news(rss(), NOW, max_age_s=30))
        self.assertFalse(is_fresh_news(rss(), NOW, max_age_s=29))

    def test_scheduled_start_or_end_does_not_reset_age(self):
        row = rss(publishedAt=NOW - 3590, originalPublishedAt=NOW - 3590)
        self.assertTrue(is_fresh_news(row, NOW, at_s=NOW + 10))
        self.assertFalse(is_fresh_news(row, NOW, at_s=NOW + 11))
        self.assertFalse(is_fresh_news(row, NOW, at_s=NOW - 1))
        # A future receipt cannot be laundered through a later playback boundary.
        self.assertFalse(is_fresh_news(rss(firstSeenAt=NOW + 1), NOW, at_s=NOW + 10))

    def test_legacy_or_self_asserted_provenance_fails_closed(self):
        for key in ('sourceKind', 'clockBasis', 'publicationField',
                    'originalPublicationVerified', 'originalPublishedAt'):
            row = rss()
            del row[key]
            with self.subTest(missing=key):
                self.assertFalse(is_fresh_news(row, NOW))
        self.assertFalse(is_fresh_news(rss(clockBasis='aggregator-rss-publication'), NOW))
        self.assertFalse(is_fresh_news(rss(originalPublicationVerified=1), NOW))
        self.assertFalse(is_fresh_news(rss(url='https://unreviewed.example/news'), NOW))
        self.assertFalse(is_fresh_news(rss(broadcastEligible=False), NOW))
        for field in ('sourceKind', 'publicationField'):
            for value in ([], {}, ['published']):
                with self.subTest(field=field, malformed=value):
                    self.assertFalse(is_fresh_news(rss(**{field: value}), NOW))

    def test_aggregator_index_clock_and_boolean_are_not_publisher_evidence(self):
        row = rss(sourceKind='publisher-aggregator', source='BBC via Google News',
            aggregator='Google News', url='https://news.google.com/rss/articles/' + 'A' * 32 + '?oc=5',
            publisherSourceUrl='https://www.bbc.com', publisherDomain='www.bbc.com',
            clockBasis='aggregator-rss-publication', originalPublicationVerified=False)
        self.assertFalse(is_fresh_news(row, NOW))
        row.update(originalPublicationVerified=True, clockBasis=PUBLISHER_CLOCK_BASIS)
        self.assertFalse(is_fresh_news(row, NOW))
        row['sourceKind'] = 'publisher-rss'
        self.assertFalse(is_fresh_news(row, NOW))  # Google URL is not a publisher URL.

    def test_author_creation_clock_is_preserved_for_pinned_social_post(self):
        row = social()
        self.assertEqual(validated_news_publication(row, NOW), NOW - 20)
        for changes in (
                {'clockBasis': 'indexed-at'}, {'timeKind': 'updated'},
                {'platform': 'Telegram'}, {'social': False},
                {'url': 'https://bsky.app/profile/did:web:unreviewed.example/post/abc123'},
                {'publishedAt': NOW - 54000, 'indexedAt': NOW},
                {'originalPublishedAt': NOW - 54000},
        ):
            with self.subTest(changes=changes):
                self.assertFalse(is_fresh_news({**row, **changes}, NOW))

    def test_fresh_reply_requires_pinned_parent_provenance_and_original_reply_clock(self):
        root = social()
        row = social(sourceKind='social-feedback', verification='unverified-public-reply',
            url='https://bsky.app/profile/did:web:reader.example/post/reply123',
            feedback={'rootUrl': root['url'],
                      'rootUri': 'at://' + SOURCES[0].did + '/app.bsky.feed.post/abc123',
                      'rootPublishedAt': NOW - 45})
        self.assertTrue(is_fresh_news(row, NOW))
        for change in ({'feedback': {}}, {'feedback': {**row['feedback'], 'rootPublishedAt': NOW}},
                       {'feedback': {**row['feedback'], 'rootUri': 'at://did:web:fake.example/app.bsky.feed.post/abc123'}},
                       {'publishedAt': NOW - 54000}):
            with self.subTest(change=change):
                self.assertFalse(is_fresh_news({**row, **change}, NOW))

    def test_invalid_clocks_fail_closed_including_boolean_and_millisecond_values(self):
        for value in (None, False, True, 0, -1, NOW + 1, float(NOW), str(NOW), NOW * 1000):
            for field in ('publishedAt', 'firstSeenAt', 'originalPublishedAt'):
                with self.subTest(value=value, field=field):
                    self.assertFalse(is_fresh_news(rss(**{field: value}), NOW))
        for value in (None, False, 0, -1, float(NOW), str(NOW), NOW * 1000):
            with self.subTest(now=value):
                self.assertFalse(is_fresh_news(rss(), value))
        self.assertFalse(is_fresh_news([], NOW))


if __name__ == '__main__':
    unittest.main()

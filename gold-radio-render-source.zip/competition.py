"""Reviewed fictional radio quiz, independent of news and the model writer.

All three characters and every answer are scripted synthetic entertainment.
Candidate reads do not consume a turn. Only a complete, successfully queued
audio slot advances the show; no real participant, reward or transaction exists.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math


POLICY_VERSION = 'fictional-competition-2026-10-25-v1'
QUESTION_BANK_REVISION = 'reviewed-bilingual-trivia-2026-10-25-v1'
INTERVAL_SECONDS = 1200
EPISODE_WALL_SECONDS = 900
MAX_TURN_SECONDS = 90
QUESTION_COUNT = 5
TURN_COUNT = 17
TARGET_SECONDS = 130
STATION_URL = 'https://gold-air.onrender.com/'
_MAX_MS = 253402300799000
_NAMES = {'en': {'host': 'Nadia', 'player-a': 'Sam', 'player-b': 'Mia'},
          'ar': {'host': 'نادية', 'player-a': 'سامر', 'player-b': 'ميرا'}}

# Static educational references were checked on 25 October 2026. They are
# provenance for this reviewed bank, never a fetched/live news context.
_GOLD = 'https://pubchem.ncbi.nlm.nih.gov/element/Gold'
_RSC = 'https://periodic-table.rsc.org/element/79/gold'
_INFLATION = 'https://www.ecb.europa.eu/ecb-and-you/explainers/tell-me-more/html/what_is_inflation.en.html'
_STOCKS = 'https://www.investor.gov/introduction-investing/investing-basics/investment-products/stocks'
_DIVERSIFY = 'https://www.investor.gov/introduction-investing/getting-started/asset-allocation'


def _question(key, correct, reference, en, ar):
    return {'id': key, 'correctChoice': correct, 'reference': reference,
            'en': dict(zip(('question', 'A', 'B', 'explanation'), en)),
            'ar': dict(zip(('question', 'A', 'B', 'explanation'), ar))}


QUESTION_BANK = (
    _question('gold-symbol', 'B', _GOLD,
        ('Which chemical symbol belongs to gold?', 'Ag', 'Au', 'Au is the chemical symbol for gold.'),
        ('ما الرمز الكيميائي للذهب؟', 'إيه جي', 'إيه يو', 'رمز الذهب الكيميائي هو إيه يو.')),
    _question('inflation', 'A', _INFLATION,
        ('What does inflation describe?', 'a broad rise in prices', 'a broad fall in prices',
         'Inflation means a broad price increase, not every individual price rising.'),
        ('ماذا يصف التضخم؟', 'ارتفاعا عاما في الأسعار', 'انخفاضا عاما في الأسعار',
         'التضخم ارتفاع عام في الأسعار، ولا يلزم أن يرتفع سعر كل سلعة.')),
    _question('red-planet', 'B', 'https://science.nasa.gov/mars/facts/',
        ('Which world is called the Red Planet?', 'Jupiter', 'Mars', 'Mars is known as the Red Planet.'),
        ('أي كوكب يسمى الكوكب الأحمر؟', 'المشتري', 'المريخ', 'المريخ معروف باسم الكوكب الأحمر.')),
    _question('gold-purity', 'A', _RSC,
        ('Which label describes pure gold?', 'twenty-four karat', 'twelve karat',
         'Twenty-four karat denotes pure gold.'),
        ('أي وصف يدل على الذهب النقي؟', 'أربعة وعشرون قيراطا', 'اثنا عشر قيراطا',
         'أربعة وعشرون قيراطا هو وصف الذهب النقي.')),
    _question('stock-ownership', 'B', _STOCKS,
        ('What does a company share represent?', 'a library membership', 'part ownership of a company',
         'A share represents an ownership interest in a company.'),
        ('ماذا يمثل سهم الشركة؟', 'عضوية في مكتبة', 'حصة ملكية في الشركة',
         'السهم يمثل حصة ملكية في الشركة.')),
    _question('gold-number', 'A', _GOLD,
        ('What is the atomic number of gold?', 'seventy-nine', 'eighty',
         'Gold has atomic number seventy-nine.'),
        ('ما العدد الذري للذهب؟', 'تسعة وسبعون', 'ثمانون', 'العدد الذري للذهب هو تسعة وسبعون.')),
    _question('diversification', 'B', _DIVERSIFY,
        ('What does investment diversification mean?', 'holding only one investment', 'spreading across investments',
         'Diversification spreads investments; it does not guarantee against losses.'),
        ('ماذا يعني تنويع الاستثمارات؟', 'الاكتفاء باستثمار واحد', 'توزيع الاستثمارات',
         'التنويع يوزع الاستثمارات، لكنه لا يضمن تجنب الخسارة.')),
    _question('sun-star', 'A', 'https://science.nasa.gov/sun/facts/',
        ('What kind of object is our Sun?', 'a star', 'a planet', 'The Sun is a star.'),
        ('ما نوع الجرم الذي تمثله الشمس؟', 'نجم', 'كوكب', 'الشمس نجم.')),
    _question('leap-days', 'B', 'https://spaceplace.nasa.gov/leap-year/sp/',
        ('How many days are in a Gregorian leap year?', 'three hundred sixty-five', 'three hundred sixty-six',
         'A Gregorian leap year has three hundred sixty-six days.'),
        ('كم يوما في السنة الكبيسة بالتقويم الميلادي؟', 'ثلاثمئة وخمسة وستون', 'ثلاثمئة وستة وستون',
         'السنة الكبيسة في التقويم الميلادي تضم ثلاثمئة وستة وستين يوما.')),
    _question('minute-seconds', 'A', 'https://www.bipm.org/en/publications/si-brochure',
        ('How many seconds make one minute?', 'sixty', 'one hundred', 'One minute is sixty seconds.'),
        ('كم ثانية في الدقيقة الواحدة؟', 'ستون', 'مئة', 'الدقيقة الواحدة ستون ثانية.')),
)


def _clock_ms(value):
    return type(value) is int and 0 < value <= _MAX_MS


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        allow_nan=False, separators=(',', ':')).encode()).hexdigest()


def _episode_id(language, number):
    return _digest([POLICY_VERSION, language, number])[:32]


def _rounds(number):
    # Two different five-question decks, then a different starting question.
    # The reviewed answer patterns yield 4–3, with the winner alternating.
    deck = list(QUESTION_BANK[((number - 1) % 2) * 5:((number - 1) % 2) * 5 + 5])
    rotation = ((number - 1) // 2) % QUESTION_COUNT
    deck = deck[rotation:] + deck[:rotation]
    pattern = ((True, True), (True, False), (False, True), (True, True), (True, False))
    result = []
    for question, correctness in zip(deck, pattern):
        if number % 2 == 0:
            correctness = correctness[::-1]
        answers = {role: question['correctChoice'] if right else
                   ('B' if question['correctChoice'] == 'A' else 'A')
                   for role, right in zip(('player-a', 'player-b'), correctness)}
        result.append((question, answers))
    return result


def _verdict(question, answers, language):
    text = question[language]
    winners = [role for role, answer in answers.items() if answer == question['correctChoice']]
    if language == 'ar':
        points = ('نقطة لكليكما.' if len(winners) == 2 else
                  'نقطة إلى ' + _NAMES[language][winners[0]] + '.' if winners else 'لا نقطة هذه المرة.')
        return text['explanation'] + ' ' + points
    points = ('A point each.' if len(winners) == 2 else
              'One point for ' + _NAMES[language][winners[0]] + '.' if winners else 'No points this time.')
    return text['explanation'] + ' ' + points


def _turns(language, number):
    names = _NAMES[language]
    intro = ('حان وقت المسابقة، فقرة خيالية مكتوبة بأصوات اصطناعية. نادية تقدم، وسامر وميرا يتنافسان. '
             'خمسة أسئلة، ولكل إجابة صحيحة نقطة. الجائزة أونصة ذهب خيالية، ولا توجد جائزة حقيقية. '
             'جهزوا الخزنة الخيالية؛ مفتاحها موزة! حظا سعيدا للجميع.' if language == 'ar' else
             'Competition time: a scripted fictional show with synthetic voices. Nadia hosts Sam and Mia. '
             'Five questions, one point per correct answer. The prize is an imaginary ounce of gold; '
             'there is no real prize. Our imaginary vault opens with a banana!')
    turns = [{'stage': 'intro', 'roundIndex': 0, 'role': 'host', 'text': intro}]
    rounds = _rounds(number)
    scores = {'player-a': 0, 'player-b': 0}
    # Brief playful replies vary by round and role without pretending to be live.
    jokes = {'en': {'player-a': ('My imaginary vault approves.', 'My calculator wants a biscuit.',
                                 'My thinking hat is wobbling.', 'The banana key agrees.', 'My eyebrows have voted.'),
                    'player-b': ('My lucky pencil agrees.', 'My quiz shoes are ready.',
                                 'I asked my imaginary hamster.', 'My brain did a cartwheel.', 'My teacup looks confident.')},
             'ar': {'player-a': ('خزنتي الخيالية موافقة.', 'آلتي الحاسبة تريد بسكويتة.',
                                 'قبعة التفكير تهتز.', 'مفتاح الموزة يوافق.', 'حاجباي صوتا للمقترح.'),
                    'player-b': ('قلمي المحظوظ موافق.', 'حذاء المسابقة مستعد.',
                                 'استشرت هامسترا خياليا.', 'عقلي أدى شقلبة.', 'فنجاني يبدو واثقا.')}}
    for index, (question, answers) in enumerate(rounds):
        text = question[language]
        verdict = _verdict(*rounds[index - 1], language) + ' ' if index else ''
        prompt = (f'السؤال {index + 1}. {text["question"]} ألف، {text["A"]}. باء، {text["B"]}.'
                  if language == 'ar' else
                  f'Question {index + 1}. {text["question"]} A, {text["A"]}. B, {text["B"]}.')
        base = {'roundIndex': index + 1, 'questionId': question['id'],
                'factReferences': [question['reference']]}
        turns.append({**base, 'stage': 'question', 'role': 'host', 'text': verdict + prompt,
                      'choices': {'A': text['A'], 'B': text['B']}})
        for role in ('player-a', 'player-b'):
            choice = answers[role]
            spoken_choice = ('ألف' if choice == 'A' else 'باء') if language == 'ar' else choice
            answer = (f'أختار {spoken_choice}. ' if language == 'ar' else f'I choose {spoken_choice}. ')
            turns.append({**base, 'stage': role, 'role': role, 'answerChoice': choice,
                          'text': answer + jokes[language][role][index]})
            scores[role] += int(choice == question['correctChoice'])
    winner = max(scores, key=scores.get)
    verdict = _verdict(*rounds[-1], language)
    result = (f'{verdict} النتيجة النهائية: سامر {scores["player-a"]}، وميرا {scores["player-b"]}. '
              f'برافو {names[winner]}! تفوز بأونصة ذهب خيالية. لا ذهب حقيقيا ينتقل إلى أحد. '
              'حتى الموزة تحتفل. انتهت مسابقتنا الخيالية!' if language == 'ar' else
              f'{verdict} Final score: Sam {scores["player-a"]}, Mia {scores["player-b"]}. '
              f'Bravo, {names[winner]}! You win the imaginary one-ounce gold trophy. '
              'No actual gold changes hands. Even the banana is cheering. Our fictional quiz is complete!')
    turns.append({'stage': 'result', 'roundIndex': QUESTION_COUNT, 'role': 'host',
                  'text': result, 'scores': scores, 'winnerRole': winner, 'winner': names[winner]})
    return turns


def _estimate_seconds(text, language):
    # Planning only; measured complete WAV duration is authoritative at commit.
    return round(max(len(text.split()) / (2.3 if language == 'ar' else 2.7),
                     len(text) / (16 if language == 'ar' else 18)) + .4, 3)


def _make_job(language, number, turn_index, generated_ms, started_ms):
    turn = _turns(language, number)[turn_index]
    expiry = (started_ms if started_ms is not None else generated_ms) + EPISODE_WALL_SECONDS * 1000
    metadata = {'policyVersion': POLICY_VERSION, 'questionBankRevision': QUESTION_BANK_REVISION,
        'mode': 'fictional-quiz', 'fictional': True, 'scripted': True, 'syntheticCast': True,
        'realParticipants': False, 'realPrize': False, 'prize': 'imaginary-one-ounce-gold-trophy',
        'currentNews': False, 'forecast': False, 'factualContextEligible': False,
        'episodeId': _episode_id(language, number), 'episodeNumber': number,
        'episodeStartedAt': started_ms, 'turnIndex': turn_index, 'turnCount': TURN_COUNT,
        'questionCount': QUESTION_COUNT, 'roundIndex': turn['roundIndex'], 'stage': turn['stage'],
        'speakerRole': turn['role'], 'generatedAt': generated_ms, 'expiresAt': expiry,
        'intervalSeconds': INTERVAL_SECONDS, 'episodeWallSeconds': EPISODE_WALL_SECONDS}
    metadata.update({key: deepcopy(turn[key]) for key in ('questionId', 'factReferences', 'choices',
        'answerChoice', 'scores', 'winnerRole', 'winner') if key in turn})
    title = 'المسابقة — فقرة خيالية' if language == 'ar' else 'Competition — fictional quiz'
    speech = turn['text']
    return {'id': _digest([metadata['episodeId'], turn_index])[:32], 'kind': 'competition',
        'language': language, 'title': title, 'source': 'Gold Pulse fictional entertainment',
        'url': STATION_URL, 'publishedAt': generated_ms // 1000, 'firstSeenAt': generated_ms // 1000,
        'sourceKind': 'fictional-quiz', 'factualContextEligible': False, 'sources': [], 'sourceIds': [],
        'speechText': speech, 'speaker': _NAMES[language][turn['role']],
        'voiceProfile': 'competition-' + turn['role'], 'competition': metadata,
        'estimatedSeconds': _estimate_seconds(speech, language)}


def job_fresh(job, at_ms):
    """Validate the reviewed script and all labels through a complete clip end.

    Extra station transport fields may be attached, but changing any canonical
    script, name, score, clock or fiction label invalidates the original job.
    No quote/news clock is created by this entertainment preparation timestamp.
    """
    try:
        if not isinstance(job, dict) or not _clock_ms(at_ms):
            return False
        metadata = job.get('competition')
        if not isinstance(metadata, dict) or job.get('language') not in _NAMES:
            return False
        generated, expiry, started = (metadata.get(key) for key in
                                      ('generatedAt', 'expiresAt', 'episodeStartedAt'))
        number, turn = metadata.get('episodeNumber'), metadata.get('turnIndex')
        if (type(number) is not int or number < 1 or number > 10**9 or
                type(turn) is not int or not 0 <= turn < TURN_COUNT or
                not _clock_ms(generated) or not _clock_ms(expiry) or
                not generated <= at_ms <= expiry or expiry - generated > INTERVAL_SECONDS * 1000 or
                started is not None and not _clock_ms(started) or
                turn == 0 and started is not None or turn > 0 and started is None):
            return False
        expected = _make_job(job['language'], number, turn, generated, started)
        return (_digest({key: job.get(key) for key in expected}) == _digest(expected) and
                expected['estimatedSeconds'] <= MAX_TURN_SECONDS)
    except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
        return False


class Competition:
    """Independent language shows with twenty-minute actual-start cadence."""

    def __init__(self, enabled=True):
        self.enabled = enabled is True
        self._states = {language: {'number': 0, 'startedAt': None, 'lastEndAt': None,
            'nextTurn': 0, 'scheduledMs': 0, 'slots': [], 'result': None, 'abandoned': False}
            for language in _NAMES}

    def _view(self, language, now_ms):
        state = self._states[language]
        started = state['startedAt']
        active = (started is not None and not state['abandoned'] and state['nextTurn'] < TURN_COUNT and
                  now_ms < started + EPISODE_WALL_SECONDS * 1000)
        next_due = None if started is None else started + INTERVAL_SECONDS * 1000
        due = active or next_due is None or now_ms >= next_due
        number = state['number'] if active else state['number'] + 1
        return state, active, due, next_due, number

    def candidate(self, language, now_ms, excluded=()):
        if (not self.enabled or not isinstance(language, str) or
                language not in self._states or not _clock_ms(now_ms)):
            return None
        try:
            blocked = set(excluded)
        except (ValueError, TypeError):
            return None
        state, active, due, _next_due, number = self._view(language, now_ms)
        if not due:
            return None
        job = _make_job(language, number, state['nextTurn'] if active else 0, now_ms,
                        state['startedAt'] if active else None)
        if job['id'] in blocked or job['competition']['episodeId'] in blocked:
            return None
        # Complete turns must fit even at the planning estimate. Actual audio
        # is independently checked before it is written to the queue.
        return job if job_fresh(job, now_ms + math.ceil(job['estimatedSeconds'] * 1000)) else None

    def _commit_plan(self, job, start_ms, end_ms):
        if (not self.enabled or not _clock_ms(start_ms) or not _clock_ms(end_ms) or
                not 0 < end_ms - start_ms <= MAX_TURN_SECONDS * 1000 or not job_fresh(job, end_ms)):
            return None
        metadata, language = job['competition'], job['language']
        if start_ms < metadata['generatedAt']:
            return None
        state, active, due, _next_due, number = self._view(language, start_ms)
        if (not due or number != metadata['episodeNumber'] or
                metadata['turnIndex'] != (state['nextTurn'] if active else 0) or
                metadata['episodeStartedAt'] != (state['startedAt'] if active else None) or
                active and start_ms < state['lastEndAt']):
            return None
        started = state['startedAt'] if active else start_ms
        if end_ms > started + EPISODE_WALL_SECONDS * 1000:
            return None
        return state, active, number

    def can_commit(self, job, start_ms, end_ms):
        return self._commit_plan(job, start_ms, end_ms) is not None

    def commit(self, job, start_ms, end_ms):
        """Call only after a complete WAV is persisted and queued successfully."""
        plan = self._commit_plan(job, start_ms, end_ms)
        if plan is None:
            return False
        state, active, number = plan
        if not active:
            state.update(number=number, startedAt=start_ms, nextTurn=0, scheduledMs=0,
                         slots=[], result=None, abandoned=False)
        state['nextTurn'] += 1
        state['lastEndAt'] = end_ms
        state['scheduledMs'] += end_ms - start_ms
        state['slots'].append((start_ms, end_ms))
        if job['competition']['stage'] == 'result':
            state['result'] = {key: deepcopy(job['competition'][key]) for key in ('scores', 'winner', 'winnerRole')}
            state['result'].update(resultStartsAt=start_ms, resultEndsAt=end_ms)
        return True

    def abandon(self, language, now_ms):
        """Explicitly stop an incomplete show after the station exhausts retries.

        The caller owns queue availability and retry policy. This changes no
        scheduled airtime or due clock, invents no result, and prevents a late
        prepared turn from restarting the abandoned episode.
        """
        if (not self.enabled or not isinstance(language, str) or
                language not in self._states or not _clock_ms(now_ms)):
            return False
        state, active, _due, _next_due, _number = self._view(language, now_ms)
        if not active:
            return False
        state['abandoned'] = True
        return True

    def _shift_plan(self, language, start_ms, delta_ms, now_ms):
        if (not isinstance(language, str) or language not in self._states or
                not _clock_ms(start_ms) or not _clock_ms(now_ms) or
                start_ms <= now_ms or type(delta_ms) is not int or
                not 0 < delta_ms <= MAX_TURN_SECONDS * 1000):
            return None
        state = self._states[language]
        if not self.enabled or state['startedAt'] is None:
            return state, [], None, None
        # Protect the introduction's original start. Later urgent inserts may
        # move whole future turns, but cannot rewrite frozen episode clocks.
        if start_ms <= state['slots'][0][0]:
            return None
        if any(left < start_ms < right for left, right in state['slots']):
            return None
        slots = [(left + delta_ms, right + delta_ms) if left >= start_ms else (left, right)
                 for left, right in state['slots']]
        started, tail = slots[0][0], slots[-1][1]
        if not _clock_ms(tail) or tail > started + EPISODE_WALL_SECONDS * 1000:
            return None
        return state, slots, started, tail

    def can_shift_future(self, language, start_ms, delta_ms, now_ms):
        """Validate insertion geometry; the station must recheck shifted jobs."""
        return self._shift_plan(language, start_ms, delta_ms, now_ms) is not None

    def shift_future(self, language, start_ms, delta_ms, now_ms):
        """Follow a safe insertion between complete turns without extra speech.

        The first slot stays protected, so its cadence and every frozen expiry
        remain accurate. The station must validate every shifted job through
        its new end before mutating its queue and then calling this method.
        """
        plan = self._shift_plan(language, start_ms, delta_ms, now_ms)
        if plan is None:
            return False
        state, slots, started, tail = plan
        if started is not None:
            state.update(slots=slots, startedAt=started, lastEndAt=tail)
            if state['result'] is not None:
                state['result'].update(resultStartsAt=slots[-1][0], resultEndsAt=slots[-1][1])
        return True

    def status(self, language, now_ms):
        basic = {'due': False, 'active': False, 'scheduledSeconds': 0, 'targetSeconds': TARGET_SECONDS,
                 'intervalSeconds': INTERVAL_SECONDS, 'episodeWallSeconds': EPISODE_WALL_SECONDS,
                 'questionCount': QUESTION_COUNT, 'turnCount': TURN_COUNT, 'emittedTurns': 0,
                 'nextDueAt': None, 'sessionStartedAt': None, 'episodeStartedAt': None, 'lastEndAt': None,
                 'fictional': True, 'realPrize': False, 'mode': 'fictional-quiz',
                 'prize': 'imaginary-one-ounce-gold-trophy', 'completed': False, 'abandoned': False,
                 'enabled': self.enabled, 'resultStartsAt': None, 'resultEndsAt': None}
        if (not self.enabled or not isinstance(language, str) or
                language not in self._states or not _clock_ms(now_ms)):
            return basic
        state, active, due, next_due, _number = self._view(language, now_ms)
        started = state['startedAt']
        basic.update(due=due, active=active, scheduledSeconds=state['scheduledMs'] / 1000,
            emittedTurns=state['nextTurn'], nextDueAt=next_due, sessionStartedAt=started,
            episodeStartedAt=started, lastEndAt=state['lastEndAt'],
            episodeId=_episode_id(language, state['number']) if started else None,
            completed=state['nextTurn'] == TURN_COUNT,
            abandoned=bool(state['abandoned'] or
                           started is not None and state['nextTurn'] < TURN_COUNT and
                           now_ms >= started + EPISODE_WALL_SECONDS * 1000))
        if state['result'] is not None:
            basic.update(deepcopy(state['result']))
        return basic

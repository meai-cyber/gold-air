"""People segment integration uses synthetic accounts and audio only."""
from copy import deepcopy
import io
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server
from test_people_now import reaction, NOW, NOW_MS


class PeopleStationTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        with patch('server.time.time', return_value=NOW):
            self.station = server.Station(self.directory.name)
        self.station.programmes = None
        self.station.languages = ('en', 'ar')
        self.post = reaction(name='Public Account')
        self.station.stories[self.post['id']] = self.post

    def tearDown(self):
        self.station.stop.set()
        self.directory.cleanup()

    def produce(self, outcome='ok', *, duration=2, at=NOW):
        station = self.station
        calls = []
        wav = io.BytesIO()
        with wave.open(wav, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
            w.writeframes(b'\x01\x00' * (24000 * duration))
        class Tts:
            def synthesize(self, text, language):
                calls.append((text, language))
                station.stop.set()
                if outcome == 'tts-error':
                    raise ValueError('synthetic failure')
                return SimpleNamespace(wav=wav.getvalue(), duration_s=duration,
                    engine='synthetic-test-only', language=language)
        self.station.stop.clear()
        with patch('server.time.time', return_value=at):
            self.station._produce(Tts(), ('en',))
        return calls

    def test_person_quotes_have_their_own_lane_and_successful_audio_consumes_original_post(self):
        self.assertIsNone(self.station._candidate('en', NOW))
        job = self.station._next_job('en', NOW_MS, {})
        self.assertEqual(job['kind'], 'people-now')
        self.assertIn(self.post['title'], job['speechText'])
        calls = self.produce()
        self.assertEqual(calls, [('On gold and interest rates. listener@mastodon.social: “' + self.post['title'] + '”', 'en')])
        segment = self.station.queues['en'][0]
        self.assertEqual(segment['kind'], 'people-now')
        self.assertEqual(segment['sources'][0]['title'], self.post['title'])
        self.assertEqual(segment['peopleNow']['authorHandle'], 'listener@mastodon.social')
        self.assertEqual(segment['peopleNow']['authorName'], 'Public Account')
        self.assertEqual(segment['publishedAt'], self.post['publishedAt'] * 1000)
        self.assertEqual(segment['firstSeenAt'], self.post['firstSeenAt'] * 1000)
        self.assertTrue(segment['peopleNow']['unverified'])
        self.assertFalse(segment['factualContextEligible'])
        self.assertIn(self.post['id'], self.station.seen['en'])
        self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 2)
        self.assertEqual(self.station.airtime['en'].intervals[-1][2], 'people-now')
        with patch('server.time.time', return_value=NOW):
            self.assertTrue(self.station.audio(segment['id']))

    def test_synthesis_or_file_failure_never_earns_airtime_or_consumes_a_post(self):
        for outcome in ('tts-error', 'file-error'):
            with self.subTest(outcome=outcome):
                self.station.stop.clear()
                if outcome == 'file-error':
                    with patch('server.Path.write_bytes', side_effect=OSError('synthetic disk error')):
                        self.produce()
                else:
                    self.produce(outcome)
                self.assertEqual(self.station.queues['en'], [])
                self.assertNotIn(self.post['id'], self.station.seen['en'])
                self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 0)

    def test_public_segment_can_be_revalidated_when_shifted_but_tampering_or_expiry_fails(self):
        self.produce()
        q = deepcopy(self.station.queues['en'][0])
        restored = {**q, 'url': q['sourceUrl'], 'publishedAt': q['publishedAt'] // 1000,
                    'firstSeenAt': q['firstSeenAt'] // 1000}
        self.assertTrue(self.station._job_fresh(restored, q['endsAt'] + 1000))
        changed = deepcopy(restored)
        changed['sources'][0]['title'] = 'I think gold could move for an invented reason.'
        self.assertFalse(self.station._job_fresh(changed, q['endsAt']))
        self.assertFalse(self.station._job_fresh(restored, NOW_MS + 3600000))

    def test_empty_or_other_language_supply_is_truthful_and_does_not_reserve_time(self):
        m = self.station.manifest('ar', NOW_MS)
        self.assertTrue(m['peopleNow']['due'])
        self.assertFalse(m['peopleNow']['eligibleNow'])
        self.assertEqual(m['peopleNow']['scheduledSeconds'], 0)
        self.assertEqual(m['peopleNow']['targetSeconds'], 150)
        self.assertEqual(m['peopleNow']['intervalSeconds'], 900)
        self.assertFalse(m['peopleNow']['translation'])
        self.assertEqual(self.station.seen['ar'], set())

    def test_price_priority_is_preserved_before_the_people_segment(self):
        price = {'kind': 'market', 'id': 'f' * 32}
        with patch.object(self.station, '_market_job', return_value=price):
            self.assertEqual(self.station._next_job('en', NOW_MS, {}), price)
        self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 0)

    def test_prepared_quote_remains_visible_without_reentering_playback_and_expires(self):
        self.produce()
        self.station.queues['en'].clear()
        m = self.station.manifest('en', NOW_MS + 60000)
        self.assertEqual(m['queue'], [])
        self.assertIsNone(m['nowPlaying'])
        quotes = m['peopleNow']['recentPrepared']
        self.assertEqual(len(quotes), 1)
        self.assertTrue(quotes[0]['previouslyPrepared'])
        self.assertEqual(quotes[0]['sources'][0]['title'], self.post['title'])
        self.assertNotIn('audioUrl', quotes[0])
        self.assertEqual(self.station.manifest('en', NOW_MS + 901000)['peopleNow']['recentPrepared'], [])

    def test_changed_price_moves_future_people_clock_without_earning_extra_speech(self):
        self.produce()
        before = self.station.people_now.status('en', NOW_MS)
        q = self.station.queues['en'][0]
        insertion = {'id': 'e' * 32, 'kind': 'market', 'startsAt': q['startsAt'],
                     'endsAt': q['startsAt'] + 6000}
        self.station._insert_priority('en', insertion, NOW_MS)
        after = self.station.people_now.status('en', NOW_MS)
        self.assertEqual(after['nextDueAt'], before['nextDueAt'] + 6000)
        self.assertEqual(after['scheduledSeconds'], before['scheduledSeconds'])
        moved = next(row for row in self.station.queues['en'] if row['kind'] == 'people-now')
        self.assertEqual(moved['startsAt'], insertion['endsAt'])

    def test_complete_persisted_group_totals_150_seconds_with_one_intro_and_900_second_cadence(self):
        # Actual WAV frames and durations are synthetic. This establishes
        # complete station accounting, not a claim about available live posts.
        rows = [reaction(key=index + 1, username='listener' + str(index),
            account_id=str(12345 + index), age=20 + index)
            for index in range(7)]
        self.station.stories = {row['id']: row for row in rows}
        segments, spoken = [], []
        at = NOW
        for duration in (30, 20, 20, 20, 20, 20, 20):
            spoken.extend(self.produce(duration=duration, at=at))
            segment = self.station.queues['en'][-1]
            segments.append(deepcopy(segment))
            self.assertEqual(segment['durationSeconds'], duration)
            self.assertEqual(segment['endsAt'] - segment['startsAt'], duration * 1000)
            with patch('server.time.time', return_value=at):
                audio = self.station.audio(segment['id'])
            with wave.open(io.BytesIO(audio), 'rb') as wav:
                self.assertEqual(wav.getnframes(), 24000 * duration)
                self.assertTrue(any(wav.readframes(wav.getnframes())))
            restored = {**segment, 'url': segment['sourceUrl'],
                'publishedAt': segment['publishedAt'] // 1000,
                'firstSeenAt': segment['firstSeenAt'] // 1000}
            self.assertTrue(self.station._job_fresh(restored, segment['endsAt']))
            at = segment['endsAt'] // 1000 - 5
        self.assertEqual(len({s['peopleNow']['authorHandle'] for s in segments}), 7)
        self.assertEqual(sum(text.count('On gold and interest rates.') for text, _ in spoken), 1)
        for index, segment in enumerate(segments):
            self.assertEqual(segment['peopleNow']['topic']['startsTopic'], index == 0)
            self.assertEqual(segment['peopleNow']['topic']['association'], 'shared-explicit-topic-not-a-news-reply')
            self.assertEqual(segment['maxAudioSeconds'], 55 if index == 0 else 35)
            quote = segment['peopleNow']['authorHandle'] + ': “' + segment['sources'][0]['title'] + '”'
            self.assertEqual(segment['speechText'], ('On gold and interest rates. ' if index == 0 else '') + quote)
        status = self.station.people_now.status('en', segments[-1]['endsAt'])
        self.assertEqual(status['scheduledSeconds'], 150)
        self.assertEqual(status['emittedPosts'], 7)
        self.assertFalse(status['active'])
        self.assertEqual(status['nextDueAt'], segments[0]['startsAt'] + 900000)
        self.assertEqual(self.station.seen['en'], {row['id'] for row in rows})
        new = reaction(key=50, username='nextsession', account_id='12555')
        self.assertIsNone(self.station.people_now.candidate('en', [new], status['nextDueAt'] - 1))
        self.assertIsNotNone(self.station.people_now.candidate('en', [new], status['nextDueAt']))


if __name__ == '__main__':
    unittest.main()

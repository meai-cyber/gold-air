"""People segment integration uses synthetic accounts and audio only."""
from copy import deepcopy
import io
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server
from test_people_now import reaction, NOW, NOW_MS


class PeopleStationTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        with patch('server.time.time', return_value=NOW):
            self.station = server.Station(self.directory.name)
        self.station.programmes = None
        self.station.languages = ('en', 'ar')
        self.post = reaction(name='Public Account')
        self.station.stories[self.post['id']] = self.post

    def tearDown(self):
        self.station.stop.set()
        self.directory.cleanup()

    def produce(self, outcome='ok'):
        station = self.station
        wav = io.BytesIO()
        with wave.open(wav, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 48000)
        class Tts:
            def synthesize(self, text, language):
                station.stop.set()
                if outcome == 'tts-error':
                    raise ValueError('synthetic failure')
                return SimpleNamespace(wav=wav.getvalue(), duration_s=2.0,
                    engine='synthetic-test-only', language=language)
        with patch('server.time.time', return_value=NOW):
            self.station._produce(Tts(), ('en',))

    def test_person_quotes_have_their_own_lane_and_successful_audio_consumes_original_post(self):
        self.assertIsNone(self.station._candidate('en', NOW))
        job = self.station._next_job('en', NOW_MS, {})
        self.assertEqual(job['kind'], 'people-now')
        self.assertIn(self.post['title'], job['speechText'])
        self.produce()
        segment = self.station.queues['en'][0]
        self.assertEqual(segment['kind'], 'people-now')
        self.assertEqual(segment['sources'][0]['title'], self.post['title'])
        self.assertEqual(segment['peopleNow']['authorHandle'], 'listener@mastodon.social')
        self.assertFalse(segment['factualContextEligible'])
        self.assertIn(self.post['id'], self.station.seen['en'])
        self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 2)
        self.assertEqual(self.station.airtime['en'].intervals[-1][2], 'people-now')
        with patch('server.time.time', return_value=NOW):
            self.assertTrue(self.station.audio(segment['id']))

    def test_synthesis_or_file_failure_never_earns_airtime_or_consumes_a_post(self):
        for outcome in ('tts-error', 'file-error'):
            with self.subTest(outcome=outcome):
                self.station.stop.clear()
                if outcome == 'file-error':
                    with patch('server.Path.write_bytes', side_effect=OSError('synthetic disk error')):
                        self.produce()
                else:
                    self.produce(outcome)
                self.assertEqual(self.station.queues['en'], [])
                self.assertNotIn(self.post['id'], self.station.seen['en'])
                self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 0)

    def test_public_segment_can_be_revalidated_when_shifted_but_tampering_or_expiry_fails(self):
        self.produce()
        q = deepcopy(self.station.queues['en'][0])
        restored = {**q, 'url': q['sourceUrl'], 'publishedAt': q['publishedAt'] // 1000,
                    'firstSeenAt': q['firstSeenAt'] // 1000}
        self.assertTrue(self.station._job_fresh(restored, q['endsAt'] + 1000))
        changed = deepcopy(restored)
        changed['sources'][0]['title'] = 'I think gold could move for an invented reason.'
        self.assertFalse(self.station._job_fresh(changed, q['endsAt']))
        self.assertFalse(self.station._job_fresh(restored, NOW_MS + 3600000))

    def test_empty_or_other_language_supply_is_truthful_and_does_not_reserve_time(self):
        m = self.station.manifest('ar', NOW_MS)
        self.assertTrue(m['peopleNow']['due'])
        self.assertFalse(m['peopleNow']['eligibleNow'])
        self.assertEqual(m['peopleNow']['scheduledSeconds'], 0)
        self.assertEqual(m['peopleNow']['targetSeconds'], 120)
        self.assertEqual(m['peopleNow']['intervalSeconds'], 600)
        self.assertFalse(m['peopleNow']['translation'])
        self.assertEqual(self.station.seen['ar'], set())

    def test_price_priority_is_preserved_before_the_people_segment(self):
        price = {'kind': 'market', 'id': 'f' * 32}
        with patch.object(self.station, '_market_job', return_value=price):
            self.assertEqual(self.station._next_job('en', NOW_MS, {}), price)
        self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 0)

    def test_changed_price_moves_future_people_clock_without_earning_extra_speech(self):
        self.produce()
        before = self.station.people_now.status('en', NOW_MS)
        q = self.station.queues['en'][0]
        insertion = {'id': 'e' * 32, 'kind': 'market', 'startsAt': q['startsAt'],
                     'endsAt': q['startsAt'] + 6000}
        self.station._insert_priority('en', insertion, NOW_MS)
        after = self.station.people_now.status('en', NOW_MS)
        self.assertEqual(after['nextDueAt'], before['nextDueAt'] + 6000)
        self.assertEqual(after['scheduledSeconds'], before['scheduledSeconds'])
        moved = next(row for row in self.station.queues['en'] if row['kind'] == 'people-now')
        self.assertEqual(moved['startsAt'], insertion['endsAt'])


if __name__ == '__main__':
    unittest.main()

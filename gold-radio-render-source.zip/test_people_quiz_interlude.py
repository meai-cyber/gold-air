"""Quiz interludes use complete fake PCM and parsed synthetic public accounts.

These deterministic scheduler checks establish no live supply or voice quality.
"""
from copy import deepcopy
import io
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

from competition import QUESTION_BANK
import server
from test_people_now import reaction, AR_OPINION, NOW, NOW_MS


BOUNDARIES = (1, 4, 7, 10, 13, 16)


class PeopleQuizInterludeTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        with patch.dict('os.environ', {'RADIO_CLOUD_LLM': '0', 'RADIO_COMPETITION': '1'}), \
                patch('server.time.time', return_value=NOW):
            self.station = server.Station(self.folder.name)
        self.station.programmes = None
        self.clock = float(NOW)

    def tearDown(self):
        self.station.stop.set()
        self.folder.cleanup()

    @staticmethod
    def audio(language, duration):
        output = io.BytesIO()
        with wave.open(output, 'wb') as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(24000)
            wav.writeframes(b'\x01\x00' * round(24000 * duration))
        return SimpleNamespace(wav=output.getvalue(), duration_s=duration,
                               engine='synthetic-quiz-interlude-only', language=language)

    def seed_quiz(self, count, language='en', duration=2):
        for _ in range(count):
            job = self.station.competition.candidate(language, round(self.clock * 1000))
            self.assertIsNotNone(job)
            self.assertTrue(self.station.competition.commit(job, round(self.clock * 1000),
                round((self.clock + duration) * 1000)))
            self.clock += duration

    def story(self, language='en'):
        return {'id': 'a' * 32, 'title': 'Gold demand and Treasury yields update',
            'language': language, 'source': 'Reuters',
            'url': 'https://www.reuters.com/markets/fresh-gold-interlude',
            'publishedAt': NOW - 20, 'firstSeenAt': NOW - 19,
            'sourceKind': 'publisher-rss', 'clockBasis': 'publisher-rss-publication',
            'publicationField': 'pubdate', 'originalPublicationVerified': True,
            'originalPublishedAt': NOW - 20}

    def test_full_arabic_150_second_interlude_resumes_same_quiz_and_computed_result(self):
        station, calls, saved, case = self.station, [], [], self
        rows = [reaction(key=i + 1, username='listener' + str(i),
            account_id=str(12345 + i), text=AR_OPINION) for i in range(10)]
        waits = [0]

        def advance_wait(_seconds):
            waits[0] += 1
            case.assertLess(waits[0], 1000, 'a complete scripted show must finish without a scheduler spin')
            case.clock += 1

        def capture():
            candidates = station.queues['ar']
            latest = max(candidates, key=lambda q: q['generatedAt'])
            if all(q['id'] != latest['id'] for q in saved):
                saved.append(deepcopy(latest))

        class Voice:
            def synthesize(self, text, language, voice_profile=None):
                kind = station.preparing[language]['kind']
                before = station.competition.status(language, round(case.clock * 1000))['emittedTurns']
                calls.append((kind, before, text, voice_profile))
                duration = 15 if kind == 'people-now' else 2
                case.clock += duration
                if kind == 'competition' and before == 3:
                    station.stories.update({row['id']: row for row in rows})
                if kind == 'competition' and before == 16:
                    station.stop.set()
                return case.audio(language, duration)

        with patch('server.time.time', side_effect=lambda: self.clock), \
                patch.object(station.stop, 'wait', side_effect=advance_wait), \
                patch.object(station, '_save_receipts', side_effect=capture):
            station._produce(Voice(), ('ar',))
        opinions = [q for q in saved if q['kind'] == 'people-now']
        quiz = [q for q in saved if q['kind'] == 'competition']
        self.assertEqual(len(opinions), 10)
        self.assertEqual(sum(q['durationSeconds'] for q in opinions), 150)
        self.assertEqual([q['competition']['turnIndex'] for q in quiz], list(range(17)))
        self.assertEqual({before for kind, before, _text, _voice in calls if kind == 'people-now'}, {4})
        self.assertEqual([kind for kind, *_rest in calls], ['competition'] * 4 + ['people-now'] * 10 + ['competition'] * 13)
        episode = quiz[0]['competition']['episodeId']
        self.assertEqual({q['competition']['episodeId'] for q in quiz}, {episode})
        self.assertGreater(opinions[-1]['endsAt'] - quiz[3]['endsAt'], 60000)
        self.assertGreaterEqual(quiz[4]['startsAt'], opinions[-1]['endsAt'])
        self.assertTrue(station.competition.status('ar', round(self.clock * 1000))['completed'])
        self.assertFalse(station.competition.status('ar', round(self.clock * 1000))['abandoned'])
        self.assertEqual(station.competition_interlude_end['ar'], {'episodeId': episode, 'endsAt': opinions[-1]['endsAt']})
        self.assertIsNone(station.competition_interlude_end['en'])
        bank, scores = {q['id']: q for q in QUESTION_BANK}, {'player-a': 0, 'player-b': 0}
        for question in (q['competition'] for q in quiz if q['competition']['stage'] == 'question'):
            fact = bank[question['questionId']]
            correct = fact['ar'][fact['correctChoice']]
            for answer in (q['competition'] for q in quiz if q['competition'].get('questionId') == question['questionId'] and q['competition']['stage'] in scores):
                scores[answer['stage']] += int(question['choices'][answer['answerChoice']] == correct)
        result = quiz[-1]['competition']
        self.assertEqual(result['scores'], scores)
        self.assertEqual(result['winnerRole'], 'player-a' if scores['player-a'] > scores['player-b'] else 'player-b')
        self.assertFalse(result['realPrize'])

    def test_only_complete_round_boundaries_offer_people_or_latest_news(self):
        station = self.station
        row = reaction()
        station.stories[row['id']] = row
        station.ingest([self.story()], NOW)
        for count in range(1, 17):
            self.seed_quiz(1)
            now_ms = round(self.clock * 1000)
            people = station._competition_people_interlude('en', now_ms, {})
            news = station._latest_news_job('en', now_ms, {})
            self.assertEqual(people is not None, count in BOUNDARIES)
            self.assertEqual(news is not None, count in BOUNDARIES)
            selected = station._next_job('en', now_ms, {})
            if count in BOUNDARIES:
                self.assertEqual(selected['kind'], 'news', 'fresh headlines retain priority before social interludes')
            else:
                self.assertEqual(selected['kind'], 'competition')
                self.assertEqual(selected['competition']['turnIndex'], count)
        with patch.object(station, '_market_job', return_value={'id': 'f' * 32, 'kind': 'market'}):
            self.assertEqual(station._next_job('en', round(self.clock * 1000), {})['kind'], 'market')

    def test_failed_or_merely_offered_opinion_never_extends_quiz_retry_reference(self):
        station, case = self.station, self
        self.seed_quiz(1)
        row = reaction()
        station.stories[row['id']] = row
        now_ms = round(self.clock * 1000)
        self.assertIsNotNone(station._competition_people_interlude('en', now_ms, {}))
        self.assertIsNone(station.competition_interlude_end['en'])

        class Voice:
            def synthesize(self, *_args, **_kwargs):
                station.stop.set()
                raise ValueError('Synthetic interlude voice failure')

        with patch('server.time.time', side_effect=lambda: case.clock):
            station._produce(Voice(), ('en',))
        self.assertEqual(station.people_now.status('en', now_ms)['emittedPosts'], 0)
        self.assertIsNone(station.competition_interlude_end['en'])
        self.assertFalse(station._competition_in_progress('en', now_ms + 60001))
        state = station.competition.status('en', now_ms + 60001)
        self.assertTrue(state['abandoned'])
        self.assertFalse(state['completed'])
        self.assertNotIn('winner', state)

    def test_original_episode_wall_rejects_an_interlude_that_cannot_leave_room_to_resume(self):
        station = self.station
        self.seed_quiz(10, duration=85)
        row = reaction()
        station.stories[row['id']] = row
        now_ms = round(self.clock * 1000)
        state = station.competition.status('en', now_ms)
        next_quiz = station._competition_continuation('en', now_ms, {})
        self.assertIsNotNone(next_quiz)
        self.assertEqual(next_quiz['competition']['turnIndex'], 10)
        self.assertIsNone(station._competition_people_interlude('en', now_ms, {}))
        offered = station.people_now.candidate('en', [row], now_ms)
        offered.update(_competitionInterludeEpisodeId=state['episodeId'], _competitionInterludeTurn=10)
        self.assertFalse(station._competition_interlude_can_commit(offered, now_ms + 6000, now_ms + 61000, now_ms))
        deadline = state['episodeStartedAt'] + 900000
        self.assertFalse(station._competition_in_progress('en', deadline))
        self.assertEqual(station.competition.status('en', deadline)['episodeStartedAt'], state['episodeStartedAt'])
        self.assertFalse(station.competition.status('en', deadline)['completed'])

    def test_complete_news_interlude_is_committed_then_the_same_question_resumes(self):
        station, case = self.station, self
        self.seed_quiz(1)
        station.ingest([self.story()], NOW)
        episode = station.competition.status('en', round(self.clock * 1000))['episodeId']
        calls = []

        class Voice:
            def synthesize(self, text, language, voice_profile=None):
                calls.append((station.preparing[language]['kind'], text))
                station.stop.set()
                return case.audio(language, 2)

        with patch('server.time.time', side_effect=lambda: case.clock):
            station._produce(Voice(), ('en',))
        news = next(q for q in station.queues['en'] if q['kind'] == 'news')
        self.assertEqual(station.competition_interlude_end['en'], {'episodeId': episode, 'endsAt': news['endsAt']})
        self.assertEqual(station.competition.status('en', round(self.clock * 1000))['emittedTurns'], 1)
        station.stop.clear()
        with patch('server.time.time', side_effect=lambda: case.clock):
            station._produce(Voice(), ('en',))
        question = next(q for q in station.queues['en'] if q['kind'] == 'competition')
        self.assertEqual(question['competition']['episodeId'], episode)
        self.assertEqual(question['competition']['turnIndex'], 1)
        self.assertGreaterEqual(question['startsAt'], news['endsAt'])
        self.assertEqual([kind for kind, _text in calls], ['news', 'competition'])

    def test_changed_price_shift_tracks_only_the_real_interlude_audio_end(self):
        station, case = self.station, self
        self.seed_quiz(1)
        row = reaction()
        station.stories[row['id']] = row
        now_ms = round(self.clock * 1000)

        class Voice:
            def synthesize(self, _text, language, **_kwargs):
                station.stop.set()
                return case.audio(language, 15)

        with patch('server.time.time', side_effect=lambda: case.clock):
            station._produce(Voice(), ('en',))
        quote = next(q for q in station.queues['en'] if q['kind'] == 'people-now')
        old_end = quote['endsAt']
        quiz_tail = station.competition.status('en', now_ms)['lastEndAt']
        station._insert_priority('en', {'id': 'e' * 32, 'kind': 'market',
            'startsAt': quote['startsAt'], 'endsAt': quote['startsAt'] + 6000}, now_ms)
        self.assertEqual(quote['endsAt'], old_end + 6000)
        self.assertEqual(station.competition_interlude_end['en']['endsAt'], quote['endsAt'])
        self.assertEqual(station.competition.status('en', now_ms)['lastEndAt'], quiz_tail)
        self.assertEqual(station.people_now.status('en', now_ms)['scheduledSeconds'], 15)


if __name__ == '__main__':
    unittest.main()

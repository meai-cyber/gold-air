from copy import deepcopy
from decimal import Decimal
import unittest

from market_brief import MarketDesk, Quote
from market_outlook import (compute_outlook, OutlookDesk, MODEL_ID, MAX_LEDGER_RECORDS,
                            OUTCOME_TOLERANCE_SECONDS)


class MarketOutlookTests(unittest.TestCase):
    now = 1792886400

    def desk(self, offsets=None, slope=2, flat=False):
        result = MarketDesk()
        for offset in (offsets if offsets is not None else range(-300, 1, 30)):
            price = Decimal('4010.125') if flat else Decimal('4010.125') + Decimal(str(slope)) * Decimal(offset) / 60
            price = price.quantize(Decimal('.000000001'))
            result.observe(Quote(price, self.now + offset, self.now + offset + 2))
        return result

    def test_monotonic_up_down_use_real_times_and_keep_baseline_precision(self):
        for slope, direction in ((2, 'up'), (-2, 'down')):
            with self.subTest(slope=slope):
                snapshot = self.desk(slope=slope).snapshot(self.now + 3)
                saved = deepcopy(snapshot)
                outlook = compute_outlook(snapshot, self.now + 3)
                self.assertEqual(outlook['status'], 'ready')
                self.assertEqual(outlook['modelId'], MODEL_ID)
                self.assertEqual(outlook['baselinePriceText'], '4010.125')
                self.assertAlmostEqual(outlook['slopeUSDPerMinute'], slope)
                self.assertEqual(outlook['sourceAt'], self.now * 1000)
                self.assertEqual(outlook['receivedAt'], (self.now + 2) * 1000)
                self.assertEqual([row['horizonMinutes'] for row in outlook['forecasts']], [1, 3, 5])
                for forecast in outlook['forecasts']:
                    self.assertEqual(forecast['targetAt'], (self.now + 3 + forecast['horizonMinutes'] * 60) * 1000)
                    self.assertEqual(forecast['direction'], direction)
                    self.assertLess(forecast['rangeLow'], forecast['price'])
                    self.assertGreater(forecast['rangeHigh'], forecast['price'])
                    self.assertFalse(forecast['rangeCalibrated'])
                    self.assertEqual(forecast['noChangePrice'], 4010.125)
                self.assertFalse(outlook['trainedModel'])
                self.assertFalse(outlook['demonstratedEdge'])
                self.assertEqual(snapshot, saved)

    def test_flat_and_sparse_samples_do_not_invent_direction_or_levels(self):
        flat = compute_outlook(self.desk(flat=True).snapshot(self.now + 3), self.now + 3)
        self.assertEqual(flat['status'], 'flat')
        self.assertEqual(flat['forecasts'], [])
        self.assertIsNone(flat['levels'])
        for offsets in ((0,), (-60, -30, 0), (-30, -20, -10, -5, 0)):
            sparse = compute_outlook(self.desk(offsets).snapshot(self.now + 3), self.now + 3)
            self.assertEqual(sparse['status'], 'insufficient')
            self.assertEqual(sparse['forecasts'], [])
            self.assertIsNone(sparse['levels'])

    def test_irregular_sampling_uses_seconds_and_an_outage_is_not_interpolated(self):
        offsets = (-240, -205, -170, -120, -75, -35, 0)
        result = compute_outlook(self.desk(offsets).snapshot(self.now + 3), self.now + 3)
        self.assertEqual(result['status'], 'ready')
        self.assertAlmostEqual(result['slopeUSDPerMinute'], 2)
        gap = compute_outlook(self.desk((-300, -270, -240, -210, -180, -25, 0)).snapshot(self.now + 3), self.now + 3)
        self.assertEqual(gap['status'], 'insufficient')
        self.assertEqual(gap['observationCount'], 2)
        self.assertEqual(gap['reason'], 'insufficient-contiguous-observations')

    def test_future_source_or_late_receipt_cannot_leak_into_projection(self):
        snapshot = self.desk().snapshot(self.now + 3)
        expected = compute_outlook(snapshot, self.now + 3)
        future = deepcopy(snapshot)
        future['observations'].append({'price': 9000, 'priceText': '9000',
            'sourceAt': (self.now + 30) * 1000, 'receivedAt': (self.now + 31) * 1000})
        self.assertEqual(compute_outlook(future, self.now + 3), expected)
        late = deepcopy(snapshot)
        late['observations'].insert(0, {'price': 9000, 'priceText': '9000',
            'sourceAt': (self.now - 300) * 1000, 'receivedAt': (self.now + 30) * 1000})
        self.assertEqual(compute_outlook(late, self.now + 3), expected)

    def test_conflicting_duplicate_or_history_reference_mismatch_fails_closed(self):
        snapshot = self.desk().snapshot(self.now + 3)
        revised = deepcopy(snapshot)
        duplicate = {**revised['observations'][0], 'price': 9000, 'priceText': '9000'}
        revised['observations'].insert(1, duplicate)
        result = compute_outlook(revised, self.now + 3)
        self.assertEqual(result['forecasts'], [])
        self.assertEqual(result['reason'], 'revised-observation-clock')
        snapshot['observations'][-1]['priceText'] = '4012'
        self.assertEqual(compute_outlook(snapshot, self.now + 3)['forecasts'], [])

    def test_observed_swings_are_tentative_and_clocked(self):
        desk = MarketDesk()
        for offset, price in ((-150, '4000'), (-120, '4004'), (-90, '4002'), (-60, '4008'), (-30, '4005'), (0, '4006')):
            desk.observe(Quote(Decimal(price), self.now + offset, self.now + offset + 2))
        levels = compute_outlook(desk.snapshot(self.now + 3), self.now + 3)['levels']
        self.assertEqual(levels['support'], 4005)
        self.assertEqual(levels['resistance'], 4008)
        self.assertEqual(levels['supportSourceAt'], (self.now - 30) * 1000)
        self.assertEqual(levels['resistanceSourceAt'], (self.now - 60) * 1000)
        self.assertTrue(levels['tentative'])
        self.assertFalse(levels['guaranteed'])

    def test_stale_invalid_quotes_and_bad_clocks_never_make_a_forecast(self):
        snapshot = self.desk().snapshot(self.now + 3)
        for change in ({'sourceAt': (self.now + 5) * 1000}, {'receivedAt': (self.now + 4) * 1000},
                       {'provider': 'Different source'}, {'priceText': 'NaN'}, {'status': 'stale'}):
            with self.subTest(change=change):
                self.assertEqual(compute_outlook({**snapshot, **change}, self.now + 3)['forecasts'], [])
        self.assertEqual(compute_outlook(snapshot, self.now + 91)['reason'], 'stale-reference')
        for stamp in (True, 0, -1, 1.5):
            with self.assertRaises(ValueError):
                compute_outlook(snapshot, stamp)

    def test_forward_ledger_requires_commit_and_genuinely_later_matched_observation(self):
        prices = self.desk()
        desk = OutlookDesk()
        issued = desk.prepare(prices.snapshot(self.now + 3), self.now + 3)
        self.assertEqual(desk.status()['retainedRecords'], 0)
        saved = deepcopy(issued)
        self.assertTrue(desk.commit(issued))
        self.assertFalse(desk.commit(issued))
        self.assertEqual(desk.status()['pending'], 3)
        self.assertEqual(desk.prepare(prices.snapshot(self.now + 30), self.now + 30)['evaluation']['matched'], 0)
        target = issued['forecasts'][0]['targetAt'] // 1000
        prices.observe(Quote(Decimal('4008.125'), target, target + 2))
        update = desk.prepare(prices.snapshot(target + 3), target + 3)
        last = update['evaluation']['latestMature']
        self.assertEqual(update['evaluation']['matched'], 1)
        self.assertEqual(last['actualSourceAt'], target * 1000)
        self.assertFalse(last['directionCorrect'])
        self.assertAlmostEqual(last['absoluteErrorUSD'], 4.1)
        self.assertEqual(last['noChangeAbsoluteErrorUSD'], 2)
        self.assertEqual(issued, saved)
        # Editing the caller's old object cannot rewrite the saved forecast.
        issued['forecasts'][0]['price'] = 4008.125
        self.assertAlmostEqual(desk.status()['latestMature']['absoluteErrorUSD'], 4.1)

    def test_missed_outcome_is_missing_not_matched_to_a_later_convenient_price(self):
        prices = self.desk()
        desk = OutlookDesk()
        outlook = desk.prepare(prices.snapshot(self.now + 3), self.now + 3)
        desk.commit(outlook)
        target = outlook['forecasts'][0]['targetAt'] // 1000
        prices.observe(Quote(Decimal('5000'), target + OUTCOME_TOLERANCE_SECONDS + 1,
                             target + OUTCOME_TOLERANCE_SECONDS + 2))
        now = target + OUTCOME_TOLERANCE_SECONDS + 91
        desk.prepare({'status': 'stale'}, now)
        self.assertEqual(desk.status()['matched'], 0)
        self.assertEqual(desk.status()['missing'], 1)

    def test_ledger_is_bounded_and_malformed_future_targets_are_not_committed(self):
        desk = OutlookDesk()
        snapshot = self.desk().snapshot(self.now + 3)
        for offset in range(70):
            self.assertTrue(desk.commit(compute_outlook(snapshot, self.now + 3 + offset)))
        self.assertEqual(desk.status()['retainedRecords'], MAX_LEDGER_RECORDS)
        broken = compute_outlook(snapshot, self.now + 80)
        broken['forecasts'][0]['targetAt'] = broken['issuedAt'] - 1
        self.assertFalse(desk.commit(broken))
        self.assertFalse(desk.commit({'status': 'ready', 'modelId': MODEL_ID, 'id': 'x', 'forecasts': []}))


if __name__ == '__main__':
    unittest.main()

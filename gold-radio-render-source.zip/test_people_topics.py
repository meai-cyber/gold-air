"""Offline topical programme fixtures; no provider, network or live evidence."""
from copy import deepcopy
import json
import unittest

from people_now import PeopleNow, job_fresh, translation_parent
from people_translation import translate_comment
from test_people_now import reaction, reply, OPINION, AR_OPINION, NOW, NOW_MS
import test_social_scrapling as hn
from social_scrapling import parse_listing, parse_thread, context_parent


class TopicalPeopleTests(unittest.TestCase):
    def test_exhausts_distinct_accounts_on_same_news_before_changing_topic(self):
        first, root = reply(handle='first.example')
        second, same_root = reply(author_did='did:plc:' + 'b' * 24, handle='second.example')
        other, other_root = reply(author_did='did:plc:' + 'c' * 24, handle='third.example',
            root_key='other123', root_title='Oil prices react to new inflation figures',
            text='I think oil deserves a closer comparison.')
        self.assertEqual(root, same_root)
        planner = PeopleNow()
        job = planner.candidate('en', [first, root], NOW_MS)
        self.assertEqual(job['peopleNow']['topic']['association'], 'reply-to-collected-post')
        self.assertTrue(job['peopleNow']['topic']['startsTopic'])
        self.assertEqual(job['speechText'], 'On a Reuters post: ' + root['title'] + '. first.example: “' + OPINION + '”')
        self.assertTrue(planner.commit(job, NOW_MS, NOW_MS + 20000))
        following = planner.candidate('en', [first, second, root, other, other_root], NOW_MS + 20000)
        self.assertEqual(following['sourceIds'], [second['id']])
        self.assertFalse(following['peopleNow']['topic']['startsTopic'])
        self.assertEqual(following['speechText'], 'second.example: “' + OPINION + '”')
        self.assertTrue(planner.commit(following, NOW_MS + 20000, NOW_MS + 30000))
        next_topic = planner.candidate('en', [first, second, root, other, other_root], NOW_MS + 30000)
        self.assertEqual(next_topic['sourceIds'], [other['id']])
        self.assertTrue(next_topic['peopleNow']['topic']['startsTopic'])
        self.assertNotEqual(next_topic['peopleNow']['topic']['key'], job['peopleNow']['topic']['key'])
        self.assertIn(other_root['title'], next_topic['speechText'])
        self.assertTrue(planner.commit(next_topic, NOW_MS + 30000, NOW_MS + 40000))
        late, _ = reply(author_did='did:plc:' + 'd' * 24, handle='late.example')
        self.assertIsNone(planner.candidate('en', [late, root], NOW_MS + 40000),
                          'a finished topic cannot return as a bare reply under a different headline')

    def test_rootless_opinions_get_explicit_themes_not_an_invented_news_association(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        self.assertEqual(first['peopleNow']['topic']['key'], 'theme:gold-rates')
        self.assertEqual(first['peopleNow']['topic']['association'], 'shared-explicit-topic-not-a-news-reply')
        self.assertEqual(first['speechText'], 'On gold and interest rates. listener@mastodon.social: “' + OPINION + '”')
        self.assertTrue(planner.commit(first, NOW_MS, NOW_MS + 15000))
        another = reaction(key=2, username='another', account_id='23456')
        following = planner.candidate('en', [another], NOW_MS + 15000)
        self.assertEqual(following['speechText'], 'another@mastodon.social: “' + OPINION + '”')
        self.assertNotIn('post:', following['speechText'])
        self.assertEqual(following['maxAudioSeconds'], 35)

    @staticmethod
    def hn_post(title='Oil prices rise after new inflation figures.', root_age=100):
        markup = hn.story(title=title, age=root_age)
        root = parse_listing(hn.listing([markup]), hn.NOW)[0]
        text = 'I think oil and inflation deserve a closer comparison before drawing a conclusion.'
        return parse_thread(hn.thread([hn.comment(text=text)], root_story=markup), root, hn.NOW)[0]

    def test_recent_comment_does_not_turn_old_or_tool_discussion_into_news(self):
        for title, root_age in (('Oil prices rise after new inflation figures.', 3601),
                ('Show HN: An AI tool for comparing oil prices', 100),
                ('The result of the C++26 DIS ballot', 100)):
            with self.subTest(title=title, root_age=root_age):
                post = self.hn_post(title, root_age)
                self.assertIsNone(PeopleNow().candidate('en', [post], hn.NOW * 1000))
        fresh = self.hn_post()
        job = PeopleNow().candidate('en', [fresh], hn.NOW * 1000)
        self.assertIsNotNone(job)
        self.assertTrue(job['speechText'].startswith('On this Hacker News headline: '))
        self.assertEqual(job['peopleNow']['maxParentAgeSeconds'], 3600)
        self.assertNotIn('verified', job['speechText'])

    def test_arabic_news_intro_and_complete_comment_use_the_same_validated_context(self):
        post = self.hn_post()
        parent = translation_parent(post, {})
        self.assertEqual(parent, context_parent(post))
        arabic_title = 'ارتفاع أسعار النفط بعد بيانات تضخم جديدة.'
        arabic_comment = 'أعتقد أن النفط والتضخم يستحقان مقارنة أدق قبل استخلاص نتيجة.'
        translations = {parent['title']: arabic_title, post['title']: arabic_comment}

        class Runtime:
            def status(self):
                return {'modelId': 'nvidia/nemotron-3.5-bolt-e4b'}

            def generate(self, prompt, **_kwargs):
                return translations[json.loads(prompt.split('PUBLIC_TEXT_JSON: ', 1)[1])]

        post['machineTranslations'] = {'ar': translate_comment(Runtime(), post, parent, now_s=hn.NOW)}
        job = PeopleNow().candidate('ar', [post], hn.NOW * 1000)
        self.assertIsNotNone(job)
        self.assertEqual(job['speechText'], 'حول هذا العنوان المتداول على Hacker News: ' +
                         arabic_title + ' Public_Reader: «' + arabic_comment + '»')
        self.assertNotIn(parent['title'], job['speechText'])
        self.assertEqual(job['peopleNow']['topic']['introMode'], 'source-title')
        self.assertTrue(job_fresh(job, hn.NOW * 1000 + 30000))
        for change in (lambda value: value['peopleNow']['topic'].update(title='عنوان مختلف.'),
                lambda value: value['sources'][0]['machineTranslations']['ar'].update(contextText='عنوان مختلف.')):
            altered = deepcopy(job)
            change(altered)
            self.assertFalse(job_fresh(altered, hn.NOW * 1000 + 30000))

    def test_native_arabic_reply_to_english_news_uses_an_arabic_topic_not_fake_title_translation(self):
        row, root = reply(text=AR_OPINION)
        job = PeopleNow().candidate('ar', [row, root], NOW_MS)
        self.assertIsNotNone(job)
        self.assertEqual(job['peopleNow']['topic']['introMode'], 'topic-label')
        self.assertEqual(job['speechText'], 'عن الذهب وأسعار الفائدة. listener.example: «' + AR_OPINION + '»')
        self.assertNotIn(root['title'], job['speechText'])
        self.assertEqual(job['sources'], [row, root])

    def test_intro_budget_does_not_relax_later_complete_quote_or_total_audio_limits(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        self.assertEqual(first['maxAudioSeconds'], 55)
        self.assertFalse(planner.can_commit(first, NOW_MS, NOW_MS + 55001))
        self.assertTrue(planner.commit(first, NOW_MS, NOW_MS + 55000))
        following = planner.candidate('en', [reaction(key=2, username='another', account_id='23456')], NOW_MS + 55000)
        self.assertEqual(following['maxAudioSeconds'], 35)
        self.assertFalse(planner.can_commit(following, NOW_MS + 55000, NOW_MS + 90001))
        self.assertTrue(planner.commit(following, NOW_MS + 55000, NOW_MS + 90000))
        status = planner.status('en', NOW_MS + 90000)
        self.assertEqual((status['scheduledSeconds'], status['targetSeconds'], status['intervalSeconds']), (90, 150, 900))
        self.assertEqual(status['introducedTopics'], 1)
        self.assertEqual(status['sessionWallSeconds'], 240)


if __name__ == '__main__':
    unittest.main()

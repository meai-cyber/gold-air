"""One-hour source-clock admission for spoken cloud-radio news.

This validates collector provenance and timestamp consistency, not the truth of
a publisher's report or the representativeness of a public reaction. Callers
still apply their topic, moderation and playback-receipt policies separately.
Only the fixed collectors may construct these records; no listener-submitted
row or verification flag is an authorization to fetch a URL.

Google News clocks establish discovery time, not original publication time.
An aggregator item must be replaced with a canonical, approved publisher row
with an original publication clock before it can become spoken current news.
"""
from __future__ import annotations

from source_policy import publisher_url_allowed, story_allowed


FRESHNESS_POLICY_VERSION = 'original-publication-one-hour-2026-10-25-v1'
MAX_NEWS_AGE_S = 3600
PUBLISHER_CLOCK_BASIS = 'publisher-rss-publication'
PUBLISHER_PUBLICATION_FIELDS = frozenset({'pubdate', 'published'})
PUBLICATION_EVIDENCE_FIELDS = ('sourceKind', 'platform', 'social', 'clockBasis', 'timeKind',
    'publicationField', 'originalPublishedAt', 'originalPublicationVerified', 'broadcastEligible',
    'discoveryOnly', 'feedback', 'reaction', 'verification')


def publication_evidence(row):
    return {key: row[key] for key in PUBLICATION_EVIDENCE_FIELDS if key in row}
# POSIX seconds through 9999-12-31; also rejects accidental millisecond clocks.
_MAX_EPOCH_SECONDS = 253402300799


def _clock(value):
    return type(value) is int and 0 < value <= _MAX_EPOCH_SECONDS


def validated_news_publication(row, now_s, *, max_age_s=MAX_NEWS_AGE_S, at_s=None):
    """Return the accepted original publication second, otherwise ``None``.

    ``now_s`` is the collection/admission clock. Optional ``at_s`` is a future
    playback boundary: freshness must still hold there, but a future receipt
    can never be made valid by supplying that later boundary. A smaller age
    window is allowed; no caller can enlarge the station's one-hour ceiling.

    Legacy RSS rows without original-clock provenance fail closed. Re-fetching,
    editing, indexing or restoring a receipt never renews a report's age.
    """
    if (not isinstance(row, dict) or not _clock(now_s) or
            type(max_age_s) is not int or not 0 < max_age_s <= MAX_NEWS_AGE_S):
        return None
    boundary = now_s if at_s is None else at_s
    if not _clock(boundary) or boundary < now_s:
        return None
    published, received = row.get('publishedAt'), row.get('firstSeenAt')
    if (not _clock(published) or not _clock(received) or
            not published <= received <= now_s or boundary - published > max_age_s):
        return None
    # Contradictory original clocks cannot be hidden behind a recent index or
    # edit clock, including in restored rows from a previous release.
    if 'originalPublishedAt' in row and (
            not _clock(row['originalPublishedAt']) or row['originalPublishedAt'] != published):
        return None
    if row.get('broadcastEligible') is False or not story_allowed(row):
        return None

    kind, basis = row.get('sourceKind'), row.get('clockBasis')
    if not isinstance(kind, str):
        return None
    if kind == 'publisher-rss':
        if (row.get('social') not in (None, False) or not publisher_url_allowed(row.get('url')) or
                basis != PUBLISHER_CLOCK_BASIS or
                not isinstance(row.get('publicationField'), str) or
                row.get('publicationField') not in PUBLISHER_PUBLICATION_FIELDS or
                row.get('originalPublicationVerified') is not True or
                row.get('originalPublishedAt') != published):
            return None
        return published

    if kind == 'social-reaction':
        if (row.get('social') is not True or row.get('platform') != 'Mastodon' or
                basis != 'author-reported' or row.get('timeKind') != 'published'):
            return None
        return published

    if kind in {'social', 'social-feedback'}:
        # source_policy validates a pinned publisher DID, or the exact pinned
        # parent-post provenance of a public reply. A reply remains unverified.
        if (row.get('social') is not True or row.get('platform') != 'Bluesky' or
                basis != 'author-reported' or row.get('timeKind') != 'published'):
            return None
        if kind == 'social-feedback':
            root = row.get('feedback', {}).get('rootPublishedAt')
            if not _clock(root) or root > published:
                return None
        return published

    # Unknown/legacy source kinds and discovery-only aggregator clocks never
    # become publication evidence through a caller-provided boolean flag.
    return None


def is_fresh_news(row, now_s, *, max_age_s=MAX_NEWS_AGE_S, at_s=None):
    """Boolean form of :func:`validated_news_publication`."""
    return validated_news_publication(row, now_s, max_age_s=max_age_s, at_s=at_s) is not None

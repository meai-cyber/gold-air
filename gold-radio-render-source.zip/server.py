"""Standalone public-news radio. Server speech, fixed feeds, no synthesis API.

Run with python server.py. State and generated audio are ephemeral on Render;
neither the Gold Pulse account database nor household data are used here.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html import unescape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import wave
from station_music import MUSIC_FILE, MUSIC_SECONDS
from market_brief import MarketDesk, QuoteUnavailable, POLL_SECONDS, MAX_QUOTE_AGE_S
from news_selection import select_news
from live_updates import LiveUpdateCollector, SOURCE as LIVE_SOURCE

WINDOW_S = 600
EARLIER_WINDOW_S = 3600
MAX_FEED_BYTES = 1024 * 1024
MAX_AUDIO_BYTES = 8 * 1024 * 1024
MAX_STORIES = 1000
MAX_QUEUE = 12
MAX_CLIP_S = 45
FEED_INTERVAL_S = 30
SERVICE_VERSION = '2026-10-23-continuous-news-1'
SPEECH_LOOKAHEAD_S = 45
MARKET_SPEECH_INTERVAL_S = 60
NEWS_BURST_LIMIT = 2
WORKSPACE = 'https://g.au7.workers.dev/app'
HERE = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Feed:
    source: str
    language: str
    url: str
    domains: tuple[str, ...]


FEEDS = (
    Feed('بي بي سي عربي', 'ar', 'https://feeds.bbci.co.uk/arabic/rss.xml', ('bbc.com', 'bbc.co.uk')),
    Feed('الجزيرة', 'ar', 'https://www.aljazeera.net/aljazeerarss', ('aljazeera.net',)),
    Feed('فرانس 24', 'ar', 'https://www.france24.com/ar/rss', ('france24.com',)),
    Feed('BBC World', 'en', 'https://feeds.bbci.co.uk/news/world/rss.xml', ('bbc.com', 'bbc.co.uk')),
    Feed('BBC Business', 'en', 'https://feeds.bbci.co.uk/news/business/rss.xml', ('bbc.com', 'bbc.co.uk')),
    Feed('The Guardian', 'en', 'https://www.theguardian.com/world/rss', ('theguardian.com',)),
    Feed('دويتشه فيله', 'ar', 'https://rss.dw.com/rdf/rss-ar-all', ('dw.com',)),
    Feed('سكاي نيوز عربية', 'ar', 'https://www.skynewsarabia.com/rss', ('skynewsarabia.com',)),
    Feed('Al Jazeera English', 'en', 'https://www.aljazeera.com/xml/rss/all.xml', ('aljazeera.com',)),
    Feed('France 24 English', 'en', 'https://www.france24.com/en/rss', ('france24.com',)),
    Feed('سي إن إن الاقتصادية', 'ar', 'https://cnnbusinessarabic.com/rssFeed/0', ('cnnbusinessarabic.com',)),
    Feed('CNBC Top News', 'en', 'https://www.cnbc.com/id/100003114/device/rss/rss.html', ('cnbc.com',)),
    Feed('CNBC Energy', 'en', 'https://www.cnbc.com/id/19836768/device/rss/rss.html', ('cnbc.com',)),
    Feed('The Guardian Business', 'en', 'https://www.theguardian.com/uk/business/rss', ('theguardian.com',)),
    Feed('Federal Reserve policy', 'en', 'https://www.federalreserve.gov/feeds/press_monetary.xml', ('federalreserve.gov',)),
    Feed('Federal Reserve speeches', 'en', 'https://www.federalreserve.gov/feeds/speeches.xml', ('federalreserve.gov',)),
    Feed('يورونيوز', 'ar', 'https://arabic.euronews.com/rss?level=theme&name=news', ('euronews.com',)),
    Feed('Euronews', 'en', 'https://www.euronews.com/rss?level=theme&name=news', ('euronews.com',)),
)


def plain(value, limit=400):
    if not isinstance(value, str) or len(value) > 8192:
        return ''
    value = unescape(re.sub(r'<[^>]*>', ' ', value))
    value = re.sub(r'https?://\S+|www\.\S+', '', value, flags=re.I)
    value = re.sub(r'\s+', ' ', value).strip()
    if re.search(r'[\x00-\x1f\x7f]', value):
        return ''
    return value[:limit].strip()


def public_link(value, domains):
    try:
        url = urllib.parse.urlsplit(value)
        host = (url.hostname or '').lower()
        if (url.scheme != 'https' or url.username or url.password or url.port or
                any(ord(c) < 33 for c in value) or '\\' in value):
            return ''
        return value if any(host == d or host.endswith('.' + d) for d in domains) else ''
    except (TypeError, ValueError):
        return ''


def publication(value, received):
    try:
        try:
            parsed = parsedate_to_datetime(value)
        except (ValueError, TypeError):
            parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            return None
        stamp = int(parsed.timestamp())
        return stamp if 0 < stamp <= received else None
    except (ValueError, TypeError, OverflowError, AttributeError):
        return None


def story_id(title):
    key = re.sub(r'[^\w]+', ' ', unicodedata.normalize('NFKC', title).casefold()).strip()
    return hashlib.sha256(key.encode()).hexdigest()[:32]


def parse_feed(body, feed, received):
    if feed not in FEEDS or not isinstance(body, bytes) or len(body) > MAX_FEED_BYTES:
        raise ValueError('Unsupported feed')
    if b'\x00' in body or re.search(br'<!\s*(?:DOCTYPE|ENTITY)\b', body, re.I):
        raise ValueError('Unsupported XML')
    root = ET.fromstring(body)
    entries = [n for n in root.iter() if n.tag.rsplit('}', 1)[-1] in ('item', 'entry')]
    if len(entries) > 500:
        raise ValueError('Feed entry limit')
    rows = []
    for entry in entries:
        fields = {n.tag.rsplit('}', 1)[-1].lower(): ''.join(n.itertext()).strip() for n in entry}
        title = plain(fields.get('title'))
        link = fields.get('link', '')
        if not link:
            link = next((n.get('href', '') for n in entry if n.tag.rsplit('}', 1)[-1] == 'link' and
                         n.get('rel', 'alternate') == 'alternate'), '')
        link = public_link(link, feed.domains)
        stamp = publication(fields.get('pubdate') or fields.get('published') or fields.get('updated') or fields.get('date'), received)
        if not title or not link or stamp is None or received - stamp > 86400:
            continue
        if feed.language == 'ar' and not re.search(r'[\u0621-\u064a]', title):
            continue
        row = {'id': story_id(title), 'title': title, 'source': feed.source, 'url': link,
               'language': feed.language, 'publishedAt': stamp, 'firstSeenAt': received}
        summary = plain(fields.get('description') or fields.get('summary'), 400)
        if summary:
            row['summary'] = summary
        rows.append(row)
    return rows


class FixedRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        old, new = urllib.parse.urlsplit(req.full_url), urllib.parse.urlsplit(newurl)
        if new.scheme != 'https' or new.hostname != old.hostname or new.username or new.password or new.port:
            raise ValueError('Feed redirect rejected')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_feed(feed):
    if feed not in FEEDS:
        raise ValueError('Unsupported feed')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), FixedRedirects())
    request = urllib.request.Request(feed.url, headers={'User-Agent': 'GoldPulseRadio/1.0 (+public RSS reader)',
                                                       'Accept': 'application/rss+xml, application/xml',
                                                       'Accept-Encoding': 'identity'})
    with opener.open(request, timeout=8) as response:
        if response.status != 200 or response.headers.get('Content-Encoding', 'identity') != 'identity':
            raise ValueError('Feed unavailable')
        size = response.headers.get('Content-Length')
        if size and (not size.isdecimal() or int(size) > MAX_FEED_BYTES):
            raise ValueError('Feed size limit')
        body = response.read(MAX_FEED_BYTES + 1)
    return parse_feed(body, feed, int(time.time()))


def fresh(story, now_s, window_s=WINDOW_S):
    return (isinstance(story, dict) and all(type(story.get(k)) is int for k in ('publishedAt', 'firstSeenAt')) and
            type(window_s) is int and window_s in (WINDOW_S, EARLIER_WINDOW_S) and
            0 < story['publishedAt'] <= story['firstSeenAt'] <= now_s and
            now_s - story['publishedAt'] <= window_s and now_s - story['firstSeenAt'] <= window_s)


def spoken_text(story):
    """One attributed report: title plus a bounded retrieved teaser, 24 words total."""
    title_words = story['title'].split()
    excerpt = ' '.join(title_words[:24])
    summary = plain(story.get('summary'), 400)
    if summary.casefold().startswith(story['title'].casefold()):
        summary = summary[len(story['title']):].lstrip(' .:–—-')
    if len(title_words) < 24 and summary:
        excerpt = excerpt.rstrip('.') + '. ' + ' '.join(summary.split()[:24 - len(title_words)])
    text = f"من {story['source']}، {excerpt}." if story['language'] == 'ar' else f"From {story['source']}: {excerpt}."
    if story.get('recency') == 'earlier':
        stamp = datetime.fromtimestamp(story['publishedAt'], timezone.utc).strftime('%H:%M')
        text = (f'خبر سابق نُشر الساعة {stamp} بالتوقيت العالمي. ' if story['language'] == 'ar'
                else f'Earlier report, published at {stamp} UTC. ') + text
    return text


def speech_check(speech, language):
    """Validate a private startup sample; never queue it as a news report."""
    if speech.language != language or not isinstance(speech.wav, bytes) or not 44 < len(speech.wav) <= MAX_AUDIO_BYTES:
        raise ValueError('Invalid speech sample')
    with wave.open(io.BytesIO(speech.wav), 'rb') as audio:
        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate(), audio.getcomptype()) != (1, 2, 24000, 'NONE'):
            raise ValueError('Unexpected speech format')
        frames = audio.getnframes()
        pcm = audio.readframes(frames)
    duration = frames / 24000
    if not 0 < duration <= MAX_CLIP_S or len(pcm) != frames * 2 or not any(pcm) or abs(duration - speech.duration_s) > .03:
        raise ValueError('Empty or inconsistent speech sample')
    return {'status': 'ready', 'bytes': len(speech.wav), 'durationSeconds': round(duration, 3),
            'engine': plain(speech.engine, 80), 'checkedAt': int(time.time() * 1000)}


class Station:
    def __init__(self, runtime_dir=None, tts_factory=None):
        self.directory = Path(runtime_dir or os.environ.get('RADIO_STATE_DIR') or os.environ.get('RADIO_DATA_DIR') or '/tmp/gold-radio-data')
        self.directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.stories, self.seen, self.queues = {}, {'ar': set(), 'en': set()}, {'ar': [], 'en': []}
        self.feed_states, self.errors, self.languages, self.engines = {}, {}, (), {}
        self.startup_speech_checks = {}
        self.market = MarketDesk()
        self.last_market_at = {'ar': 0, 'en': 0}
        self.last_market_id = {'ar': None, 'en': None}
        self.news_streak = {'ar': 0, 'en': 0}
        self.preparing = {'ar': None, 'en': None}
        self.last_prepared = {'ar': None, 'en': None}
        self.discussions = None
        # This cloud edition never initializes the old PC-backed importer,
        # even if a previous deployment left its environment flag enabled.
        self.live_updates = LiveUpdateCollector()
        self.live_state = self.live_updates.status()
        self.status, self.last_collection = 'starting', 0
        self.tts_factory = tts_factory
        try:
            path = Path(os.environ.get('RADIO_MODEL_DIR', '/opt/gold-radio-assets')) / MUSIC_FILE
            self.music_data = path.read_bytes() if path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_AUDIO_BYTES else None
        except OSError:
            self.music_data = None
        self._load_receipts()

    def _load_receipts(self):
        try:
            path = self.directory / 'receipts.json'
            if path.is_symlink() or path.stat().st_size > 1024 * 1024:
                return
            state = json.loads(path.read_text('utf-8'))
            now = int(time.time())
            for row in state.get('stories', [])[:MAX_STORIES]:
                if (row.get('language') in self.queues and re.fullmatch('[a-f0-9]{32}', row.get('id', '')) and
                        plain(row.get('title')) == row.get('title') and isinstance(row.get('source'), str) and
                        fresh(row, now, EARLIER_WINDOW_S)):
                    self.stories[row['id']] = row
            for lang in self.seen:
                self.seen[lang] = {v for v in state.get('seen', {}).get(lang, [])[:MAX_STORIES] if re.fullmatch('[a-f0-9]{32}', v)}
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def _save_receipts(self):
        state = {'stories': list(self.stories.values()), 'seen': {k: sorted(v)[-MAX_STORIES:] for k, v in self.seen.items()}}
        temporary = self.directory / 'receipts.tmp'
        temporary.write_text(json.dumps(state, ensure_ascii=False), 'utf-8')
        temporary.replace(self.directory / 'receipts.json')

    def ingest(self, rows, now_s=None):
        now_s = int(time.time()) if now_s is None else now_s
        with self.lock:
            for row in rows:
                if row['id'] in self.stories:
                    old = self.stories[row['id']]
                    old['firstSeenAt'] = min(old['firstSeenAt'], row['firstSeenAt'])
                    old['publishedAt'] = min(old['publishedAt'], row['publishedAt'])
                else:
                    self.stories[row['id']] = dict(row)
            self.stories = {r['id']: r for r in sorted(self.stories.values(), key=lambda r: r['firstSeenAt'], reverse=True)
                            if now_s - r['firstSeenAt'] <= 86400}
            self.stories = dict(list(self.stories.items())[:MAX_STORIES])
            for language in self.seen:
                self.seen[language].intersection_update(self.stories)
            self._save_receipts()

    def collect(self):
        while not self.stop.is_set():
            # This worker pool is owner-started; HTTP listeners cannot add URLs.
            with ThreadPoolExecutor(max_workers=3) as pool:
                jobs = [(feed, pool.submit(fetch_feed, feed)) for feed in FEEDS]
                for feed, job in jobs:
                    try:
                        self.ingest(job.result())
                        state = 'ready'
                    except Exception:
                        state = 'unavailable'
                    with self.lock:
                        self.feed_states[feed.source] = {'status': state, 'checkedAt': int(time.time() * 1000)}
                        self.last_collection = int(time.time() * 1000)
            self.stop.wait(FEED_INTERVAL_S)

    def collect_market(self):
        # Owner polling is independent of speech. No listener can initiate a fetch.
        while not self.stop.is_set():
            try:
                self.market.poll()
            except QuoteUnavailable:
                pass
            self.stop.wait(POLL_SECONDS)

    def collect_live_updates(self):
        while not self.stop.is_set():
            # Its own cache/backoff controls publisher polling. Never hold the
            # station lock across a network request or a collector status read.
            rows = self.live_updates.collect()
            state = self.live_updates.status()
            if rows:
                self.ingest(rows)
            with self.lock:
                self.live_state = state
                self.feed_states[LIVE_SOURCE] = {'status': state['status'], 'checkedAt': state['checkedAt']}
                self.last_collection = max(self.last_collection, state['checkedAt'])
            self.stop.wait(10)

    def collect_discussions(self):
        # Read finished public scripts, never a raw PC inference service.
        while not self.stop.is_set() and self.discussions is not None:
            self.discussions.poll()
            self.stop.wait(30)

    def _candidate(self, language, now_s, retry_at=None):
        retry_at = retry_at or {}
        # Select before receipts/retries: draining the queue must not promote
        # the omitted 30% merely because higher-ranked stories were spoken.
        for recency, window, minimum_age in (('fresh', WINDOW_S, 0), ('earlier', EARLIER_WINDOW_S, WINDOW_S + 1)):
            selection = select_news(self.stories.values(), language, now_s,
                                    window_s=window, minimum_age_s=minimum_age)
            values = [s for s in selection.selected if s['id'] not in self.seen[language]
                      and retry_at.get(s['id'], 0) <= now_s * 1000]
            if values:
                story = min(values, key=lambda s: (-selection.scores[s['id']], s['publishedAt'], s['firstSeenAt'], s['id']))
                return {**story, 'recency': recency, 'relevance': {'score': selection.scores[story['id']],
                        'topics': list(selection.reasons[story['id']]), 'method': selection.summary()['method']}}
        return None

    def _next_job(self, language, now_ms, retry_at):
        story = self._candidate(language, now_ms // 1000, retry_at)
        # Give fresh headlines first access, but do not let a large feed burst
        # silence every market update and discussion until the backlog expires.
        if story and self.news_streak[language] < NEWS_BURST_LIMIT:
            return {**story, 'kind': 'news'}
        if now_ms - self.last_market_at[language] >= MARKET_SPEECH_INTERVAL_S * 1000:
            market = self.market.brief(language, now_ms // 1000)
            if (market and market['id'] != self.last_market_id[language] and
                    retry_at.get(market['id'], 0) <= now_ms):
                return market
        if self.discussions is not None:
            discussion = self.discussions.candidate(language, now_ms // 1000,
                exclude_ids=[key for key, until in retry_at.items() if until > now_ms])
            if discussion:
                return discussion
        return {**story, 'kind': 'news'} if story else None

    def _production(self, language, now_ms):
        active, previous = self.preparing[language], self.last_prepared[language]
        return {'preparing': active is not None, 'kind': active['kind'] if active else None,
            'startedAt': active['startedAt'] if active else None,
            'lastPreparedAt': previous['preparedAt'] if previous else None,
            'lastPreparationSeconds': previous['seconds'] if previous else None,
            'lookaheadSeconds': SPEECH_LOOKAHEAD_S,
            'queuedSeconds': round(sum(max(0, q['endsAt'] - max(now_ms, q['startsAt']))
                for q in self.queues[language]) / 1000, 3)}

    @staticmethod
    def _job_fresh(job, at_ms):
        if job.get('kind') == 'market':
            return (0 <= at_ms // 1000 - job['publishedAt'] <= MAX_QUOTE_AGE_S and
                    job['publishedAt'] <= job['firstSeenAt'] <= at_ms // 1000)
        if job.get('kind') == 'discussion':
            programme = job['programme']
            return (0 <= at_ms - programme['windowEnd'] <= 900000 and
                    programme['windowEnd'] <= programme['generatedAt'] <= at_ms and
                    job['firstSeenAt'] <= at_ms // 1000)
        return fresh(job, at_ms // 1000, EARLIER_WINDOW_S if job.get('recency') == 'earlier' else WINDOW_S)

    def _prune(self, now_ms):
        keep = set()
        for language, queue in self.queues.items():
            # Never evict an on-air or future clip to retain expired history.
            prior = [q for q in queue if now_ms - 120000 <= q['endsAt'] <= now_ms][-2:]
            self.queues[language] = prior + [q for q in queue if q['endsAt'] > now_ms]
            keep.update(q['id'] for q in self.queues[language])
        for path in self.directory.glob('*.wav'):
            if path.stem not in keep and time.time() - path.stat().st_mtime > 180:
                path.unlink(missing_ok=True)

    def generate(self):
        try:
            if self.tts_factory is None:
                from tts import ServerTts
                tts = ServerTts()
            else:
                tts = self.tts_factory()
            with self.lock:
                self.languages = tuple(l for l in tts.available_languages if l in self.queues)
                self.engines = {k: plain(v, 80) for k, v in getattr(tts, 'engines', {}).items() if k in self.languages}
                self.status = 'ready' if self.languages else 'unavailable'
            if self.tts_factory is None and os.environ.get('RADIO_STARTUP_SPEECH_CHECK') == '1':
                samples = {'ar': 'مرحباً بكم في غولد بالس. هذا اختبار للصوت العربي.',
                           'en': 'Welcome to Gold Pulse. This is a station audio check.'}
                for language in self.languages:
                    try:
                        result = speech_check(tts.synthesize(samples[language], language=language), language)
                    except Exception as error:
                        result = {'status': 'unavailable', 'errorType': type(error).__name__,
                                  'checkedAt': int(time.time() * 1000)}
                    with self.lock:
                        self.startup_speech_checks[language] = result
        except Exception:
            with self.lock:
                self.status = 'unavailable'
            return
        retry_at, last_language = {}, None
        while not self.stop.is_set():
            now_ms = int(time.time() * 1000)
            retry_at = {key: until for key, until in retry_at.items() if until > now_ms}
            job = None
            with self.lock:
                self._prune(now_ms)
                for language in sorted(self.languages, key=lambda v: v == last_language):
                    if sum(q['endsAt'] > now_ms for q in self.queues[language]) >= MAX_QUEUE:
                        continue
                    tail = max((q['endsAt'] for q in self.queues[language]), default=0)
                    if tail > now_ms + SPEECH_LOOKAHEAD_S * 1000:
                        continue
                    candidate = self._next_job(language, now_ms, retry_at)
                    if candidate:
                        job = dict(candidate)
                        break
            if job is None:
                self.stop.wait(1)
                continue
            language = job['language']
            last_language = language
            started = time.monotonic()
            with self.lock:
                self.preparing[language] = {'kind': job['kind'], 'startedAt': int(time.time() * 1000)}
            try:
                spoken = job.get('speechText') or spoken_text(job)
                speech = tts.synthesize(spoken, language=language)
                speech_check(speech, language)
                duration = speech.duration_s
                if (not isinstance(speech.wav, bytes) or not 44 < len(speech.wav) <= MAX_AUDIO_BYTES or
                        not isinstance(duration, (int, float)) or not math.isfinite(duration) or
                        not 0 < duration <= MAX_CLIP_S or speech.language != language):
                    raise ValueError('Invalid server audio')
                generated = int(time.time() * 1000)
                with self.lock:
                    if sum(q['endsAt'] > generated for q in self.queues[language]) >= MAX_QUEUE:
                        continue
                    # Let four-second manifest polling prefetch short bulletins.
                    start = max(generated + 6000, max((q['endsAt'] for q in self.queues[language]), default=0))
                    if not self._job_fresh(job, start):
                        # A ten-minute item may have aged into the labelled
                        # earlier cohort during synthesis. It needs a new,
                        # honestly prefixed recording rather than silent loss.
                        retry_at[job['id']] = generated + 30000
                        continue
                    identifier = hashlib.sha256((job['id'] + language + str(generated)).encode()).hexdigest()[:32]
                    (self.directory / (identifier + '.wav')).write_bytes(speech.wav)
                    segment = {'id': identifier, 'kind': job['kind'], 'language': language,
                        'headline': job['title'], 'source': job['source'], 'sourceUrl': job['url'],
                        'publishedAt': job['publishedAt'] * 1000, 'firstSeenAt': job['firstSeenAt'] * 1000,
                        'generatedAt': generated, 'startsAt': start, 'endsAt': start + round(duration * 1000),
                        'durationSeconds': round(duration, 3), 'speechText': spoken,
                        'preparationSeconds': round(time.monotonic() - started, 3),
                        'engine': plain(speech.engine, 80), 'audioUrl': '/audio/' + identifier + '.wav'}
                    if job['kind'] == 'market':
                        segment['market'] = job['market']
                        clock = datetime.fromtimestamp(job['publishedAt'], timezone.utc).strftime('%H:%M:%S UTC')
                        segment['caption'] = (f'رصد Gold API الساعة {clock} · مصدر منفصل عن الرسم البياني' if language == 'ar'
                            else f'Observed Gold API reference at {clock} · separate from TradingView/OANDA')
                        self.last_market_at[language] = start
                        self.last_market_id[language] = job['id']
                    elif job['kind'] == 'discussion':
                        segment['programme'] = job['programme']
                        segment['sources'] = job['sources']
                        segment['speaker'] = job['speaker']
                        segment['caption'] = (f"مناقشة مشروطة · {job['speaker']} · نافذة الأخبار " if language == 'ar'
                            else f"Conditional discussion · {job['speaker']} · news window ending ") + datetime.fromtimestamp(
                                job['publishedAt'], timezone.utc).strftime('%H:%M UTC')
                        if self.discussions.consume(job) is not True:
                            # A refreshed/bounded source queue can retire an
                            # in-flight turn. Never publish it out of order or
                            # let a later re-import repeat unconsumed speech.
                            (self.directory / (identifier + '.wav')).unlink(missing_ok=True)
                            continue
                    else:
                        segment['recency'] = job.get('recency', 'fresh')
                        segment['relevance'] = job.get('relevance')
                        self.seen[language].add(job['id'])
                    self.queues[language].append(segment)
                    self.news_streak[language] = self.news_streak[language] + 1 if job['kind'] == 'news' else 0
                    self.last_prepared[language] = {'preparedAt': generated, 'seconds': segment['preparationSeconds']}
                    self.errors.pop(language, None)
                    self._save_receipts()
            except Exception:
                retry_at[job['id']] = int(time.time() * 1000) + 30000
                with self.lock:
                    self.errors[language] = 'Speech preparation unavailable; retrying.'
            finally:
                with self.lock:
                    self.preparing[language] = None

    def start(self):
        for target in (self.collect, self.collect_live_updates, self.collect_market, self.generate):
            threading.Thread(target=target, daemon=True).start()

    def manifest(self, language, now_ms=None):
        now = int(time.time() * 1000) if now_ms is None else now_ms
        with self.lock:
            queue = [dict(q) for q in self.queues[language] if q['endsAt'] > now]
            current = next((q for q in queue if q['startsAt'] <= now < q['endsAt']), None)
            selection = select_news(self.stories.values(), language, now // 1000)
            unread = sum(s['id'] not in self.seen[language] for s in selection.selected)
            earlier = select_news(self.stories.values(), language, now // 1000,
                                  window_s=EARLIER_WINDOW_S, minimum_age_s=WINDOW_S + 1)
            earlier_unread = sum(s['id'] not in self.seen[language] for s in earlier.selected)
            return {'version': 1, 'serviceVersion': SERVICE_VERSION, 'station': 'Gold Pulse Radio', 'serverTime': now, 'language': language,
                'mode': 'cloud-news', 'dependencies': {'pcRequired': False, 'publicDiscussionImporter': False},
                'languages': list(self.languages), 'status': 'live' if current else self.status if self.status != 'ready' else 'waiting',
                'nowPlaying': current, 'queue': queue[:MAX_QUEUE], 'lastCollectionAt': self.last_collection,
                'recent': [dict(q) for q in self.queues[language] if now - 120000 <= q['endsAt'] <= now][-2:],
                'music': {'audioUrl': '/' + MUSIC_FILE, 'durationSeconds': MUSIC_SECONDS, 'epochMs': 0, 'gain': .45} if self.music_data else None,
                'freshStories': sum(1 for s in self.stories.values() if s['language'] == language and fresh(s, now // 1000)),
                'unreadFreshStories': unread,
                'newsSelection': {**selection.summary(), 'fraction': .7, 'freshCount': selection.scannedFresh,
                    'relevantCount': selection.relevant, 'selectedCount': len(selection.selected),
                    'unreadSelectedCount': unread, 'scheduledSelectedCount': len(selection.selected) - unread},
                'earlierNewsSelection': {**earlier.summary(), 'fraction': .7, 'freshCount': earlier.scannedFresh,
                    'relevantCount': earlier.relevant, 'selectedCount': len(earlier.selected),
                    'unreadSelectedCount': earlier_unread, 'scheduledSelectedCount': len(earlier.selected) - earlier_unread},
                'feedsReached': sum(s['status'] == 'ready' for s in self.feed_states.values()), 'feedCount': len(FEEDS) + 1,
                'liveUpdates': dict(self.live_state),
                'error': self.errors.get(language), 'newsWindowSeconds': WINDOW_S, 'earlierNewsWindowSeconds': EARLIER_WINDOW_S,
                'market': self.market.snapshot(now // 1000), 'marketCadenceSeconds': MARKET_SPEECH_INTERVAL_S,
                'production': self._production(language, now),
                'discussions': self.discussions.status(language) if self.discussions else {'enabled': False, 'pending': 0},
                'note': 'Latest-ten-minute news first, then unspoken relevant last-hour reports clearly announced as earlier with their publication time. Waiting music yields to speech. No PC source or model is required.'}

    def audio(self, identifier):
        with self.lock:
            now = int(time.time() * 1000)
            if not any(q['id'] == identifier and q['endsAt'] > now - 120000 for queue in self.queues.values() for q in queue):
                return None
            path = self.directory / (identifier + '.wav')
            if path.is_symlink() or not path.is_file() or not 44 < path.stat().st_size <= MAX_AUDIO_BYTES:
                return None
            return path.read_bytes()


def make_handler(station):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'GoldRadio'
        sys_version = ''

        def log_message(self, *_):
            pass  # Request IPs and query strings are not written to application logs.

        def send(self, status, body, content_type, head=False, cache='no-store'):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', cache)
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-src https://www.tradingview-widget.com; media-src 'self' blob:; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            if not head:
                self.wfile.write(body)

        def route(self, head=False):
            if len(self.path) > 2048:
                return self.send(414, b'{"error":"Request too long"}', 'application/json', head)
            try:
                path = urllib.parse.urlsplit(self.path)
                query = urllib.parse.parse_qs(path.query, keep_blank_values=True, max_num_fields=10)
            except ValueError:
                return self.send(400, b'{"error":"Invalid request"}', 'application/json', head)
            if path.path == '/' and not query:
                return self.send(200, (HERE / 'index.html').read_bytes(), 'text/html; charset=utf-8', head)
            if path.path == '/' + MUSIC_FILE and not query and station.music_data:
                return self.send(200, station.music_data, 'audio/wav', head, 'public, max-age=86400')
            if path.path == '/health' and not query:
                return self.send(200, json.dumps({'ok': True, 'speechStatus': station.status,
                    'serviceVersion': SERVICE_VERSION,
                    'mode': 'cloud-news', 'dependencies': {'pcRequired': False, 'publicDiscussionImporter': False},
                    'languages': list(station.languages), 'speechEngines': station.engines,
                    'musicReady': bool(station.music_data),
                    'startupSpeechChecks': station.startup_speech_checks}).encode(), 'application/json', head)
            if path.path == '/radio.json' and set(query) <= {'language'} and len(query.get('language', [])) <= 1:
                language = query.get('language', ['ar'])[0]
                if language in ('ar', 'en'):
                    body = json.dumps(station.manifest(language), ensure_ascii=False).encode()
                    return self.send(200, body, 'application/json; charset=utf-8', head)
            match = re.fullmatch(r'/audio/([a-f0-9]{32})\.wav', path.path)
            if match and not query:
                body = station.audio(match.group(1))
                if body is not None:
                    return self.send(200, body, 'audio/wav', head)
            return self.send(404, b'{"error":"Not found"}', 'application/json', head)

        def do_GET(self):
            self.route()

        def do_HEAD(self):
            self.route(head=True)

        def do_POST(self):
            self.send(405, b'{"error":"Read-only service"}', 'application/json')

    return Handler


class RadioHttpServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler):
        self.slots = threading.BoundedSemaphore(20)
        super().__init__(address, handler)

    def get_request(self):
        request, address = super().get_request()
        request.settimeout(10)
        return request, address

    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.slots.release()


def main():
    station = Station()
    station.start()
    server = RadioHttpServer(('0.0.0.0', int(os.environ.get('PORT', '10000'))), make_handler(station))
    print('Gold Pulse Radio HTTP service started.', flush=True)
    try:
        server.serve_forever()
    finally:
        station.stop.set()
        server.server_close()


if __name__ == '__main__':
    main()

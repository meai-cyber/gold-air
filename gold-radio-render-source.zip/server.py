"""Standalone public-news radio. Server speech, fixed feeds, no synthesis API.

Run with python server.py. State and generated audio are ephemeral on Render;
neither the Gold Pulse account database nor household data are used here.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from email.utils import parsedate_to_datetime
from html import unescape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import threading
import time
from types import SimpleNamespace
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import wave
from station_music import MUSIC_FILE, MUSIC_SECONDS
from market_brief import MarketDesk, QuoteUnavailable, POLL_SECONDS, MAX_QUOTE_AGE_S
from news_selection import select_news, TARGET_PERCENT
from source_policy import collection_url_allowed, story_allowed, POLICY_ID, APPROVED_PUBLISHER_DOMAINS
from social_sources import SocialCollector
from news_speech import public_report_text, complete_prefix
from gold_briefing import build_briefing
from phonon_runtime import container_memory
from airtime_mix import AirtimeMix
from station_programme import ProgrammeLibrary
from licensed_music import MusicLibrary
from news_context_reports import build_news_context
from station_cast import CAST_VERSION
from social_feedback import SocialFeedbackCollector
from economic_feeds import EconomicFeedCollector
from market_outlook import OutlookDesk

WINDOW_S = 600
EARLIER_WINDOW_S = 7200
MAX_FEED_BYTES = 1024 * 1024
MAX_AUDIO_BYTES = 8 * 1024 * 1024
MAX_STORIES = 1000
MAX_QUEUE = 12
MAX_CLIP_S = 90
FEED_INTERVAL_S = 30
SERVICE_VERSION = '2026-10-25-cloud-350m-radio-3'
SPEECH_LOOKAHEAD_S = 60
MARKET_SPEECH_INTERVAL_S = 15
PRICE_HEARTBEAT_S = 600
PRICE_HEARTBEAT_LEAD_S = 120
NEWS_BURST_LIMIT = 2
ANALYSIS_INTERVAL_S = 240
ANALYSIS_PREPARE_LEAD_S = 90
MUSIC_BREAK_S = 12
PODCAST_CACHE_BYTES = 32 * 1024 * 1024
WORKSPACE = 'https://g.au7.workers.dev/app'
HERE = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Feed:
    source: str
    language: str
    url: str
    domains: tuple[str, ...]


FEEDS = (
    Feed('بي بي سي عربي', 'ar', 'https://feeds.bbci.co.uk/arabic/rss.xml', ('bbc.com', 'bbc.co.uk')),
    Feed('فرانس 24', 'ar', 'https://www.france24.com/ar/rss', ('france24.com',)),
    Feed('BBC World', 'en', 'https://feeds.bbci.co.uk/news/world/rss.xml', ('bbc.com', 'bbc.co.uk')),
    Feed('BBC Business', 'en', 'https://feeds.bbci.co.uk/news/business/rss.xml', ('bbc.com', 'bbc.co.uk')),
    Feed('The Guardian', 'en', 'https://www.theguardian.com/world/rss', ('theguardian.com',)),
    Feed('دويتشه فيله', 'ar', 'https://rss.dw.com/rdf/rss-ar-all', ('dw.com',)),
    Feed('France 24 English', 'en', 'https://www.france24.com/en/rss', ('france24.com',)),
    Feed('CNBC Top News', 'en', 'https://www.cnbc.com/id/100003114/device/rss/rss.html', ('cnbc.com',)),
    Feed('CNBC Energy', 'en', 'https://www.cnbc.com/id/19836768/device/rss/rss.html', ('cnbc.com',)),
    Feed('The Guardian Business', 'en', 'https://www.theguardian.com/uk/business/rss', ('theguardian.com',)),
    Feed('Federal Reserve policy', 'en', 'https://www.federalreserve.gov/feeds/press_monetary.xml', ('federalreserve.gov',)),
    Feed('Federal Reserve speeches', 'en', 'https://www.federalreserve.gov/feeds/speeches.xml', ('federalreserve.gov',)),
    Feed('يورونيوز', 'ar', 'https://arabic.euronews.com/rss?level=theme&name=news', ('euronews.com',)),
    Feed('Euronews', 'en', 'https://www.euronews.com/rss?level=theme&name=news', ('euronews.com',)),
    Feed('Le Monde World', 'en', 'https://www.lemonde.fr/en/international/rss_full.xml', ('lemonde.fr',)),
    Feed('Le Monde World Economy', 'en', 'https://www.lemonde.fr/en/world-economy/rss_full.xml', ('lemonde.fr',)),
    Feed('CNBC World', 'en', 'https://www.cnbc.com/id/100727362/device/rss/rss.html', ('cnbc.com',)),
    Feed('CNBC Finance', 'en', 'https://www.cnbc.com/id/10000664/device/rss/rss.html', ('cnbc.com',)),
    Feed('BBC Science and Environment', 'en', 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml', ('bbc.com', 'bbc.co.uk')),
    Feed('The Guardian Economics', 'en', 'https://www.theguardian.com/business/economics/rss', ('theguardian.com',)),
    Feed('The Guardian Science', 'en', 'https://www.theguardian.com/science/rss', ('theguardian.com',)),
    Feed('NASA News Releases', 'en', 'https://www.nasa.gov/news-release/feed/', ('nasa.gov',)),
)


def plain(value, limit=400):
    if not isinstance(value, str) or len(value) > 8192:
        return ''
    value = unescape(re.sub(r'<[^>]*>', ' ', value))
    value = re.sub(r'https?://\S+|www\.\S+', '', value, flags=re.I)
    value = re.sub(r'\s+', ' ', value).strip()
    if re.search(r'[\x00-\x1f\x7f]', value):
        return ''
    return complete_prefix(value, limit)


def public_link(value, domains):
    try:
        url = urllib.parse.urlsplit(value)
        host = (url.hostname or '').lower()
        if (url.scheme != 'https' or url.username or url.password or url.port or
                any(ord(c) < 33 for c in value) or '\\' in value):
            return ''
        return value if any(host == d or host.endswith('.' + d) for d in domains) else ''
    except (TypeError, ValueError):
        return ''


def publication(value, received):
    try:
        try:
            parsed = parsedate_to_datetime(value)
        except (ValueError, TypeError):
            parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            return None
        stamp = int(parsed.timestamp())
        return stamp if 0 < stamp <= received else None
    except (ValueError, TypeError, OverflowError, AttributeError):
        return None


def story_id(title):
    key = re.sub(r'[^\w]+', ' ', unicodedata.normalize('NFKC', title).casefold()).strip()
    return hashlib.sha256(key.encode()).hexdigest()[:32]


def parse_feed(body, feed, received):
    if feed not in FEEDS or not isinstance(body, bytes) or len(body) > MAX_FEED_BYTES:
        raise ValueError('Unsupported feed')
    if b'\x00' in body or re.search(br'<!\s*(?:DOCTYPE|ENTITY)\b', body, re.I):
        raise ValueError('Unsupported XML')
    root = ET.fromstring(body)
    entries = [n for n in root.iter() if n.tag.rsplit('}', 1)[-1] in ('item', 'entry')]
    if len(entries) > 500:
        raise ValueError('Feed entry limit')
    rows = []
    for entry in entries:
        fields = {n.tag.rsplit('}', 1)[-1].lower(): ''.join(n.itertext()).strip() for n in entry}
        title = plain(fields.get('title'))
        link = fields.get('link', '')
        if not link:
            link = next((n.get('href', '') for n in entry if n.tag.rsplit('}', 1)[-1] == 'link' and
                         n.get('rel', 'alternate') == 'alternate'), '')
        link = public_link(link, feed.domains)
        stamp = publication(fields.get('pubdate') or fields.get('published') or fields.get('updated') or fields.get('date'), received)
        if not title or not link or stamp is None or received - stamp > 86400:
            continue
        if feed.language == 'ar' and not re.search(r'[\u0621-\u064a]', title):
            continue
        row = {'id': story_id(title), 'title': title, 'source': feed.source, 'url': link,
               'language': feed.language, 'publishedAt': stamp, 'firstSeenAt': received}
        summary = plain(fields.get('description') or fields.get('summary'), 400)
        if summary:
            row['summary'] = summary
        rows.append(row)
    return rows


class FixedRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        old, new = urllib.parse.urlsplit(req.full_url), urllib.parse.urlsplit(newurl)
        if (new.scheme != 'https' or new.hostname != old.hostname or new.username or new.password or new.port
                or not collection_url_allowed(newurl)):
            raise ValueError('Feed redirect rejected')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_feed(feed):
    if feed not in FEEDS or not collection_url_allowed(feed.url):
        raise ValueError('Unsupported feed')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), FixedRedirects())
    request = urllib.request.Request(feed.url, headers={'User-Agent': 'PublicNewsReader/1.0',
                                                       'Accept': 'application/rss+xml, application/xml',
                                                       'Accept-Encoding': 'identity'})
    with opener.open(request, timeout=8) as response:
        if response.status != 200 or response.headers.get('Content-Encoding', 'identity') != 'identity':
            raise ValueError('Feed unavailable')
        size = response.headers.get('Content-Length')
        if size and (not size.isdecimal() or int(size) > MAX_FEED_BYTES):
            raise ValueError('Feed size limit')
        body = response.read(MAX_FEED_BYTES + 1)
    return parse_feed(body, feed, int(time.time()))


def fresh(story, now_s, window_s=WINDOW_S):
    return (isinstance(story, dict) and all(type(story.get(k)) is int for k in ('publishedAt', 'firstSeenAt')) and
            type(window_s) is int and window_s in (WINDOW_S, 3600, EARLIER_WINDOW_S) and
            0 < story['publishedAt'] <= story['firstSeenAt'] <= now_s and
            now_s - story['publishedAt'] <= window_s and now_s - story['firstSeenAt'] <= window_s)


def spoken_text(story):
    return public_report_text(story)


def job_speech_text(job):
    text = job.get('speechText') or spoken_text(job)
    if job.get('kind') != 'podcast':
        return text
    # Presenter identity stays on screen; do not read script role labels aloud.
    prefixes = ('Recorded educational discussion. ', 'A replay from our educational archive. ',
                'من حواراتنا التعليمية المسجلة. ', 'إعادة من أرشيفنا التعليمي. ')
    intro = next((value for value in prefixes if text.startswith(value)), '')
    body = text[len(intro):]
    body = re.sub(r'^(?:Maya|Maia|Omar|مايا|عمر)\s*:\s*', '', body, count=1)
    return intro + body


def speech_check(speech, language):
    """Validate a private startup sample; never queue it as a news report."""
    if speech.language != language or not isinstance(speech.wav, bytes) or not 44 < len(speech.wav) <= MAX_AUDIO_BYTES:
        raise ValueError('Invalid speech sample')
    with wave.open(io.BytesIO(speech.wav), 'rb') as audio:
        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate(), audio.getcomptype()) != (1, 2, 24000, 'NONE'):
            raise ValueError('Unexpected speech format')
        frames = audio.getnframes()
        pcm = audio.readframes(frames)
    duration = frames / 24000
    if not 0 < duration <= MAX_CLIP_S or len(pcm) != frames * 2 or not any(pcm) or abs(duration - speech.duration_s) > .03:
        raise ValueError('Empty or inconsistent speech sample')
    result = {'status': 'ready', 'bytes': len(speech.wav), 'durationSeconds': round(duration, 3),
            'engine': plain(speech.engine, 80), 'checkedAt': int(time.time() * 1000)}
    for key, attribute in (('inferenceSeconds', 'inference_s'), ('firstChunkSeconds', 'first_chunk_s')):
        value = getattr(speech, attribute, None)
        if type(value) in (int, float) and math.isfinite(value) and value >= 0:
            result[key] = round(value, 3)
    return result


class Station:
    def __init__(self, runtime_dir=None, tts_factory=None):
        self.directory = Path(runtime_dir or os.environ.get('RADIO_STATE_DIR') or os.environ.get('RADIO_DATA_DIR') or '/tmp/gold-radio-data')
        self.directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.stories, self.seen, self.queues = {}, {'ar': set(), 'en': set()}, {'ar': [], 'en': []}
        self.feed_states, self.errors, self.languages, self.engines = {}, {}, (), {}
        self.startup_speech_checks = {}
        self.english_native_failure = None
        self.english_native_policy = None
        self.arabic_news_policy = None
        self.arabic_news_failure = None
        self.market = MarketDesk()
        self.outlook = OutlookDesk()
        self.last_market_outlook = None
        self.last_market_at = {'ar': 0, 'en': 0}
        self.last_market_id = {'ar': None, 'en': None}
        self.last_analysis_at = {'ar': 0, 'en': 0}
        # Keep source-based change detection separate from periodic deadlines.
        self.initial_price = {'ar': None, 'en': None}
        self.last_announced_price = {'ar': None, 'en': None}
        self.news_streak = {'ar': 0, 'en': 0}
        self.last_news_source = {'ar': None, 'en': None}
        self.last_news_topics = {'ar': (), 'en': ()}
        self.speech_seconds_per_character = {'ar': .08, 'en': .008}
        self.last_deferred_quote = {'ar': None, 'en': None}
        self.preparing = {'ar': None, 'en': None}
        self.last_prepared = {'ar': None, 'en': None}
        self.discussions = None
        self.cloud_llm = None
        self.cloud_writer = None
        if os.environ.get('RADIO_CLOUD_LLM') == '1':
            from cloud_llm_runtime import CloudLlmRuntime
            from cloud_script_writer import CloudScriptWriter
            self.cloud_llm = CloudLlmRuntime(state_dir=self.directory)
            self.cloud_writer = CloudScriptWriter(self.cloud_llm)
        # In cloud-model mode no archive is selected as a substitute for a
        # freshly generated script. Source news/price reading stays independent.
        self.programmes = None if self.cloud_writer is not None else ProgrammeLibrary()
        self.started_at = int(time.time() * 1000)
        self.airtime = {language: AirtimeMix(self.started_at) for language in ('ar', 'en')}
        self.podcast_cache = {}
        self.cache_lock = threading.Lock()
        self.podcast_cache_directory = self.directory / 'podcast-cache'
        self.podcast_cache_directory.mkdir(exist_ok=True)
        self.music_library = MusicLibrary(Path(os.environ.get('RADIO_MODEL_DIR', '/opt/gold-radio-assets')))
        # This cloud edition never initializes the old PC-backed importer,
        # even if a previous deployment left its environment flag enabled.
        # The former regional live-blog source is never initialized or polled.
        self.live_updates = None
        self.live_state = {'enabled': False, 'status': 'disabled-by-source-policy',
                           'checkedAt': 0, 'reason': 'Excluded regional publisher'}
        self.social_sources = SocialCollector()
        self.social_state = self.social_sources.status()
        self.social_feedback = SocialFeedbackCollector()
        self.feedback_state = self.social_feedback.status()
        self.economic_feeds = EconomicFeedCollector()
        self.economic_state = self.economic_feeds.status()
        self.status, self.last_collection = 'starting', 0
        self.tts_factory = tts_factory
        try:
            path = Path(os.environ.get('RADIO_MODEL_DIR', '/opt/gold-radio-assets')) / MUSIC_FILE
            self.music_data = path.read_bytes() if path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_AUDIO_BYTES else None
        except OSError:
            self.music_data = None
        self._load_receipts()

    def _load_receipts(self):
        try:
            path = self.directory / 'receipts.json'
            if path.is_symlink() or path.stat().st_size > 1024 * 1024:
                return
            state = json.loads(path.read_text('utf-8'))
            now = int(time.time())
            for row in state.get('stories', [])[:MAX_STORIES]:
                if (row.get('language') in self.queues and re.fullmatch('[a-f0-9]{32}', row.get('id', '')) and
                        plain(row.get('title')) == row.get('title') and isinstance(row.get('source'), str) and
                        fresh(row, now, EARLIER_WINDOW_S) and story_allowed(row)):
                    self.stories[row['id']] = row
            for lang in self.seen:
                self.seen[lang] = {v for v in state.get('seen', {}).get(lang, [])[:MAX_STORIES] if re.fullmatch('[a-f0-9]{32}', v)}
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def _save_receipts(self):
        state = {'stories': list(self.stories.values()), 'seen': {k: sorted(v)[-MAX_STORIES:] for k, v in self.seen.items()}}
        temporary = self.directory / 'receipts.tmp'
        temporary.write_text(json.dumps(state, ensure_ascii=False), 'utf-8')
        temporary.replace(self.directory / 'receipts.json')

    def ingest(self, rows, now_s=None):
        now_s = int(time.time()) if now_s is None else now_s
        with self.lock:
            for row in rows:
                if not story_allowed(row):
                    continue
                if row['id'] in self.stories:
                    old = self.stories[row['id']]
                    old['firstSeenAt'] = min(old['firstSeenAt'], row['firstSeenAt'])
                    old['publishedAt'] = min(old['publishedAt'], row['publishedAt'])
                else:
                    self.stories[row['id']] = dict(row)
            self.stories = {r['id']: r for r in sorted(self.stories.values(), key=lambda r: r['firstSeenAt'], reverse=True)
                            if now_s - r['firstSeenAt'] <= 86400}
            self.stories = dict(list(self.stories.items())[:MAX_STORIES])
            for language in self.seen:
                self.seen[language].intersection_update(self.stories)
            self._save_receipts()

    def collect(self):
        while not self.stop.is_set():
            # This worker pool is owner-started; HTTP listeners cannot add URLs.
            with ThreadPoolExecutor(max_workers=3) as pool:
                jobs = [(feed, pool.submit(fetch_feed, feed)) for feed in FEEDS]
                for feed, job in jobs:
                    try:
                        self.ingest(job.result())
                        state = 'ready'
                    except Exception:
                        state = 'unavailable'
                    with self.lock:
                        self.feed_states[feed.source] = {'status': state, 'checkedAt': int(time.time() * 1000)}
                        self.last_collection = int(time.time() * 1000)
            self.stop.wait(FEED_INTERVAL_S)

    def collect_market(self):
        # Owner polling is independent of speech. No listener can initiate a fetch.
        while not self.stop.is_set():
            try:
                self.market.poll()
            except QuoteUnavailable:
                pass
            self.stop.wait(POLL_SECONDS)

    def collect_live_updates(self):
        # Retained as a no-op for old launchers; no object, URL or thread is used.
        return

    def collect_discussions(self):
        # Read finished public scripts, never a raw PC inference service.
        while not self.stop.is_set() and self.discussions is not None:
            self.discussions.poll()
            self.stop.wait(30)

    def collect_cloud_scripts(self):
        """One inference owner; feeds, HTTP and speech never wait on its lock."""
        if self.cloud_writer is None:
            return
        try:
            while not self.stop.is_set():
                with self.lock:
                    languages = tuple(self.languages)
                if not languages:
                    self.stop.wait(1)
                    continue
                for language in languages:
                    if self.stop.is_set():
                        break
                    with self.lock:
                        stories = [dict(row) for row in self.stories.values()]
                        market = self.market.snapshot()
                        outlook = self.last_market_outlook
                    # prepare is intentionally outside the station lock. It is
                    # a no-op while the previous generated pair is still pending.
                    self.cloud_writer.prepare(language, stories, market, outlook)
                self.stop.wait(2)
        finally:
            if self.cloud_llm is not None:
                self.cloud_llm.close()

    def collect_social(self):
        while not self.stop.is_set():
            # Fixed public publisher accounts only. The collector owns polling
            # intervals and denial backoff; listeners cannot supply a URL.
            rows = self.social_sources.collect()
            state = self.social_sources.status()
            if rows:
                self.ingest(rows)
            with self.lock:
                self.social_state = state
                self.last_collection = max(self.last_collection, state.get('checkedAt', 0))
            self.stop.wait(10)

    def collect_feedback(self):
        while not self.stop.is_set():
            with self.lock:
                reports = [dict(row) for row in self.stories.values()]
            rows = self.social_feedback.collect(reports)
            state = self.social_feedback.status()
            if rows:
                self.ingest(rows)
            with self.lock:
                self.feedback_state = state
            self.stop.wait(10)

    def collect_economic_feeds(self):
        while not self.stop.is_set():
            rows = self.economic_feeds.collect()
            state = self.economic_feeds.status()
            if rows:
                self.ingest(rows)
            with self.lock:
                self.economic_state = state
            self.stop.wait(10)

    def _candidate(self, language, now_s, retry_at=None):
        retry_at = retry_at or {}
        # Select before receipts/retries: draining the queue must not promote
        # the omitted share merely because higher-ranked stories were spoken.
        for recency, window, minimum_age in (('fresh', WINDOW_S, 0), ('earlier', EARLIER_WINDOW_S, WINDOW_S + 1)):
            selection = select_news([row for row in self.stories.values() if story_allowed(row)], language, now_s,
                                    window_s=window, minimum_age_s=minimum_age)
            values = [s for s in selection.selected if s['id'] not in self.seen[language]
                      and retry_at.get(s['id'], 0) <= now_s * 1000]
            if values:
                previous_topics = set(self.last_news_topics[language])
                story = min(values, key=lambda s: (-selection.scores[s['id']],
                    bool(previous_topics) and not set(selection.reasons[s['id']]).difference(previous_topics),
                    s['source'] == self.last_news_source[language],
                    -s['publishedAt'], -s['firstSeenAt'], s['id']))
                return {**story, 'recency': recency, 'relevance': {'score': selection.scores[story['id']],
                        'topics': list(selection.reasons[story['id']]), 'method': selection.summary()['method']}}
        return None

    def _next_job(self, language, now_ms, retry_at):
        market_job = self._market_job(language, now_ms, retry_at)
        if market_job:
            return market_job
        snapshot = self.market.snapshot(now_ms // 1000)
        story = self._candidate(language, now_ms // 1000, retry_at)
        # Give fresh headlines first access, but do not let a large feed burst
        # silence every market update and discussion until the backlog expires.
        if story and self.news_streak[language] < NEWS_BURST_LIMIT:
            return {**story, 'kind': 'news'}
        if self.discussions is not None:
            discussion = self.discussions.candidate(language, now_ms // 1000,
                exclude_ids=[key for key, until in retry_at.items() if until > now_ms])
            if discussion:
                return discussion
        if self.cloud_writer is not None:
            cloud = self.cloud_writer.candidate(language, now_ms // 1000,
                exclude_ids=[key for key, until in retry_at.items() if until > now_ms])
            if cloud:
                estimate = min(90, max(1, len(cloud['speechText']) * (.065 if language == 'ar' else .06)))
                start = self._scheduled_start(language, now_ms, estimate)
                quiet = story is None
                if self.airtime[language].can_schedule_podcast(estimate, now_ms, start_ms=start, quiet=quiet):
                    return {**cloud, '_cloudCandidate': cloud, 'quietPodcastFallback': quiet}
        if self.programmes is not None and (not story or self.news_streak[language] >= 4):
            podcast = self.programmes.candidate(language, now_ms // 1000,
                excluded=[key for key, until in retry_at.items() if until > now_ms])
            if podcast:
                estimated = min(90, max(1, len(podcast['speechText']) * (.065 if language == 'ar' else .06)))
                start = self._scheduled_start(language, now_ms, estimated)
                quiet = story is None
                if self.airtime[language].can_schedule_podcast(estimated, now_ms, start_ms=start, quiet=quiet):
                    return {**podcast, 'quietPodcastFallback': quiet}
        if story:
            # The free CPU cannot reliably synthesize a combined Arabic
            # roundup inside the bounded native audio slot. Read each complete
            # report separately; network English can use the collected roundup.
            if language == 'en' and self.news_streak[language] >= 3:
                context = build_news_context(language, self.stories.values(), now_ms // 1000,
                    excluded=self.seen[language] | {key for key, until in retry_at.items() if until > now_ms})
                if (context and retry_at.get(context['id'], 0) <= now_ms and
                        (story.get('relevance') or {}).get('score', 0) <= context['relevance']['score']):
                    return context
            return {**story, 'kind': 'news'}
        return None

    def _market_job(self, language, now_ms, retry_at):
        snapshot = self.market.snapshot(now_ms // 1000)
        if snapshot.get('status') != 'ready':
            return None
        changed = self._price_change_pending(language, snapshot)
        pending_price = any(q.get('kind') == 'market' and q['startsAt'] > now_ms
                            for q in self.queues[language])
        periodic = (not self.last_market_at[language] or
                    now_ms >= self.last_market_at[language] +
                    (PRICE_HEARTBEAT_S - PRICE_HEARTBEAT_LEAD_S) * 1000)
        change_due = changed and now_ms - self.last_market_at[language] >= MARKET_SPEECH_INTERVAL_S * 1000
        if not pending_price and (periodic or change_due):
            job = self.market.brief(language, now_ms // 1000, reason='changed' if change_due else 'periodic')
            if job and change_due:
                previous = self.last_announced_price[language]
                if previous is None:
                    previous = self.initial_price[language]
                higher = self._spoken_quote_price(snapshot) > previous
                price = job['spokenPriceUsd']
                job['speechText'] = (f'الذهب {"يرتفع" if higher else "ينخفض"}، نحو {price} دولاراً للأونصة.'
                    if language == 'ar' else
                    f'Gold is {"higher" if higher else "lower"}, about {price} dollars per ounce.')
                job['changeSinceLastCall'] = 'up' if higher else 'down'
            if job and retry_at.get(job['id'], 0) <= now_ms and self._can_prepare_quote(job, now_ms):
                return job
        analysis_reference = self.last_analysis_at[language] or self.started_at
        if now_ms >= analysis_reference + (ANALYSIS_INTERVAL_S - ANALYSIS_PREPARE_LEAD_S) * 1000:
            job = build_briefing(language, snapshot, self.stories.values(), now_ms // 1000,
                                 outlook_desk=self.outlook)
            if job and retry_at.get(job['id'], 0) <= now_ms and self._can_prepare_quote(job, now_ms):
                return job
        return None

    def _priority_start(self, language, ready_ms, kind, duration_s=1.0):
        guard = ready_ms + 6000
        protected_ends = [q['endsAt'] for q in self.queues[language]
                          if q['endsAt'] > ready_ms and q['startsAt'] < guard]
        if kind == 'analysis':
            protected_ends += [q['endsAt'] for q in self.queues[language]
                               if q.get('kind') == 'market' and q['endsAt'] > ready_ms]
        start = max([guard, *protected_ends])
        delta = round(duration_s * 1000)
        # A priority report must not age an already recorded headline across
        # its spoken freshness label, or turn another quote into a stale call.
        # Preserve such complete items before the new slot. Original clocks,
        # source text and saved forecast targets are never rewritten.
        for queued in sorted(self.queues[language], key=lambda item: item['startsAt']):
            if queued['startsAt'] < start:
                continue
            original_job = {**queued, 'publishedAt': queued['publishedAt'] // 1000,
                            'firstSeenAt': queued['firstSeenAt'] // 1000}
            if not self._job_fresh(original_job, queued['startsAt'] + delta):
                start = queued['endsAt']
        return start

    def _insert_priority(self, language, segment, now_ms):
        start, end = segment['startsAt'], segment['endsAt']
        # The current complete voice item is preserved. Already prepared future
        # items keep their order and exact audio, shifted by the new short slot.
        delta = self.airtime[language].insert_before_future(start, end, segment['kind'], now_ms)
        for queued in self.queues[language]:
            if queued['startsAt'] >= start:
                previous_start = queued['startsAt']
                queued['startsAt'] += delta
                queued['endsAt'] += delta
                if queued['kind'] == 'analysis' and self.last_analysis_at[language] == previous_start:
                    self.last_analysis_at[language] += delta
                if queued['kind'] == 'market' and self.last_market_at[language] == previous_start:
                    self.last_market_at[language] += delta
        self.queues[language].append(segment)
        self.queues[language].sort(key=lambda queued: queued['startsAt'])

    @staticmethod
    def _spoken_quote_price(snapshot):
        if (not isinstance(snapshot, dict) or snapshot.get('status') != 'ready' or
                snapshot.get('provider') != 'Gold API' or snapshot.get('asset') != 'XAU' or
                snapshot.get('currency') != 'USD'):
            return None
        raw = snapshot.get('priceText')
        if not isinstance(raw, str) or not 1 <= len(raw) <= 64:
            return None
        try:
            value = Decimal(raw)
            if not value.is_finite() or not 0 < value < Decimal('1000000000'):
                return None
            # Cent-level change detection; audible prices are rounded separately
            # to whole dollars by the market desk.
            return value.quantize(Decimal('.01'))
        except (InvalidOperation, ValueError):
            return None

    def _price_change_pending(self, language, snapshot):
        price = self._spoken_quote_price(snapshot)
        if price is None:
            return False
        if self.initial_price[language] is None:
            self.initial_price[language] = price
            return False
        reference = self.last_announced_price[language]
        if reference is None:
            reference = self.initial_price[language]
        return price != reference

    def _can_prepare_quote(self, job, now_ms):
        language = job['language']
        # A learned preparation estimate avoids spending the free CPU on an
        # already infeasible quote. The original final freshness check stays.
        estimated_seconds = min(60, max(1, len(job['speechText']) * self.speech_seconds_per_character[language]))
        estimated_audio = min(90, max(1, len(job['speechText']) * (.08 if language == 'ar' else .065)))
        expected_start = self._priority_start(language, now_ms + math.ceil(estimated_seconds * 1000),
                                              job['kind'], estimated_audio)
        if self._job_fresh(job, expected_start + 3000):
            return True
        self.last_deferred_quote[language] = {'kind': job['kind'], 'checkedAt': now_ms,
            'sourceAt': job['publishedAt'] * 1000, 'estimatedStartAt': expected_start,
            'reason': 'A newer reference quote is needed before preparing this update.'}
        return False

    def _production(self, language, now_ms):
        active, previous = self.preparing[language], self.last_prepared[language]
        return {'preparing': active is not None, 'kind': active['kind'] if active else None,
            'startedAt': active['startedAt'] if active else None,
            'lastPreparedAt': previous['preparedAt'] if previous else None,
            'lastPreparationSeconds': previous['seconds'] if previous else None,
            'lastDeferredQuote': self.last_deferred_quote[language],
            'lookaheadSeconds': SPEECH_LOOKAHEAD_S,
            'queuedSeconds': round(sum(max(0, q['endsAt'] - max(now_ms, q['startsAt']))
                for q in self.queues[language]) / 1000, 3)}

    @staticmethod
    def _job_fresh(job, at_ms):
        if job.get('kind') == 'cloud-discussion':
            programme, sources = job.get('programme', {}), job.get('sources', [])
            captured, generated, expiry = (programme.get(key) for key in
                                           ('contextCapturedAt', 'generatedAt', 'expiresAt'))
            return (programme.get('mode') == 'cloud-llm' and programme.get('forecast') is False and
                    all(type(value) is int for value in (captured, generated, expiry)) and
                    0 < captured <= generated <= at_ms <= expiry and expiry - generated <= 300000 and
                    isinstance(sources, list) and len(sources) <= 1 and
                    (bool(sources) or programme.get('educational') is True) and
                    all(type(row.get('publishedAt')) is int and type(row.get('firstSeenAt')) is int and
                        0 < row['publishedAt'] <= row['firstSeenAt'] <= captured and
                        at_ms - row['publishedAt'] <= EARLIER_WINDOW_S * 1000 and
                        story_allowed({**row, 'publishedAt': row['publishedAt'] // 1000,
                                       'firstSeenAt': row['firstSeenAt'] // 1000}) for row in sources))
        if job.get('kind') == 'news-context':
            sources = job.get('sources', [])
            window = job.get('newsContext', {}).get('windowSeconds')
            return (2 <= len(sources) <= 3 and window in (600, 3600, 7200) and
                    all(fresh(row, at_ms // 1000, window) for row in sources))
        if job.get('kind') == 'podcast':
            programme = job.get('programme', {})
            return (programme.get('mode') == 'recorded-educational' and programme.get('educational') is True
                    and programme.get('currentNews') is False and programme.get('forecast') is False
                    and type(programme.get('preparedAt')) is int and 0 < programme['preparedAt'] <= at_ms
                    and job['publishedAt'] <= job['firstSeenAt'] <= at_ms // 1000)
        if job.get('kind') in ('market', 'analysis'):
            return (0 <= at_ms // 1000 - job['publishedAt'] <= MAX_QUOTE_AGE_S and
                    job['publishedAt'] <= job['firstSeenAt'] <= at_ms // 1000)
        if job.get('kind') == 'discussion':
            programme = job['programme']
            return (0 <= at_ms - programme['windowEnd'] <= 900000 and
                    programme['windowEnd'] <= programme['generatedAt'] <= at_ms and
                    job['firstSeenAt'] <= at_ms // 1000)
        return fresh(job, at_ms // 1000, EARLIER_WINDOW_S if job.get('recency') == 'earlier' else WINDOW_S)

    def _scheduled_start(self, language, generated_ms, duration_s=1.0):
        return self.airtime[language].next_start(self.queues[language], generated_ms, duration_s)

    def _speech_for_job(self, tts, job, spoken):
        """Reuse recorded educational audio; current news always gets new speech."""
        if job['kind'] == 'cloud-discussion':
            return tts.synthesize(spoken, language=job['language'],
                                  voice_profile=job['programme']['speakerRole']), False, None
        if job['kind'] != 'podcast':
            return tts.synthesize(spoken, language=job['language']), False, None
        role = job['programme']['speakerRole']
        key = hashlib.sha256(json.dumps({'text': spoken, 'language': job['language'],
            'engines': getattr(tts, 'engines', {}), 'voiceProfile': role,
            'castVersion': CAST_VERSION}, sort_keys=True).encode()).hexdigest()
        now_ms = int(time.time() * 1000)
        with self.cache_lock:
            saved = self.podcast_cache.get(key)
            if saved:
                path = self.podcast_cache_directory / (key + '.wav')
                if not path.is_symlink() and path.is_file() and path.stat().st_size == saved['bytes']:
                    speech = SimpleNamespace(wav=path.read_bytes(), duration_s=saved['duration'],
                        engine=saved['engine'], language=job['language'], inference_s=0, cast=saved.get('cast'))
                    try:
                        speech_check(speech, job['language'])
                        saved['touchedAt'] = now_ms
                        return speech, True, saved['recordedAt']
                    except ValueError:
                        pass
                self.podcast_cache.pop(key, None)
        speech = tts.synthesize(spoken, language=job['language'], voice_profile=role)
        speech_check(speech, job['language'])
        with self.cache_lock:
            while self.podcast_cache and (len(self.podcast_cache) >= 128 or
                    sum(row['bytes'] for row in self.podcast_cache.values()) + len(speech.wav) > PODCAST_CACHE_BYTES):
                oldest = min(self.podcast_cache, key=lambda item: self.podcast_cache[item]['touchedAt'])
                (self.podcast_cache_directory / (oldest + '.wav')).unlink(missing_ok=True)
                del self.podcast_cache[oldest]
            path = self.podcast_cache_directory / (key + '.wav')
            path.write_bytes(speech.wav)
            self.podcast_cache[key] = {'bytes': len(speech.wav), 'duration': speech.duration_s,
                'engine': speech.engine, 'recordedAt': now_ms, 'touchedAt': now_ms,
                'cast': getattr(speech, 'cast', None)}
        return speech, False, now_ms

    def _music_manifest(self, language, now_ms, current):
        elapsed = self.airtime[language].total_music_ms(now_ms)
        selected = self.music_library.selection(elapsed, now_ms, current is None)
        if selected:
            return selected
        if not self.music_data:
            return None
        return {'audioUrl': '/' + MUSIC_FILE, 'durationSeconds': MUSIC_SECONDS, 'epochMs': 0, 'gain': .45,
                'trackId': 'station-relax-' + str(elapsed // (MUSIC_SECONDS * 1000)),
                'title': 'Gold Pulse relaxation', 'artist': 'Gold Pulse',
                'license': 'Original station composition', 'sourceUrl': 'https://gold-air.onrender.com/',
                'positionSeconds': (elapsed / 1000) % MUSIC_SECONDS,
                'asOfServerTime': now_ms, 'playing': current is None}

    def _prune(self, now_ms):
        keep = set()
        for language, queue in self.queues.items():
            # Never evict an on-air or future clip to retain expired history.
            prior = [q for q in queue if now_ms - 120000 <= q['endsAt'] <= now_ms][-2:]
            self.queues[language] = prior + [q for q in queue if q['endsAt'] > now_ms]
            keep.update(q['id'] for q in self.queues[language])
        for path in self.directory.glob('*.wav'):
            if path.stem not in keep and time.time() - path.stat().st_mtime > 180:
                path.unlink(missing_ok=True)

    def generate(self):
        try:
            if self.tts_factory is None:
                from tts import ServerTts
                tts = ServerTts()
            else:
                tts = self.tts_factory()
            if self.cloud_llm is not None and hasattr(tts, 'before_native'):
                tts.before_native = lambda: self.cloud_llm.pause(seconds=120)
            with self.lock:
                self.languages = tuple(l for l in tts.available_languages if l in self.queues)
                self.engines = {k: plain(v, 80) for k, v in getattr(tts, 'engines', {}).items() if k in self.languages}
                self.english_native_policy = getattr(tts, 'english_native_policy', None)
                self.arabic_news_policy = getattr(tts, 'arabic_news_policy', None)
                self.status = 'ready' if self.languages else 'unavailable'
            if self.tts_factory is None and os.environ.get('RADIO_STARTUP_SPEECH_CHECK') == '1':
                samples = {'ar': 'مرحباً بكم في غولد بالس. هذا اختبار للصوت العربي.',
                           'en': 'Welcome to Gold Pulse. This is a station audio check.'}
                for language in self.languages:
                    try:
                        result = speech_check(tts.synthesize(samples[language], language=language), language)
                    except Exception as error:
                        result = {'status': 'unavailable', 'errorType': type(error).__name__,
                                  'checkedAt': int(time.time() * 1000)}
                    with self.lock:
                        self.startup_speech_checks[language] = result
                        self.english_native_failure = getattr(tts, 'english_failure', None)
                        self.arabic_news_failure = getattr(tts, 'arabic_news_failure', None)
                        if result.get('engine'):
                            self.engines[language] = result['engine']
        except Exception:
            with self.lock:
                self.status = 'unavailable'
            return
        if len(self.languages) > 1:
            workers = [threading.Thread(target=self._produce, args=(tts, (language,)), daemon=True)
                       for language in self.languages]
            for worker in workers:
                worker.start()
            for worker in workers:
                worker.join()
        else:
            self._produce(tts, self.languages)

    def _produce(self, tts, languages):
        retry_at, last_language = {}, None
        while not self.stop.is_set():
            now_ms = int(time.time() * 1000)
            retry_at = {key: until for key, until in retry_at.items() if until > now_ms}
            job = None
            with self.lock:
                self._prune(now_ms)
                for language in sorted(languages, key=lambda v: v == last_language):
                    priority = self._market_job(language, now_ms, retry_at)
                    if priority:
                        job = dict(priority)
                        break
                    if sum(q['endsAt'] > now_ms for q in self.queues[language]) >= MAX_QUEUE:
                        continue
                    tail = max((q['endsAt'] for q in self.queues[language]), default=0)
                    if tail > now_ms + SPEECH_LOOKAHEAD_S * 1000:
                        continue
                    candidate = self._next_job(language, now_ms, retry_at)
                    if candidate:
                        job = dict(candidate)
                        break
            if job is None:
                self.stop.wait(1)
                continue
            language = job['language']
            last_language = language
            started = time.monotonic()
            with self.lock:
                self.preparing[language] = {'kind': job['kind'], 'startedAt': int(time.time() * 1000)}
            try:
                spoken = job_speech_text(job)
                speech, cached_podcast, recorded_at = self._speech_for_job(tts, job, spoken)
                speech_check(speech, language)
                duration = speech.duration_s
                if (not isinstance(speech.wav, bytes) or not 44 < len(speech.wav) <= MAX_AUDIO_BYTES or
                        not isinstance(duration, (int, float)) or not math.isfinite(duration) or
                        not 0 < duration <= MAX_CLIP_S or speech.language != language):
                    raise ValueError('Invalid server audio')
                generated = int(time.time() * 1000)
                with self.lock:
                    priority_job = job['kind'] in ('market', 'analysis')
                    if not priority_job and sum(q['endsAt'] > generated for q in self.queues[language]) >= MAX_QUEUE:
                        continue
                    # Let four-second manifest polling prefetch short bulletins.
                    start = (self._priority_start(language, generated, job['kind'], duration) if priority_job else
                             self._scheduled_start(language, generated, duration))
                    if not self._job_fresh(job, start):
                        # A ten-minute item may have aged into the labelled
                        # earlier cohort during synthesis. It needs a new,
                        # honestly prefixed recording rather than silent loss.
                        retry_at[job['id']] = generated + 30000
                        continue
                    quiet_podcast = False
                    if job['kind'] in ('podcast', 'cloud-discussion'):
                        new_report = self._candidate(language, generated // 1000, retry_at)
                        quiet_podcast = new_report is None
                        if job.get('quietPodcastFallback') and new_report is not None:
                            # A report arrived during speech preparation. Keep
                            # the private recording, but give that report the
                            # next queue slot before consuming this turn.
                            retry_at[job['id']] = generated + 1000
                            continue
                        if not self.airtime[language].can_schedule_podcast(
                                duration, generated, start_ms=start, quiet=quiet_podcast):
                            retry_at[job['id']] = generated + 10000
                            continue
                    if (job['kind'] == 'market' and job.get('announcementReason') == 'changed' and
                            not self._price_change_pending(language, job['market'])):
                        continue
                    identifier = hashlib.sha256((job['id'] + language + str(generated)).encode()).hexdigest()[:32]
                    (self.directory / (identifier + '.wav')).write_bytes(speech.wav)
                    segment = {'id': identifier, 'kind': job['kind'], 'language': language,
                        'headline': job['title'], 'source': job['source'], 'sourceUrl': job['url'],
                        'publishedAt': job['publishedAt'] * 1000, 'firstSeenAt': job['firstSeenAt'] * 1000,
                        'generatedAt': generated, 'startsAt': start, 'endsAt': start + round(duration * 1000),
                        'durationSeconds': round(duration, 3), 'speechText': spoken,
                        'preparationSeconds': round(time.monotonic() - started, 3),
                        'engine': plain(speech.engine, 80), 'audioUrl': '/audio/' + identifier + '.wav'}
                    self.engines[language] = segment['engine']
                    self.english_native_failure = getattr(tts, 'english_failure', None)
                    self.arabic_news_failure = getattr(tts, 'arabic_news_failure', None)
                    for key, attribute in (('inferenceSeconds', 'inference_s'), ('firstChunkSeconds', 'first_chunk_s')):
                        value = getattr(speech, attribute, None)
                        if type(value) in (int, float) and math.isfinite(value) and value >= 0:
                            segment[key] = round(value, 3)
                    if job['kind'] in ('market', 'analysis'):
                        segment['market'] = job['market']
                        segment['announcementReason'] = job.get('announcementReason')
                        segment['changeSinceLastCall'] = job.get('changeSinceLastCall')
                        segment['spokenRounding'] = 'nearest-whole-dollar-half-up'
                        clock = datetime.fromtimestamp(job['publishedAt'], timezone.utc).strftime('%H:%M:%S UTC')
                        segment['caption'] = (f'رصد Gold API الساعة {clock} · مصدر منفصل عن الرسم البياني' if language == 'ar'
                            else f'Observed Gold API reference at {clock} · separate from TradingView/OANDA')
                        if job['kind'] == 'analysis':
                            segment['analysis'] = job.get('analysis')
                            segment['sources'] = job.get('sources', [])
                            segment['caption'] = (f'قراءة وصفية للمنحنى المرصود عند {clock}' if language == 'ar'
                                else f'Briefing on the observed curve at {clock}')
                    elif job['kind'] == 'cloud-discussion':
                        segment.update(programme=job['programme'], sources=job.get('sources', []),
                            speaker=job['speaker'], voiceProfile=job['programme']['speakerRole'],
                            quietNewsFallback=quiet_podcast, audioSource='cloud-llm-script',
                            generationSeconds=job.get('generationSeconds'))
                        if isinstance(getattr(speech, 'cast', None), dict):
                            segment['cast'] = dict(speech.cast)
                        segment['caption'] = ('نقاش مولد حديثاً في الخادم' if language == 'ar' else
                                              'Freshly generated cloud discussion')
                    elif job['kind'] == 'podcast':
                        segment['programme'] = job['programme']
                        segment['speaker'] = job['speaker']
                        segment['voiceProfile'] = job['programme']['speakerRole']
                        segment['quietNewsFallback'] = quiet_podcast
                        if isinstance(getattr(speech, 'cast', None), dict):
                            segment['cast'] = dict(speech.cast)
                        segment['recordedAt'] = recorded_at
                        segment['audioSource'] = 'cached-recorded-podcast' if cached_podcast else 'recorded-podcast'
                        segment['caption'] = (('إعادة · ' if job['programme']['repeat'] else '') + 'بودكاست تعليمي مسجل · ' + job['speaker']
                            if language == 'ar' else ('Replay · ' if job['programme']['repeat'] else '') +
                            'Recorded educational podcast · ' + job['speaker'])
                        if self.programmes is None or not self.programmes.consume(job, generated // 1000):
                            (self.directory / (identifier + '.wav')).unlink(missing_ok=True)
                            continue
                    elif job['kind'] == 'discussion':
                        segment['programme'] = job['programme']
                        segment['sources'] = job['sources']
                        segment['speaker'] = job['speaker']
                        segment['caption'] = (f"مناقشة مشروطة · {job['speaker']} · نافذة الأخبار " if language == 'ar'
                            else f"Conditional discussion · {job['speaker']} · news window ending ") + datetime.fromtimestamp(
                                job['publishedAt'], timezone.utc).strftime('%H:%M UTC')
                        if self.discussions.consume(job) is not True:
                            # A refreshed/bounded source queue can retire an
                            # in-flight turn. Never publish it out of order or
                            # let a later re-import repeat unconsumed speech.
                            (self.directory / (identifier + '.wav')).unlink(missing_ok=True)
                            continue
                    elif job['kind'] == 'news-context':
                        segment['sources'] = job['sources']
                        segment['sourceIds'] = job['sourceIds']
                        segment['newsContext'] = job['newsContext']
                        segment['recency'] = job['recency']
                        segment['caption'] = ('تقارير فعلية من المصادر المذكورة مع أوقاتها الأصلية' if language == 'ar'
                            else 'Collected reports from named sources, with original publication times')
                        self.seen[language].update(job['sourceIds'])
                        self.last_news_topics[language] = (job['newsContext']['groupTopic'],)
                    else:
                        segment['recency'] = job.get('recency', 'fresh')
                        segment['relevance'] = job.get('relevance')
                        if job.get('social') is True:
                            segment.update(social=True, sourceKind=job.get('sourceKind', 'social'), platform=job.get('platform'),
                                           timeKind=job.get('timeKind', 'published'), authorTimeUnverified=True)
                            if isinstance(job.get('feedback'), dict):
                                segment['feedback'] = dict(job['feedback'])
                        self.seen[language].add(job['id'])
                        self.last_news_source[language] = job['source']
                        self.last_news_topics[language] = tuple((job.get('relevance') or {}).get('topics') or ())
                    # A CPU preparation gap is not another programme item.
                    # Otherwise slower Arabic synthesis can reset this count
                    # forever and prevent an earned host/analyst discussion.
                    prior_streak = self.news_streak[language]
                    if priority_job:
                        self._insert_priority(language, segment, generated)
                    else:
                        self.queues[language].append(segment)
                        self.airtime[language].commit(segment['startsAt'], segment['endsAt'],
                            'social' if segment.get('social') else
                            'discussion' if segment['kind'] == 'cloud-discussion' else segment['kind'])
                    if job['kind'] == 'cloud-discussion':
                        self.cloud_writer.consume(job.get('_cloudCandidate', job), generated // 1000)
                    if job['kind'] == 'analysis':
                        self.last_analysis_at[language] = start
                        self.last_market_outlook = (job.get('analysis') or {}).get('outlook')
                        if self.last_market_outlook:
                            self.outlook.commit(self.last_market_outlook)
                    if job['kind'] == 'market':
                        self.last_market_at[language] = start
                        self.last_market_id[language] = job['id']
                        # Failed or expired synthesis never advances this
                        # reference; queued clips do, even before they air.
                        self.last_announced_price[language] = self._spoken_quote_price(job['market'])
                    if job['kind'] in ('news', 'news-context'):
                        self.news_streak[language] = prior_streak + 1
                    elif not priority_job:
                        self.news_streak[language] = 0
                    # Short price calls do not reset the editorial news burst;
                    # otherwise a moving market could starve every discussion.
                    self.last_prepared[language] = {'preparedAt': generated, 'seconds': segment['preparationSeconds']}
                    measured_cost = segment['preparationSeconds'] / max(1, len(spoken))
                    self.speech_seconds_per_character[language] = min(.5, max(.001,
                        .7 * self.speech_seconds_per_character[language] + .3 * measured_cost))
                    self.errors.pop(language, None)
                    self._save_receipts()
            except Exception:
                retry_at[job['id']] = int(time.time() * 1000) + 30000
                with self.lock:
                    self.errors[language] = 'Speech preparation unavailable; retrying.'
            finally:
                with self.lock:
                    self.preparing[language] = None

    def start(self):
        for target in (self.collect, self.collect_social, self.collect_feedback, self.collect_cloud_scripts,
                       self.collect_economic_feeds, self.collect_market, self.generate):
            threading.Thread(target=target, daemon=True).start()

    def manifest(self, language, now_ms=None):
        now = int(time.time() * 1000) if now_ms is None else now_ms
        with self.lock:
            queue = [dict(q) for q in self.queues[language] if q['endsAt'] > now]
            current = next((q for q in queue if q['startsAt'] <= now < q['endsAt']), None)
            selection = select_news(self.stories.values(), language, now // 1000)
            unread = sum(s['id'] not in self.seen[language] for s in selection.selected)
            earlier = select_news(self.stories.values(), language, now // 1000,
                                  window_s=EARLIER_WINDOW_S, minimum_age_s=WINDOW_S + 1)
            earlier_unread = sum(s['id'] not in self.seen[language] for s in earlier.selected)
            market_schedule = {'priceDueAt': (self.last_market_at[language] + PRICE_HEARTBEAT_S * 1000
                                             if self.last_market_at[language] else now),
                'analysisDueAt': (self.last_analysis_at[language] or self.started_at) + ANALYSIS_INTERVAL_S * 1000,
                'lastPriceAt': self.last_market_at[language] or None,
                'lastAnalysisAt': self.last_analysis_at[language] or None}
            return {'version': 1, 'serviceVersion': SERVICE_VERSION, 'station': 'Gold Pulse Radio', 'serverTime': now, 'language': language,
                'mode': 'cloud-news', 'dependencies': {'pcRequired': False, 'publicDiscussionImporter': False},
                'languages': list(self.languages), 'status': 'live' if current else self.status if self.status != 'ready' else 'waiting',
                'nowPlaying': current, 'queue': queue[:MAX_QUEUE], 'lastCollectionAt': self.last_collection,
                'recent': [dict(q) for q in self.queues[language] if now - 120000 <= q['endsAt'] <= now][-2:],
                'music': self._music_manifest(language, now, current),
                'freshStories': sum(1 for s in self.stories.values() if s['language'] == language and fresh(s, now // 1000)),
                'unreadFreshStories': unread,
                'newsSelection': {**selection.summary(), 'fraction': TARGET_PERCENT / 100, 'freshCount': selection.scannedFresh,
                    'relevantCount': selection.relevant, 'selectedCount': len(selection.selected),
                    'unreadSelectedCount': unread, 'scheduledSelectedCount': len(selection.selected) - unread},
                'earlierNewsSelection': {**earlier.summary(), 'fraction': TARGET_PERCENT / 100, 'freshCount': earlier.scannedFresh,
                    'relevantCount': earlier.relevant, 'selectedCount': len(earlier.selected),
                    'unreadSelectedCount': earlier_unread, 'scheduledSelectedCount': len(earlier.selected) - earlier_unread},
                'feedsReached': sum(s['status'] == 'ready' for s in self.feed_states.values()), 'feedCount': len(FEEDS),
                'sourcePolicy': {'id': POLICY_ID, 'publisherDomains': sorted(APPROVED_PUBLISHER_DOMAINS),
                    'regionalArabPublishers': False, 'regionalLiveBlog': False,
                    'internationalArabicEditions': True, 'siteIdentityInCollectorHeaders': False},
                'liveUpdates': dict(self.live_state),
                'socialSources': dict(self.social_state),
                'socialFeedback': dict(self.feedback_state),
                'economicFeeds': dict(self.economic_state),
                'socialStories': sum(s.get('social') is True and s['language'] == language and
                    fresh(s, now // 1000, EARLIER_WINDOW_S) for s in self.stories.values()),
                'error': self.errors.get(language), 'newsWindowSeconds': WINDOW_S, 'earlierNewsWindowSeconds': EARLIER_WINDOW_S,
                'market': self.market.snapshot(now // 1000), 'marketCadenceSeconds': PRICE_HEARTBEAT_S,
                'marketSchedule': market_schedule, 'marketOutlook': self.last_market_outlook,
                'forecastEvaluation': self.outlook.status(),
                'programmeMix': {'newsTargetPercent': TARGET_PERCENT, 'analysisIntervalSeconds': ANALYSIS_INTERVAL_S,
                    'contentTargetPercent': 80, 'musicTargetPercent': 20,
                    'marketCadenceSeconds': PRICE_HEARTBEAT_S,
                    'priceChangeCooldownSeconds': MARKET_SPEECH_INTERVAL_S,
                    'priceChangeOnly': False, 'priceRounding': 'whole-dollar-speech',
                    'newsShareOfSpeechTargetPercent': 60,
                    'podcastNewsPolicy': 'news-priority-with-quiet-podcast-fallback',
                    'newsSupplyState': 'available' if unread + earlier_unread else 'quiet',
                    'observed': self.airtime[language].snapshot(now),
                    'cloudLlmPodcasts': self.cloud_writer is not None,
                    'recordedEducationalPodcasts': self.programmes is not None},
                'cloudWriter': (self.cloud_writer.status(language) if self.cloud_writer is not None
                                else {'enabled': False, 'status': 'disabled'}),
                'cloudLlm': self.cloud_llm.status() if self.cloud_llm is not None else {'enabled': False},
                'podcasts': self.programmes.status(language, now // 1000) if self.programmes else {'enabled': False},
                'production': self._production(language, now),
                'discussions': self.discussions.status(language) if self.discussions else {'enabled': False, 'pending': 0},
                'note': ('Target 80% speech and 20% music. New reports have priority. All eligible relevant reports up to two hours old are selected, newest first with gold, economy and oil priority. Original source clocks are announced for earlier items. ' +
                    ('Fresh cloud-generated discussions continue during quiet periods; the recorded archive is disabled. Generation speed and source availability can affect the target. ' if self.cloud_writer is not None else
                     'Clearly labelled recorded discussions continue during quiet periods and never count as news. ') +
                    'No PC source is required.')}

    def audio(self, identifier):
        with self.lock:
            now = int(time.time() * 1000)
            if not any(q['id'] == identifier and q['endsAt'] > now - 120000 for queue in self.queues.values() for q in queue):
                return None
            path = self.directory / (identifier + '.wav')
            if path.is_symlink() or not path.is_file() or not 44 < path.stat().st_size <= MAX_AUDIO_BYTES:
                return None
            return path.read_bytes()


def make_handler(station):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'GoldRadio'
        sys_version = ''

        def log_message(self, *_):
            pass  # Request IPs and query strings are not written to application logs.

        def send(self, status, body, content_type, head=False, cache='no-store'):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', cache)
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-src https://www.tradingview-widget.com; media-src 'self' blob:; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            if not head:
                self.wfile.write(body)

        def route(self, head=False):
            if len(self.path) > 2048:
                return self.send(414, b'{"error":"Request too long"}', 'application/json', head)
            try:
                path = urllib.parse.urlsplit(self.path)
                query = urllib.parse.parse_qs(path.query, keep_blank_values=True, max_num_fields=10)
            except ValueError:
                return self.send(400, b'{"error":"Invalid request"}', 'application/json', head)
            if path.path == '/' and not query:
                return self.send(200, (HERE / 'index.html').read_bytes(), 'text/html; charset=utf-8', head)
            if path.path == '/' + MUSIC_FILE and not query and station.music_data:
                return self.send(200, station.music_data, 'audio/wav', head, 'public, max-age=86400')
            music_match = re.fullmatch(r'/music/([a-z0-9-]{1,64})\.mp3', path.path)
            if music_match and not query:
                asset = station.music_library.asset(music_match.group(1))
                if asset is not None:
                    return self.send_music(asset, head)
            if path.path == '/health' and not query:
                budget = container_memory()
                return self.send(200, json.dumps({'ok': True, 'speechStatus': station.status,
                    'serviceVersion': SERVICE_VERSION,
                    'mode': 'cloud-news', 'dependencies': {'pcRequired': False, 'publicDiscussionImporter': False},
                    'languages': list(station.languages), 'speechEngines': station.engines,
                    'musicReady': bool(station.music_data) or bool(len(station.music_library)),
                    'licensedMusicTracks': len(station.music_library),
                    'englishNativeFailure': station.english_native_failure,
                    'englishNativePolicy': station.english_native_policy,
                    'arabicNewsPolicy': station.arabic_news_policy,
                    'arabicNewsFailure': station.arabic_news_failure,
                    'containerMemory': ({'currentBytes': budget[0], 'limitBytes': budget[1]} if budget else None),
                    'cloudLlm': station.cloud_llm.status() if station.cloud_llm is not None else {'enabled': False},
                    'startupSpeechChecks': station.startup_speech_checks}).encode(), 'application/json', head)
            if path.path == '/radio.json' and set(query) <= {'language'} and len(query.get('language', [])) <= 1:
                language = query.get('language', ['ar'])[0]
                if language in ('ar', 'en'):
                    body = json.dumps(station.manifest(language), ensure_ascii=False).encode()
                    return self.send(200, body, 'application/json; charset=utf-8', head)
            match = re.fullmatch(r'/audio/([a-f0-9]{32})\.wav', path.path)
            if match and not query:
                body = station.audio(match.group(1))
                if body is not None:
                    return self.send(200, body, 'audio/wav', head)
            return self.send(404, b'{"error":"Not found"}', 'application/json', head)

        def send_music(self, asset, head):
            # Asset lookup already used the fixed, verified playlist allowlist.
            # Stream small blocks instead of holding every listener's MP3 in RAM.
            size = asset.stat().st_size
            start, end, status = 0, size - 1, 200
            requested = self.headers.get('Range')
            if requested:
                match = re.fullmatch(r'bytes=(\d{0,12})-(\d{0,12})', requested)
                if not match or not any(match.groups()):
                    return self.send(416, b'Invalid audio range', 'text/plain', head)
                if match[1]:
                    start = int(match[1])
                    end = min(size - 1, int(match[2])) if match[2] else size - 1
                else:
                    suffix = int(match[2])
                    start = max(0, size - suffix)
                if start >= size or end < start:
                    return self.send(416, b'Invalid audio range', 'text/plain', head)
                status = 206
            self.send_response(status)
            self.send_header('Content-Type', 'audio/mpeg')
            self.send_header('Content-Length', str(end - start + 1))
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Cache-Control', 'public, max-age=86400')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            if status == 206:
                self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
            self.end_headers()
            if head:
                return
            with asset.open('rb') as audio:
                audio.seek(start)
                remaining = end - start + 1
                while remaining:
                    data = audio.read(min(65536, remaining))
                    if not data:
                        break
                    self.wfile.write(data)
                    remaining -= len(data)

        def do_GET(self):
            try:
                self.route()
            except (BrokenPipeError, ConnectionResetError):
                # Browsers cancel a music range when news interrupts it.
                # That normal client disconnect must not become a server fault.
                self.close_connection = True

        def do_HEAD(self):
            try:
                self.route(head=True)
            except (BrokenPipeError, ConnectionResetError):
                self.close_connection = True

        def do_POST(self):
            self.send(405, b'{"error":"Read-only service"}', 'application/json')

    return Handler


class RadioHttpServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler):
        self.slots = threading.BoundedSemaphore(20)
        super().__init__(address, handler)

    def get_request(self):
        request, address = super().get_request()
        request.settimeout(10)
        return request, address

    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.slots.release()


def main():
    station = Station()
    station.start()
    server = RadioHttpServer(('0.0.0.0', int(os.environ.get('PORT', '10000'))), make_handler(station))
    print('Gold Pulse Radio HTTP service started.', flush=True)
    try:
        server.serve_forever()
    finally:
        station.stop.set()
        server.server_close()


if __name__ == '__main__':
    main()

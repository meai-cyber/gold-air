"""Attributed topic roundups made only from unspoken collected reports.

Counts describe this station's eligible input sample, never public sentiment,
independent corroboration, agreement, or a measured gold-price effect. This
module fetches nothing, generates no claims, and does not renew source clocks.
The owner must mark EVERY sourceId consumed only when the audio is queued;
otherwise the raw reports could be spoken a second time under another label.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
from itertools import islice
import json

from news_selection import MAX_INPUT_ROWS, select_news
from news_speech import public_report_text


MAX_REPORTS = 3
MIN_REPORTS = 2
MAX_SPEECH_CHARACTERS = 900
METHOD = 'unspoken-collected-topic-roundup-v1'
_TOPICS = {
    'gold': ('gold', 'الذهب'),
    'precious-metals': ('precious metals', 'المعادن الثمينة'),
    'central-banks': ('central banks', 'البنوك المركزية'),
    'rates-and-bonds': ('rates and bonds', 'الفائدة والسندات'),
    'inflation': ('inflation', 'التضخم'),
    'currencies': ('currencies', 'العملات'),
    'energy': ('energy', 'الطاقة'),
    'trade-and-supply': ('trade and supply', 'التجارة والإمدادات'),
    'jobs-and-growth': ('jobs and economic activity', 'الوظائف والنشاط الاقتصادي'),
    'financial-risk': ('financial markets', 'الأسواق المالية'),
    'geopolitics': ('international security', 'الأمن الدولي'),
    'natural-supply-shock': ('disruption of supplies', 'تعطل الإمدادات'),
    'world-security': ('security developments', 'التطورات الأمنية'),
    'world-diplomacy': ('diplomacy', 'الدبلوماسية'),
    'world-policy': ('public policy', 'السياسات العامة'),
    'market-context': ('market developments', 'تطورات الأسواق'),
    'humanitarian': ('humanitarian developments', 'التطورات الإنسانية'),
    'world-emergency': ('major emergencies', 'حالات الطوارئ الكبرى'),
    'science-and-environment': ('science and the environment', 'العلوم والبيئة'),
}


def _excluded(values):
    if isinstance(values, (str, bytes, dict)):
        raise ValueError('Excluded report IDs must be a bounded iterable')
    try:
        values = list(islice(iter(values), MAX_INPUT_ROWS + 1))
    except TypeError:
        raise ValueError('Excluded report IDs must be a bounded iterable') from None
    if len(values) > MAX_INPUT_ROWS or any(not isinstance(value, str) for value in values):
        raise ValueError('Excluded report IDs must be a bounded iterable')
    return set(values)


def _report_speech(row, language, recency):
    # A title is the collected report; an absent article body is never invented.
    speech = public_report_text({**row, 'summary': '', 'recency': recency})
    if recency == 'fresh':
        clock = datetime.fromtimestamp(row['publishedAt'], timezone.utc).strftime('%H:%M')
        if row.get('social') is True:
            prefix = (f'Post time according to its source: {clock} UTC. ' if language == 'en' else
                      f'وقت المنشور حسب مصدره {clock} بالتوقيت العالمي. ')
        else:
            prefix = (f'Published at {clock} UTC. ' if language == 'en' else
                      f'نشر عند {clock} بالتوقيت العالمي. ')
        speech = prefix + speech
    return speech


def _intro(language, topic, count, source_count, recency, window):
    label = _TOPICS[topic][0 if language == 'en' else 1]
    if language == 'en':
        period = ('the last ten minutes' if recency == 'fresh' else
                  'the last two hours, with their original times' if window == 7200 else
                  'the last hour, with their original times')
        return (f'Collected report roundup on {label}: {count} reports attributed to '
                f'{source_count} named source' + ('' if source_count == 1 else 's') + f' from {period}.')
    period = ('العشر دقائق الأخيرة' if recency == 'fresh' else
              'الساعتين الأخيرتين مع أوقاتها الأصلية' if window == 7200 else
              'الساعة الأخيرة مع أوقاتها الأصلية')
    reports = 'تقريراً واحداً' if count == 1 else 'تقريرين' if count == 2 else 'ثلاثة تقارير'
    sources = 'مصدر واحد' if source_count == 1 else 'مصدرين' if source_count == 2 else 'ثلاثة مصادر'
    return f'جولة في التقارير المجموعة عن {label} من {period}. تشمل {reports} من {sources} مذكورة بالاسم.'


def build_news_context(language, stories, now_s, excluded=()):
    """Return >=2 related unspoken reports, preserving every original clock.

    Fresh and earlier cohorts stay separate. A failed build consumes nothing.
    The result's sourceIds are the only consumption contract: callers must
    apply them to the same receipts used for ordinary news after publication.
    """
    if language not in ('ar', 'en') or type(now_s) is not int or now_s <= 0:
        raise ValueError('Unsupported report language or clock')
    excluded = _excluded(excluded)
    if isinstance(stories, (str, bytes, dict)):
        raise ValueError('Expected collected report rows')
    try:
        rows = list(islice(iter(stories), MAX_INPUT_ROWS + 1))
    except TypeError:
        raise ValueError('Expected collected report rows') from None
    for recency, window, minimum in (('fresh', 600, 0), ('earlier', 3600, 601), ('earlier', 7200, 3601)):
        selection = select_news(rows, language, now_s, window_s=window, minimum_age_s=minimum,
                                target_percent=100)
        unspoken = [row for row in selection.selected if row['id'] not in excluded]
        groups = {}
        for row in unspoken:
            for topic in selection.reasons[row['id']]:
                if topic in _TOPICS:
                    groups.setdefault(topic, []).append(row)
        ordered = sorted(((topic, values) for topic, values in groups.items() if len(values) >= MIN_REPORTS),
                         key=lambda pair: (-max(selection.scores[row['id']] for row in pair[1]),
                                           -len(pair[1]), pair[0]))
        for topic, values in ordered:
            included, spoken = [], []
            for row in values:
                try:
                    excerpt = _report_speech(row, language, recency)
                except (TypeError, ValueError, OverflowError, OSError):
                    continue
                prospective = [*included, row]
                sources = len({value['source'] for value in prospective})
                speech = ' '.join([_intro(language, topic, len(prospective), sources, recency, window), *spoken, excerpt])
                if len(speech) > MAX_SPEECH_CHARACTERS:
                    continue
                included, spoken = prospective, [*spoken, excerpt]
                if len(included) == MAX_REPORTS:
                    break
            if len(included) < MIN_REPORTS:
                continue
            sources = [{key: row[key] for key in ('id', 'title', 'source', 'url', 'publishedAt', 'firstSeenAt')} |
                       {'social': row.get('social') is True, 'platform': row.get('platform'),
                        'sourceKind': row.get('sourceKind', 'publisher'),
                        'timeKind': row.get('timeKind', 'published')}
                       for row in included]
            for source, row in zip(sources, included):
                if row.get('sourceKind') == 'social-feedback' and isinstance(row.get('feedback'), dict):
                    source['feedback'] = {key: row['feedback'].get(key) for key in
                        ('authorHandle', 'rootSource', 'rootUrl', 'rootId', 'rootPublishedAt')}
                    source['feedback'].update(unverified=True, representative=False)
            source_count = len({row['source'] for row in included})
            speech = ' '.join([_intro(language, topic, len(included), source_count, recency, window), *spoken])
            fingerprint = {'language': language, 'sources': sources, 'recency': recency, 'method': METHOD}
            identity = hashlib.sha256(json.dumps(fingerprint, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:32]
            title = ('Collected report roundup: ' if language == 'en' else 'جولة في التقارير المجموعة: ') + \
                    _TOPICS[topic][0 if language == 'en' else 1]
            topic_counts = Counter(reason for row in included for reason in selection.reasons[row['id']])
            original_from, original_through = min(row['publishedAt'] for row in included), max(row['publishedAt'] for row in included)
            evidence = {'method': METHOD, 'corpus': 'included-station-collected-report-sample',
                'windowSeconds': window, 'minimumAgeSeconds': minimum, 'groupTopic': topic,
                'reportCount': len(included), 'sourceCount': source_count,
                'sourceCountBasis': 'distinct-labels-not-independent-confirmation',
                'topicCounts': dict(sorted(topic_counts.items())),
                'eligibleCorpusReports': selection.relevant, 'unspokenCorpusReports': len(unspoken),
                'sourceIds': [row['id'] for row in included],
                'originalPublishedFrom': original_from * 1000, 'originalPublishedThrough': original_through * 1000,
                'preparedAt': now_s * 1000, 'socialReports': sum(row.get('social') is True for row in included),
                'publicConsensus': False, 'sourceAgreementInferred': False,
                'causalGoldClaim': False, 'forecast': False}
            return {'id': identity, 'kind': 'news-context', 'language': language,
                    'title': title, 'source': 'Gold Pulse collected reports', 'url': included[0]['url'],
                    'publishedAt': original_from,
                    'firstSeenAt': max(row['firstSeenAt'] for row in included),
                    'speechText': speech, 'recency': recency,
                    'sourceIds': evidence['sourceIds'], 'sources': sources, 'newsContext': evidence,
                    'relevance': {'score': max(selection.scores[row['id']] for row in included),
                                  'topics': sorted(topic_counts), 'method': METHOD}}
    return None

"""Fixed broadcast cast; public feed text cannot choose a voice or role.

The official Microsoft voice catalog identifies these as separate female and
male neural voices. Their presence and gender were also checked against the
live Edge catalog on 24 October 2026. The fixed Competitioncast voices were
checked against that public catalog on 25 October 2026. These are network
speech voices, not models hosted on Render. Arabic news uses a separate
Zariyah newsreader, with local Nabra retained as the explicitly separate fallback.
https://learn.microsoft.com/en-us/azure/ai-services/speech-service/language-support
"""
from dataclasses import dataclass
from types import MappingProxyType

CAST_VERSION = '2026-10-25-distinct-cast-v2'
NEWS_ENGLISH_VOICE = 'en-US-JennyNeural'
NEWS_ARABIC_VOICE = 'ar-SA-ZariyahNeural'
NEWS_ARABIC_ENGINE = 'edge-network-ar-sa-zariyahneural'


@dataclass(frozen=True)
class CastVoice:
    language: str
    profile: str
    speaker: str
    gender: str
    locale: str
    voice: str
    rate: str = '+0%'

    @property
    def engine(self):
        return 'edge-network-' + self.voice.lower()


CAST_VOICES = MappingProxyType({
    ('en', 'host'): CastVoice('en', 'host', 'Maia', 'Female', 'en-US', 'en-US-AriaNeural'),
    ('en', 'analyst'): CastVoice('en', 'analyst', 'Omar', 'Male', 'en-US', 'en-US-GuyNeural', '+60%'),
    ('ar', 'host'): CastVoice('ar', 'host', 'مايا', 'Female', 'ar-LB', 'ar-LB-LaylaNeural'),
    ('ar', 'analyst'): CastVoice('ar', 'analyst', 'عمر', 'Male', 'ar-LB', 'ar-LB-RamiNeural', '+60%'),
    ('en', 'competition-host'): CastVoice('en', 'competition-host', 'Nadia', 'Female', 'en-US', 'en-US-AvaNeural'),
    ('en', 'competition-player-a'): CastVoice('en', 'competition-player-a', 'Sam', 'Male', 'en-US', 'en-US-AndrewNeural'),
    ('en', 'competition-player-b'): CastVoice('en', 'competition-player-b', 'Mia', 'Female', 'en-US', 'en-US-EmmaNeural'),
    ('ar', 'competition-host'): CastVoice('ar', 'competition-host', 'نادية', 'Female', 'ar-EG', 'ar-EG-SalmaNeural'),
    ('ar', 'competition-player-a'): CastVoice('ar', 'competition-player-a', 'سامر', 'Male', 'ar-EG', 'ar-EG-ShakirNeural'),
    ('ar', 'competition-player-b'): CastVoice('ar', 'competition-player-b', 'ميرا', 'Female', 'ar-AE', 'ar-AE-FatimaNeural'),
})
_NETWORK_REQUESTS = frozenset((value.voice, value.rate) for value in CAST_VOICES.values()) | {
    (NEWS_ENGLISH_VOICE, '+0%'), (NEWS_ARABIC_VOICE, '+0%')}


def get_cast_voice(language, profile):
    if not isinstance(language, str) or not isinstance(profile, str) or (language, profile) not in CAST_VOICES:
        raise ValueError('Unsupported fixed broadcast cast profile')
    return CAST_VOICES[language, profile]


def cast_metadata(language, profile):
    voice = get_cast_voice(language, profile)
    return {'version': CAST_VERSION, 'profile': voice.profile, 'speaker': voice.speaker,
            'voice': voice.voice, 'gender': voice.gender, 'locale': voice.locale,
            'language': voice.language, 'rate': voice.rate,
            'requestedSpeedMultiplier': 1.6 if voice.rate == '+60%' else 1.0,
            'network': True, 'pitchShifted': False}


def network_voice_allowed(voice, rate):
    return isinstance(voice, str) and isinstance(rate, str) and (voice, rate) in _NETWORK_REQUESTS

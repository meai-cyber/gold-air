from datetime import datetime, timezone
from decimal import Decimal
import unittest
from unittest.mock import patch

import market_brief as market


class MarketBriefTests(unittest.TestCase):
    now = 1792713000

    def quote(self, stamp=None, price="4023.00", received=None):
        stamp = self.now if stamp is None else stamp
        return market.parse_quote({"symbol": "XAU", "currency": "USD", "price": Decimal(price),
            "updatedAt": datetime.fromtimestamp(stamp, timezone.utc).isoformat()},
            stamp + 3 if received is None else received)

    def test_provider_clock_asset_price_and_staleness_are_required(self):
        valid = {"symbol": "XAU", "price": 4023.25,
                 "updatedAt": datetime.fromtimestamp(self.now, timezone.utc).isoformat()}
        self.assertEqual(market.parse_quote(valid, self.now + 1).price, Decimal("4023.25"))
        for change in ({"symbol": "PAXG"}, {"currency": "EUR"}, {"price": True}, {"price": "4023"},
                       {"price": float("nan")}, {"price": 0}, {"price": -2}, {"updatedAt": None},
                       {"updatedAt": "2026-10-22T23:50:00"}):
            with self.subTest(change=change), self.assertRaises(market.QuoteUnavailable):
                market.parse_quote({**valid, **change}, self.now + 1)
        for received in (self.now - 1, self.now + 91):
            with self.assertRaises(market.QuoteUnavailable):
                market.parse_quote(valid, received)

    def test_duplicate_checks_preserve_first_receipt_and_no_fabricated_changes(self):
        desk = market.MarketDesk()
        self.assertTrue(desk.observe(self.quote()))
        self.assertFalse(desk.observe(self.quote(received=self.now + 20)))
        snap = desk.snapshot(self.now + 21)
        self.assertEqual(snap["receivedAt"], (self.now + 3) * 1000)
        self.assertEqual(snap["changes"], {})
        self.assertIsNone(snap["observedRange"])
        with self.assertRaises(market.QuoteUnavailable):
            desk.observe(self.quote(price="4024"))
        self.assertEqual(len(desk.history), 1)

    def test_real_horizons_are_matched_earlier_without_interpolation(self):
        desk = market.MarketDesk()
        for delta, price in ((-600, "4010.10"), (-300, "4020.00"), (-60, "4025.25"), (0, "4023.125")):
            desk.observe(self.quote(self.now + delta, price))
        snap = desk.snapshot(self.now + 5)
        self.assertEqual(snap["priceText"], "4023.125")
        self.assertAlmostEqual(snap["changes"]["1"]["usd"], -2.125)
        self.assertEqual(snap["changes"]["1"]["direction"], "down")
        self.assertEqual(snap["changes"]["5"]["usdText"], "3.125")
        self.assertEqual(snap["changes"]["10"]["seconds"], 600)
        self.assertEqual(snap["observedRange"]["sampleCount"], 3)
        self.assertEqual(snap["observedRange"]["lowText"], "4020.00")
        for language in ("ar", "en"):
            brief = desk.brief(language, self.now + 5)
            self.assertIn("4023", brief["speechText"])
            self.assertNotRegex(brief["speechText"], r'\d+\.\d+')
            self.assertEqual(brief["market"]["priceText"], "4023.125")
            self.assertEqual(brief["kind"], "market")
            self.assertEqual(brief["publishedAt"], self.now)
            self.assertEqual(brief["firstSeenAt"], self.now + 3)
            self.assertEqual(len(brief["id"]), 32)
            self.assertLess(len(brief["speechText"]), 1200)
            self.assertNotRegex(brief["speechText"].lower(), r"predict|support|resistance|llm|توقع|دعم|مقاومة")
            self.assertEqual(brief["id"], desk.brief(language, self.now + 30)["id"])

    def test_missing_baseline_is_omitted_not_filled_or_looked_ahead(self):
        desk = market.MarketDesk()
        for delta in (-130, -59, 0):
            desk.observe(self.quote(self.now + delta))
        self.assertEqual(desk.snapshot(self.now + 5)["changes"], {})
        self.assertNotIn("About one minute", desk.brief("en", self.now + 5)["speechText"])
        self.assertIsNone(desk.brief("ar", self.now + 91))
        self.assertEqual(desk.snapshot(self.now + 91)["status"], "stale")

    def test_compact_calls_are_one_short_whole_price_sentence_with_detail_in_metadata(self):
        desk = market.MarketDesk()
        for delta, price in ((-600, "4010.10"), (-300, "4020.00"), (-60, "4025.25"), (0, "4023.125")):
            desk.observe(self.quote(self.now + delta, price))
        for language in ("ar", "en"):
            with self.subTest(language=language):
                brief = desk.brief(language, self.now + 5)
                text = brief["speechText"]
                self.assertIn('4023', text)
                self.assertNotRegex(text, r'\d+\.\d+|\d+:\d+|UTC|Gold API|دقيقة|دقائق')
                self.assertTrue(text.endswith("."))
                self.assertEqual(text.count('.'), 1)
                self.assertLessEqual(len(text.split()), 8)
                self.assertEqual(brief["market"], desk.snapshot(self.now + 5))
                self.assertAlmostEqual(brief['market']['changes']['1']['usd'], -2.125)
                self.assertEqual(brief['market']['priceText'], '4023.125')
        self.assertEqual(desk.brief('en', self.now + 5)['speechText'], 'Gold is about 4023 dollars per ounce.')
        self.assertEqual(desk.brief('ar', self.now + 5)['speechText'], 'الذهب نحو 4023 دولاراً للأونصة.')

    def test_whole_price_call_is_stable_but_identity_keeps_the_original_source_clock(self):
        openings = {"ar": set(), "en": set()}
        identities = {"ar": set(), "en": set()}
        for minute in range(3):
            stamp = self.now + minute * 60
            desk = market.MarketDesk()
            desk.observe(self.quote(stamp, "4023.125"))
            for language in ("ar", "en"):
                brief = desk.brief(language, stamp + 5)
                self.assertEqual(brief["speechText"], desk.brief(language, stamp + 65)["speechText"])
                self.assertEqual(brief["id"], desk.brief(language, stamp + 65)["id"])
                self.assertIn("4023", brief["speechText"])
                self.assertEqual(brief["market"]["priceText"], "4023.125")
                openings[language].add(brief["speechText"])
                identities[language].add(brief['id'])
        self.assertEqual(len(openings["en"]), 1)
        self.assertEqual(len(openings["ar"]), 1)
        self.assertEqual(len(identities['en']), 3)
        self.assertEqual(len(identities['ar']), 3)

    def test_unchanged_and_mixed_observed_windows_stay_in_metadata_not_the_short_price_call(self):
        desk = market.MarketDesk()
        for offset in (-600, -300, -60, 0):
            desk.observe(self.quote(self.now + offset))
        en = desk.brief("en", self.now + 5)["speechText"]
        ar = desk.brief("ar", self.now + 5)["speechText"]
        self.assertNotIn('unchanged', en.lower())
        self.assertNotIn('لم يتغير', ar)
        self.assertTrue(all(row['direction'] == 'unchanged' for row in desk.snapshot(self.now + 5)['changes'].values()))
        one = market.MarketDesk()
        for offset in (-60, 0):
            one.observe(self.quote(self.now + offset))
        self.assertEqual(set(one.brief('en', self.now + 5)['market']['changes']), {'1'})
        self.assertNotIn("five", one.brief("en", self.now + 5)["speechText"])
        self.assertNotIn("خمس", one.brief("ar", self.now + 5)["speechText"])
        mixed = market.MarketDesk()
        for offset, price in ((-600, "4000"), (-300, "4020"), (-60, "4023"), (0, "4023")):
            mixed.observe(self.quote(self.now + offset, price))
        brief = mixed.brief('en', self.now + 5)
        self.assertEqual(brief['market']['changes']['1']['direction'], 'unchanged')
        self.assertEqual(brief['market']['changes']['5']['usdText'], '3.00')
        self.assertEqual(brief['market']['changes']['10']['usdText'], '23.00')
        self.assertNotIn('unchanged', brief['speechText'])

    def test_old_provider_clock_and_backwards_receipts_are_rejected(self):
        desk = market.MarketDesk()
        desk.observe(self.quote())
        with self.assertRaises(market.QuoteUnavailable):
            desk.observe(self.quote(self.now - 10, received=self.now + 5))
        with self.assertRaises(market.QuoteUnavailable):
            desk.observe(self.quote(self.now + 1, received=self.now + 1))

    def test_poll_is_at_most_every_ten_seconds_including_failure(self):
        desk = market.MarketDesk()
        with patch.object(market, "fetch_quote", return_value=self.quote()) as fetch:
            self.assertTrue(desk.poll(self.now + 3))
            self.assertFalse(desk.poll(self.now + 12))
            self.assertFalse(desk.poll(self.now + 13))
            self.assertEqual(fetch.call_count, 2)
        with patch.object(market, "fetch_quote", side_effect=market.QuoteUnavailable("Unavailable")) as fetch:
            with self.assertRaises(market.QuoteUnavailable):
                desk.poll(self.now + 23)
            self.assertFalse(desk.poll(self.now + 24))
            self.assertFalse(desk.poll(self.now + 32))
            self.assertEqual(fetch.call_count, 1)

    def test_faster_history_is_bounded_and_retains_real_unchanged_observations(self):
        desk = market.MarketDesk()
        for index in range(120):
            desk.observe(self.quote(self.now + index * 10))
        self.assertEqual(len(desk.history), market.MAX_HISTORY)
        snap = desk.snapshot(self.now + 119 * 10 + 4)
        self.assertEqual(snap["changes"]["1"]["direction"], "unchanged")
        self.assertEqual(len(snap['observations']), market.MAX_HISTORY)
        self.assertEqual(snap['changes']['10']['direction'], 'unchanged')
        self.assertTrue(all(row['priceText'] == '4023.00' for row in snap['observations']))
        self.assertNotIn('unchanged', desk.brief('en', self.now + 119 * 10 + 4)['speechText'].lower())

    def test_whole_price_rounds_half_up_without_losing_reference_precision(self):
        for exact, rounded in (('3996.899902', '3997'), ('4023.499999', '4023'),
                               ('4023.5', '4024'), ('4024.5', '4025')):
            desk = market.MarketDesk()
            desk.observe(self.quote(price=exact))
            for language in ('ar', 'en'):
                with self.subTest(exact=exact, language=language):
                    brief = desk.brief(language, self.now + 5, reason='changed')
                    self.assertIn(rounded, brief['speechText'])
                    self.assertNotRegex(brief['speechText'], r'\d+\.\d+')
                    self.assertEqual(brief['spokenPriceUsd'], int(rounded))
                    self.assertEqual(Decimal(brief['market']['priceText']), Decimal(exact))
                    self.assertEqual(brief['spokenRounding'], 'nearest-whole-dollar-half-up')

    def test_periodic_and_changed_reasons_do_not_embellish_the_price_sentence(self):
        desk = market.MarketDesk()
        desk.observe(self.quote())
        periodic = desk.brief('en', self.now + 5)
        changed = desk.brief('en', self.now + 5, reason='changed')
        self.assertEqual((periodic['announcementReason'], changed['announcementReason']), ('periodic', 'changed'))
        self.assertEqual(periodic['speechText'], changed['speechText'])
        self.assertNotEqual(periodic['id'], changed['id'])
        for reason in ('', 'arbitrary', None, []):
            with self.assertRaises(ValueError):
                desk.brief('en', self.now + 5, reason=reason)

    def test_observation_series_is_chronological_precise_bounded_and_without_future_points(self):
        desk = market.MarketDesk()
        desk.observe(self.quote(self.now - 60, '4020.123456'))
        desk.observe(self.quote(self.now, '4023.987654321', received=self.now + 4))
        early = desk.snapshot(self.now + 2)['observations']
        self.assertEqual(len(early), 1)
        self.assertEqual(early[0]['priceText'], '4020.123456')
        rows = desk.snapshot(self.now + 4)['observations']
        self.assertEqual([row['sourceAt'] for row in rows], [(self.now - 60) * 1000, self.now * 1000])
        self.assertEqual(rows[-1]['priceText'], '4023.987654321')
        self.assertEqual(rows[-1]['receivedAt'], (self.now + 4) * 1000)
        self.assertTrue(all(row['sourceAt'] <= row['receivedAt'] <= (self.now + 4) * 1000 for row in rows))
        rows[0]['priceText'] = 'not shared mutable state'
        self.assertEqual(desk.snapshot(self.now + 4)['observations'][0]['priceText'], '4020.123456')
        self.assertEqual(desk.snapshot(self.now + 91)['observations'], [])
        self.assertEqual(market.MarketDesk().snapshot(self.now)['observations'], [])

    def test_http_get_is_fixed_bounded_and_rejects_redirect_before_body(self):
        import email.message
        class Response:
            status = 200
            def __init__(self, body, size=None):
                self.body, self.read_bound = body, None
                self.headers = email.message.Message()
                self.headers["Content-Type"] = "application/json"
                if size is not None:
                    self.headers["Content-Length"] = size
            def __enter__(self): return self
            def __exit__(self, *_): return None
            def geturl(self): return market.QUOTE_URL
            def read(self, bound):
                self.read_bound = bound
                return self.body
        import json
        body = json.dumps({"symbol": "XAU", "price": 4023.25,
            "updatedAt": datetime.fromtimestamp(self.now, timezone.utc).isoformat()}).encode()
        response = Response(body)
        with patch.object(market.urllib.request, "build_opener") as opener, patch.object(market.time, "time", return_value=self.now + 3):
            opener.return_value.open.return_value = response
            self.assertEqual(market.fetch_quote().price, Decimal("4023.25"))
            args = opener.return_value.open.call_args
            self.assertEqual(args.args[0].full_url, market.QUOTE_URL)
            self.assertEqual(args.args[0].get_method(), "GET")
            self.assertEqual(args.kwargs["timeout"], 8)
            self.assertEqual(response.read_bound, market.MAX_RESPONSE_BYTES + 1)
        for response in (Response(body, "99999999"), Response(b'{"symbol":"XAU","symbol":"XAG"}'),
                         Response(b'{"price":NaN}')):
            with patch.object(market.urllib.request, "build_opener") as opener:
                opener.return_value.open.return_value = response
                with self.assertRaises(market.QuoteUnavailable):
                    market.fetch_quote()
        with self.assertRaises(market.QuoteUnavailable):
            market._NoRedirect().redirect_request(None, None, None, None, None, "http://127.0.0.1")


if __name__ == "__main__":
    unittest.main()

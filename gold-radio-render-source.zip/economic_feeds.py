"""Fixed, attributed Google News RSS discovery for public economic reporting.

Six public two-hour searches are owner-polled. Only explicitly allowlisted
publisher domains are admitted. No article fetch, redirect following, encoded
link decoding, account, browser session, or generated summary is used. Google
RSS publication clocks are retained as supplied, not independently verified
publisher timestamps. Receipt clocks never make an old report fresh again.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
import hashlib
from html import unescape
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from news_speech import complete_prefix
from social_sources import Response, _next_delay
from source_policy import publisher_url_allowed, collection_url_allowed


MAX_BYTES = 1024 * 1024
MAX_AGE_S = 7200
MAX_ITEMS = 200
MAX_WORKERS = 4
COLLECTION_BUDGET_S = 8
POLL_SECONDS = 60
PUBLISHER_DOMAINS = frozenset({
    'reuters.com', 'apnews.com', 'bloomberg.com', 'ft.com', 'cnbc.com',
    'bbc.com', 'bbc.co.uk', 'theguardian.com', 'france24.com', 'dw.com', 'euronews.com',
    'kitco.com', 'fxstreet.com', 'investing.com', 'businessinsider.com',
    'cnn.com',
})


@dataclass(frozen=True)
class SearchFeed:
    key: str
    language: str
    query: str

    @property
    def url(self):
        arabic = self.language == 'ar'
        return 'https://news.google.com/rss/search?' + urllib.parse.urlencode({
            'q': self.query + ' when:2h', 'hl': 'ar' if arabic else 'en-US',
            'gl': 'SA' if arabic else 'US', 'ceid': 'SA:ar' if arabic else 'US:en'})


FEEDS = (
    SearchFeed('en-gold', 'en', '"gold price" OR bullion OR XAU'),
    SearchFeed('ar-gold', 'ar', 'الذهب'),
    SearchFeed('en-oil', 'en', '"oil price" OR crude OR OPEC'),
    SearchFeed('ar-oil', 'ar', 'النفط'),
    SearchFeed('en-economy', 'en', 'economy OR inflation OR "interest rates"'),
    SearchFeed('ar-economy', 'ar', 'الاقتصاد OR التضخم OR الفائدة'),
)
ALLOWED_URLS = frozenset(feed.url for feed in FEEDS)
_NON_REPORT = re.compile(r'live\s+gold\s+prices?|live\s+gold\s+charts?|'
                         r'اسعار الذهب لحظة بلحظة|سعر الذهب مباشر|sponsored promotion|'
                         r'guaranteed\s+(?:profits?|returns?)|discount code|promo code', re.I)


def _plain(value, maximum):
    if not isinstance(value, str) or len(value) > 8192:
        return ''
    value = re.sub(r'\s+', ' ', unescape(value)).strip()
    if re.search(r'[\x00-\x1f\x7f<>]', value):
        return ''
    return value if len(value) <= maximum else complete_prefix(value, maximum)


def story_id(title):
    # Exact contract of server.story_id; avoid a circular server import.
    key = re.sub(r'[^\w]+', ' ', unicodedata.normalize('NFKC', title).casefold()).strip()
    return hashlib.sha256(key.encode()).hexdigest()[:32]


def _publisher(value):
    try:
        parsed = urllib.parse.urlsplit(value)
        if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.port or
                '\\' in value or any(ord(character) < 33 for character in value)):
            return None
        host = parsed.hostname.lower()
        return host if publisher_url_allowed(value) and any(host == domain or host.endswith('.' + domain) for domain in PUBLISHER_DOMAINS) else None
    except (TypeError, ValueError):
        return None


def _item_link(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 2048:
        return None
    try:
        parsed = urllib.parse.urlsplit(value)
        if (parsed.scheme != 'https' or parsed.netloc != 'news.google.com' or parsed.fragment or
                not re.fullmatch(r'/rss/articles/[a-zA-Z0-9_-]{16,1900}', parsed.path) or
                any(ord(character) < 33 for character in value) or '\\' in value):
            return None
        query = urllib.parse.parse_qs(parsed.query, strict_parsing=True)
        if set(query) - {'oc', 'hl', 'gl', 'ceid'} or any(len(values) != 1 or len(values[0]) > 80 for values in query.values()):
            return None
        return value
    except (TypeError, ValueError):
        return None


def parse_feed(body, feed, received_s):
    if (feed not in FEEDS or type(received_s) is not int or received_s <= 0 or not isinstance(body, bytes) or
            len(body) > MAX_BYTES or b'\x00' in body or b'<!DOCTYPE' in body.upper() or b'<!ENTITY' in body.upper()):
        raise ValueError('Unsupported economic RSS response')
    document = ET.fromstring(body)
    channel = document.find('channel')
    if document.tag != 'rss' or channel is None:
        raise ValueError('Unexpected economic RSS document')
    result = []
    for item in channel.findall('item')[:MAX_ITEMS]:
        source = item.find('source')
        if source is None or list(source):
            continue
        domain = _publisher(source.get('url', ''))
        publisher = _plain(source.text or '', 100)
        link = _item_link((item.findtext('link') or '').strip())
        if not domain or not publisher or not link:
            continue
        title = _plain(item.findtext('title') or '', 1000)
        suffix = ' - ' + publisher
        if title.endswith(suffix):
            title = title[:-len(suffix)].strip()
        title = _plain(title, 400)
        if not title or len(title.split()) < 3 or _NON_REPORT.search(title):
            continue
        arabic = sum('\u0600' <= character <= '\u06ff' and character.isalpha() for character in title)
        latin = sum('a' <= character.lower() <= 'z' for character in title)
        if (feed.language == 'ar' and (arabic < 8 or arabic <= latin) or
                feed.language == 'en' and (latin < 12 or any(character.isalpha() and
                'LATIN' not in unicodedata.name(character, '') for character in title))):
            continue
        try:
            published = parsedate_to_datetime(item.findtext('pubDate') or '')
            if published.tzinfo is None:
                continue
            stamp = int(published.timestamp())
        except (ValueError, TypeError, OverflowError):
            continue
        if not 0 < stamp <= received_s or received_s - stamp > MAX_AGE_S:
            continue
        result.append({'id': story_id(title), 'title': title, 'summary': '',
            'source': publisher + ' via Google News', 'url': link, 'language': feed.language,
            'publishedAt': stamp, 'firstSeenAt': received_s, 'social': False,
            'sourceKind': 'publisher-aggregator', 'aggregator': 'Google News',
            'publisher': publisher, 'publisherDomain': domain, 'publisherSourceUrl': source.get('url'),
            'clockBasis': 'aggregator-rss-publication', 'discoveryFeed': feed.key})
    return result


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        return None


def fetch_public(url, _headers, timeout):
    if (url not in ALLOWED_URLS or not collection_url_allowed(url) or
            not isinstance(timeout, (int, float)) or not 0 < timeout <= COLLECTION_BUDGET_S):
        raise ValueError('Unsupported economic RSS URL')
    headers = {'User-Agent': 'PublicNewsReader/1.0', 'Accept-Encoding': 'identity',
               'Accept': 'application/rss+xml, application/xml, text/xml'}
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    deadline = time.monotonic() + timeout
    try:
        response = opener.open(urllib.request.Request(url, headers=headers), timeout=timeout)
    except urllib.error.HTTPError as error:
        return Response(error.code, dict(error.headers.items()), b'', url)
    with response:
        values = {key.lower(): value for key, value in response.headers.items()}
        size = values.get('content-length')
        if (values.get('content-encoding', 'identity') != 'identity' or
                size and (not size.isdecimal() or int(size) > MAX_BYTES)):
            raise ValueError('Economic RSS body limit')
        parts, total = [], 0
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Economic RSS deadline')
            socket = getattr(getattr(response.fp, 'raw', None), '_sock', None)
            if socket is not None:
                socket.settimeout(max(.1, deadline - time.monotonic()))
            block = response.read1(min(65536, MAX_BYTES + 1 - total))
            if not block:
                break
            total += len(block)
            if total > MAX_BYTES:
                raise ValueError('Economic RSS body limit')
            parts.append(block)
        return Response(response.status, values, b''.join(parts), response.url)


class EconomicFeedCollector:
    def __init__(self, fetcher=None):
        self._fetcher = fetcher or fetch_public
        self._pool = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix='economic-rss')
        self._lock, self._collect_lock = threading.RLock(), threading.Lock()
        self._pending, self._receipts = {}, {}
        self._states = {feed.key: {'key': feed.key, 'language': feed.language, 'status': 'starting',
            'checkedAt': 0, 'lastSuccessAt': 0, 'nextCheckAt': 0, 'accepted': 0,
            'httpStatus': None, 'failures': 0} for feed in FEEDS}

    def status(self):
        with self._lock:
            sources = [dict(self._states[feed.key]) for feed in FEEDS]
            ready = sum(source['status'] == 'ready' for source in sources)
            return {'status': 'ready' if ready else 'starting' if any(source['status'] == 'starting' for source in sources) else 'unavailable',
                    'checkedAt': max(source['checkedAt'] for source in sources),
                    'sourceCount': len(FEEDS), 'readySources': ready, 'sources': sources,
                    'transport': 'Fixed public Google News RSS; allowlisted publishers; no article fetch',
                    'publicationWindowSeconds': MAX_AGE_S, 'publisherDomainCount': len(PUBLISHER_DOMAINS)}

    def _request(self, feed, now_s, real_clock, deadline):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Economic RSS deadline')
        response = self._fetcher(feed.url, {}, min(COLLECTION_BUDGET_S, remaining))
        if (not isinstance(response, Response) or response.url != feed.url or not isinstance(response.body, bytes) or
                len(response.body) > MAX_BYTES or time.monotonic() > deadline):
            raise ValueError('Invalid economic RSS response')
        headers = {key.lower(): value for key, value in response.headers.items()}
        if response.status == 200:
            if not any(kind in headers.get('content-type', '').lower() for kind in ('application/rss+xml', 'application/xml', 'text/xml')):
                raise ValueError('Unexpected economic RSS type')
            rows = parse_feed(response.body, feed, int(time.time()) if real_clock else now_s)
        else:
            rows = []
        return response.status, headers, rows

    def collect(self, now_s=None):
        real_clock = now_s is None
        now_s = int(time.time()) if real_clock else now_s
        if type(now_s) is not int or now_s <= 0:
            raise ValueError('A valid economic RSS clock is required')
        if not self._collect_lock.acquire(blocking=False):
            return []
        try:
            deadline, result = time.monotonic() + COLLECTION_BUDGET_S, []
            with self._lock:
                self._pending = {key: future for key, future in self._pending.items() if not future.done()}
                due = [feed for feed in FEEDS if feed.key not in self._pending and
                       now_s * 1000 >= self._states[feed.key]['nextCheckAt']]
                due.sort(key=lambda feed: self._states[feed.key]['nextCheckAt'])
                jobs = {}
                for feed in due[:max(0, MAX_WORKERS - len(self._pending))]:
                    self._states[feed.key]['checkedAt'] = now_s * 1000
                    future = self._pool.submit(self._request, feed, now_s, real_clock, deadline)
                    self._pending[feed.key] = future
                    jobs[future] = feed
            done, _ = wait(jobs, timeout=max(0, deadline - time.monotonic()))
            finished = int(time.time()) if real_clock else now_s
            with self._lock:
                for future, feed in jobs.items():
                    state, status, headers = self._states[feed.key], None, {}
                    try:
                        if future not in done:
                            future.cancel()
                            raise TimeoutError('Economic RSS deadline')
                        status, headers, rows = future.result()
                        if status != 200:
                            raise ValueError('Economic RSS unavailable')
                        state.update(status='ready', lastSuccessAt=finished * 1000, httpStatus=status, failures=0,
                                     nextCheckAt=(finished + _next_delay(headers, finished, status=status)) * 1000,
                                     accepted=len(rows))
                        for row in rows:
                            old = self._receipts.get(row['id'])
                            if old:
                                row['firstSeenAt'] = min(old[0], row['firstSeenAt'])
                                row['publishedAt'] = min(old[1], row['publishedAt'])
                            self._receipts[row['id']] = (row['firstSeenAt'], row['publishedAt'])
                            if finished - row['publishedAt'] <= MAX_AGE_S:
                                result.append(row)
                    except Exception:
                        failures = state['failures'] + 1
                        state.update(status='access_denied' if status in (401, 403) else 'rate_limited' if status == 429 else 'unavailable',
                            httpStatus=status, failures=failures, accepted=0,
                            nextCheckAt=(finished + _next_delay(headers, finished, failures, status)) * 1000)
                    if future.done():
                        self._pending.pop(feed.key, None)
                self._receipts = dict(sorted(((key, value) for key, value in self._receipts.items()
                    if finished - value[1] <= 86400), key=lambda pair: pair[1][0], reverse=True)[:4000])
            return result
        finally:
            self._collect_lock.release()

import math
import unittest

from airtime_mix import AirtimeMix, MAX_INTERVALS, WINDOW_MS


class AirtimeMixTests(unittest.TestCase):
    def test_elapsed_only_metrics_and_future_plans_are_separate(self):
        mix = AirtimeMix(0)
        mix.commit(10_000, 30_000, 'news')
        before = mix.snapshot(5_000)
        self.assertEqual((before['speechSeconds'], before['musicSeconds']), (0, 5))
        self.assertEqual((before['plannedSpeechSeconds'], before['plannedMusicSeconds']), (20, 5))
        during = mix.snapshot(15_000)
        self.assertEqual((during['speechSeconds'], during['musicSeconds']), (5, 10))
        self.assertEqual((during['plannedSpeechSeconds'], during['plannedMusicSeconds']), (15, 0))
        after = mix.snapshot(40_000)
        self.assertEqual((after['speechSeconds'], after['musicSeconds']), (20, 20))
        self.assertEqual(after['spokenPercent'], 50)
        self.assertEqual(after['musicPercent'], 50)
        self.assertEqual(after['elapsedSeconds'], 40)

    def test_cold_prefetch_counts_as_music_and_target_is_not_fabricated(self):
        mix = AirtimeMix(0)
        start = mix.next_start([], 0, 4)
        self.assertEqual(start, 6000)
        mix.commit(start, start + 4000, 'podcast')
        metrics = mix.snapshot(10_000)
        self.assertEqual(metrics['musicPercent'], 60)
        self.assertEqual(metrics['spokenPercent'], 40)
        self.assertEqual(metrics['targetMusicPercent'], 20)
        self.assertEqual(metrics['speechShortfallSeconds'], 4)

    def test_music_debt_catches_up_without_a_second_optional_break(self):
        mix = AirtimeMix(0)
        mix.commit(40_000, 60_000, 'news')
        start = mix.next_start([{'startsAt': 40_000, 'endsAt': 60_000}], 45_000, 40)
        self.assertEqual(start, 60_000)
        mix.commit(start, start + 40_000, 'podcast')
        self.assertEqual(mix.snapshot(100_000)['musicPercent'], 40)

    def test_only_played_speech_earns_music_before_the_next_complete_clip(self):
        mix = AirtimeMix(0)
        first = mix.next_start([], 0, 40)
        self.assertEqual(first, 6000)
        mix.commit(first, first + 40_000, 'news')
        queue = [{'startsAt': first, 'endsAt': first + 40_000}]
        second = mix.next_start(queue, 20_000, 20)
        self.assertEqual(second, 50_000)
        self.assertEqual(mix.next_start(queue, 20_000, 90), second,
                         'A longer future clip cannot earn an advance music break')
        mix.commit(second, second + 20_000, 'podcast')
        at_start = mix.snapshot(second)
        self.assertEqual((at_start['speechSeconds'], at_start['musicSeconds']), (40, 10))
        self.assertEqual((at_start['spokenPercent'], at_start['musicPercent']), (80, 20))
        metrics = mix.snapshot(70_000)
        self.assertEqual((metrics['speechSeconds'], metrics['musicSeconds']), (60, 10))
        self.assertLess(metrics['musicPercent'], 20)
        fractional = AirtimeMix(0)
        fractional.commit(0, 1001, 'news')
        boundary = fractional.next_start([], 1001, 20, prefetch_ms=0)
        self.assertEqual(boundary, 1251, 'Fractional ideal budgets must round below the cap')
        self.assertLessEqual(fractional.snapshot(boundary)['musicPercent'], 20)

    def test_late_producer_prefetch_cannot_overlap_or_erase_the_real_gap(self):
        mix = AirtimeMix(0)
        mix.commit(0, 20_000, 'news')
        start = mix.next_start([], 50_000, 10)
        self.assertEqual(start, 56_000)
        mix.commit(start, 66_000, 'podcast')
        metrics = mix.snapshot(66_000)
        self.assertEqual(metrics['musicSeconds'], 36)
        self.assertGreater(metrics['musicPercent'], 20)

    def test_mixed_complete_clip_lengths_sustain_target_across_multiple_windows(self):
        mix = AirtimeMix(0)
        queue, end = [], 0
        for index in range(45):
            duration = (40, 20, 50)[index % 3]
            start = mix.next_start(queue, max(0, end - 30_000), duration)
            self.assertGreaterEqual(start, end)
            end = start + duration * 1000
            mix.commit(start, end, 'podcast')
            queue = [{'startsAt': start, 'endsAt': end}]
            if index:
                at_start = mix.snapshot(start)
                self.assertLessEqual(at_start['musicPercent'], 20)
                self.assertGreaterEqual(at_start['spokenPercent'], 80)
                during = mix.snapshot(start + duration * 500)
                self.assertLessEqual(during['musicPercent'], 20)
            metrics = mix.snapshot(end)
            self.assertLessEqual(metrics['musicPercent'], 20)
            self.assertGreaterEqual(metrics['spokenPercent'], 80)
            self.assertEqual(metrics['speechSeconds'] + metrics['musicSeconds'], metrics['elapsedSeconds'])
        self.assertGreater(end, WINDOW_MS * 3)

    def test_window_clips_partial_intervals_and_never_counts_future_words(self):
        mix = AirtimeMix(0)
        mix.commit(0, 80_000, 'news')
        mix.commit(600_000, 680_000, 'podcast')
        metrics = mix.snapshot(650_000)
        self.assertEqual(metrics['elapsedSeconds'], 600)
        self.assertEqual(metrics['speechSeconds'], 80)
        self.assertEqual(metrics['musicSeconds'], 520)
        self.assertEqual(metrics['plannedSpeechSeconds'], 30)
        self.assertEqual((metrics['fromAt'], metrics['throughAt']), (50_000, 650_000))

    def test_cumulative_music_resumes_from_same_position_after_speech(self):
        mix = AirtimeMix(1000)
        mix.commit(11_000, 31_000, 'news')
        self.assertEqual(mix.total_music_ms(6000), 5000)
        self.assertEqual(mix.total_music_ms(11_000), 10_000)
        self.assertEqual(mix.total_music_ms(21_000), 10_000)
        self.assertEqual(mix.total_music_ms(31_000), 10_000)
        self.assertEqual(mix.total_music_ms(36_000), 15_000)

    def test_cumulative_clock_retains_old_speech_after_rolling_prune(self):
        mix = AirtimeMix(0)
        mix.commit(10_000, 30_000, 'news')
        mix.commit(900_000, 920_000, 'podcast')
        self.assertEqual(mix.total_music_ms(800_000), 780_000)
        self.assertEqual(len(mix.intervals), 1)
        self.assertEqual(mix.snapshot(800_000)['speechSeconds'], 0)
        self.assertEqual(mix.total_music_ms(910_000), 880_000)
        self.assertEqual(mix.total_music_ms(930_000), 890_000)

    def test_scheduling_projection_does_not_retire_observed_history_early(self):
        mix = AirtimeMix(0)
        mix.commit(0, 90_000, 'news')
        mix.commit(580_000, 670_000, 'podcast')
        start = mix.next_start([{'startsAt': 580_000, 'endsAt': 670_000}], 590_000, 80)
        self.assertGreaterEqual(start, 670_000)
        self.assertEqual(mix.snapshot(590_000)['speechSeconds'], 100)
        self.assertEqual(mix.total_music_ms(590_000), 490_000)

    def test_independent_channels_do_not_share_debt_or_music_clock(self):
        arabic, english = AirtimeMix(0), AirtimeMix(0)
        arabic.commit(6000, 16_000, 'news')
        self.assertEqual(arabic.total_music_ms(20_000), 10_000)
        self.assertEqual(english.total_music_ms(20_000), 20_000)
        self.assertNotEqual(arabic.snapshot(20_000)['spokenPercent'], english.snapshot(20_000)['spokenPercent'])

    def test_bounded_journal_retires_past_but_not_future_audio(self):
        mix = AirtimeMix(0)
        for index in range(2000):
            start = index * 1000
            mix.snapshot(start)
            mix.commit(start, start + 500, 'news' if index % 2 else 'podcast')
        self.assertLess(len(mix.intervals), MAX_INTERVALS)
        mix.commit(2_010_000, 2_020_000, 'podcast')
        mix.snapshot(2_000_000)
        self.assertEqual(mix.intervals[-1][1], 2_020_000)
        self.assertEqual(mix.total_music_ms(2_000_000), 1_000_000)

    def test_invalid_or_overlapping_intervals_fail_before_mutating(self):
        mix = AirtimeMix(0)
        mix.commit(6000, 16_000, 'news')
        for args in ((10_000, 20_000, 'podcast'), (16_000, 16_000, 'news'),
                     (16_000, 107_000, 'news'), (16_000, 20_000, 'arbitrary'),
                     (16_000, 20_000, [])):
            with self.assertRaises(ValueError):
                mix.commit(*args)
        self.assertEqual(mix.intervals, [(6000, 16_000, 'news')])
        for duration in (True, 0, -1, math.nan, math.inf, 91):
            with self.assertRaises(ValueError):
                mix.next_start([], 1000, duration)
        for queue in ('not a queue', [{'endsAt': True}], [{'startsAt': 20, 'endsAt': 10}]):
            with self.assertRaises(ValueError):
                mix.next_start(queue, 1000, 5)
        with self.assertRaises(ValueError):
            mix.snapshot(-1)

    def test_empty_window_does_not_claim_measured_eighty_percent(self):
        empty = AirtimeMix(1000).snapshot(1000)
        self.assertIsNone(empty['spokenPercent'])
        self.assertIsNone(empty['musicPercent'])
        self.assertEqual(empty['elapsedSeconds'], 0)

    def test_priority_insert_preserves_on_air_speech_and_shifts_whole_future_items(self):
        mix = AirtimeMix(0)
        mix.commit(0, 40_000, 'news')
        mix.commit(40_000, 70_000, 'podcast')
        mix.commit(75_000, 95_000, 'news')
        before = mix.snapshot(15_000)
        music_clock = mix.total_music_ms(15_000)
        delta = mix.insert_before_future(40_000, 45_000, 'market', 15_000)
        self.assertEqual(delta, 5000)
        self.assertEqual(mix.intervals, [(0, 40_000, 'news'), (40_000, 45_000, 'market'),
                                        (45_000, 75_000, 'podcast'), (80_000, 100_000, 'news')])
        self.assertEqual(mix.total_music_ms(15_000), music_clock)
        after = mix.snapshot(15_000)
        for key in ('elapsedSeconds', 'speechSeconds', 'musicSeconds', 'newsSeconds', 'podcastSeconds'):
            self.assertEqual(after[key], before[key])
        self.assertEqual(after['plannedSpeechSeconds'], before['plannedSpeechSeconds'] + 5)
        self.assertEqual(after['plannedMusicSeconds'], before['plannedMusicSeconds'])
        self.assertEqual(mix._last_end_ms, 100_000)
        mix.commit(100_000, 110_000, 'podcast')
        self.assertEqual(mix._last_end_ms, 110_000)

    def test_priority_insert_between_adjacent_same_kind_clips_uses_real_boundaries(self):
        mix = AirtimeMix(0)
        mix.commit(0, 30_000, 'news')
        mix.commit(30_000, 60_000, 'news')
        self.assertEqual(len(mix.intervals), 2)
        mix.insert_before_future(30_000, 34_000, 'analysis', 10_000)
        self.assertEqual(mix.intervals, [(0, 30_000, 'news'), (30_000, 34_000, 'analysis'),
                                        (34_000, 64_000, 'news')])
        self.assertEqual(mix.snapshot(10_000)['speechSeconds'], 10)

    def test_priority_insert_after_retirement_preserves_cumulative_music_offset(self):
        mix = AirtimeMix(0)
        mix.commit(10_000, 30_000, 'news')
        mix.commit(800_000, 820_000, 'podcast')
        before = mix.total_music_ms(750_000)
        self.assertEqual(before, 730_000)
        self.assertEqual(len(mix.intervals), 1)
        mix.insert_before_future(760_000, 765_000, 'market', 750_000)
        self.assertEqual(mix.total_music_ms(750_000), before)
        self.assertEqual(mix.intervals, [(760_000, 765_000, 'market'), (805_000, 825_000, 'podcast')])
        self.assertEqual(mix.total_music_ms(762_000), 740_000)
        self.assertEqual(mix.total_music_ms(765_000), 740_000)
        self.assertEqual(mix.total_music_ms(800_000), 775_000)

    def test_priority_insert_in_empty_or_finished_schedule_can_be_followed_by_commit(self):
        mix = AirtimeMix(0)
        self.assertEqual(mix.insert_before_future(6000, 9000, 'market', 0), 3000)
        self.assertEqual(mix.intervals, [(6000, 9000, 'market')])
        mix.commit(10_000, 20_000, 'news')
        self.assertEqual(mix.total_music_ms(7000), 6000)
        self.assertEqual(mix.insert_before_future(36_000, 40_000, 'analysis', 30_000), 4000)
        self.assertEqual(mix._last_end_ms, 40_000)
        mix.commit(40_000, 45_000, 'podcast')

    def test_invalid_priority_insert_cannot_mutate_journal_or_retired_offset(self):
        mix = AirtimeMix(0)
        mix.commit(0, 40_000, 'news')
        mix.commit(40_000, 70_000, 'podcast')
        original = list(mix.intervals)
        state = (mix._last_end_ms, mix._retired_spoken_ms, mix._retired_through_ms)
        for start, end, kind, now in ((9000, 12_000, 'market', 10_000),
                                     (10_000, 12_000, 'market', 10_000),
                                     (20_000, 25_000, 'market', 10_000),
                                     (50_000, 54_000, 'analysis', 10_000),
                                     (40_000, 40_000, 'market', 10_000),
                                     (40_000, 131_000, 'market', 10_000),
                                     (40_000, 45_000, 'unknown', 10_000)):
            with self.subTest(start=start, kind=kind), self.assertRaises(ValueError):
                mix.insert_before_future(start, end, kind, now)
            self.assertEqual(mix.intervals, original)
            self.assertEqual((mix._last_end_ms, mix._retired_spoken_ms, mix._retired_through_ms), state)

    def test_elapsed_kind_shares_distinguish_reports_from_recorded_education(self):
        mix = AirtimeMix(0)
        mix.commit(10_000, 30_000, 'news')
        mix.commit(40_000, 50_000, 'podcast')
        mix.commit(60_000, 65_000, 'analysis')
        mix.commit(80_000, 90_000, 'social')
        before = mix.snapshot(25_000)
        self.assertEqual((before['newsSeconds'], before['podcastSeconds'], before['otherSpeechSeconds']), (15, 0, 0))
        self.assertEqual(before['newsShareOfSpeechPercent'], 100)
        current = mix.snapshot(65_000)
        self.assertEqual((current['newsSeconds'], current['podcastSeconds'], current['otherSpeechSeconds']), (20, 10, 5))
        self.assertEqual(current['newsShareOfSpeechPercent'], 57.14)
        self.assertEqual(current['newsShareTargetPercent'], 60)
        self.assertEqual(current['newsShareShortfallSeconds'], 2.5)
        self.assertEqual(sum(current[key] for key in ('newsSeconds', 'podcastSeconds', 'otherSpeechSeconds')),
                         current['speechSeconds'])

    def test_social_and_current_report_context_count_but_generic_discussions_do_not(self):
        mix = AirtimeMix(0)
        mix.commit(0, 10_000, 'social')
        mix.commit(10_000, 20_000, 'news-context')
        mix.commit(20_000, 30_000, 'discussion')
        metrics = mix.snapshot(30_000)
        self.assertEqual((metrics['newsSeconds'], metrics['podcastSeconds'], metrics['otherSpeechSeconds']), (20, 0, 10))
        self.assertEqual(metrics['newsShareOfSpeechPercent'], 66.67)

    def test_no_news_grace_can_admit_a_recorded_podcast(self):
        mix = AirtimeMix(0)
        self.assertFalse(mix.can_schedule_podcast(1, 0))
        self.assertFalse(mix.can_schedule_podcast(90, 0))
        self.assertEqual(mix.intervals, [])
        self.assertIsNone(mix.snapshot(0)['newsShareOfSpeechPercent'])
        self.assertEqual(mix.snapshot(0)['newsShareShortfallSeconds'], 0)
        mix.commit(0, 30_000, 'analysis')
        self.assertFalse(mix.can_schedule_podcast(1, 30_000))
        self.assertEqual(mix.snapshot(30_000)['newsShareShortfallSeconds'], 45)

    def test_explicit_quiet_escape_allows_recorded_speech_without_inventing_news(self):
        mix = AirtimeMix(0)
        self.assertFalse(mix.can_schedule_podcast(30, 0))
        self.assertTrue(mix.can_schedule_podcast(30, 0, quiet=True))
        self.assertEqual(mix.intervals, [])
        start = mix.next_start([], 0, 30)
        mix.commit(start, start + 30_000, 'podcast')
        metrics = mix.snapshot(start + 30_000)
        self.assertEqual(metrics['newsSeconds'], 0)
        self.assertEqual(metrics['podcastSeconds'], 30)
        self.assertEqual(metrics['newsShareOfSpeechPercent'], 0)
        self.assertEqual(metrics['newsShareTargetPercent'], 60)
        self.assertGreater(metrics['newsShareShortfallSeconds'], 0)
        self.assertFalse(mix.can_schedule_podcast(30, start + 30_000))

    def test_quiet_escape_preserves_clock_duration_and_owner_flag_validation(self):
        mix = AirtimeMix(0)
        mix.commit(0, 20_000, 'news')
        for flag in ('true', 1, None, [], {}):
            with self.assertRaises(ValueError):
                mix.can_schedule_podcast(30, 1000, quiet=flag)
        with self.assertRaises(ValueError):
            mix.can_schedule_podcast(91, 1000, quiet=True)
        with self.assertRaises(ValueError):
            mix.can_schedule_podcast(30, 1000, start_ms=10_000, quiet=True)

    def test_real_programme_library_keeps_both_quiet_channels_spoken_for_45_minutes(self):
        # A deterministic scheduling integration, not a wall-clock or TTS-speed
        # benchmark. Use the actual bilingual catalogue, full turns, role speed,
        # queued-ahead preparation and the configured archive replay cooldown.
        from station_programme import ProgrammeLibrary, EPISODES, REPLAY_COOLDOWN_S
        base = 1_700_000_000_000
        horizon = base + 45 * 60 * 1000
        for language, characters_per_second in (('en', 14), ('ar', 12)):
            with self.subTest(language=language):
                mix, library = AirtimeMix(base), ProgrammeLibrary()
                queue, producer, last_end = [], base, base
                visits, completed, current_episode = set(), {}, None
                expected_turn, replays, warm_samples, longest_gap = 0, 0, 0, 0
                while producer < horizon:
                    # The real producer stops adding clips once it has about a
                    # minute in hand, then resumes while that complete audio airs.
                    producer = max(producer, last_end - 60_000)
                    if producer >= horizon:
                        break
                    job = library.candidate(language, producer // 1000)
                    self.assertIsNotNone(job, 'The real archive must not exhaust into a long music-only cooldown')
                    programme = job['programme']
                    episode, turn = programme['episodeId'], programme['turnIndex']
                    if current_episode is None:
                        self.assertEqual(turn, 0)
                        current_episode, expected_turn = episode, 0
                        if programme['repeat']:
                            replays += 1
                            self.assertEqual(len(visits), len(EPISODES), 'Finish unplayed episodes before replay')
                            self.assertGreaterEqual(producer // 1000 - completed[episode], REPLAY_COOLDOWN_S)
                        visits.add(episode)
                    self.assertEqual((episode, turn), (current_episode, expected_turn))
                    speed = 1.6 if programme['speakerRole'] == 'analyst' else 1.0
                    duration = round(len(job['speechText']) / characters_per_second / speed, 3)
                    self.assertTrue(0 < duration <= 90)
                    prepared = producer + 2200
                    start = mix.next_start(queue, prepared, duration)
                    self.assertTrue(mix.can_schedule_podcast(duration, prepared, start_ms=start, quiet=True))
                    end = start + round(duration * 1000)
                    longest_gap = max(longest_gap, start - last_end)
                    mix.commit(start, end, 'podcast')
                    self.assertTrue(library.consume(job, prepared // 1000))
                    expected_turn += 1
                    if expected_turn == programme['turnCount']:
                        completed[episode] = prepared // 1000
                        current_episode, expected_turn = None, 0
                    queue = [row for row in queue if row['endsAt'] > prepared]
                    queue.append({'startsAt': start, 'endsAt': end})
                    producer, last_end = prepared, end
                    metrics = mix.snapshot(producer)
                    if producer >= base + WINDOW_MS:
                        warm_samples += 1
                        self.assertLessEqual(metrics['musicPercent'], 20)
                        self.assertGreaterEqual(metrics['spokenPercent'], 80)
                    self.assertEqual(metrics['newsSeconds'], 0, 'Education must never become fake news credit')
                    self.assertEqual(metrics['podcastSeconds'], metrics['speechSeconds'])
                self.assertGreater(warm_samples, 20)
                self.assertGreater(replays, 0, 'The test must cross a real catalogue replay, not just startup')
                self.assertLess(longest_gap, 60_000, 'No extended archive-exhaustion music gap is allowed')
                final = mix.snapshot(horizon)
                self.assertEqual(final['elapsedSeconds'], 600)
                self.assertLessEqual(final['musicPercent'], 20)
                self.assertEqual(final['newsShareOfSpeechPercent'], 0)
                self.assertGreater(final['newsShareShortfallSeconds'], 0)

    def test_news_majority_gate_uses_complete_candidate_without_committing_it(self):
        mix = AirtimeMix(0)
        mix.commit(0, 60_000, 'news')
        self.assertTrue(mix.can_schedule_podcast(40, 50_000))
        self.assertFalse(mix.can_schedule_podcast(40.001, 50_000))
        self.assertTrue(mix.can_schedule_podcast(40, 50_000, start_ms=60_000))
        self.assertTrue(mix.can_schedule_podcast(49, 50_000, min_news_share=.55))
        self.assertFalse(mix.can_schedule_podcast(50, 50_000, min_news_share=.55))
        self.assertEqual(mix.intervals, [(0, 60_000, 'news')])
        self.assertEqual(mix.snapshot(50_000)['newsSeconds'], 50)

    def test_existing_podcasts_and_other_speech_spend_the_same_news_budget(self):
        mix = AirtimeMix(0)
        mix.commit(0, 60_000, 'news')
        mix.commit(60_000, 80_000, 'podcast')
        self.assertTrue(mix.can_schedule_podcast(20, 80_000, start_ms=80_000))
        self.assertFalse(mix.can_schedule_podcast(20.001, 80_000, start_ms=80_000))
        mix.commit(80_000, 90_000, 'market')
        self.assertTrue(mix.can_schedule_podcast(10, 90_000, start_ms=90_000))
        self.assertFalse(mix.can_schedule_podcast(10.001, 90_000, start_ms=90_000))

    def test_queued_reports_earn_future_credit_but_not_elapsed_news_metrics(self):
        mix = AirtimeMix(0)
        mix.commit(100_000, 160_000, 'news')
        self.assertTrue(mix.can_schedule_podcast(40, 0, start_ms=160_000))
        before = mix.snapshot(50_000)
        self.assertEqual(before['newsSeconds'], 0)
        self.assertIsNone(before['newsShareOfSpeechPercent'])

    def test_majority_gate_expires_old_news_at_the_full_candidate_end(self):
        mix = AirtimeMix(0)
        mix.commit(0, 60_000, 'news')
        self.assertTrue(mix.can_schedule_podcast(20, 590_000))
        self.assertFalse(mix.can_schedule_podcast(40, 590_000))
        self.assertFalse(mix.can_schedule_podcast(1, 590_000, start_ms=670_000))

    def test_majority_gate_rejects_invalid_thresholds_and_earlier_starts(self):
        mix = AirtimeMix(0)
        mix.commit(0, 60_000, 'news')
        for share in (True, 0, .5, -.1, 1.1, math.nan, math.inf, '0.6'):
            with self.assertRaises(ValueError):
                mix.can_schedule_podcast(10, 1000, min_news_share=share)
        for start in (999, 59_999, True):
            with self.assertRaises(ValueError):
                mix.can_schedule_podcast(10, 1000, start_ms=start)


if __name__ == '__main__':
    unittest.main()

import math
import unittest

from airtime_mix import AirtimeMix, MAX_INTERVALS, WINDOW_MS


class AirtimeMixTests(unittest.TestCase):
    def test_elapsed_only_metrics_and_future_plans_are_separate(self):
        mix = AirtimeMix(0)
        mix.commit(10_000, 30_000, 'news')
        before = mix.snapshot(5_000)
        self.assertEqual((before['speechSeconds'], before['musicSeconds']), (0, 5))
        self.assertEqual((before['plannedSpeechSeconds'], before['plannedMusicSeconds']), (20, 5))
        during = mix.snapshot(15_000)
        self.assertEqual((during['speechSeconds'], during['musicSeconds']), (5, 10))
        self.assertEqual((during['plannedSpeechSeconds'], during['plannedMusicSeconds']), (15, 0))
        after = mix.snapshot(40_000)
        self.assertEqual((after['speechSeconds'], after['musicSeconds']), (20, 20))
        self.assertEqual(after['spokenPercent'], 50)
        self.assertEqual(after['musicPercent'], 50)
        self.assertEqual(after['elapsedSeconds'], 40)

    def test_cold_prefetch_counts_as_music_and_target_is_not_fabricated(self):
        mix = AirtimeMix(0)
        start = mix.next_start([], 0, 4)
        self.assertEqual(start, 6000)
        mix.commit(start, start + 4000, 'podcast')
        metrics = mix.snapshot(10_000)
        self.assertEqual(metrics['musicPercent'], 60)
        self.assertEqual(metrics['spokenPercent'], 40)
        self.assertEqual(metrics['targetMusicPercent'], 20)
        self.assertEqual(metrics['speechShortfallSeconds'], 4)

    def test_music_debt_catches_up_without_a_second_optional_break(self):
        mix = AirtimeMix(0)
        mix.commit(40_000, 60_000, 'news')
        start = mix.next_start([{'startsAt': 40_000, 'endsAt': 60_000}], 45_000, 40)
        self.assertEqual(start, 60_000)
        mix.commit(start, start + 40_000, 'podcast')
        self.assertEqual(mix.snapshot(100_000)['musicPercent'], 40)

    def test_complete_duration_drives_quarter_music_budget_instead_of_fixed_breaks(self):
        mix = AirtimeMix(0)
        first = mix.next_start([], 0, 40)
        self.assertEqual(first, 10_000)
        mix.commit(first, first + 40_000, 'news')
        second = mix.next_start([{'startsAt': first, 'endsAt': first + 40_000}], 20_000, 20)
        self.assertEqual(second, 55_000)
        mix.commit(second, second + 20_000, 'podcast')
        metrics = mix.snapshot(75_000)
        self.assertEqual((metrics['speechSeconds'], metrics['musicSeconds']), (60, 15))
        self.assertEqual((metrics['spokenPercent'], metrics['musicPercent']), (80, 20))

    def test_late_producer_prefetch_cannot_overlap_or_erase_the_real_gap(self):
        mix = AirtimeMix(0)
        mix.commit(0, 20_000, 'news')
        start = mix.next_start([], 50_000, 10)
        self.assertEqual(start, 56_000)
        mix.commit(start, 66_000, 'podcast')
        metrics = mix.snapshot(66_000)
        self.assertEqual(metrics['musicSeconds'], 36)
        self.assertGreater(metrics['musicPercent'], 20)

    def test_mixed_complete_clip_lengths_sustain_target_across_multiple_windows(self):
        mix = AirtimeMix(0)
        queue, end = [], 0
        for index in range(45):
            duration = (40, 20, 50)[index % 3]
            start = mix.next_start(queue, max(0, end - 30_000), duration)
            self.assertGreaterEqual(start, end)
            end = start + duration * 1000
            mix.commit(start, end, 'podcast')
            queue = [{'startsAt': start, 'endsAt': end}]
            metrics = mix.snapshot(end)
            self.assertAlmostEqual(metrics['musicPercent'], 20, delta=.02)
            self.assertAlmostEqual(metrics['spokenPercent'], 80, delta=.02)
            self.assertEqual(metrics['speechSeconds'] + metrics['musicSeconds'], metrics['elapsedSeconds'])
        self.assertGreater(end, WINDOW_MS * 3)

    def test_window_clips_partial_intervals_and_never_counts_future_words(self):
        mix = AirtimeMix(0)
        mix.commit(0, 80_000, 'news')
        mix.commit(600_000, 680_000, 'podcast')
        metrics = mix.snapshot(650_000)
        self.assertEqual(metrics['elapsedSeconds'], 600)
        self.assertEqual(metrics['speechSeconds'], 80)
        self.assertEqual(metrics['musicSeconds'], 520)
        self.assertEqual(metrics['plannedSpeechSeconds'], 30)
        self.assertEqual((metrics['fromAt'], metrics['throughAt']), (50_000, 650_000))

    def test_cumulative_music_resumes_from_same_position_after_speech(self):
        mix = AirtimeMix(1000)
        mix.commit(11_000, 31_000, 'news')
        self.assertEqual(mix.total_music_ms(6000), 5000)
        self.assertEqual(mix.total_music_ms(11_000), 10_000)
        self.assertEqual(mix.total_music_ms(21_000), 10_000)
        self.assertEqual(mix.total_music_ms(31_000), 10_000)
        self.assertEqual(mix.total_music_ms(36_000), 15_000)

    def test_cumulative_clock_retains_old_speech_after_rolling_prune(self):
        mix = AirtimeMix(0)
        mix.commit(10_000, 30_000, 'news')
        mix.commit(900_000, 920_000, 'podcast')
        self.assertEqual(mix.total_music_ms(800_000), 780_000)
        self.assertEqual(len(mix.intervals), 1)
        self.assertEqual(mix.snapshot(800_000)['speechSeconds'], 0)
        self.assertEqual(mix.total_music_ms(910_000), 880_000)
        self.assertEqual(mix.total_music_ms(930_000), 890_000)

    def test_scheduling_projection_does_not_retire_observed_history_early(self):
        mix = AirtimeMix(0)
        mix.commit(0, 90_000, 'news')
        mix.commit(580_000, 670_000, 'podcast')
        start = mix.next_start([{'startsAt': 580_000, 'endsAt': 670_000}], 590_000, 80)
        self.assertGreaterEqual(start, 670_000)
        self.assertEqual(mix.snapshot(590_000)['speechSeconds'], 100)
        self.assertEqual(mix.total_music_ms(590_000), 490_000)

    def test_independent_channels_do_not_share_debt_or_music_clock(self):
        arabic, english = AirtimeMix(0), AirtimeMix(0)
        arabic.commit(6000, 16_000, 'news')
        self.assertEqual(arabic.total_music_ms(20_000), 10_000)
        self.assertEqual(english.total_music_ms(20_000), 20_000)
        self.assertNotEqual(arabic.snapshot(20_000)['spokenPercent'], english.snapshot(20_000)['spokenPercent'])

    def test_bounded_journal_retires_past_but_not_future_audio(self):
        mix = AirtimeMix(0)
        for index in range(2000):
            start = index * 1000
            mix.snapshot(start)
            mix.commit(start, start + 500, 'news' if index % 2 else 'podcast')
        self.assertLess(len(mix.intervals), MAX_INTERVALS)
        mix.commit(2_010_000, 2_020_000, 'podcast')
        mix.snapshot(2_000_000)
        self.assertEqual(mix.intervals[-1][1], 2_020_000)
        self.assertEqual(mix.total_music_ms(2_000_000), 1_000_000)

    def test_invalid_or_overlapping_intervals_fail_before_mutating(self):
        mix = AirtimeMix(0)
        mix.commit(6000, 16_000, 'news')
        for args in ((10_000, 20_000, 'podcast'), (16_000, 16_000, 'news'),
                     (16_000, 107_000, 'news'), (16_000, 20_000, 'arbitrary'),
                     (16_000, 20_000, [])):
            with self.assertRaises(ValueError):
                mix.commit(*args)
        self.assertEqual(mix.intervals, [(6000, 16_000, 'news')])
        for duration in (True, 0, -1, math.nan, math.inf, 91):
            with self.assertRaises(ValueError):
                mix.next_start([], 1000, duration)
        for queue in ('not a queue', [{'endsAt': True}], [{'startsAt': 20, 'endsAt': 10}]):
            with self.assertRaises(ValueError):
                mix.next_start(queue, 1000, 5)
        with self.assertRaises(ValueError):
            mix.snapshot(-1)

    def test_empty_window_does_not_claim_measured_eighty_percent(self):
        empty = AirtimeMix(1000).snapshot(1000)
        self.assertIsNone(empty['spokenPercent'])
        self.assertIsNone(empty['musicPercent'])
        self.assertEqual(empty['elapsedSeconds'], 0)


if __name__ == '__main__':
    unittest.main()

"""Deterministic producer regressions; no live feeds, network TTS or price calls."""
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import io
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server
from market_brief import parse_quote


class PriceScheduleTests(unittest.TestCase):
    NOW = 1_792_934_000

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.stations = []

    def tearDown(self):
        for station in self.stations:
            station.stop.set()
        self.temporary.cleanup()

    def station(self, name):
        with patch('server.time.time', return_value=self.NOW - 1000):
            station = server.Station(Path(self.temporary.name) / name)
        station.programmes = None
        station.languages = ('ar', 'en')
        station.last_analysis_at = {language: self.NOW * 1000 for language in ('ar', 'en')}
        self.stations.append(station)
        return station

    def observe(self, station, price, offset=0):
        stamp = self.NOW + offset
        station.market.observe(parse_quote({'symbol': 'XAU', 'price': Decimal(price),
            'updatedAt': datetime.fromtimestamp(stamp, timezone.utc).isoformat()}, stamp))

    def announced(self, station, language, price='4020.00', offset=-30):
        station.initial_price[language] = Decimal(price)
        station.last_announced_price[language] = Decimal(price)
        station.last_market_at[language] = (self.NOW + offset) * 1000

    @staticmethod
    def wav(duration_s, marker=1):
        output = io.BytesIO()
        with wave.open(output, 'wb') as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(24000)
            audio.writeframes(bytes((marker, 0)) * round(24000 * duration_s))
        return output.getvalue()

    def produce_one(self, station, language, duration_s=3):
        calls = []
        data = self.wav(duration_s)

        class Voice:
            def synthesize(self, text, language):
                calls.append((text, language))
                station.stop.set()
                return SimpleNamespace(wav=data, duration_s=duration_s,
                    engine='fake-schedule-test', language=language)

        station.stop.clear()
        with patch('server.time.time', return_value=self.NOW), \
                patch('server.time.monotonic', return_value=50):
            station._produce(Voice(), (language,))
        self.assertEqual(len(calls), 1, 'one complete synthetic producer turn must run')
        return calls[0]

    def queued_news(self, station, language, identifier, start_s, end_s,
                    *, published_s=-20, recency='fresh'):
        data = self.wav(end_s - start_s, marker=2)
        row = {'id': identifier * 32, 'kind': 'news', 'language': language,
            'headline': 'Collected source report', 'source': 'Test publisher',
            'sourceUrl': 'https://example.org/public-report',
            'speechText': 'A complete source report, preserved by priority scheduling.',
            'publishedAt': (self.NOW + published_s) * 1000,
            'firstSeenAt': (self.NOW + published_s + 1) * 1000,
            'generatedAt': (self.NOW - 15) * 1000,
            'startsAt': (self.NOW + start_s) * 1000,
            'endsAt': (self.NOW + end_s) * 1000,
            'durationSeconds': end_s - start_s, 'recency': recency,
            'audioUrl': '/audio/' + identifier * 32 + '.wav'}
        station.queues[language].append(row)
        station.airtime[language].commit(row['startsAt'], row['endsAt'], 'news')
        (station.directory / (row['id'] + '.wav')).write_bytes(data)
        return row, data

    def test_unchanged_fresh_quote_has_periodic_heartbeat_not_timestamp_repeat(self):
        for language in ('ar', 'en'):
            with self.subTest(language=language):
                station = self.station('heartbeat-' + language)
                self.announced(station, language, offset=-480)
                self.observe(station, '4020.00', -1)
                self.assertIsNone(station._next_job(language, (self.NOW - 1) * 1000, {}),
                                  'a fresh provider timestamp alone is not a changed-price call')
                self.observe(station, '4020.00')
                job = station._next_job(language, self.NOW * 1000, {})
                self.assertEqual((job['kind'], job['announcementReason']), ('market', 'periodic'))
                self.assertFalse(station._price_change_pending(language, job['market']))
                self.produce_one(station, language)
                segment = station.queues[language][-1]
                self.assertEqual(segment['announcementReason'], 'periodic')
                self.assertLessEqual(segment['startsAt'],
                    (self.NOW - 480 + server.PRICE_HEARTBEAT_S) * 1000)
                self.assertEqual(station.last_market_at[language], segment['startsAt'])
                self.assertEqual(station.last_announced_price[language], Decimal('4020.00'))
                self.observe(station, '4020.00', 30)
                self.assertIsNone(station._next_job(language, (self.NOW + 30) * 1000, {}))

    def test_periodic_curve_runs_on_flat_and_sparse_quotes_without_price_move(self):
        for language in ('ar', 'en'):
            for history in ('sparse', 'flat'):
                with self.subTest(language=language, history=history):
                    station = self.station('curve-' + language + '-' + history)
                    self.announced(station, language)
                    for offset in ((0,) if history == 'sparse' else (-80, -60, -40, -20, 0)):
                        self.observe(station, '4020.00', offset)
                    station.last_analysis_at[language] = (self.NOW - 150) * 1000
                    prior_market = station.last_market_at[language]
                    job = station._next_job(language, self.NOW * 1000, {})
                    self.assertEqual(job['kind'], 'analysis')
                    self.assertFalse(station._price_change_pending(language, job['market']))
                    self.assertFalse(job['analysis']['forecast'])
                    self.assertEqual(job['analysis']['outlook']['status'],
                                     'insufficient' if history == 'sparse' else 'flat')
                    self.produce_one(station, language, duration_s=8)
                    segment = station.queues[language][-1]
                    self.assertEqual(segment['kind'], 'analysis')
                    self.assertLess(segment['startsAt'] - (self.NOW - 150) * 1000, 300000)
                    self.assertEqual(station.last_analysis_at[language], segment['startsAt'])
                    self.assertEqual(station.last_market_at[language], prior_market)
                    self.assertEqual(station.last_announced_price[language], Decimal('4020.00'))
                    self.assertEqual(station.outlook.status()['retainedRecords'], 0)

    def test_changed_quote_bypasses_long_future_backlog_at_complete_current_boundary(self):
        for language in ('ar', 'en'):
            with self.subTest(language=language):
                station = self.station('priority-' + language)
                self.announced(station, language)
                self.observe(station, '4021.25')
                station.news_streak[language] = server.NEWS_BURST_LIMIT
                current, current_audio = self.queued_news(station, language, 'a', -10, 20)
                future, future_audio = self.queued_news(station, language, 'b', 20, 90)
                tail, _ = self.queued_news(station, language, 'c', 90, 160)
                current_before, future_before, tail_before = map(deepcopy, (current, future, tail))
                clock_before = station.airtime[language].total_music_ms(self.NOW * 1000)
                self.assertGreater(tail['endsAt'], (self.NOW + server.SPEECH_LOOKAHEAD_S) * 1000)
                self.produce_one(station, language)
                rows = station.queues[language]
                self.assertEqual([row['kind'] for row in rows], ['news', 'market', 'news', 'news'])
                self.assertEqual(rows[0], current_before)
                self.assertEqual(rows[1]['startsAt'], current_before['endsAt'])
                self.assertEqual(rows[1]['announcementReason'], 'changed')
                for original, delayed in ((future_before, rows[2]), (tail_before, rows[3])):
                    self.assertEqual(delayed, {**original,
                        'startsAt': original['startsAt'] + 3000, 'endsAt': original['endsAt'] + 3000})
                self.assertEqual((station.directory / (current['id'] + '.wav')).read_bytes(), current_audio)
                self.assertEqual((station.directory / (future['id'] + '.wav')).read_bytes(), future_audio)
                self.assertEqual(station.airtime[language].total_music_ms(self.NOW * 1000), clock_before)
                self.assertEqual(station.last_announced_price[language], Decimal('4021.25'))
                self.assertEqual(station.news_streak[language], server.NEWS_BURST_LIMIT)

    def test_priority_preserves_news_before_it_would_cross_its_spoken_freshness_boundary(self):
        for recency, published in (('fresh', -579), ('earlier', -7179)):
            with self.subTest(recency=recency):
                station = self.station('freshness-' + recency)
                language = 'en'
                self.announced(station, language)
                self.observe(station, '4021.00')
                self.queued_news(station, language, 'a', -10, 20)
                near_expiry, _ = self.queued_news(station, language, 'b', 20, 30,
                    published_s=published, recency=recency)
                future, _ = self.queued_news(station, language, 'c', 30, 90)
                protected, delayed = deepcopy(near_expiry), deepcopy(future)
                original_job = {**near_expiry, 'publishedAt': near_expiry['publishedAt'] // 1000,
                                'firstSeenAt': near_expiry['firstSeenAt'] // 1000}
                self.assertTrue(station._job_fresh(original_job, near_expiry['startsAt']))
                self.assertFalse(station._job_fresh(original_job, near_expiry['startsAt'] + 3000))
                self.produce_one(station, language)
                self.assertEqual(station.queues[language][1], protected)
                priority = station.queues[language][2]
                self.assertEqual((priority['kind'], priority['startsAt']), ('market', protected['endsAt']))
                self.assertEqual(station.queues[language][3], {**delayed,
                    'startsAt': delayed['startsAt'] + 3000, 'endsAt': delayed['endsAt'] + 3000})
                for row in station.queues[language]:
                    original = {**row, 'publishedAt': row['publishedAt'] // 1000,
                                'firstSeenAt': row['firstSeenAt'] // 1000}
                    self.assertTrue(station._job_fresh(original, row['startsAt']))

    def test_failed_priority_insertion_does_not_advance_market_or_outlook_state(self):
        for kind in ('market', 'analysis'):
            with self.subTest(kind=kind):
                station = self.station('rejected-' + kind)
                language = 'en'
                for offset, price in zip((-80, -60, -40, -20, 0),
                                         ('4020', '4020.25', '4020.5', '4020.75', '4021')):
                    self.observe(station, price, offset)
                self.announced(station, language, price='4020.00' if kind == 'market' else '4021.00')
                if kind == 'analysis':
                    station.last_analysis_at[language] = (self.NOW - 150) * 1000
                job = station._next_job(language, self.NOW * 1000, {})
                self.assertEqual(job['kind'], kind)
                if kind == 'analysis':
                    self.assertEqual(job['analysis']['outlook']['status'], 'ready')
                    self.assertEqual(len(job['analysis']['outlook']['forecasts']), 3)
                before = deepcopy({'last_market_at': station.last_market_at,
                    'last_market_id': station.last_market_id, 'last_analysis_at': station.last_analysis_at,
                    'announced': station.last_announced_price, 'outlook': station.outlook.status(),
                    'last_outlook': station.last_market_outlook, 'queues': station.queues,
                    'prepared': station.last_prepared, 'seen': station.seen,
                    'airtime': station.airtime[language].intervals})
                with patch.object(station.airtime[language], 'insert_before_future',
                                  side_effect=ValueError('test-only insertion rejection')):
                    self.produce_one(station, language)
                after = {'last_market_at': station.last_market_at, 'last_market_id': station.last_market_id,
                    'last_analysis_at': station.last_analysis_at, 'announced': station.last_announced_price,
                    'outlook': station.outlook.status(), 'last_outlook': station.last_market_outlook,
                    'queues': station.queues, 'prepared': station.last_prepared, 'seen': station.seen,
                    'airtime': station.airtime[language].intervals}
                self.assertEqual(after, before)
                self.assertIsNone(station.preparing[language])
                self.assertIn('retrying', station.errors[language])

    def test_shifted_future_market_cadence_follows_airtime_without_reissuing_forecasts(self):
        for future_kind in ('market', 'analysis'):
            with self.subTest(future_kind=future_kind):
                station = self.station('cadence-' + future_kind)
                language = 'en'
                for offset, price in zip((-80, -60, -40, -20, 0),
                                         ('4020', '4020.25', '4020.5', '4020.75', '4021')):
                    self.observe(station, price, offset)
                briefing = server.build_briefing(language, station.market.snapshot(self.NOW), (),
                                                 self.NOW, outlook_desk=station.outlook)
                outlook = briefing['analysis']['outlook']
                self.assertTrue(station.outlook.commit(outlook))
                self.queued_news(station, language, 'a', -10, 20)
                future = {'id': 'd' * 32, 'kind': future_kind, 'language': language,
                    'publishedAt': self.NOW * 1000, 'firstSeenAt': self.NOW * 1000,
                    'startsAt': (self.NOW + 20) * 1000, 'endsAt': (self.NOW + 40) * 1000,
                    'market': station.market.snapshot(self.NOW), 'analysis': briefing['analysis']}
                station.queues[language].append(future)
                station.airtime[language].commit(future['startsAt'], future['endsAt'], future_kind)
                cadence = station.last_market_at if future_kind == 'market' else station.last_analysis_at
                cadence[language] = future['startsAt']
                before_forecast = deepcopy(future['analysis'])
                before_ledger = deepcopy(list(station.outlook._records))
                before_clock = station.airtime[language].total_music_ms(self.NOW * 1000)
                inserted = {'id': 'e' * 32, 'kind': 'market', 'language': language,
                    'publishedAt': self.NOW * 1000, 'firstSeenAt': self.NOW * 1000,
                    'startsAt': (self.NOW + 20) * 1000, 'endsAt': (self.NOW + 23) * 1000}
                station._insert_priority(language, inserted, self.NOW * 1000)
                self.assertEqual(cadence[language], (self.NOW + 23) * 1000)
                self.assertEqual((future['startsAt'], future['endsAt']),
                                 ((self.NOW + 23) * 1000, (self.NOW + 43) * 1000))
                self.assertEqual((future['publishedAt'], future['firstSeenAt']), (self.NOW * 1000,) * 2)
                self.assertEqual(future['analysis'], before_forecast)
                self.assertEqual(list(station.outlook._records), before_ledger)
                self.assertEqual(station.airtime[language].total_music_ms(self.NOW * 1000), before_clock)


if __name__ == '__main__':
    unittest.main()

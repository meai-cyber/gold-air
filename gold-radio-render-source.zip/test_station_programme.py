from copy import deepcopy
import re
import unittest

from station_programme import EPISODES, LIBRARY_VERSION, ProgrammeLibrary, REPLAY_COOLDOWN_S


class ProgrammeLibraryTests(unittest.TestCase):
    now = 1792860000

    def setUp(self):
        self.library = ProgrammeLibrary()

    def finish_episode(self, language, now_s):
        jobs = []
        for index in range(4):
            job = self.library.candidate(language, now_s + index)
            self.assertEqual(job['programme']['turnIndex'], index)
            self.assertTrue(self.library.consume(job, now_s + index))
            jobs.append(job)
        return jobs

    def test_reviewed_library_is_bilingual_complete_and_bounded(self):
        self.assertGreaterEqual(len(EPISODES), 12)
        self.assertEqual(len({episode.identity for episode in EPISODES}), len(EPISODES))
        for episode in EPISODES:
            self.assertEqual(len(episode.turns), 4)
            self.assertTrue(episode.title_en and episode.title_ar)
            for turn, (english, arabic) in enumerate(episode.turns):
                with self.subTest(episode=episode.identity, turn=turn):
                    self.assertTrue(300 <= len(english) <= 550)
                    self.assertTrue(200 <= len(arabic) <= 450)
                    self.assertTrue(english.endswith(('.', '?')))
                    self.assertTrue(arabic.endswith(('.', '؟')))
                    self.assertNotIn('...', english + arabic)
                    self.assertNotIn('http', english + arabic)
                    self.assertNotIn('guaranteed profit', english.lower())
                    self.assertGreater(len(re.findall(r'[\u0600-\u06ff]', arabic)), 100)
        for index in (0, 1):
            self.assertGreater(sum(len(turn[index].split()) for episode in EPISODES for turn in episode.turns), 2400)

    def test_candidate_is_a_labelled_recorded_job_with_preparation_not_news_clock(self):
        for language, opening in (('en', 'Recorded educational discussion.'),
                                  ('ar', 'من حواراتنا التعليمية المسجلة.')):
            job = self.library.candidate(language, self.now)
            self.assertEqual(job['kind'], 'podcast')
            self.assertEqual(job['language'], language)
            self.assertRegex(job['id'], r'^[a-f0-9]{32}$')
            self.assertEqual(job['publishedAt'], self.now)
            self.assertEqual(job['firstSeenAt'], self.now)
            self.assertTrue(job['speechText'].startswith(opening))
            self.assertLessEqual(len(job['speechText']), 800)
            programme = job['programme']
            self.assertEqual(programme['mode'], 'recorded-educational')
            self.assertEqual(programme['libraryVersion'], LIBRARY_VERSION)
            self.assertTrue(programme['educational'])
            self.assertFalse(programme['currentNews'])
            self.assertFalse(programme['forecast'])
            self.assertFalse(programme['repeat'])
            self.assertEqual(programme['timingBasis'], 'preparation-not-news-publication')
            self.assertEqual(programme['turnCount'], 4)
            self.assertEqual(programme['speakerRole'], 'host')

    def test_failed_preparation_or_news_interruption_does_not_advance_turn(self):
        offered = self.library.candidate('en', self.now)
        later = self.library.candidate('en', self.now + 75)
        self.assertEqual(offered['id'], later['id'])
        self.assertEqual(offered['speechText'], later['speechText'])
        self.assertEqual(later['programme']['turnIndex'], 0)
        self.assertTrue(self.library.consume(later, self.now + 80))
        next_turn = self.library.candidate('en', self.now + 81)
        self.assertEqual(next_turn['programme']['episodeId'], offered['programme']['episodeId'])
        self.assertEqual(next_turn['programme']['turnIndex'], 1)
        self.assertEqual(next_turn['programme']['speakerRole'], 'analyst')
        self.assertNotEqual(next_turn['id'], offered['id'])

    def test_consumption_is_ordered_single_use_and_requires_an_offered_job(self):
        self.assertFalse(self.library.consume({}, self.now))
        job = self.library.candidate('ar', self.now)
        for changed in ({'id': '0' * 32}, {'kind': 'news'}, {'language': 'en'},
                        {'language': []}, {'firstSeenAt': self.now + 1},
                        {'programme': {**job['programme'], 'turnIndex': 1}},
                        {'programme': {**job['programme'], 'turnIndex': True}}):
            with self.subTest(changed=changed):
                self.assertFalse(self.library.consume({**job, **changed}, self.now))
        self.assertTrue(self.library.consume(job, self.now))
        self.assertFalse(self.library.consume(job, self.now))
        self.assertEqual(self.library.candidate('ar', self.now + 1)['programme']['turnIndex'], 1)

    def test_excluded_retry_id_waits_without_skipping_the_episode(self):
        first = self.library.candidate('en', self.now)
        self.assertIsNone(self.library.candidate('en', self.now + 1, excluded={first['id']}))
        self.assertEqual(self.library.candidate('en', self.now + 2)['id'], first['id'])
        self.assertTrue(self.library.consume(first, self.now + 2))
        second = self.library.candidate('en', self.now + 3)
        self.assertIsNone(self.library.candidate('en', self.now + 4, excluded={second['id']}))
        resumed = self.library.candidate('en', self.now + REPLAY_COOLDOWN_S * 2)
        self.assertEqual(resumed['id'], second['id'])
        self.assertEqual(resumed['programme']['episodeId'], first['programme']['episodeId'])

    def test_languages_keep_independent_progress_and_stable_distinct_ids(self):
        ar = self.library.candidate('ar', self.now)
        en = self.library.candidate('en', self.now)
        self.assertNotEqual(ar['id'], en['id'])
        self.assertTrue(self.library.consume(ar, self.now))
        self.assertEqual(self.library.candidate('en', self.now + 1)['id'], en['id'])
        self.assertEqual(self.library.candidate('ar', self.now + 1)['programme']['turnIndex'], 1)
        self.assertEqual(self.library.status('en', self.now)['unplayedEpisodes'], len(EPISODES))

    def test_all_unplayed_episodes_precede_any_replay_even_after_a_long_pause(self):
        first = self.finish_episode('en', self.now)
        after_pause = self.library.candidate('en', self.now + REPLAY_COOLDOWN_S * 3)
        self.assertNotEqual(after_pause['programme']['episodeId'], first[0]['programme']['episodeId'])
        self.assertFalse(after_pause['programme']['repeat'])
        self.assertEqual(after_pause['programme']['turnIndex'], 0)

    def test_cooldown_starts_at_successful_completion_and_replay_is_explicit(self):
        first = None
        completed_at = None
        offered_ids = set()
        for episode_index in range(len(EPISODES)):
            start = self.now + episode_index * 10
            jobs = self.finish_episode('ar', start)
            if episode_index == 0:
                first, completed_at = jobs[0], start + 3
            for job in jobs:
                self.assertNotIn(job['id'], offered_ids)
                offered_ids.add(job['id'])
        self.assertIsNone(self.library.candidate('ar', completed_at + REPLAY_COOLDOWN_S - 1))
        status = self.library.status('ar', self.now + 200)
        self.assertEqual(status['unplayedEpisodes'], 0)
        self.assertEqual(status['nextReplayAt'], (completed_at + REPLAY_COOLDOWN_S) * 1000)
        replay = self.library.candidate('ar', completed_at + REPLAY_COOLDOWN_S)
        self.assertEqual(replay['id'], first['id'])
        self.assertTrue(replay['programme']['repeat'])
        self.assertTrue(replay['speechText'].startswith('إعادة من أرشيفنا التعليمي.'))
        self.assertNotEqual(replay['speechText'], first['speechText'])
        self.assertEqual(replay['programme']['turnIndex'], 0)

    def test_jobs_are_copies_and_restart_does_not_claim_a_private_history(self):
        job = self.library.candidate('en', self.now)
        saved = deepcopy(job)
        job['speechText'] = 'Changed by caller'
        job['programme']['references'].append('https://example.com/not-a-source')
        self.assertEqual(self.library.candidate('en', self.now), saved)
        self.finish_episode('en', self.now)
        restart = ProgrammeLibrary().candidate('en', self.now + 100)
        self.assertEqual(restart['programme']['episodeId'], EPISODES[0].identity)
        self.assertFalse(restart['programme']['repeat'])

    def test_invalid_language_clock_or_exclusions_do_not_create_jobs(self):
        for language, stamp in (('fr', self.now), ('en', True), ('ar', 0), ('ar', -1), ('en', 1.5)):
            with self.subTest(language=language, stamp=stamp), self.assertRaises(ValueError):
                self.library.candidate(language, stamp)
        for excluded in ('not-an-iterable-of-ids', {}, None, [None], ('x' for _ in range(1001))):
            with self.subTest(excluded_type=type(excluded).__name__), self.assertRaises(ValueError):
                self.library.candidate('en', self.now, excluded)


if __name__ == '__main__':
    unittest.main()

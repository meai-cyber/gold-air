"""A bounded, exact-quote public-opinion segment; no model or network access.

Candidate reads are side-effect free. Only successfully scheduled, complete
audio advances a session. Public account names and opinions remain unverified,
unrepresentative and excluded from factual model context.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
from itertools import islice
import json
import math
import re
import uuid

from news_freshness import is_fresh_news
from social_feedback import publisher_root, reaction_allowed as reply_allowed
from social_reactions import _language, reaction_allowed as opinion_allowed
from people_translation import translation_allowed
from social_scrapling import reaction_allowed as scraped_opinion_allowed, context_parent, MAX_CONTEXT_AGE_S


POLICY_VERSION = 'people-now-compact-public-opinion-2026-10-26-v4'
INTERVAL_SECONDS = 600
TARGET_SECONDS = 120
SESSION_WALL_SECONDS = 180
MAX_POST_AGE_SECONDS = 3600
MAX_PARENT_AGE_SECONDS = 3600
PREFERRED_POST_AGE_SECONDS = 600
MAX_TURN_SECONDS = 35
# This is the length of an unrelated priority clip, not a people's quote.
# Retain the original insertion budget while keeping opinions themselves short.
MAX_PRIORITY_INSERT_SECONDS = 90
MAX_STORIES = 1000
_MAX_MS = 253402300799000
_HEX_ID = re.compile(r'[a-f0-9]{32}')


def _clock_ms(value):
    return type(value) is int and 0 < value <= _MAX_MS


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        allow_nan=False, separators=(',', ':')).encode()).hexdigest()


def _author(row):
    metadata = row['feedback' if row['sourceKind'] == 'social-feedback' else 'reaction']
    # Use the stable provider identity as well as the handle when preventing
    # repeat authors. A handle change does not create another person.
    identity = ('Bluesky:' + metadata['authorDid'] if row['sourceKind'] == 'social-feedback'
                else row['platform'] + ':' + metadata['authorId'])
    post_id = (metadata['replyUri'] if row['sourceKind'] == 'social-feedback' else metadata['statusId'])
    return metadata, identity, post_id


def _speech(row, language=None):
    """Say only the exact account handle and the complete chosen opinion.

    Publication/context clocks, original text and machine-translation labels
    stay in source metadata and the player; they are not repeated on air.
    """
    language = language or row['language']
    translated = language == 'ar' and row['language'] == 'en'
    quote = row.get('machineTranslations', {}).get('ar', {}).get('text', '') if translated else row['title']
    metadata, _identity, _post_id = _author(row)
    handle = metadata['authorHandle']
    return f'{handle}: «{quote}»' if language == 'ar' else f'{handle}: “{quote}”'


def _estimate_seconds(text, language):
    # Planning only; actual complete WAV duration is the commit authority.
    # Count handle characters too, since long account names take time to read.
    return round(max(len(text) / (11 if language == 'ar' else 14),
                     len(text.split()) / (2 if language == 'ar' else 2.5)) + 2, 3)


def _sources_allowed(sources, admitted_ms, end_ms, language):
    if (not isinstance(sources, list) or not 1 <= len(sources) <= 2 or
            not all(isinstance(row, dict) for row in sources) or
            not _clock_ms(admitted_ms) or not _clock_ms(end_ms) or end_ms < admitted_ms):
        return False
    row = sources[0]
    admitted_s, end_s = admitted_ms // 1000, math.ceil(end_ms / 1000)
    translated = language == 'ar' and row.get('language') == 'en'
    parent = sources[1] if len(sources) == 2 else None
    hn_parent = context_parent(row) if row.get('platform') == 'HackerNews' else None
    if (language not in ('en', 'ar') or row.get('language') != language and not translated or
            translated and (not translation_allowed(row.get('machineTranslations', {}).get('ar'), row,
                parent if not hn_parent and row.get('feedback', {}).get('screeningKind') == 'bounded-news-opinion' else None, at_s=end_s))):
        return False
    kind = row.get('sourceKind')
    guard = (scraped_opinion_allowed if hn_parent else reply_allowed if kind == 'social-feedback'
             else opinion_allowed if kind == 'social-reaction' else None)
    if (guard is None or not guard(row, admitted_s) or not guard(row, end_s) or
            _language(row.get('title', '')) != row.get('language') or
            not is_fresh_news(row, admitted_s, max_age_s=MAX_POST_AGE_SECONDS, at_s=end_s)):
        return False
    # Compare milliseconds, without allowing a final fractional second beyond
    # the policy ceiling. Receipt or update clocks never renew this boundary.
    if end_ms - row['publishedAt'] * 1000 > MAX_POST_AGE_SECONDS * 1000:
        return False
    if hn_parent:
        return (len(sources) == 2 and parent == hn_parent and
                end_ms - parent['publishedAt'] * 1000 <= MAX_CONTEXT_AGE_S * 1000 and
                _language(parent['title']) == 'en')
    if kind == 'social-reaction':
        return len(sources) == 1
    if len(sources) != 2:
        return False
    root, metadata = sources[1], row['feedback']
    validated = publisher_root(root, admitted_s)
    if metadata.get('screeningKind') == 'bounded-news-opinion' and (
            metadata.get('rootTitle') != root.get('title') or
            _language(root.get('title', '')) != root.get('language')):
        return False
    return bool(validated and validated['uri'] == metadata['rootUri'] and
        root.get('id') == metadata['rootId'] and root.get('url') == metadata['rootUrl'] and
        root.get('source') == metadata['rootSource'] and
        root.get('publishedAt') == metadata['rootPublishedAt'] and
        root['publishedAt'] <= row['publishedAt'] and
        is_fresh_news(root, admitted_s, max_age_s=MAX_PARENT_AGE_SECONDS, at_s=end_s) and
        end_ms - root['publishedAt'] * 1000 <= MAX_PARENT_AGE_SECONDS * 1000)


def _job_id(language, session_id, source_id):
    return _digest([POLICY_VERSION, language, session_id, source_id])[:32]


def _admission_digest(metadata, sources, speech, language):
    return _digest([POLICY_VERSION, {key: value for key, value in metadata.items()
        if key != 'admissionDigest'}, sources, speech, language])


def job_fresh(job, at_ms):
    """Revalidate original post and parent through the complete audio end.

    Admission time and full immutable source snapshots travel with the job.
    Matching metadata, exact speech and a content digest prevent an in-flight
    edit, changed clock or a different account name from replacing the quote.
    This is an internal consistency check, not independent identity proof.
    """
    try:
        if (not isinstance(job, dict) or job.get('kind') != 'people-now' or
                not _clock_ms(at_ms) or job.get('factualContextEligible') is not False):
            return False
        metadata, sources = job.get('peopleNow'), job.get('sources')
        if not isinstance(metadata, dict):
            return False
        admitted = metadata.get('admittedAt')
        if not _sources_allowed(sources, admitted, at_ms, job.get('language')):
            return False
        row = sources[0]
        author, _identity, post_id = _author(row)
        session_id, turn = metadata.get('sessionId'), metadata.get('turnIndex')
        if (not isinstance(session_id, str) or not _HEX_ID.fullmatch(session_id) or
                type(turn) is not int or not 0 <= turn < 120 or
                metadata.get('policyVersion') != POLICY_VERSION or
                metadata.get('intervalSeconds') != INTERVAL_SECONDS or
                metadata.get('targetSeconds') != TARGET_SECONDS or
                metadata.get('maxPostAgeSeconds') != MAX_POST_AGE_SECONDS or
                metadata.get('maxParentAgeSeconds') != (MAX_CONTEXT_AGE_S if row.get('platform') == 'HackerNews' else MAX_PARENT_AGE_SECONDS) or
                metadata.get('accountNameUnverified') is not True or
                metadata.get('unverified') is not True or metadata.get('representative') is not False or
                metadata.get('factualContextEligible') is not False or
                metadata.get('authorHandle') != author['authorHandle'] or
                metadata.get('sourcePostId') != post_id or
                metadata.get('originalPublishedAt') != row['publishedAt'] or
                metadata.get('sourceKind') != row['sourceKind'] or
                metadata.get('sourceDigest') != _digest(sources) or
                metadata.get('authorName') != author.get('authorName') or
                ('authorName' in metadata) != ('authorName' in author)):
            return False
        if row['sourceKind'] == 'social-feedback':
            if metadata.get('rootUrl') != author['rootUrl']:
                return False
        elif 'rootUrl' in metadata:
            return False
        translated = job['language'] != row['language']
        if (metadata.get('machineTranslation') is not translated or
                metadata.get('originalLanguage') != row['language'] or
                translated and (metadata.get('translationVerified') is not False or
                    metadata.get('translationModelId') != row['machineTranslations']['ar']['modelId'])):
            return False
        expected_speech = _speech(row, job['language'])
        expected_title = row['machineTranslations']['ar']['text'] if translated else row['title']
        estimate = _estimate_seconds(expected_speech, job['language'])
        return (metadata.get('admissionDigest') == _admission_digest(
                    metadata, sources, expected_speech, job['language']) and
                job.get('id') == _job_id(job['language'], session_id, row['id']) and
                job.get('sourceIds') == [row['id']] and job.get('speechText') == expected_speech and
                job.get('title') == expected_title and job.get('source') == row['source'] and
                job.get('url') == row['url'] and job.get('publishedAt') == row['publishedAt'] and
                job.get('firstSeenAt') == row['firstSeenAt'] and job.get('social') is True and
                job.get('sourceKind') == row['sourceKind'] and job.get('platform') == row['platform'] and
                job.get('estimatedSeconds') == estimate and estimate <= MAX_TURN_SECONDS)
    except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
        return False


class PeopleNow:
    """Independent language sessions, starting only on a successful first slot."""

    def __init__(self):
        self._namespace = uuid.uuid4().hex
        self._states = {language: {'number': 0, 'startedAt': None, 'lastEndAt': None,
            'scheduledMs': 0, 'posts': set(), 'authors': set(), 'handles': set(), 'slots': []}
            for language in ('en', 'ar')}

    def _view(self, language, now_ms):
        state = self._states[language]
        started = state['startedAt']
        active = (started is not None and state['scheduledMs'] < TARGET_SECONDS * 1000 and
                  now_ms < started + SESSION_WALL_SECONDS * 1000)
        next_due = None if started is None else started + INTERVAL_SECONDS * 1000
        due = active or next_due is None or now_ms >= next_due
        number = state['number'] if active else state['number'] + 1
        session_id = _digest([self._namespace, language, number])[:32]
        return state, active, due, next_due, number, session_id

    def candidate(self, language, stories, now_ms, excluded=(), seen=()):
        if language not in self._states or not _clock_ms(now_ms):
            return None
        state, active, due, _next_due, _number, session_id = self._view(language, now_ms)
        if not due or isinstance(stories, (str, bytes, dict)):
            return None
        try:
            rows = list(islice(iter(stories), MAX_STORIES))
            blocked = set(excluded) | set(seen)
        except (TypeError, ValueError):
            return None
        roots = {row.get('id'): row for row in rows if isinstance(row, dict) and
                 isinstance(row.get('id'), str) and row.get('sourceKind') == 'social'}
        eligible = []
        for row in rows:
            if (not isinstance(row, dict) or (row.get('language') != language and
                    not (language == 'ar' and row.get('language') == 'en' and row.get('machineTranslations', {}).get('ar'))) or
                    row.get('sourceKind') not in ('social-feedback', 'social-reaction')):
                continue
            try:
                sources = [row]
                if row.get('platform') == 'HackerNews':
                    parent = context_parent(row)
                    if parent is None:
                        continue
                    sources.append(parent)
                if row['sourceKind'] == 'social-feedback':
                    root = roots.get(row.get('feedback', {}).get('rootId'))
                    if root is None:
                        continue
                    sources.append(root)
                if not _sources_allowed(sources, now_ms, now_ms, language):
                    continue
                author, identity, post_id = _author(row)
                job_id = _job_id(language, session_id, row['id'])
                if ({row['id'], row['url'], post_id, job_id} & blocked or
                        active and (post_id in state['posts'] or identity in state['authors'] or
                                    author['authorHandle'].casefold() in state['handles'])):
                    continue
                speech = _speech(row, language)
                estimate = _estimate_seconds(speech, language)
                remaining_ms = TARGET_SECONDS * 1000 - (state['scheduledMs'] if active else 0)
                estimated_end = now_ms + math.ceil(estimate * 1000)
                if (estimate > MAX_TURN_SECONDS or estimate * 1000 > remaining_ms or
                        active and estimated_end > state['startedAt'] + SESSION_WALL_SECONDS * 1000 or
                        not _sources_allowed(sources, now_ms, estimated_end, language)):
                    continue
                metadata = {'policyVersion': POLICY_VERSION, 'sessionId': session_id,
                    'turnIndex': len(state['posts']) if active else 0,
                    'intervalSeconds': INTERVAL_SECONDS, 'targetSeconds': TARGET_SECONDS,
                    'maxPostAgeSeconds': MAX_POST_AGE_SECONDS, 'admittedAt': now_ms,
                    'maxParentAgeSeconds': MAX_CONTEXT_AGE_S if row.get('platform') == 'HackerNews' else MAX_PARENT_AGE_SECONDS,
                    'authorHandle': author['authorHandle'], 'accountNameUnverified': True,
                    'sourcePostId': post_id, 'originalPublishedAt': row['publishedAt'],
                    'sourceKind': row['sourceKind'], 'sourceDigest': _digest(sources),
                    'unverified': True, 'representative': False, 'factualContextEligible': False,
                    'machineTranslation': row['language'] != language, 'originalLanguage': row['language']}
                if metadata['machineTranslation']:
                    metadata.update(translationVerified=False,
                        translationModelId=row['machineTranslations']['ar']['modelId'])
                if 'authorName' in author:
                    metadata['authorName'] = author['authorName']
                if row['sourceKind'] == 'social-feedback':
                    metadata['rootUrl'] = author['rootUrl']
                metadata['admissionDigest'] = _admission_digest(metadata, sources, speech, language)
                job = {key: row[key] for key in ('title', 'source', 'url', 'publishedAt',
                    'firstSeenAt', 'social', 'sourceKind', 'platform')}
                job.update(id=job_id, kind='people-now', language=language, speechText=speech,
                    sources=deepcopy(sources), sourceIds=[row['id']], peopleNow=metadata,
                    estimatedSeconds=estimate, factualContextEligible=False)
                if metadata['machineTranslation']:
                    job['title'] = row['machineTranslations']['ar']['text']
                age = now_ms - row['publishedAt'] * 1000
                eligible.append((estimate > 25, age > PREFERRED_POST_AGE_SECONDS * 1000, estimate, -row['publishedAt'], row['id'], job))
            except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
                continue
        return min(eligible, key=lambda item: item[:5])[5] if eligible else None

    def _commit_plan(self, job, start_ms, end_ms):
        """Pure validation shared by the pre-write check and final commit."""
        if (not _clock_ms(start_ms) or not _clock_ms(end_ms) or
                not 0 < end_ms - start_ms <= MAX_TURN_SECONDS * 1000 or
                not job_fresh(job, end_ms)):
            return None
        language, metadata = job['language'], job['peopleNow']
        if language not in self._states or start_ms < metadata['admittedAt']:
            return None
        state, active, due, _next_due, number, session_id = self._view(language, start_ms)
        if (not due or metadata['sessionId'] != session_id or
                metadata['turnIndex'] != (len(state['posts']) if active else 0)):
            return None
        row = job['sources'][0]
        author, identity, post_id = _author(row)
        scheduled = state['scheduledMs'] if active else 0
        started = state['startedAt'] if active else start_ms
        if (scheduled + end_ms - start_ms > TARGET_SECONDS * 1000 or
                end_ms > started + SESSION_WALL_SECONDS * 1000 or
                active and (start_ms < state['lastEndAt'] or post_id in state['posts'] or
                            identity in state['authors'] or author['authorHandle'].casefold() in state['handles'])):
            return None
        return state, active, number, post_id, identity, author['authorHandle'].casefold()

    def can_commit(self, job, start_ms, end_ms):
        """Check a complete audio slot without consuming any session progress."""
        return self._commit_plan(job, start_ms, end_ms) is not None

    def commit(self, job, start_ms, end_ms):
        """Consume only complete scheduled audio, within actual per-session limits."""
        plan = self._commit_plan(job, start_ms, end_ms)
        if plan is None:
            return False
        state, active, number, post_id, identity, handle = plan
        if not active:
            state.update(number=number, startedAt=start_ms, scheduledMs=0,
                         posts=set(), authors=set(), handles=set(), slots=[])
        state['scheduledMs'] += end_ms - start_ms
        state['lastEndAt'] = end_ms
        state['posts'].add(post_id)
        state['authors'].add(identity)
        state['handles'].add(handle)
        state['slots'].append((start_ms, end_ms))
        return True

    def _shift_plan(self, language, start_ms, delta_ms, now_ms):
        """Validate an insertion at a complete-clip boundary, without mutation.

        The station separately rechecks each source through its shifted end.
        This planner owns session geometry and cadence, not the audio queue.
        """
        if (language not in self._states or not _clock_ms(start_ms) or
                not _clock_ms(now_ms) or start_ms <= now_ms or
                type(delta_ms) is not int or not 0 < delta_ms <= MAX_PRIORITY_INSERT_SECONDS * 1000):
            return None
        state = self._states[language]
        if state['startedAt'] is None:
            return state, [], None, None
        if any(left < start_ms < right for left, right in state['slots']):
            return None
        slots = [(left + delta_ms, right + delta_ms) if left >= start_ms else (left, right)
                 for left, right in state['slots']]
        started, tail = slots[0][0], slots[-1][1]
        if not _clock_ms(tail) or tail - started > SESSION_WALL_SECONDS * 1000:
            return None
        return state, slots, started, tail

    def can_shift_future(self, language, start_ms, delta_ms, now_ms):
        """Pure preflight for the station's future priority-clip insertion."""
        return self._shift_plan(language, start_ms, delta_ms, now_ms) is not None

    def shift_future(self, language, start_ms, delta_ms, now_ms):
        """Follow a validated queue shift without earning any extra speech.

        Call under the station lock after matching queue/airtime clocks move.
        Moving the first future slot also moves the next ten-minute due clock.
        An insertion between quotes retains the actual first slot and may not
        push the final quote beyond its 180-second session wall.
        """
        plan = self._shift_plan(language, start_ms, delta_ms, now_ms)
        if plan is None:
            return False
        state, slots, started, tail = plan
        if started is not None:
            state.update(slots=slots, startedAt=started, lastEndAt=tail)
        return True

    def status(self, language, now_ms):
        if language not in self._states or not _clock_ms(now_ms):
            return {'due': False, 'active': False, 'scheduledSeconds': 0,
                    'targetSeconds': TARGET_SECONDS, 'nextDueAt': None, 'emittedPosts': 0}
        state, active, due, next_due, _number, _session_id = self._view(language, now_ms)
        return {'due': due, 'active': active, 'scheduledSeconds': state['scheduledMs'] / 1000,
                'targetSeconds': TARGET_SECONDS, 'intervalSeconds': INTERVAL_SECONDS,
                'readStyle': 'handle-and-complete-comment', 'maxQuoteSeconds': MAX_TURN_SECONDS,
                'preferredQuoteSeconds': 25, 'spokenSourceClocks': False,
                'maxPostAgeSeconds': MAX_POST_AGE_SECONDS,
                'maxParentAgeSeconds': MAX_PARENT_AGE_SECONDS,
                'nextDueAt': next_due, 'emittedPosts': len(state['posts']),
                'sessionStartedAt': state['startedAt']}

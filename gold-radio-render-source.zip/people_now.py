"""A bounded, exact-quote public-opinion segment; no model or network access.

Candidate reads are side-effect free. Only successfully scheduled, complete
audio advances a session. Public account names and opinions remain unverified,
unrepresentative and excluded from factual model context.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
from itertools import islice
import json
import math
import re
import unicodedata
import uuid

from news_freshness import is_fresh_news
from social_feedback import publisher_root, reaction_allowed as reply_allowed
from social_reactions import _language, reaction_allowed as opinion_allowed


POLICY_VERSION = 'people-now-exact-public-opinion-2026-10-25-v1'
INTERVAL_SECONDS = 600
TARGET_SECONDS = 120
SESSION_WALL_SECONDS = 180
MAX_POST_AGE_SECONDS = 1800
MAX_PARENT_AGE_SECONDS = 3600
PREFERRED_POST_AGE_SECONDS = 600
MAX_TURN_SECONDS = 90
MAX_STORIES = 1000
_MAX_MS = 253402300799000
_HEX_ID = re.compile(r'[a-f0-9]{32}')


def _clock_ms(value):
    return type(value) is int and 0 < value <= _MAX_MS


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        allow_nan=False, separators=(',', ':')).encode()).hexdigest()


def _author(row):
    metadata = row['feedback' if row['sourceKind'] == 'social-feedback' else 'reaction']
    # Use the stable provider identity as well as the handle when preventing
    # repeat authors. A handle change does not create another person.
    identity = ('Bluesky:' + metadata['authorDid'] if row['sourceKind'] == 'social-feedback'
                else 'Mastodon:' + metadata['authorId'])
    post_id = (metadata['replyUri'] if row['sourceKind'] == 'social-feedback' else metadata['statusId'])
    return metadata, identity, post_id


def _speech(row):
    metadata, _identity, _post_id = _author(row)
    handle, name = metadata['authorHandle'], metadata.get('authorName')
    clock = datetime.fromtimestamp(row['publishedAt'], timezone.utc).strftime('%H:%M UTC')
    # Keep the profile name in metadata even when its script cannot be voiced
    # by this channel. Do not transliterate an account into another identity.
    if name and row['language'] == 'en' and any(
            c.isalpha() and 'LATIN' not in unicodedata.name(c, '') for c in name):
        name = None
    if row['language'] == 'ar':
        name_text = f' اسم العرض للحساب، غير المتحقق منه: {name}.' if name else ''
        context = (' رداً على منشور ' + metadata['rootSource'] if row['sourceKind'] == 'social-feedback'
                   else ' على ماستودون')
        if metadata.get('screeningKind') == 'bounded-news-opinion':
            context += '، ونص منشور المصدر: «' + metadata['rootTitle'] + '»'
        return (f'ماذا يقول الناس الآن. كتب الحساب @{handle}{context}.{name_text} '
                f'وقت النشر الأصلي المعلن من الحساب: {clock}. '
                f'هذا رأي فردي غير متحقق منه. اقتباس: «{row["title"]}» '
                'نهاية الاقتباس. هذا المنشور لا يمثل الرأي العام.')
    name_text = f' Unverified account display name: {name}.' if name else ''
    context = (' in reply to ' + metadata['rootSource'] if row['sourceKind'] == 'social-feedback'
               else ' on Mastodon')
    if metadata.get('screeningKind') == 'bounded-news-opinion':
        context += ', whose original post reads: “' + metadata['rootTitle'] + '”'
    return (f'What people say now. Account @{handle} posted{context}.{name_text} '
            f'Original author-reported post time: {clock}. '
            f'This is an individual, unverified opinion. Quote: “{row["title"]}” '
            'End quote. This post does not represent public opinion.')


def _estimate_seconds(text, language):
    # Planning only; actual complete WAV duration is the commit authority.
    # Count handle characters too, since long account names take time to read.
    return round(max(len(text) / (11 if language == 'ar' else 14),
                     len(text.split()) / (2 if language == 'ar' else 2.5)) + 2, 3)


def _sources_allowed(sources, admitted_ms, end_ms, language):
    if (not isinstance(sources, list) or not 1 <= len(sources) <= 2 or
            not all(isinstance(row, dict) for row in sources) or
            not _clock_ms(admitted_ms) or not _clock_ms(end_ms) or end_ms < admitted_ms):
        return False
    row = sources[0]
    admitted_s, end_s = admitted_ms // 1000, math.ceil(end_ms / 1000)
    if row.get('language') != language or language not in ('en', 'ar'):
        return False
    kind = row.get('sourceKind')
    guard = reply_allowed if kind == 'social-feedback' else opinion_allowed if kind == 'social-reaction' else None
    if (guard is None or not guard(row, admitted_s) or not guard(row, end_s) or
            _language(row.get('title', '')) != language or
            not is_fresh_news(row, admitted_s, max_age_s=MAX_POST_AGE_SECONDS, at_s=end_s)):
        return False
    # Compare milliseconds, without allowing a final fractional second beyond
    # the policy ceiling. Receipt or update clocks never renew this boundary.
    if end_ms - row['publishedAt'] * 1000 > MAX_POST_AGE_SECONDS * 1000:
        return False
    if kind == 'social-reaction':
        return len(sources) == 1
    if len(sources) != 2:
        return False
    root, metadata = sources[1], row['feedback']
    validated = publisher_root(root, admitted_s)
    if metadata.get('screeningKind') == 'bounded-news-opinion' and (
            metadata.get('rootTitle') != root.get('title') or _language(root.get('title', '')) != language):
        return False
    return bool(validated and validated['uri'] == metadata['rootUri'] and
        root.get('id') == metadata['rootId'] and root.get('url') == metadata['rootUrl'] and
        root.get('source') == metadata['rootSource'] and
        root.get('publishedAt') == metadata['rootPublishedAt'] and
        root['publishedAt'] <= row['publishedAt'] and
        is_fresh_news(root, admitted_s, max_age_s=MAX_PARENT_AGE_SECONDS, at_s=end_s) and
        end_ms - root['publishedAt'] * 1000 <= MAX_PARENT_AGE_SECONDS * 1000)


def _job_id(language, session_id, source_id):
    return _digest([POLICY_VERSION, language, session_id, source_id])[:32]


def _admission_digest(metadata, sources, speech, language):
    return _digest([POLICY_VERSION, {key: value for key, value in metadata.items()
        if key != 'admissionDigest'}, sources, speech, language])


def job_fresh(job, at_ms):
    """Revalidate original post and parent through the complete audio end.

    Admission time and full immutable source snapshots travel with the job.
    Matching metadata, exact speech and a content digest prevent an in-flight
    edit, changed clock or a different account name from replacing the quote.
    This is an internal consistency check, not independent identity proof.
    """
    try:
        if (not isinstance(job, dict) or job.get('kind') != 'people-now' or
                not _clock_ms(at_ms) or job.get('factualContextEligible') is not False):
            return False
        metadata, sources = job.get('peopleNow'), job.get('sources')
        if not isinstance(metadata, dict):
            return False
        admitted = metadata.get('admittedAt')
        if not _sources_allowed(sources, admitted, at_ms, job.get('language')):
            return False
        row = sources[0]
        author, _identity, post_id = _author(row)
        session_id, turn = metadata.get('sessionId'), metadata.get('turnIndex')
        if (not isinstance(session_id, str) or not _HEX_ID.fullmatch(session_id) or
                type(turn) is not int or not 0 <= turn < 120 or
                metadata.get('policyVersion') != POLICY_VERSION or
                metadata.get('intervalSeconds') != INTERVAL_SECONDS or
                metadata.get('targetSeconds') != TARGET_SECONDS or
                metadata.get('maxPostAgeSeconds') != MAX_POST_AGE_SECONDS or
                metadata.get('maxParentAgeSeconds') != MAX_PARENT_AGE_SECONDS or
                metadata.get('accountNameUnverified') is not True or
                metadata.get('unverified') is not True or metadata.get('representative') is not False or
                metadata.get('factualContextEligible') is not False or
                metadata.get('authorHandle') != author['authorHandle'] or
                metadata.get('sourcePostId') != post_id or
                metadata.get('originalPublishedAt') != row['publishedAt'] or
                metadata.get('sourceKind') != row['sourceKind'] or
                metadata.get('sourceDigest') != _digest(sources) or
                metadata.get('authorName') != author.get('authorName') or
                ('authorName' in metadata) != ('authorName' in author)):
            return False
        if row['sourceKind'] == 'social-feedback':
            if metadata.get('rootUrl') != author['rootUrl']:
                return False
        elif 'rootUrl' in metadata:
            return False
        expected_speech = _speech(row)
        estimate = _estimate_seconds(expected_speech, row['language'])
        return (metadata.get('admissionDigest') == _admission_digest(
                    metadata, sources, expected_speech, row['language']) and
                job.get('id') == _job_id(row['language'], session_id, row['id']) and
                job.get('sourceIds') == [row['id']] and job.get('speechText') == expected_speech and
                job.get('title') == row['title'] and job.get('source') == row['source'] and
                job.get('url') == row['url'] and job.get('publishedAt') == row['publishedAt'] and
                job.get('firstSeenAt') == row['firstSeenAt'] and job.get('social') is True and
                job.get('sourceKind') == row['sourceKind'] and job.get('platform') == row['platform'] and
                job.get('estimatedSeconds') == estimate and estimate <= MAX_TURN_SECONDS)
    except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
        return False


class PeopleNow:
    """Independent language sessions, starting only on a successful first slot."""

    def __init__(self):
        self._namespace = uuid.uuid4().hex
        self._states = {language: {'number': 0, 'startedAt': None, 'lastEndAt': None,
            'scheduledMs': 0, 'posts': set(), 'authors': set(), 'handles': set(), 'slots': []}
            for language in ('en', 'ar')}

    def _view(self, language, now_ms):
        state = self._states[language]
        started = state['startedAt']
        active = (started is not None and state['scheduledMs'] < TARGET_SECONDS * 1000 and
                  now_ms < started + SESSION_WALL_SECONDS * 1000)
        next_due = None if started is None else started + INTERVAL_SECONDS * 1000
        due = active or next_due is None or now_ms >= next_due
        number = state['number'] if active else state['number'] + 1
        session_id = _digest([self._namespace, language, number])[:32]
        return state, active, due, next_due, number, session_id

    def candidate(self, language, stories, now_ms, excluded=(), seen=()):
        if language not in self._states or not _clock_ms(now_ms):
            return None
        state, active, due, _next_due, _number, session_id = self._view(language, now_ms)
        if not due or isinstance(stories, (str, bytes, dict)):
            return None
        try:
            rows = list(islice(iter(stories), MAX_STORIES))
            blocked = set(excluded) | set(seen)
        except (TypeError, ValueError):
            return None
        roots = {row.get('id'): row for row in rows if isinstance(row, dict) and
                 isinstance(row.get('id'), str) and row.get('sourceKind') == 'social'}
        eligible = []
        for row in rows:
            if (not isinstance(row, dict) or row.get('language') != language or
                    row.get('sourceKind') not in ('social-feedback', 'social-reaction')):
                continue
            try:
                sources = [row]
                if row['sourceKind'] == 'social-feedback':
                    root = roots.get(row.get('feedback', {}).get('rootId'))
                    if root is None:
                        continue
                    sources.append(root)
                if not _sources_allowed(sources, now_ms, now_ms, language):
                    continue
                author, identity, post_id = _author(row)
                job_id = _job_id(language, session_id, row['id'])
                if ({row['id'], row['url'], post_id, job_id} & blocked or
                        active and (post_id in state['posts'] or identity in state['authors'] or
                                    author['authorHandle'].casefold() in state['handles'])):
                    continue
                speech = _speech(row)
                estimate = _estimate_seconds(speech, language)
                remaining_ms = TARGET_SECONDS * 1000 - (state['scheduledMs'] if active else 0)
                estimated_end = now_ms + math.ceil(estimate * 1000)
                if (estimate > MAX_TURN_SECONDS or estimate * 1000 > remaining_ms or
                        active and estimated_end > state['startedAt'] + SESSION_WALL_SECONDS * 1000 or
                        not _sources_allowed(sources, now_ms, estimated_end, language)):
                    continue
                metadata = {'policyVersion': POLICY_VERSION, 'sessionId': session_id,
                    'turnIndex': len(state['posts']) if active else 0,
                    'intervalSeconds': INTERVAL_SECONDS, 'targetSeconds': TARGET_SECONDS,
                    'maxPostAgeSeconds': MAX_POST_AGE_SECONDS, 'admittedAt': now_ms,
                    'maxParentAgeSeconds': MAX_PARENT_AGE_SECONDS,
                    'authorHandle': author['authorHandle'], 'accountNameUnverified': True,
                    'sourcePostId': post_id, 'originalPublishedAt': row['publishedAt'],
                    'sourceKind': row['sourceKind'], 'sourceDigest': _digest(sources),
                    'unverified': True, 'representative': False, 'factualContextEligible': False}
                if 'authorName' in author:
                    metadata['authorName'] = author['authorName']
                if row['sourceKind'] == 'social-feedback':
                    metadata['rootUrl'] = author['rootUrl']
                metadata['admissionDigest'] = _admission_digest(metadata, sources, speech, language)
                job = {key: row[key] for key in ('title', 'source', 'url', 'publishedAt',
                    'firstSeenAt', 'social', 'sourceKind', 'platform')}
                job.update(id=job_id, kind='people-now', language=language, speechText=speech,
                    sources=deepcopy(sources), sourceIds=[row['id']], peopleNow=metadata,
                    estimatedSeconds=estimate, factualContextEligible=False)
                age = now_ms - row['publishedAt'] * 1000
                eligible.append((age > PREFERRED_POST_AGE_SECONDS * 1000, -row['publishedAt'], row['id'], job))
            except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
                continue
        return min(eligible, key=lambda item: item[:3])[3] if eligible else None

    def _commit_plan(self, job, start_ms, end_ms):
        """Pure validation shared by the pre-write check and final commit."""
        if (not _clock_ms(start_ms) or not _clock_ms(end_ms) or
                not 0 < end_ms - start_ms <= MAX_TURN_SECONDS * 1000 or
                not job_fresh(job, end_ms)):
            return None
        language, metadata = job['language'], job['peopleNow']
        if language not in self._states or start_ms < metadata['admittedAt']:
            return None
        state, active, due, _next_due, number, session_id = self._view(language, start_ms)
        if (not due or metadata['sessionId'] != session_id or
                metadata['turnIndex'] != (len(state['posts']) if active else 0)):
            return None
        row = job['sources'][0]
        author, identity, post_id = _author(row)
        scheduled = state['scheduledMs'] if active else 0
        started = state['startedAt'] if active else start_ms
        if (scheduled + end_ms - start_ms > TARGET_SECONDS * 1000 or
                end_ms > started + SESSION_WALL_SECONDS * 1000 or
                active and (start_ms < state['lastEndAt'] or post_id in state['posts'] or
                            identity in state['authors'] or author['authorHandle'].casefold() in state['handles'])):
            return None
        return state, active, number, post_id, identity, author['authorHandle'].casefold()

    def can_commit(self, job, start_ms, end_ms):
        """Check a complete audio slot without consuming any session progress."""
        return self._commit_plan(job, start_ms, end_ms) is not None

    def commit(self, job, start_ms, end_ms):
        """Consume only complete scheduled audio, within actual per-session limits."""
        plan = self._commit_plan(job, start_ms, end_ms)
        if plan is None:
            return False
        state, active, number, post_id, identity, handle = plan
        if not active:
            state.update(number=number, startedAt=start_ms, scheduledMs=0,
                         posts=set(), authors=set(), handles=set(), slots=[])
        state['scheduledMs'] += end_ms - start_ms
        state['lastEndAt'] = end_ms
        state['posts'].add(post_id)
        state['authors'].add(identity)
        state['handles'].add(handle)
        state['slots'].append((start_ms, end_ms))
        return True

    def _shift_plan(self, language, start_ms, delta_ms, now_ms):
        """Validate an insertion at a complete-clip boundary, without mutation.

        The station separately rechecks each source through its shifted end.
        This planner owns session geometry and cadence, not the audio queue.
        """
        if (language not in self._states or not _clock_ms(start_ms) or
                not _clock_ms(now_ms) or start_ms <= now_ms or
                type(delta_ms) is not int or not 0 < delta_ms <= MAX_TURN_SECONDS * 1000):
            return None
        state = self._states[language]
        if state['startedAt'] is None:
            return state, [], None, None
        if any(left < start_ms < right for left, right in state['slots']):
            return None
        slots = [(left + delta_ms, right + delta_ms) if left >= start_ms else (left, right)
                 for left, right in state['slots']]
        started, tail = slots[0][0], slots[-1][1]
        if not _clock_ms(tail) or tail - started > SESSION_WALL_SECONDS * 1000:
            return None
        return state, slots, started, tail

    def can_shift_future(self, language, start_ms, delta_ms, now_ms):
        """Pure preflight for the station's future priority-clip insertion."""
        return self._shift_plan(language, start_ms, delta_ms, now_ms) is not None

    def shift_future(self, language, start_ms, delta_ms, now_ms):
        """Follow a validated queue shift without earning any extra speech.

        Call under the station lock after matching queue/airtime clocks move.
        Moving the first future slot also moves the next ten-minute due clock.
        An insertion between quotes retains the actual first slot and may not
        push the final quote beyond its 180-second session wall.
        """
        plan = self._shift_plan(language, start_ms, delta_ms, now_ms)
        if plan is None:
            return False
        state, slots, started, tail = plan
        if started is not None:
            state.update(slots=slots, startedAt=started, lastEndAt=tail)
        return True

    def status(self, language, now_ms):
        if language not in self._states or not _clock_ms(now_ms):
            return {'due': False, 'active': False, 'scheduledSeconds': 0,
                    'targetSeconds': TARGET_SECONDS, 'nextDueAt': None, 'emittedPosts': 0}
        state, active, due, next_due, _number, _session_id = self._view(language, now_ms)
        return {'due': due, 'active': active, 'scheduledSeconds': state['scheduledMs'] / 1000,
                'targetSeconds': TARGET_SECONDS, 'intervalSeconds': INTERVAL_SECONDS,
                'maxPostAgeSeconds': MAX_POST_AGE_SECONDS,
                'maxParentAgeSeconds': MAX_PARENT_AGE_SECONDS,
                'nextDueAt': next_due, 'emittedPosts': len(state['posts']),
                'sessionStartedAt': state['startedAt']}

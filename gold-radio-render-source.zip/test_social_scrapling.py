from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from social_sources import Response
from social_scrapling import (SocialScraplingCollector, ScraplingSocialCollector, LISTING_URLS,
    ORIGIN, MAX_BYTES, MAX_THREADS, MAX_WORKERS, MAX_AGE_S, MAX_CONTEXT_AGE_S,
    COLLECTION_BUDGET_S, REACTION_POLICY_VERSION, parse_listing, parse_thread,
    fetch_public, reaction_allowed, context_parent, opinion_text, request_url_allowed)


NOW = 1793006400
ROOT_ID = '50239748'
COMMENT_ID = '50240817'
TEXT = 'I think C++ software should be easier to understand and more useful for developers.'


def iso(stamp):
    return datetime.fromtimestamp(stamp, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')


def document(value, canonical=''):
    return ('<html><head>' + ('<link rel="canonical" href="' + canonical + '">' if canonical else '') +
            '</head><body>' + value + '</body></html>').encode()


def story(identity=ROOT_ID, age=7200, title='The result of the C++26 DIS ballot',
          href='https://example.org/business/software', count=2):
    return ('<tr class="athing submission" id="' + identity + '"><td><span class="titleline">' +
        '<a href="' + href + '">' + title + '</a></span></td></tr><tr><td class="subtext">' +
        '<a class="hnuser" href="user?id=editor">editor</a><span class="age" title="' + iso(NOW-age) + '">' +
        '<a href="item?id=' + identity + '">2 hours ago</a></span><a href="item?id=' + identity + '">' +
        str(count) + ' comments</a></td></tr>')


def comment(identity=COMMENT_ID, age=20, text=TEXT, author='Public_Reader', depth=0, width=0,
            extra='', prose_class='commtext c00', raw=None):
    return ('<tr class="athing comtr" id="' + identity + '"' + extra + '><td class="ind" indent="' +
        str(depth) + '"><img width="' + str(width) + '"></td><td class="default">' +
        '<a class="hnuser" href="user?id=' + author + '">' + author + '</a>' +
        '<span class="age" title="' + iso(NOW-age) + '"><a href="item?id=' + identity + '">now</a></span>' +
        '<div class="' + prose_class + '">' + (text if raw is None else raw) + '</div></td></tr>')


def listing(roots=None):
    return document('<table>' + (story() if roots is None else ''.join(roots)) + '</table>')


def thread(comments=None, root_story=None, identity=ROOT_ID):
    return document('<table class="fatitem">' + (story() if root_story is None else root_story) +
        '</table><table class="comment-tree">' +
        (comment() if comments is None else ''.join(comments)) + '</table>', ORIGIN + '/item?id=' + identity)


def root():
    return parse_listing(listing(), NOW)[0]


def row():
    return parse_thread(thread(), root(), NOW)[0]


class HNParsingTests(unittest.TestCase):
    def test_exact_complete_opinion_and_original_older_discussion_metadata(self):
        value = row()
        self.assertTrue(reaction_allowed(value, NOW))
        self.assertEqual(value['title'], TEXT)
        self.assertEqual(value['publishedAt'], NOW - 20)
        self.assertEqual(value['firstSeenAt'], NOW)
        self.assertEqual(value['reaction']['root']['publishedAt'], NOW - 7200)
        self.assertEqual(value['reaction']['screeningPolicy'], REACTION_POLICY_VERSION)
        self.assertEqual(value['reaction']['authorHandle'], 'Public_Reader')
        self.assertEqual(value['reaction']['authorId'], 'Public_Reader')
        self.assertNotIn('authorName', value['reaction'])
        self.assertEqual(value['source'], 'Public comment @Public_Reader on Hacker News')
        self.assertEqual(value['url'], ORIGIN + '/item?id=' + COMMENT_ID)
        self.assertEqual(value['id'], hashlib.sha256(('social-reaction:' + value['url']).encode()).hexdigest()[:32])
        parent = context_parent(value)
        self.assertEqual(parent, value['reaction']['root'])
        parent['title'] = 'changed'
        self.assertNotEqual(parent, value['reaction']['root'])
        def plain_json(item):
            if isinstance(item, dict):
                return all(type(key) is str and plain_json(value) for key, value in item.items())
            if isinstance(item, list):
                return all(plain_json(value) for value in item)
            return type(item) in (str, int, bool, float, type(None))
        self.assertTrue(plain_json(value), 'Scrapling TextHandler subclasses must not enter saved/translated rows')

    def test_hour_comment_and_day_context_boundaries_are_independent(self):
        for age, expected in ((0, 1), (3600, 1), (3601, 0), (-1, 0)):
            with self.subTest(comment_age=age):
                self.assertEqual(len(parse_thread(thread([comment(age=age)]), root(), NOW)), expected)
        for age, expected in ((86400, 1), (86401, 0), (-1, 0)):
            self.assertEqual(len(parse_listing(listing([story(age=age)]), NOW)), expected)
        value = row()
        self.assertTrue(reaction_allowed(value, NOW + MAX_AGE_S - 20))
        self.assertFalse(reaction_allowed(value, NOW + MAX_AGE_S - 19))
        recent_root = parse_listing(listing([story(age=86400)]), NOW)[0]
        value = parse_thread(thread(root_story=story(age=86400)), recent_root, NOW)[0]
        self.assertFalse(reaction_allowed(value, NOW + 1))

    def test_exact_utc_title_or_matching_epoch_is_required_not_relative_age(self):
        for old, new in ((iso(NOW-20), '20 seconds ago'), (iso(NOW-20), iso(NOW-20) + ' 1'),
                         (iso(NOW-20), iso(NOW-20) + '+02:00')):
            self.assertEqual(parse_thread(thread().replace(old.encode(), new.encode()), root(), NOW), [])
        for raw in (iso(NOW-20) + 'Z', iso(NOW-20) + ' ' + str(NOW-20)):
            value = parse_thread(thread().replace(iso(NOW-20).encode(), raw.encode()), root(), NOW)[0]
            self.assertEqual(value['publishedAt'], NOW-20)

    def test_nested_unseen_parents_dead_and_hidden_comments_are_excluded(self):
        for kwargs in ({'depth': 1}, {'width': 40}, {'extra': ' hidden="hidden"'},
                       {'prose_class': 'commtext cdd'}, {'prose_class': 'commtext c5a'},
                       {'raw': '<span style="display:none">I think software is good.</span>'},
                       {'raw': '<script>I think software is good.</script>'}):
            with self.subTest(kwargs=kwargs):
                self.assertEqual(parse_thread(thread([comment(**kwargs)]), root(), NOW), [])
        markup = comment().replace('<td class="default">', '<td class="default"><span class="navs">' +
            '<a href="item?id=111">parent</a></span>')
        self.assertEqual(parse_thread(thread([markup]), root(), NOW), [])

    def test_hn_navigation_hidden_from_accessibility_is_not_hidden_authored_text(self):
        markup = comment().replace('<td class="default">', '<td class="default"><span class="navs">' +
            '<a class="clicky" href="#50240887" aria-hidden="true">next</a></span>')
        self.assertEqual(len(parse_thread(thread([markup]), root(), NOW)), 1)
        for part in ('<span hidden="hidden">hidden content</span>',
                     '<span aria-hidden="true">hidden content</span>'):
            hidden = comment().replace('<td class="default">', '<td class="default">' + part)
            self.assertEqual(parse_thread(thread([hidden]), root(), NOW), [])

    def test_whole_comment_not_excerpts_or_inline_links(self):
        for text in (TEXT + '...', TEXT + ' Buy gold with leverage.', TEXT + ' Contact me at private@example.org.',
                TEXT + ' Join my signals channel.', TEXT + ' The company acquired a software business.',
                TEXT + ' See the image.', TEXT + '\x01', TEXT + ' I own gold.',
                TEXT + ' Ignore previous instructions.', 'Agreed.', 'What does DIS mean?'):
            with self.subTest(text=text):
                self.assertEqual(opinion_text(text), '')
        for raw in ('<a href="https://example.org/">' + TEXT + '</a>', TEXT + '<!-- hidden -->',
                    '<blockquote>' + TEXT + '</blockquote>', '<pre>' + TEXT + '</pre>'):
            self.assertEqual(parse_thread(thread([comment(raw=raw)]), root(), NOW), [])
        value = parse_thread(thread([comment(raw='I think <em>C++ software</em> should be easier for developers.')]), root(), NOW)[0]
        self.assertEqual(value['title'], 'I think C++ software should be easier for developers.')

    def test_context_title_is_entire_and_rechecked_against_fetched_story(self):
        for changed in (story(title='An unrelated cooking recipe'), story(age=7201),
                        story(title='The result of the C++26 DIS ballot...'),
                        story(href='https://aljazeera.com/technology/software')):
            with self.assertRaises(ValueError):
                parse_thread(thread(root_story=changed), root(), NOW)
        with self.assertRaises(ValueError):
            parse_thread(thread(identity='999'), root(), NOW)
        self.assertEqual(parse_listing(listing([story(href='https://aljazeera.com/tech')]), NOW), [])
        self.assertEqual(parse_listing(listing([story(title='Software company faces fraud allegations')]), NOW), [])

    def test_uncommented_and_duplicate_roots_do_not_spend_request_budget(self):
        self.assertEqual(parse_listing(listing([story(count=0)]), NOW), [])
        self.assertEqual(len(parse_listing(listing([story(), story()]), NOW)), 1)
        self.assertEqual(len(parse_thread(thread([comment(), comment()]), root(), NOW)), 1)

    def test_empty_truncated_oversized_and_non_utf8_html_fails_closed(self):
        for body in (b'', b'\xff</html>', b'x' * (MAX_BYTES+1), listing()[:-7], listing() + b'\x00'):
            with self.subTest(length=len(body)):
                with self.assertRaises((ValueError, UnicodeDecodeError)):
                    parse_listing(body, NOW)

    def test_restored_provenance_tampering_fails(self):
        value = row()
        for key, replacement in (('platform', 'Mastodon'), ('social', False), ('language', 'ar'),
                ('source', 'Public comment @other on Hacker News'), ('url', value['url'] + '&x=1'),
                ('title', ''), ('summary', 'added claim'), ('publishedAt', NOW - 10),
                ('firstSeenAt', NOW + 1), ('id', '0' * 32)):
            changed = deepcopy(value); changed[key] = replacement
            self.assertFalse(reaction_allowed(changed, NOW), key)
        for key, replacement in (('authorId', 'other'), ('authorHandle', 'Public_Reader@mastodon.social'),
                ('statusId', ROOT_ID), ('commentDepth', False), ('parentId', '1'),
                ('contentHash', '0' * 64), ('rawCommentHash', '0' * 64),
                ('rawCommentHtml', '<div class="commtext c00">I think software is useful.</div>'),
                ('createdAtRaw', iso(NOW - 10)), ('rootHash', '0' * 64), ('unverified', False),
                ('representative', True), ('screeningPolicy', 'other'), ('authorName', 'Real Identity')):
            changed = deepcopy(value); changed['reaction'][key] = replacement
            self.assertFalse(reaction_allowed(changed, NOW), key)
        for key, replacement in (('title', 'A different software title'), ('publishedAt', NOW-7201),
                ('createdAtRaw', iso(NOW-7201)), ('url', ORIGIN + '/item?id=1'),
                ('firstSeenAt', NOW + 1), ('storyUrl', 'https://arabnews.com/technology')):
            changed = deepcopy(value); changed['reaction']['root'][key] = replacement
            self.assertFalse(reaction_allowed(changed, NOW), key)


class HNTransportTests(unittest.TestCase):
    def test_only_exact_fixed_https_routes_are_allowed(self):
        for url in (*LISTING_URLS, ORIGIN + '/item?id=123'):
            self.assertTrue(request_url_allowed(url))
        for url in (ORIGIN + '/newest?page=2', ORIGIN + '/item?id=0', ORIGIN + '/item?id=123&x=1',
                ORIGIN + '/item?id=123#123', ORIGIN + '/user?id=reader',
                'http://news.ycombinator.com/newest', 'https://evil.example/newest',
                'https://news.ycombinator.com.evil.example/newest'):
            with self.subTest(url=url), patch('scrapling.fetchers.Fetcher.get') as get:
                with self.assertRaises(ValueError):
                    fetch_public(url, {}, 1)
                get.assert_not_called()

    def test_static_fetcher_disables_redirects_retry_stealth_browser_and_proxy(self):
        def fake(url, **kwargs):
            self.assertEqual(kwargs['retries'], 0)
            self.assertIs(kwargs['follow_redirects'], False)
            self.assertEqual(kwargs['max_redirects'], 0)
            self.assertIsNone(kwargs['impersonate'])
            self.assertIs(kwargs['stealthy_headers'], False)
            self.assertEqual(kwargs['proxies'], {'all': ''})
            self.assertNotIn('Authorization', kwargs['headers'])
            self.assertEqual(kwargs['content_callback'](listing()), len(listing()))
            return SimpleNamespace(status=200, headers={'Content-Type': 'text/html'}, url=url, history=[])
        with patch('scrapling.fetchers.Fetcher.get', fake):
            result = fetch_public(LISTING_URLS[0], {'Authorization': 'never-forward'}, 1)
        self.assertEqual(result.body, listing())

    def test_body_limit_applies_during_transfer_without_content_length(self):
        def fake(url, **kwargs):
            callback = kwargs['content_callback']
            self.assertEqual(callback(b'a' * MAX_BYTES), MAX_BYTES)
            self.assertEqual(callback(b'b'), 0xFFFFFFFF)
            return SimpleNamespace(status=200, headers={'Content-Type': 'text/html'}, url=url, history=[])
        with patch('scrapling.fetchers.Fetcher.get', fake):
            with self.assertRaises(ValueError):
                fetch_public(LISTING_URLS[0], {}, 1)

    def test_redirect_or_compressed_or_declared_oversize_response_is_rejected(self):
        for changes in ({'url': 'https://other.example/'}, {'history': [object()]},
                        {'headers': {'content-length': str(MAX_BYTES+1)}},
                        {'headers': {'content-encoding': 'gzip'}}):
            response = SimpleNamespace(status=200, headers={'Content-Type': 'text/html'},
                                       url=LISTING_URLS[0], history=[])
            for key, value in changes.items():
                setattr(response, key, value)
            with patch('scrapling.fetchers.Fetcher.get', return_value=response):
                with self.assertRaises(ValueError):
                    fetch_public(LISTING_URLS[0], {}, 1)


class HNCollectorTests(unittest.TestCase):
    def collector(self, fetch):
        collector = SocialScraplingCollector(fetch)
        self.addCleanup(collector._pool.shutdown, wait=True, cancel_futures=True)
        return collector

    def test_collect_polling_status_and_first_receipt_freeze(self):
        calls = []
        def fetch(url, _headers, _timeout):
            calls.append(url)
            return Response(200, {'content-type': 'text/html'},
                            listing() if url in LISTING_URLS else thread(), url)
        collector = self.collector(fetch)
        self.assertIs(ScraplingSocialCollector, SocialScraplingCollector)
        first = collector.collect(NOW)
        self.assertEqual(len(first), 1)
        self.assertEqual(collector.collect(NOW + 59), [])
        self.assertEqual(len(calls), 3)
        second = collector.collect(NOW + 60)
        self.assertEqual(second, first)
        status = collector.status()
        self.assertEqual(status['status'], 'ready')
        self.assertEqual(status['enabledSourceCount'], 1)
        self.assertEqual(status['readySources'], 1)
        self.assertIn('Scrapling static', status['transport'])
        self.assertIn('no PC', status['transport'])

    def test_changed_comment_or_context_cannot_replace_first_receipt(self):
        altered = False
        def fetch(url, _headers, _timeout):
            body = listing() if url in LISTING_URLS else thread([comment(
                text='I think C++ software should be more useful and easier to learn.' if altered else TEXT)])
            return Response(200, {'content-type': 'text/html'}, body, url)
        collector = self.collector(fetch)
        self.assertEqual(len(collector.collect(NOW)), 1)
        altered = True
        self.assertEqual(collector.collect(NOW+60), [])
        self.assertEqual(next(iter(collector._receipts.values()))['title'], TEXT)

    def test_four_thread_limit_two_workers_and_rotation(self):
        calls, active, maximum, guard = [], 0, 0, threading.Lock()
        identities = [str(int(ROOT_ID)+offset) for offset in range(6)]
        stories = {identity: story(identity=identity, age=7200+offset) for offset, identity in enumerate(identities)}
        def fetch(url, _headers, timeout):
            nonlocal active, maximum
            self.assertLessEqual(timeout, COLLECTION_BUDGET_S)
            with guard:
                calls.append(url); active += 1; maximum = max(maximum, active)
            time.sleep(.005)
            if url in LISTING_URLS:
                body = listing(list(stories.values()))
            else:
                identity = url.split('=')[1]
                body = thread([comment(identity=str(int(identity)+100), age=20)], stories[identity], identity)
            with guard:
                active -= 1
            return Response(200, {'content-type': 'text/html'}, body, url)
        collector = self.collector(fetch)
        self.assertEqual(len(collector.collect(NOW)), MAX_THREADS)
        self.assertLessEqual(maximum, MAX_WORKERS)
        self.assertEqual(len([url for url in calls if url not in LISTING_URLS]), MAX_THREADS)
        calls.clear()
        collector.collect(NOW+60)
        threaded = [url for url in calls if url not in LISTING_URLS]
        self.assertIn(ORIGIN + '/item?id=' + identities[-1], threaded)
        self.assertIn(ORIGIN + '/item?id=' + identities[-2], threaded)

    def test_shared_access_denial_or_quota_backs_off_all_requests(self):
        for status in (403, 429):
            calls = []
            def fetch(url, _headers, _timeout):
                calls.append(url)
                return Response(status, {'retry-after': '600'}, b'', url)
            collector = self.collector(fetch)
            self.assertEqual(collector.collect(NOW), [])
            self.assertEqual(collector.collect(NOW+60), [])
            self.assertEqual(len(calls), 2)
            state = collector.status()
            self.assertEqual(state['status'], 'access_denied' if status == 403 else 'rate_limited')
            self.assertGreaterEqual(state['nextCheckAt'], (NOW+600)*1000)

    def test_malformed_or_redirected_http_does_not_supply_rows(self):
        for response in (Response(200, {'content-type': 'application/json'}, b'[]', LISTING_URLS[0]),
                         Response(200, {'content-type': 'text/html'}, listing(), 'https://other.example/'),
                         Response(200, {'content-type': 'text/html'}, b'x'*(MAX_BYTES+1), LISTING_URLS[0])):
            collector = self.collector(lambda *_: response)
            self.assertEqual(collector.collect(NOW), [])
            self.assertIsNotNone(collector.status()['sources'][0]['error'])


if __name__ == '__main__':
    unittest.main()

"""Delete only expired, generated direct-child audio files in owned state.

No recursive deletion, author-selected paths, model assets, source history,
provider ledgers or credentials are handled by this module.
"""
from pathlib import Path
import re
import stat


def clean_audio(directory, keep, cutoff_s, *, hash_length=32):
    result = {'filesDeleted': 0, 'bytesDeleted': 0, 'errors': 0}
    root = Path(directory)
    if hash_length not in (32, 64):
        raise ValueError('Unsupported generated-audio identity')
    try:
        # Resolving an alias before deleting could silently change the target.
        # Reject aliased roots/ancestors; never traverse a linked child either.
        if root.resolve() != root.absolute() or any(p.is_symlink() for p in (root, *root.parents)):
            result['errors'] += 1
            return result
        if not root.exists():
            return result
        for path in root.iterdir():
            if not re.fullmatch(r'[a-f0-9]{' + str(hash_length) + r'}\.(?:wav|mp3)', path.name) or path.stem in keep:
                continue
            try:
                info = path.lstat()
                if not stat.S_ISREG(info.st_mode) or info.st_mtime > cutoff_s:
                    continue
                path.unlink()
                result['filesDeleted'] += 1
                result['bytesDeleted'] += info.st_size
            except FileNotFoundError:
                pass  # Another owner worker already removed this expired file.
            except OSError:
                result['errors'] += 1
    except OSError:
        result['errors'] += 1
    return result

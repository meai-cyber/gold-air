"""Complete collected news items, rather than a cut-off word preview.

This formats already collected public titles and retrieved teasers. It does not
fetch or invent an article, and an incomplete teaser tail is never read aloud.
"""
from datetime import datetime, timezone
from html import unescape
from html.parser import HTMLParser
import re
import unicodedata


MAX_TITLE_CHARACTERS = 400
MAX_SOURCE_BODY_CHARACTERS = 800
MAX_SUMMARY_CHARACTERS = 400


class _PublicText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.hidden = [], []

    def handle_starttag(self, tag, attrs):
        if tag in {'script', 'style', 'noscript', 'template'}:
            self.hidden.append(tag)
        elif not self.hidden:
            self.parts.append(' ')

    def handle_endtag(self, tag):
        if self.hidden:
            if tag == self.hidden[-1]:
                self.hidden.pop()
        else:
            self.parts.append(' ')

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def _clean(value):
    if not isinstance(value, str) or len(value) > 8192:
        raise ValueError('A bounded collected public news item is required')
    parser = _PublicText()
    parser.feed(unescape(value))
    parser.close()
    text = re.sub(r'https?://\S+|www\.\S+', '', ''.join(parser.parts), flags=re.I)
    text = ''.join(c for c in text if not unicodedata.category(c).startswith('C') or c in '\n\r\t')
    return re.sub(r'\s+', ' ', text).strip()


_END = re.compile(r'[.!?؟]+["\u201d\u2019»\')\]]*(?=\s|$)')
_ABBREVIATION = re.compile(r'(?:\b[A-Za-z]\.){2,}$|\b(?:Mr|Mrs|Ms|Dr|Prof|St|vs|etc|e\.g|i\.e)\.$', re.I)


def _sentences(text):
    """Yield only terminated sentence units, keeping dotted abbreviations intact."""
    start = 0
    for match in _END.finditer(text):
        punctuation = text[match.start():match.end()].rstrip('"\u201d\u2019»\')\]')
        if punctuation == '.' and _ABBREVIATION.search(text[:match.start() + 1]):
            continue
        value = text[start:match.end()].strip()
        if value:
            yield value
        start = match.end()


def _terminated(text):
    return text.rstrip('"\u201d\u2019»\')\]').endswith(('.', '!', '?', '؟', '؛'))


def complete_prefix(text, limit):
    """Bound an oversized source field only at complete sentence boundaries."""
    if len(text) <= limit:
        return text
    parts = []
    for sentence in _sentences(text):
        if len(' '.join(parts + [sentence])) > limit:
            break
        parts.append(sentence)
    return ' '.join(parts)


def _full_stop(text):
    return text if _terminated(text) else text + '.'


def _comparison(text):
    # Curly punctuation in a headline and plain punctuation in its feed teaser
    # are the same words. Preserve the actual source wording when speaking.
    return re.sub(r'[^\w]+', ' ', unicodedata.normalize('NFKC', text).casefold()).strip()


def public_report_text(story):
    """Read the entire collected title, plus complete retrieved teaser sentences.

    A title is an independent collected headline and may have no punctuation.
    Teasers can have been clipped by their feed, so their unfinished last clause
    is omitted. Whole sentence units fit the bounded source body or are omitted;
    no word slicing is used. Source attribution and clocks are not rewritten.
    """
    language = story.get('language')
    if language not in {'ar', 'en'}:
        raise ValueError('Unsupported news language')
    title = _clean(story.get('title'))
    source = _clean(story.get('source'))
    if not title or len(title) > MAX_TITLE_CHARACTERS or not source or len(source) > 160:
        raise ValueError('A complete bounded title and source are required')
    body = title
    summary = _clean(story.get('summary') or '')
    if summary.casefold().startswith(title.casefold()):
        tail = summary[len(title):]
        # An extended headline ("Gold rises by two percent") is not a duplicate
        # sentence of the shorter title ("Gold rises"). Keep it grammatically intact.
        if not tail or _terminated(title) or tail[:1] in '.:–—-':
            summary = tail.lstrip(' .:–—-')
    summary_used = 0
    for sentence in _sentences(summary):
        if _comparison(sentence) == _comparison(title):
            continue
        separator = ' ' if _terminated(body) else '. '
        if (summary_used + len(sentence) > MAX_SUMMARY_CHARACTERS or
                len(body) + len(separator) + len(sentence) > MAX_SOURCE_BODY_CHARACTERS):
            break
        body += separator + sentence
        summary_used += len(sentence) + 1
    body = _full_stop(body)
    social = story.get('social') is True
    if social and story.get('sourceKind') == 'social-feedback':
        text = (f'رد عام غير متحقق منه، لا يمثل رأي الجمهور. من {source}، {body}' if language == 'ar'
                else f'Unverified public reply, not a representative opinion sample. From {source}: {body}')
    elif social:
        text = f'في منشور عام من {source}، {body}' if language == 'ar' else f'Public post from {source}: {body}'
    else:
        text = f'من {source}، {body}' if language == 'ar' else f'From {source}: {body}'
    if story.get('recency') == 'earlier':
        stamp = story.get('publishedAt')
        if type(stamp) is not int or stamp <= 0:
            raise ValueError('An earlier report requires its original source clock')
        clock = datetime.fromtimestamp(stamp, timezone.utc).strftime('%H:%M')
        if social:
            text = (f'منشور سابق، وقته حسب المصدر {clock} بالتوقيت العالمي. ' if language == 'ar'
                    else f'Earlier post, source-reported time {clock} UTC. ') + text
        else:
            text = (f'خبر سابق نُشر الساعة {clock} بالتوقيت العالمي. ' if language == 'ar'
                    else f'Earlier report, published at {clock} UTC. ') + text
    return text

# Server speech implementation

This folder is a separate, self-contained Gold Pulse radio service. The Docker
build context is the repository root; the Dockerfile copies only this folder.
It never connects to a PC, Windows account, tunnel, local database, localhost
model API or household memories. No registration/account data is migrated.

The web server owns `ServerTts` and supplies only excerpts from its fixed public
news feeds. There is no public synthesis endpoint, arbitrary fetch endpoint,
model-path selector or voice-upload API. English and Arabic are separate shared
broadcast clocks, not separate generation jobs for every listener.

## Voices and public data

- Arabic2: Nabra FP32, native ONNX Runtime **1.30.0 CPUExecutionProvider**, one
  thread; matching reviewed Nabra G2P in a private Node pipe. Piper's small
  offline Arabic vowel restoration runs on one CPU thread before pronunciation.
  Arabic never falls back to English or a network Arabic voice.
- English: **edge-tts 7.3.1**, fixed `en-US-JennyNeural`, requested by the Render
  server. This is a **network speech service**, not local CPU model inference.
  Only the selected public news text is transmitted. ffmpeg converts the result
  to bounded mono 24 kHz PCM16 WAV using fixed pipe arguments.
- No LLM, embeddings, price model, manufactured news or trading signal is added
  by this speech package.

## Pins and build

`bootstrap.py` downloads only fixed public URLs at image build time and checks
SHA256 and bounded lengths. It writes assets to `/opt/gold-radio-assets`, outside
the application. Runtime model downloading is disabled.

Nabra model: `oddadmix/Nabra-7M-Distill-ONNX`, revision
`bbac0f1e6b001bfae89871be366a4b000180deb2`.

FP32 `model/model.onnx`: 30,542,978 bytes, SHA256
`08c1df048f2decbff3f86dc8e625e10ff3c8d5f66dfc97881c6974272f41ca5e`.
This local runtime filename is downloaded from repository `onnx/model.onnx`.

Voice `model/af_msa.bin`: 522,240 bytes, SHA256
`129d447a7c9bdce1d5b6cb5ecb789bbfd9f427b7775131a97dfa5638583b3b92`.
The repository path is `voices/af_msa.bin`; both full remote downloads were
tested and matched the fixed sizes and SHA256 hashes.

G2P source: `Oddadmix/nabra-tts`, revision
`16b5281ce61993df3526740990cf845a3f3036f4`; bundled `vendor/g2p.mjs` SHA256
`8f00bba1b4b97eaa9342dc68cf6b11e2c926d714052c035228d10ad69ad93d0c`.
It includes eSpeak NG 1.52.0 and matching Arabic phonemizer logic.

The pinned Piper 1.8.0 Linux wheel is downloaded and verified, but is **not
installed or executed**. Only the 4,788,213-byte tashkeel model, matching maps,
reviewed Python vowel module and license are extracted. All five resource hashes
are checked at startup. Linux wheel text uses LF line endings; it was compared
with the previously reviewed Windows resources and differs only in line endings.

The Docker process is non-root. Models are read-only. Audio and state are bounded
and ephemeral under `/tmp/gold-radio-data`; a Render restart resets its queue.
There is one scheduler/server process, rather than multiple competing workers.

## Contract

```python
from tts import ServerTts

tts = ServerTts()  # assets from RADIO_MODEL_DIR, default /opt/gold-radio-assets
tts.available_languages  # ('ar', 'en')
speech = tts.synthesize(public_news_excerpt, language='ar')
# speech.wav: bytes, actual mono 24 kHz PCM16 RIFF/WAV
# speech.duration_s, speech.inference_s: measured floats
# speech.engine, speech.language: honest engine and language identifiers
tts.close()
```

Calls serialize across both voices to limit CPU/memory contention. This method
is intended for the scheduler's background thread, not an HTTP request handler.
Every text is bounded to 1,200 characters; the station should keep excerpts much
shorter. Unknown phonemes, changed assets, bad audio, expired inference deadlines
or altered base text during vowel restoration fail closed.

## Verification on this PC, 22 October 2026

Nine focused contract tests pass, including the Linux `/app` asset-path boundary,
G2P hash, numeric pronunciation, preserved base words, language validation and
actual WAV lengths. The Node G2P worker passes syntax validation. Build downloads
and the pinned source archive were exercised successfully.

One real **Windows CPU** smoke used the same portable module, FP32 model and
one thread, alongside the owner's existing services. Loading took **5.007 s**;
**7.95 s** of Arabic audio took **5.390 s** to generate. Peak combined Python and
owned Node process RSS was **302,522,368 bytes** (~289 MiB). The audio was nonzero
mono PCM16 at 24 kHz. This is not a Render/Linux benchmark or human listening
confirmation. No existing radio, PC model or native DLL was changed.

Free Render CPU is substantially smaller than this PC; free-service sleep,
generation latency and model memory must be verified after deployment. These
measurements do not establish continuous real-time generation or uptime on
Render. English additionally depends on the availability of its remote voice.

## Notices

Nabra model/source: Apache-2.0. ONNX Runtime: MIT. Nabra's bundled eSpeak NG and
derived phonemizer logic: GPL-3.0-or-later. Piper tashkeel resources/code are
distributed under Piper's bundled GPL notice. `vendor/` retains Nabra's source
license and third-party notices. The image retains the complete pinned upstream
Nabra source archive/build instructions and Piper's COPYING under the model
directory's `licenses/`. eSpeak NG upstream source is available at
https://github.com/espeak-ng/espeak-ng/tree/1.52.0 and the vowel implementation
documents https://github.com/mush42/libtashkeel.

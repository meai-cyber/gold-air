# Server speech implementation

## 24 October: changed prices and Phonon English

`RADIO_ENGLISH_TTS=phonon40` selects `gradium/phonon-40m-en`, revision
`cc738b7e4d182c2ba1bafb8062aa4846af000637`, native `ptts==0.4.1`, CPU/q8,
one inference thread and the embedded default voice. Four pinned files total
75,092,305 bytes; `phonon_assets.py` contains their verified SHA256 values.
Weights use CC BY-NC 4.0 and require owner-approved Hugging Face access. They
are outside the source ZIP/repository. The web page attributes Gradium and the
license. This profile is unsuitable for commercial use under that license.

Render receives only a temporary model-specific build grant as secret file
`phonon-build.json`, mounted with BuildKit ID `phonon-build_json`. It contains
three small model resources and a scoped, expiring official CDN download URL
for the pinned weights. No Hugging Face account token is stored on Render or in
an image/repository. Build-time integrity checks cover every file. The grant
must be refreshed for an uncached future build after its URL expires.
The JSON is zlib-compressed/base64-wrapped to 428,139 bytes for Docker's
500 KiB secret limit; bounded decompression permits at most 1 MiB of JSON.

English uses a resident, private subprocess. Complete float32 chunks are
converted to bounded mono 24 kHz PCM16; invalid/nonfinite/silent or overlong
audio fails whole. A 45-second hard timeout and container memory guards close
the worker, then the existing network voice keeps news available. Native
failure disables native retries until service restart. Arabic remains Nabra
FP32 with offline vowels. Actual clip/startup metadata records the used engine,
inference time and first generated chunk; that chunk time excludes model load
and is not listener latency. Shared playback still schedules complete clips.

Native English is limited to complete items of at most 120 characters AND
22 words. Longer reports go directly to the previous network voice, unchanged;
this bypass does not disable native speech or unload Arabic. The measured free
Render native sample took 12.191 seconds for 3.6 seconds of audio; a longer
174-character report exceeded 45 seconds. This host is not near-real-time for
native 40M speech. The previous voice remains the practical long-report path.

In a bounded Linux container, the service releases Arabic before English when
less than 320 MiB is free, and releases English before Arabic below 160 MiB.
The vowel model stays resident. Native fallback exposes only a fixed reason
code, never a model path, token or raw native exception. This avoids assuming
both speech models can stay resident inside the free service's 512 MiB quota.

Both market bulletins and observed gold briefings now need a changed price at
spoken-cent precision. The first fresh quote silently seeds each language;
timestamp-only refreshes and sub-cent fluctuations do not repeat commentary.
Only a successfully queued price clip advances its announced reference. News
is independent of this rule. No price source, forecast or saved history changes.

The remaining sections describe the baseline Arabic/network voice setup; the
profile above overrides the English engine when native generation succeeds.

This folder is a separate, self-contained Gold Pulse radio service. The Docker
build context is the repository root; the Dockerfile copies only this folder.
This cloud-news edition collects news and gold quotes, selects relevant reports
and generates speech without a PC. The previous public-discussion importer is
not initialized, even when a legacy environment flag remains enabled. No PC
station, local inference endpoint, Windows account, local database or household
memory is accessed. No account data is migrated.

The web server owns `ServerTts` and supplies only excerpts from its fixed public
news feeds and observed Gold API quotes.
It also collects fixed public publisher social channels through bounded static
Telegram previews and Bluesky author APIs. Public posts are attributed in the
audio and labelled unverified in the page, with source-reported creation and
first-receipt clocks preserved separately. Search denials are respected. No
public search, firehose, login, private timeline or PC forwarding is required.
There is no public synthesis endpoint, arbitrary fetch endpoint,
model-path selector or voice-upload API. English and Arabic are separate shared
broadcast clocks, not separate generation jobs for every listener.

## Voices and public data

- Arabic2: Nabra FP32, native ONNX Runtime **1.30.0 CPUExecutionProvider**, one
  thread; matching reviewed Nabra G2P in a private Node pipe. Piper's small
  offline Arabic vowel restoration runs on one CPU thread before pronunciation.
  Arabic never falls back to English or a network Arabic voice.
- English: **edge-tts 7.3.1**, fixed `en-US-JennyNeural`, requested by the Render
  server. This is a **network speech service**, not local CPU model inference.
  Only selected public station text is transmitted. ffmpeg converts the result
  to bounded mono 24 kHz PCM16 WAV using fixed pipe arguments.
- No LLM, embeddings or prediction model is hosted by this speech package.
  Fixed-source price briefs describe real observations. A deterministic
  bilingual gold/macro topic filter selects ceil(40% of relevant unique fresh
  reports); unrelated stories do not fill the quota. Selection covers all
  retained stories before excluding playback receipts, so draining the queue
  cannot automatically admit the omitted 60%. Counts and named topic rules are
  available in manifests. This is editorial selection, not verified facts,
  calibrated probabilities or demonstrated trading signals.

## Pins and build

`bootstrap.py` downloads only fixed public URLs at image build time and checks
SHA256 and bounded lengths. It writes assets to `/opt/gold-radio-assets`, outside
the application. Runtime model downloading is disabled.

Nabra model: `oddadmix/Nabra-7M-Distill-ONNX`, revision
`bbac0f1e6b001bfae89871be366a4b000180deb2`.

FP32 `model/model.onnx`: 30,542,978 bytes, SHA256
`08c1df048f2decbff3f86dc8e625e10ff3c8d5f66dfc97881c6974272f41ca5e`.
This local runtime filename is downloaded from repository `onnx/model.onnx`.

Voice `model/af_msa.bin`: 522,240 bytes, SHA256
`129d447a7c9bdce1d5b6cb5ecb789bbfd9f427b7775131a97dfa5638583b3b92`.
The repository path is `voices/af_msa.bin`; both full remote downloads were
tested and matched the fixed sizes and SHA256 hashes.

G2P source: `Oddadmix/nabra-tts`, revision
`16b5281ce61993df3526740990cf845a3f3036f4`; bundled `vendor/g2p.mjs` SHA256
`8f00bba1b4b97eaa9342dc68cf6b11e2c926d714052c035228d10ad69ad93d0c`.
It includes eSpeak NG 1.52.0 and matching Arabic phonemizer logic.

The pinned Piper 1.8.0 Linux wheel is downloaded and verified, but is **not
installed or executed**. Only the 4,788,213-byte tashkeel model, matching maps,
reviewed Python vowel module and license are extracted. All five resource hashes
are checked at startup. Linux wheel text uses LF line endings; it was compared
with the previously reviewed Windows resources and differs only in line endings.

The Docker process is non-root. Models are read-only. Audio and state are bounded
and ephemeral under `/tmp/gold-radio-data`; a Render restart resets its queue.
There is one scheduler/server process, rather than multiple competing workers.

## Contract

```python
from tts import ServerTts

tts = ServerTts()  # assets from RADIO_MODEL_DIR, default /opt/gold-radio-assets
tts.available_languages  # ('ar', 'en')
speech = tts.synthesize(public_news_excerpt, language='ar')
# speech.wav: bytes, actual mono 24 kHz PCM16 RIFF/WAV
# speech.duration_s, speech.inference_s: measured floats
# speech.engine, speech.language: honest engine and language identifiers
tts.close()
```

Calls serialize across both voices to limit CPU/memory contention. This method
is intended for the scheduler's background thread, not an HTTP request handler.
Every text is bounded to 1,200 characters; the station should keep excerpts much
shorter. Unknown phonemes, changed assets, bad audio, expired inference deadlines
or altered base text during vowel restoration fail closed.

## Cloud-only collection, 23 October

The later continuous-news release adds Euronews Arabic and English, bringing the
configured collection to 19 sources including individual live updates. Latest
ten-minute reports have priority; only when that selected queue is empty does
the producer read relevant, previously unspoken 10–60-minute reports. These
items are labelled `EARLIER REPORT` in the player and their original publication
time is announced in speech. Each cohort keeps the top-40% rule and receipts;
the station does not recycle a spoken report merely to fill airtime. A short
retrieved teaser can supplement a title using complete sentences only, within
an 800-character source body. The 24-word cutoff is removed. Complete collected
titles retain their ending, and oversized source fields are sentence-bounded
or rejected. Clips support up to 90 seconds consistently in server and player.
No new article facts or analysis are generated by an LLM.

Factual gold briefings have a separate approximately three-minute cadence when
enough fresh observations exist. They describe observed changes/ranges and
eligible publisher topics without making forecasts or causal claims. Twelve-second
music breaks follow complete news bursts or briefings. No cloud LLM podcast is
connected on this free instance.

The refined-radio release rotates three observed-curve briefing styles and
provider-minute price openings. Ordinary bulletins combine all available
1/5/10-minute deltas into a compact sentence; missing intervals remain absent.
Equal-score admitted news prefers a different topic/source, while higher-scored
gold reports and the 40% cohort quota retain priority. A learned speech-time
estimate plus queued start checks quote feasibility before synthesis; the final
90-second source-age check still applies after synthesis. No expiry is relaxed.
The reference-price strip clears stale prices/deltas and stays independent of
TradingView/OANDA. The full spoken transcript is in an expandable panel below
playback controls.

The producer prepares up to about 45 seconds ahead with a bounded 12-clip queue
per language. The new original `station-relax-v2.wav` is a 120-second, 64 BPM
instrumental rendered once during image build, without downloaded recordings.
It loops throughout waiting/download/retry gaps and yields on the same audio
element when speech is ready. Pause stops it. The former eight-second music
cap described in historical notes below no longer applies to this release.

The fixed feed list adds CNN Business Arabic, CNBC Top News/Energy, Guardian
Business and Federal Reserve policy/speeches. Publisher and first-received
clocks also accompany individual Al Jazeera liveblog updates, collected directly
from the fixed publisher origin with bounded requests and cache/backoff rules.
No publisher code is executed or full article text broadcast. Those
timestamps remain separate. A breaking report must be within ten minutes when
its speech is scheduled; a labelled earlier report must be within one hour.
The service does not claim coverage of the whole
internet. Arabic and English use their respective publisher-language feeds.
Cloud startup and manifests report `pcRequired: false`; all runtime collection
and synthesis is owned by this service. Free Render idle sleep, limited CPU
and ephemeral state still apply; this is not a 24/7 uptime commitment.

## Playback and queue recovery, earlier 23 October

The player owns abortable language/poll/media jobs. Old responses and media
events cannot take control after a language switch; metadata/play timeouts
release their listeners and retry. Later station clocks must increase strictly,
and new clips cannot start from a manifest older than 15 seconds. Already
playing speech can finish once through an outage. Music still has one bounded
eight-second budget per gap, including stalled browser play promises.

The previous optional importer preserved complete turn prefixes, programme/chapter order and
progress across bounded deduplication history. A failed turn cannot be skipped
to play its answer out of context; other programmes remain eligible. News is
served in bursts of at most two when a price brief or discussion is waiting.
Preparation times in manifests are measured server work, not model estimates.
The cloud-news release disables that importer and its polling thread entirely.

Parts containing only excluded forecast/review bookends count as received only
after their complete public DTO passes validation. They cannot hold back the
later discussion. Exact same-speaker turns overlapping two public programme
parts are synthesized once, with normal progress through subsequent parts.

Focused verification: Python tests in this directory and
`node --test deployment/render-radio/test_player.cjs` from the project root.
Use `scripts/observe-render-radio.py --seconds 600 --output NEW_FILE.json`
for a bounded read-only production check, then verify actual browser playback.

## Verification on this PC, 22 October 2026

Production enables one fixed Arabic and one fixed English startup speech check.
The generated samples are private checks, never queued as news. `/health` reports
their completion, engine, byte length and measured audio duration under
`startupSpeechChecks`; a successful HTTP response alone remains insufficient.
The checks validate nonzero PCM16 mono 24 kHz frames and actual WAV duration.
This also warms the resident Arabic engine during quiet feed periods.

Nine focused contract tests pass, including the Linux `/app` asset-path boundary,
G2P hash, numeric pronunciation, preserved base words, language validation and
actual WAV lengths. The Node G2P worker passes syntax validation. Build downloads
and the pinned source archive were exercised successfully.

One real **Windows CPU** smoke used the same portable module, FP32 model and
one thread, alongside the owner's existing services. Loading took **5.007 s**;
**7.95 s** of Arabic audio took **5.390 s** to generate. Peak combined Python and
owned Node process RSS was **302,522,368 bytes** (~289 MiB). The audio was nonzero
mono PCM16 at 24 kHz. This is not a Render/Linux benchmark or human listening
confirmation. No existing radio, PC model or native DLL was changed.

Free Render CPU is substantially smaller than this PC; free-service sleep,
generation latency and model memory must be verified after deployment. These
measurements do not establish continuous real-time generation or uptime on
Render. English additionally depends on the availability of its remote voice.

## Notices

Nabra model/source: Apache-2.0. ONNX Runtime: MIT. Nabra's bundled eSpeak NG and
derived phonemizer logic: GPL-3.0-or-later. Piper tashkeel resources/code are
distributed under Piper's bundled GPL notice. `vendor/` retains Nabra's source
license and third-party notices. The image retains the complete pinned upstream
Nabra source archive/build instructions and Piper's COPYING under the model
directory's `licenses/`. eSpeak NG upstream source is available at
https://github.com/espeak-ng/espeak-ng/tree/1.52.0 and the vowel implementation
documents https://github.com/mush42/libtashkeel.

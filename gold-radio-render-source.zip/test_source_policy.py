"""Offline destination/receipt regressions: these tests never make requests."""
import unittest
from urllib.parse import urlencode

from source_policy import (APPROVED_SOCIAL_DIDS, collector_url_allowed, collection_url_allowed,
                           publisher_domain_allowed, publisher_url_allowed, story_allowed)


REUTERS = 'did:plc:jbvnehrrdqoulco4rf5gxg5r'
ALJAZEERA = 'did:plc:2lofqead276vtc5647ye7sl2'


class SourcePolicyTests(unittest.TestCase):
    def test_every_configured_news_and_social_collector_obeys_the_policy(self):
        import server
        from economic_feeds import FEEDS as DISCOVERY_FEEDS
        from social_sources import SOURCES
        for source in (*server.FEEDS, *DISCOVERY_FEEDS, *SOURCES):
            with self.subTest(source=getattr(source, 'source', getattr(source, 'key', 'unknown'))):
                self.assertTrue(collector_url_allowed(source.url), source.url)

    def test_international_arabic_editions_and_world_sources_remain_allowed(self):
        for url in ('https://feeds.bbci.co.uk/arabic/rss.xml', 'https://www.bbc.com/arabic/example',
                    'https://www.france24.com/ar/rss', 'https://rss.dw.com/rdf/rss-ar-all',
                    'https://arabic.euronews.com/rss?level=theme&name=news',
                    'https://www.reuters.com/world/story', 'https://apnews.com/article/world',
                    'https://www.theguardian.com/world/rss', 'https://www.nasa.gov/news-release/feed/'):
            with self.subTest(url=url):
                self.assertTrue(publisher_url_allowed(url))
                self.assertTrue(collector_url_allowed(url))
                self.assertTrue(story_allowed({'url': url}))

    def test_regional_publishers_are_excluded_in_all_languages_and_subdomains(self):
        for domain in ('aljazeera.com', 'aljazeera.net', 'alarabiya.net', 'alhadath.net',
                       'aawsat.com', 'asharq.com', 'asharqnews.com', 'asharqbusiness.com',
                       'arabnews.com', 'thenationalnews.com', 'skynewsarabia.com', 'cnnbusinessarabic.com'):
            for host in (domain, 'www.' + domain, 'english.' + domain):
                with self.subTest(host=host):
                    url = 'https://' + host + '/news/'
                    self.assertFalse(publisher_domain_allowed(host))
                    self.assertFalse(publisher_url_allowed(url))
                    self.assertFalse(collector_url_allowed(url))
                    self.assertFalse(story_allowed({'url': url}))

    def test_malformed_and_unapproved_urls_fail_closed(self):
        for value in (None, {}, 42, '', 'http://bbc.com/news', '//bbc.com/news',
                      'https://bbc.com.evil.example/news', 'https://evilbbc.com/news',
                      'https://bbc.com@aljazeera.com/news', 'https://aljazeera.com@bbc.com/news',
                      'https://bbc.com:443/news', 'https://bbc.com/news#redirect',
                      'https://bbc.com./news', 'https://foo..bbc.com/news',
                      'https://bbc.com\\@aljazeera.com/news', 'https://bbc.com/\nnews',
                      'https://127.0.0.1/news'):
            with self.subTest(value=value):
                self.assertFalse(publisher_url_allowed(value))
                self.assertFalse(collector_url_allowed(value))
                self.assertFalse(story_allowed({'url': value}))
        for row in (None, [], {}, {'social': True, 'url': 'https://www.bbc.com/news'},
                    {'social': 'true', 'url': 'https://www.bbc.com/news'}):
            self.assertFalse(story_allowed(row))

    def test_social_collection_requires_exact_approved_global_identity_and_operation(self):
        for did in APPROVED_SOCIAL_DIDS:
            url = 'https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed?' + urlencode({
                'actor': did, 'filter': 'posts_no_replies', 'limit': 30})
            self.assertTrue(collector_url_allowed(url))
            self.assertTrue(collection_url_allowed(url))
            self.assertFalse(collector_url_allowed(url.replace('limit=30', 'limit=300')))
        base = 'https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed?'
        for query in ({'actor': ALJAZEERA, 'filter': 'posts_no_replies', 'limit': 30},
                      {'actor': 'reuters.com', 'filter': 'posts_no_replies', 'limit': 30},
                      {'actor': REUTERS, 'filter': 'posts_with_replies', 'limit': 30},
                      {'actor': REUTERS, 'filter': 'posts_no_replies', 'limit': 30, 'cursor': 'unbounded'}):
            self.assertFalse(collector_url_allowed(base + urlencode(query)))
        self.assertFalse(collector_url_allowed('https://t.me/s/ajmubasher'))
        self.assertFalse(collector_url_allowed('https://t.me/s/Reuters'))
        self.assertFalse(collector_url_allowed('https://public.api.bsky.app/xrpc/app.bsky.feed.searchPosts?q=gold'))

    def test_social_rows_and_feedback_require_allowed_root_not_just_global_host(self):
        post = lambda did: 'https://bsky.app/profile/' + did + '/post/3abc'
        row = {'social': True, 'platform': 'Bluesky', 'sourceKind': 'social', 'url': post(REUTERS)}
        self.assertTrue(story_allowed(row))
        self.assertFalse(story_allowed({**row, 'url': post(ALJAZEERA)}))
        self.assertFalse(story_allowed({**row, 'platform': 'Telegram', 'url': 'https://t.me/ajmubasher/1'}))
        reply = {**row, 'sourceKind': 'social-feedback', 'url': post('did:plc:aaaaaaaaaaaaaaaaaaaaaaaa'),
                 'feedback': {'rootUrl': post(REUTERS),
                              'rootUri': 'at://' + REUTERS + '/app.bsky.feed.post/3abc'}}
        self.assertTrue(story_allowed(reply))
        for feedback in ({}, None, {'rootUrl': post(REUTERS)},
                         {'rootUrl': post(REUTERS), 'rootUri': 'at://' + ALJAZEERA + '/app.bsky.feed.post/3abc'},
                         {'rootUrl': post(ALJAZEERA), 'rootUri': 'at://' + ALJAZEERA + '/app.bsky.feed.post/3abc'}):
            self.assertFalse(story_allowed({**reply, 'feedback': feedback}))
        url = 'https://public.api.bsky.app/xrpc/app.bsky.feed.getPostThread?' + urlencode({
            'uri': reply['feedback']['rootUri'], 'depth': 1, 'parentHeight': 0})
        self.assertTrue(collector_url_allowed(url))
        self.assertFalse(collector_url_allowed(url.replace('depth=1', 'depth=2')))
        blocked_thread = 'https://public.api.bsky.app/xrpc/app.bsky.feed.getPostThread?' + urlencode({
            'uri': 'at://' + ALJAZEERA + '/app.bsky.feed.post/3abc', 'depth': 1, 'parentHeight': 0})
        self.assertFalse(collector_url_allowed(blocked_thread))

    def test_google_discovery_never_approves_regional_publisher_or_redirect_destination(self):
        for q, hl, gl, ceid in (('gold when:1h', 'en-US', 'US', 'US:en'),
                                ('الذهب when:1h', 'ar', 'SA', 'SA:ar')):
            url = 'https://news.google.com/rss/search?' + urlencode({'q': q, 'hl': hl, 'gl': gl, 'ceid': ceid})
            self.assertTrue(collector_url_allowed(url))
            self.assertFalse(collector_url_allowed(url + '&url=https%3A%2F%2Faljazeera.com'))
        row = {'sourceKind': 'publisher-aggregator', 'aggregator': 'Google News',
               'publisherDomain': 'www.reuters.com', 'publisherSourceUrl': 'https://www.reuters.com',
               'url': 'https://news.google.com/rss/articles/' + 'a' * 32 + '?oc=5'}
        self.assertTrue(story_allowed(row))
        for domain in ('aljazeera.com', 'aljazeera.net', 'arabnews.com', 'aawsat.com'):
            self.assertFalse(story_allowed({**row, 'publisherDomain': domain,
                                          'publisherSourceUrl': 'https://' + domain}))
        self.assertFalse(story_allowed({**row, 'publisherSourceUrl': 'https://aljazeera.com'}))
        self.assertFalse(story_allowed({**row, 'publisherDomain': None}))
        self.assertFalse(story_allowed({**row, 'url': 'https://news.google.com/url?url=https://aljazeera.com'}))
        self.assertFalse(story_allowed({**row, 'url': row['url'] + '&url=https://aljazeera.com'}))
        self.assertFalse(collector_url_allowed(row['url']))

    def test_fixed_mastodon_tag_reads_do_not_allow_arbitrary_urls_or_queries(self):
        for tag in ('gold', 'oil', 'inflation', 'economy'):
            self.assertTrue(collector_url_allowed(
                'https://mastodon.social/api/v1/timelines/tag/' + tag + '?limit=20'))
        for value in ('https://mastodon.social/api/v1/timelines/tag/politics?limit=20',
                      'https://mastodon.social/api/v1/timelines/tag/gold?limit=40',
                      'https://mastodon.social/api/v1/timelines/tag/gold?limit=20&max_id=123',
                      'https://mastodon.social/api/v1/timelines/tag/gold?limit=20&remote=true',
                      'https://mastodon.social/api/v1/timelines/public?limit=20',
                      'https://mastodon.social.evil.example/api/v1/timelines/tag/gold?limit=20',
                      'https://mastodon.scot/api/v1/timelines/tag/gold?limit=20',
                      'http://mastodon.social/api/v1/timelines/tag/gold?limit=20'):
            with self.subTest(value=value):
                self.assertFalse(collector_url_allowed(value))

    def test_mastodon_reactions_require_typed_local_identity_and_moderation_provenance(self):
        row = {'social': True, 'sourceKind': 'social-reaction', 'platform': 'Mastodon',
               'url': 'https://mastodon.social/@goldlistener/123456',
               'reaction': {'username': 'goldlistener', 'statusId': '123456',
                   'accountUrl': 'https://mastodon.social/@goldlistener',
                   'authorHandle': 'goldlistener@mastodon.social', 'sourceTag': 'gold',
                   'screeningPolicy': 'mastodon-financial-opinion-2026-10-25-v1',
                   'unverified': True, 'representative': False}}
        self.assertTrue(story_allowed(row))
        for patch in ({'username': 'other'}, {'statusId': '654321'},
                      {'accountUrl': 'https://mastodon.scot/@goldlistener'},
                      {'authorHandle': 'goldlistener@mastodon.scot'}, {'sourceTag': 'politics'},
                      {'screeningPolicy': 'unreviewed'}, {'unverified': False}, {'representative': True}):
            with self.subTest(patch=patch):
                self.assertFalse(story_allowed({**row, 'reaction': {**row['reaction'], **patch}}))
        self.assertFalse(story_allowed({**row, 'url': row['url'] + '?redirect=1'}))
        self.assertFalse(story_allowed({**row, 'url': 'https://mastodon.scot/@goldlistener/123456'}))
        self.assertFalse(story_allowed({**row, 'reaction': None}))


if __name__ == '__main__':
    unittest.main()

"""Original recorded educational conversations for quiet station periods.

These reviewed bilingual scripts are not live reporting, generated analysis,
personal advice, or price forecasts. They contain no current quotes, scraped
news, account data, model calls, or network requests. ``publishedAt`` and
``firstSeenAt`` in a candidate are preparation clocks, never news-source clocks.

Each language finishes the selected episode in order, allowing the owner
scheduler to insert news between turns. Only consume() after successful queue
publication advances a turn. State is bounded, in memory, and starts over after
a process restart. Replays are labelled and require a twenty-minute cooldown
after the episode's last successful completion; all unplayed episodes go first.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
from itertools import islice
import threading
import time


LIBRARY_VERSION = 'gold-pulse-education-2026-10-24-v1'
REPLAY_COOLDOWN_S = 20 * 60
SOURCE_URL = 'https://gold-air.onrender.com/'


@dataclass(frozen=True)
class Episode:
    identity: str
    title_en: str
    title_ar: str
    # Each pair is one complete turn: English, then Arabic.
    turns: tuple[tuple[str, str], ...]
    references: tuple[str, ...] = ()


EPISODES = (
    Episode('real-yields', 'The return gold does not pay', 'العائد الذي لا يدفعه الذهب', (
        (
            'Maya here, with Omar. A gold bar does not send its owner an interest payment. Yet a discussion about gold quickly turns into a discussion about bond yields. What is the connection? Let us work through the choice between holding an asset and receiving income, without turning that comparison into a prediction about the next price move.',
            'معكم مايا ومعي عمر. قطعة الذهب لا ترسل لصاحبها دفعة فائدة، ومع ذلك ينتقل الحديث عن الذهب سريعاً إلى عوائد السندات. ما الرابط بينهما؟ دعنا نفهم المقارنة بين الاحتفاظ بأصل والحصول على دخل، من غير أن نحولها إلى توقع للحركة التالية. نريد تفسير الفكرة الاقتصادية، وليس إعلان اتجاه لسعر نجهله.',
        ),
        (
            'Omar: the useful starting point is opportunity cost. Holding gold means giving up some alternatives that may pay income. But the quoted interest rate is only part of the comparison. Purchasing power matters too. An inflation-adjusted return asks what that income could buy, rather than simply counting the extra currency received at the end.',
            'عمر: البداية المفيدة هي تكلفة الفرصة البديلة. الاحتفاظ بالذهب يعني ترك بدائل قد تدفع دخلاً، لكن الفائدة المعلنة ليست كل المقارنة. القوة الشرائية مهمة أيضاً. العائد بعد تعديل التضخم يسأل عما يستطيع الدخل شراءه، بدلاً من الاكتفاء بعد النقود الإضافية. وهذه مقارنة اقتصادية لا تعني أن الذهب يتحرك آلياً بعكس كل تغير في العائد.',
        ),
        (
            'Maya: so two identical interest rates could feel quite different if people expect different inflation. Is it enough to subtract a recently published inflation figure and call the result the market real yield? I also wonder how we avoid mixing a one-month price report with a bond that will remain outstanding for several years.',
            'مايا: إذن قد يختلف معنى فائدتين متماثلتين إذا اختلف التضخم المتوقع. هل يكفي طرح آخر رقم منشور للتضخم وتسميته العائد الحقيقي في السوق؟ وكيف نتجنب الخلط بين تقرير أسعار يغطي شهراً وسند يمتد لسنوات؟ يبدو أن فترة القياس وتوقيت المعلومة جزء من السؤال، وليسا مجرد تفاصيل صغيرة في الهامش.',
        ),
        (
            'Omar: match the horizon and distinguish expected inflation from inflation already measured. Simple subtraction is an approximation; market measures also have their own assumptions. Even a sound comparison leaves room for currency moves, demand and uncertainty. Real yields are one explanatory lens. They are not a switch that determines what every gold transaction must do.',
            'عمر: نقارن الفترات المتقاربة ونميز التضخم المتوقع عن التضخم الذي قيس بالفعل. والطرح البسيط تقريب، كما أن مقاييس السوق لها افتراضاتها. تبقى العملة والطلب وعدم اليقين ضمن الصورة حتى بعد إجراء مقارنة سليمة. العوائد الحقيقية زاوية لفهم السوق، وليست مفتاحاً يفرض نتيجة واحدة على كل عملية بيع أو شراء للذهب.',
        ),
    ), ('https://www.frbsf.org/research-and-insights/publications/doctor-econ/2003/08/real-nominal-interest-rate/',)),
    Episode('dollar-translation', 'One metal, different currencies', 'معدن واحد وعملات مختلفة', (
        (
            'Maya: imagine two listeners looking at the same ounce of gold. One display is in dollars and the other is in a local currency. Their charts do not have to show the same percentage change. Omar, can we separate the movement of the metal from the movement of the measuring currency, using an imaginary example rather than any live market number?',
            'مايا: تخيل مستمعين ينظران إلى الأونصة نفسها. الشاشة الأولى تعرض الدولار والثانية تعرض عملة محلية، وقد لا تظهران النسبة نفسها من التغير. كيف نفصل حركة المعدن عن حركة العملة التي نقيس بها قيمته؟ لنستخدم مثالاً افتراضياً بعيداً عن الأسعار الحية، حتى يتضح لماذا قد تختلف تجربة شخصين رغم حديثهما عن الذهب نفسه.',
        ),
        (
            'Omar: suppose, purely for illustration, that the dollar gold price stays fixed while a local currency weakens against the dollar. Converting the same dollar amount can then require more local currency. A local-currency increase does not, by itself, prove a new rise in the dollar gold market. The conversion is part of the observation, not an extra ounce of metal.',
            'عمر: نفترض للتوضيح فقط أن سعر الذهب بالدولار ثابت، بينما تضعف عملة محلية أمام الدولار. تحويل المبلغ نفسه قد يحتاج عندها إلى عدد أكبر من وحدات العملة المحلية. الزيادة المحلية لا تثبت وحدها ارتفاعاً جديداً في سوق الذهب بالدولار. تغير وحدة القياس جزء من المشاهدة، وليس زيادة في كمية المعدن أو خبراً جديداً عن الطلب عليه.',
        ),
        (
            'Maya: that helps with local prices. But we often hear that a stronger dollar must mean weaker gold. Is that a reliable rule, or a shorthand that leaves things out? It seems possible for demand for the currency and demand for the metal to rise during the same unsettled period, even if their usual relationship attracts more attention.',
            'مايا: بهذا نفهم الأسعار المحلية، لكننا نسمع أيضاً أن قوة الدولار تعني بالضرورة ضعف الذهب. هل هذه قاعدة ثابتة أم اختصار يترك عوامل أخرى خارج الصورة؟ قد يتجه الطلب إلى العملة والمعدن معاً في فترة مضطربة. كيف نحافظ على الفكرة المفيدة في العلاقة بينهما، من دون تحويلها إلى قانون لا يقبل الاستثناء؟',
        ),
        (
            'Omar: currency translation is arithmetic; the joint behaviour of markets is more complicated. Several motives can operate at once, so a familiar inverse relationship can weaken or reverse. An explanation should identify the quote currency and the observation period, then examine the other evidence. A currency chart alone cannot settle why gold moved.',
            'عمر: تحويل العملة عملية حسابية، أما سلوك الأسواق معاً فأكثر تعقيداً. يمكن أن تعمل دوافع متعددة في الوقت نفسه، فتضعف العلاقة العكسية المعتادة أو تنعكس. نحدد عملة التسعير وفترة الرصد ثم ننظر إلى بقية الأدلة. رسم العملة وحده لا يحسم سبب حركة الذهب، والارتباط المعتاد لا يكفي لإثبات سبب حركة بعينها.',
        ),
    )),
    Episode('oil-channels', 'How an oil headline reaches gold', 'كيف يصل خبر النفط إلى الذهب', (
        (
            'Maya: an oil story can sound immediately relevant to gold, but there is more than one route between them. Energy costs, inflation expectations and worries about supply may all appear in the same conversation. Omar, how would you unpack those channels without making the claim that every oil increase automatically lifts the gold price?',
            'مايا: يبدو خبر النفط مهماً للذهب فوراً، لكن الطريق بينهما ليس واحداً. تكلفة الطاقة والتضخم المتوقع والقلق على الإمدادات قد تجتمع في النقاش نفسه. كيف نفكك هذه القنوات من دون القول إن كل ارتفاع في النفط يرفع الذهب تلقائياً؟ نحتاج أيضاً إلى التمييز بين تغير اقتصادي واسع وحادث محلي لا يغير حجم المعروض كثيراً.',
        ),
        (
            'Omar: first separate a supply disruption from stronger demand. A disruption may raise costs while hurting activity; stronger demand tells a different economic story. Then ask how inflation expectations, interest-rate expectations and currencies respond. These channels can pull in different directions. A single commodity price is not a complete description of the economy.',
            'عمر: نميز أولاً اضطراب الإمدادات من زيادة الطلب. الاضطراب قد يرفع التكاليف ويضغط على النشاط، بينما يحمل الطلب الأقوى معنى اقتصادياً مختلفاً. ثم نسأل عن توقعات التضخم والفائدة واستجابة العملات. قد تسحب هذه القنوات في اتجاهات متعارضة، لذلك لا يختصر سعر سلعة واحدة حالة الاقتصاد كلها ولا يحدد وحده نتيجة سوق آخر.',
        ),
        (
            'Maya: suppose a report describes trouble near an important shipping route. Before connecting it with gold, what details deserve attention? I would want to know whether traffic actually stopped, how long any disruption lasted, and whether an alternative route existed. The dramatic wording of a headline may be much clearer than its economic scale.',
            'مايا: إذا وصف تقرير مشكلة قرب ممر مهم للشحن، فما التفاصيل التي تستحق الانتباه قبل ربطها بالذهب؟ أريد معرفة هل توقفت الحركة فعلاً، وكم استمر التعطل، وهل توجد طرق بديلة. قد يكون العنوان مثيراً وواضحاً، بينما يظل الحجم الاقتصادي للحدث غير معروف. وتأكيد وقوع حادث لا يثبت وحده أن أثره واسع أو مستمر.',
        ),
        (
            'Omar: exactly. Establish what happened and distinguish confirmed disruption from a possible threat. The scale, duration and response matter. It is reasonable to discuss conditional channels, such as higher transport costs, while saying that their effect has not been measured. Explaining a mechanism is different from announcing that the mechanism already caused a particular gold move.',
            'عمر: صحيح. نثبت ما حدث ونفصل التعطل المؤكد عن التهديد المحتمل، ثم ننظر إلى الحجم والمدة والاستجابة. يمكن شرح قناة مشروطة مثل ارتفاع تكلفة النقل، مع توضيح أن أثرها لم يقس بعد. تفسير الآلية يختلف عن إعلان أنها سببت بالفعل حركة معينة للذهب. هذا التفريق يحافظ على فائدة النقاش من غير اختراع علاقة مؤكدة.',
        ),
    )),
    Episode('inflation-baskets', 'The inflation number behind the headline', 'رقم التضخم وراء العنوان', (
        (
            'Maya: inflation discussions often start with one percentage, although that number describes a basket of prices and a particular period. Two reports can sound contradictory while measuring different things. Omar, what should a listener establish before comparing an inflation headline with a gold chart, especially when one report is monthly and another is annual?',
            'مايا: يبدأ نقاش التضخم غالباً بنسبة واحدة، لكنها تصف سلة من الأسعار وفترة محددة. قد يبدو تقريران متناقضين وهما يقيسان شيئين مختلفين. ماذا نحتاج إلى معرفته قبل مقارنة خبر التضخم برسم الذهب، خصوصاً إذا كان أحد الرقمين شهرياً والآخر سنوياً؟ وحتى العبارة القصيرة عن تباطؤ التضخم تحتاج إلى تفسير ما الذي تباطأ بالضبط.',
        ),
        (
            'Omar: identify the index, the period and whether the change was adjusted for seasonal patterns. A slower inflation rate means prices are rising more slowly; it does not necessarily mean the overall price level fell. Different baskets and methods can produce different readings. Those distinctions help explain the report before we discuss any possible market response.',
            'عمر: نحدد المؤشر والفترة وما إذا كان التغير معدلاً للعوامل الموسمية. تباطؤ التضخم يعني أن الأسعار ترتفع بوتيرة أبطأ، ولا يعني بالضرورة انخفاض مستوى الأسعار العام. اختلاف السلال وطرق الحساب قد يعطي قراءات مختلفة. فهم هذه الفروق يساعدنا على تفسير التقرير نفسه قبل مناقشة أي استجابة محتملة من الأسواق.',
        ),
        (
            'Maya: and a high reading may already have been widely expected. Does that mean the gap between a result and expectations can matter as much as the level itself? I want to avoid a habit of attaching the same gold story to every inflation release, without asking what people believed before the data and what genuinely changed afterward.',
            'مايا: وقد تكون قراءة مرتفعة متوقعة على نطاق واسع من قبل. هل يعني ذلك أن الفرق بين النتيجة والتوقعات قد يكون مهماً بقدر أهمية المستوى نفسه؟ لا أريد إرفاق الحكاية نفسها عن الذهب بكل إصدار للتضخم، من دون معرفة ما الذي كان معروفاً قبله وما المعلومة الجديدة التي أضافها فعلاً إلى الصورة.',
        ),
        (
            'Omar: that is a useful distinction, provided the expectations were recorded before the release. A surprise is not whatever a commentator decides later was surprising. Even then, rates, currencies and other news may change together. A careful discussion explains the data, the prior expectation and the timing, while leaving the precise cause of a price move open when evidence is incomplete.',
            'عمر: هذا تمييز مفيد إذا كانت التوقعات موثقة قبل الإصدار. المفاجأة ليست وصفاً يختاره المعلق بعد معرفة النتيجة. وقد تتغير الفائدة والعملات وأخبار أخرى معاً رغم ذلك. يشرح النقاش الدقيق البيانات والتوقع السابق والتوقيت، ويترك سبب الحركة المحدد مفتوحاً عندما لا تكون الأدلة كافية للحسم بدلاً من ملء الفراغ بحكاية جاهزة.',
        ),
    ), ('https://www.federalreserve.gov/faqs/economy_14419.htm',)),
    Episode('liquidity', 'The difference between a quote and a fill', 'الفرق بين السعر المعروض والتنفيذ', (
        (
            'Maya: a price can be visible on a screen without being the price available for every possible order. That distinction is easy to miss in a simulation. Omar, let us explain liquidity and the spread in ordinary language. Why can a small displayed movement feel very different from the result of an actual transaction, even before any financing costs are considered?',
            'مايا: قد يظهر سعر على الشاشة من دون أن يكون متاحاً لكل أمر وبأي حجم. يسهل إغفال هذا الفرق في المحاكاة. دعنا نشرح السيولة وفارق البيع والشراء بلغة بسيطة. لماذا قد تختلف حركة صغيرة نراها عن نتيجة عملية فعلية، حتى قبل احتساب أي تمويل؟ نريد فهم طريقة القراءة والتنفيذ، لا افتراض أن كل نقرة تحصل على السعر نفسه.',
        ),
        (
            'Omar: a bid is an offered buying price and an ask is an offered selling price. Their gap is the spread. Liquidity also concerns how much can trade and how execution changes with size and urgency. A narrow displayed spread is helpful information, but not a promise that a much larger order can be filled there. Depth and the speed of changing quotes matter too.',
            'عمر: هناك سعر معروض للشراء وآخر للبيع، والمسافة بينهما هي الفارق. وتشمل السيولة أيضاً الكمية التي يمكن تداولها وكيف يتغير التنفيذ مع الحجم والسرعة المطلوبة. الفارق الضيق معلومة مفيدة، لكنه ليس وعداً بتنفيذ أمر أكبر كثيراً عند السعر نفسه. عمق الطلبات وسرعة تغير العروض مهمان أيضاً، ولا تكشفهما نقطة واحدة على الرسم.',
        ),
        (
            'Maya: so a quiet-looking chart does not prove that execution would be effortless. What about a fast move after a data release, when the screen keeps updating? A listener might compare a forecast with the next displayed quote and assume the same result could have been captured in a trade. That seems to leave the path between observation and execution out of the calculation.',
            'مايا: إذن هدوء الرسم لا يثبت سهولة التنفيذ. وماذا عن حركة سريعة بعد إصدار اقتصادي بينما تستمر الشاشة في التحديث؟ قد يقارن المستمع توقعاً بالسعر المعروض التالي ويفترض أن النتيجة نفسها كانت متاحة في صفقة. يبدو أن هذا يتجاهل الطريق بين رؤية المعلومة ووصول الأمر، كما يتجاهل الفارق والكمية المتاحة والتكاليف.',
        ),
        (
            'Omar: keep those steps separate. A reference quote, a simulated fill and a real fill are different records. Delay, spreads and available size can alter the result. An honest simulation records its cost and fill assumptions explicitly. It cannot turn a correct directional observation into proof of achievable profit without checking what execution would have required.',
            'عمر: نفصل هذه الخطوات. السعر المرجعي والتنفيذ الافتراضي والتنفيذ الحقيقي سجلات مختلفة. التأخير والفارق والكمية المتاحة قد تغير النتيجة. تسجل المحاكاة الصادقة افتراضات التكلفة والتنفيذ بوضوح، ولا تحول صحة ملاحظة الاتجاه إلى دليل على ربح قابل للتحقق من دون فحص ما كان يلزم لتنفيذ العملية فعلاً.',
        ),
    ), ('https://www.investor.gov/introduction-investing/investing-basics/how-stock-markets-work/executing-order',)),
    Episode('reserve-demand', 'Central banks and different time horizons', 'البنوك المركزية واختلاف الأفق الزمني', (
        (
            'Maya: central-bank gold purchases often enter the conversation as if they explain every short movement. But reserve decisions and minute-by-minute trading operate on different clocks. Omar, how can we discuss official demand as background without presenting a delayed monthly report as fresh evidence about what is happening inside the next few minutes?',
            'مايا: تدخل مشتريات البنوك المركزية إلى النقاش أحياناً وكأنها تفسر كل حركة قصيرة. لكن قرارات الاحتياطيات والتداول دقيقة بدقيقة يعملان على ساعتين مختلفتين. كيف نناقش الطلب الرسمي كسياق، من دون تقديم تقرير شهري متأخر بوصفه دليلاً جديداً على ما يحدث في الدقائق التالية؟ الفكرة مهمة حتى عندما يكون المصدر موثوقاً.',
        ),
        (
            'Omar: start with the reporting period and the publication date. A report released after a month ends describes that earlier period, not a live order feed. Reserve management can involve diversification, liquidity and institutional constraints. Those motives help frame a longer discussion, but they do not reveal the timing or price of an unknown transaction.',
            'عمر: نبدأ بفترة التقرير وتاريخ نشره. الإصدار الذي يأتي بعد نهاية شهر يصف تلك الفترة السابقة، وليس تدفقاً حياً للأوامر. قد تتعلق إدارة الاحتياطيات بالتنويع والسيولة وقيود المؤسسة. تساعد هذه الدوافع في نقاش طويل الأجل، لكنها لا تكشف توقيت عملية مجهولة أو سعرها ولا تمنحنا معرفة بما تفعله كل جهة في اللحظة نفسها.',
        ),
        (
            'Maya: there is also a difference between an institution adding tonnes of gold and the dollar value of its holdings increasing. Could a higher valuation occur even without a change in physical quantity? I would like listeners to hear the measurement question before treating a large currency figure as an equally large new purchase.',
            'مايا: هناك أيضاً فرق بين إضافة أطنان من الذهب وارتفاع قيمة الحيازة بالدولار. هل يمكن أن تزيد القيمة من دون تغير الكمية الفعلية؟ أريد أن ينتبه المستمع إلى سؤال القياس قبل تفسير مبلغ كبير بوصفه مشتريات جديدة بالحجم نفسه. فالتقرير قد يعرض قيمة أو وزناً أو نسبة من الاحتياطيات، وهذه مقاييس مختلفة.',
        ),
        (
            'Omar: yes. Quantity, valuation and the share of reserves answer different questions. Price and currency changes can alter valuations without new metal being acquired. Check which measure the source actually reports and whether revisions are possible. Long-horizon demand deserves a place in the programme, with its original dates, rather than being recycled as a new short-term catalyst.',
            'عمر: نعم. الكمية والقيمة وحصة الذهب من الاحتياطيات تجيب عن أسئلة مختلفة. تغير السعر أو العملة قد يغير التقييم من دون اقتناء معدن إضافي. نراجع المقياس الذي يورده المصدر وإمكان المراجعة لاحقاً. للطلب طويل الأجل مكانه في النقاش مع تواريخه الأصلية، بدلاً من إعادة تدويره كل مرة كأنه محفز قصير الأجل جديد.',
        ),
    )),
    Episode('risk-haven', 'A haven is not a guarantee', 'الملاذ لا يعني ضماناً', (
        (
            'Maya: the phrase safe haven is familiar, but it can conceal several different ideas. Some people mean protection against uncertainty; others mean a price that never falls. Omar, those meanings are clearly not equivalent. How should a gold discussion describe defensive demand without giving the impression that the metal cannot decline during a difficult period?',
            'مايا: عبارة الملاذ الآمن مألوفة، لكنها قد تخفي أفكاراً مختلفة. يقصد بعض الناس طلب الحماية من عدم اليقين، بينما يتخيل آخرون سعراً لا ينخفض أبداً. المعنيان ليسا متساويين. كيف نصف الطلب الدفاعي على الذهب من دون إعطاء انطباع بأن المعدن لا يمكن أن يتراجع في فترة صعبة، أو أنه يؤدي الدور نفسه في كل لحظة؟',
        ),
        (
            'Omar: a label describes a possible role, not a guarantee of any particular return. Buyers may seek gold when uncertainty rises, while other holders may need cash and sell liquid assets. Currency and interest-rate changes can also be occurring. These motives can coexist. A difficult day for several markets does not dictate a single, compulsory response for gold.',
            'عمر: الوصف يعبر عن دور محتمل، وليس ضماناً لعائد معين. قد يطلب بعض المشترين الذهب مع ارتفاع عدم اليقين، بينما يحتاج آخرون إلى النقد فيبيعون أصولاً قابلة للتسييل. وقد تتغير العملة والفائدة في الوقت نفسه. يمكن أن تتعايش هذه الدوافع، ولا يفرض يوم صعب على أسواق متعددة استجابة واحدة إلزامية من الذهب.',
        ),
        (
            'Maya: then a story about fear may be incomplete if it ignores the need for cash. Could looking at different time windows help us see that tension? A sharp opening movement, the close of a trading session and a monthly change are three different observations. Using whichever window fits a story afterward would make the explanation far too easy.',
            'مايا: إذن قد تكون حكاية الخوف ناقصة إذا تجاهلت الحاجة إلى النقد. هل تساعدنا النوافذ الزمنية المختلفة على رؤية هذا التوتر؟ الحركة الحادة في البداية وإغلاق الجلسة والتغير الشهري ثلاث ملاحظات مختلفة. اختيار النافذة التي تناسب الحكاية بعد وقوع الحدث يجعل التفسير سهلاً أكثر مما ينبغي، ويخفي ما لم ينسجم معه.',
        ),
        (
            'Omar: choose the observation window clearly and keep inconvenient observations in view. A temporary decline and a longer rise can both be real. Neither justifies pretending every later event was predictable. A useful discussion acknowledges competing channels and identifies what remains unknown, instead of treating the haven label as a substitute for evidence.',
            'عمر: نحدد نافذة الرصد بوضوح ونحتفظ بالملاحظات التي لا تناسب الحكاية أيضاً. التراجع المؤقت والارتفاع الأطول قد يكونان صحيحين معاً. ولا يبرر أي منهما الادعاء بأن كل ما حدث لاحقاً كان متوقعاً. يعترف النقاش المفيد بالقنوات المتنافسة وبما لا نعرفه، بدلاً من استخدام وصف الملاذ بديلاً عن الدليل.',
        ),
    )),
    Episode('clock-and-data', 'Which clock did the market see?', 'أي ساعة وصلت إلى السوق؟', (
        (
            'Maya: a report can have an event time, a publication time and a time when our station first receives it. Those are not interchangeable. Omar, why does a careful timeline matter when a commentator connects a headline with a gold move? Let us examine the order of information before drawing a line between two things that happened near each other.',
            'مايا: قد يكون للتقرير وقت وقوع الحدث ووقت النشر ووقت وصوله إلى محطتنا أول مرة. هذه الأوقات ليست متبادلة. لماذا يهم ترتيبها عندما يربط معلق عنواناً بحركة الذهب؟ دعنا نفحص تسلسل وصول المعلومات قبل رسم خط بين حدثين متقاربين زمنياً. حتى الخبر الصحيح قد يصل متأخراً بالنسبة إلى السؤال الذي نحاول الإجابة عنه.',
        ),
        (
            'Omar: information received later cannot explain what a forecasting system genuinely knew earlier. A headline may describe an old event or be republished with a new delivery time. Preserving the original source clock prevents it from becoming artificially fresh. The receipt time answers when our system learned of it, which is a separate and equally useful fact.',
            'عمر: المعلومة التي وصلت لاحقاً لا تصبح جزءاً مما عرفه نظام التوقع فعلاً في وقت أسبق. قد يصف العنوان حدثاً قديماً أو يعاد توزيعه بوقت تسليم جديد. حفظ ساعة المصدر الأصلية يمنع تجديد الخبر بشكل مصطنع. أما وقت الاستلام فيجيب عن موعد معرفة نظامنا به، وهو سؤال منفصل ومفيد أيضاً عند مراجعة الأداء.',
        ),
        (
            'Maya: what if a social post gives its own creation time but there is no independent confirmation of the claim? Does a precise timestamp make the content more certain? I think we need two separate questions: when the post appeared, and what evidence supports its statement. A very exact clock cannot do the work of checking a claim.',
            'مايا: ماذا إذا أعطى منشور اجتماعي وقت إنشائه، من دون تأكيد مستقل لما يقوله؟ هل يجعل التوقيت الدقيق المعلومة أكثر يقيناً؟ نحتاج إلى سؤالين منفصلين: متى ظهر المنشور، وما الدليل على ادعائه؟ الساعة شديدة الدقة لا تقوم مقام التحقق، كما أن وصول الخبر سريعاً لا يحوله وحده إلى حقيقة مؤكدة.',
        ),
        (
            'Omar: exactly. Preserve attribution and distinguish a publisher report from an unverified public post. Then separate timing evidence from factual verification. Several outlets repeating one claim may still trace back to one original source. The responsible conclusion can be that a story deserves attention while its substance or its connection with a market move remains unsettled.',
            'عمر: بالضبط. نحفظ النسبة إلى المصدر ونميز التقرير المنشور من المنشور العام غير المتحقق منه. ثم نفصل دليل التوقيت عن التحقق من الوقائع. قد تعود نسخ متعددة من ادعاء واحد إلى مصدر أصلي واحد. ويمكن أن تكون الخلاصة المسؤولة أن الموضوع يستحق المتابعة، بينما تظل صحته أو صلته بحركة السوق غير محسومة.',
        ),
    )),
    Episode('chart-basics', 'Reading a curve without inventing a story', 'قراءة المنحنى دون اختراع حكاية', (
        (
            'Maya: two charts can make the same movement look dramatic or almost flat. Scale, time window and sampling explain much of that difference. Omar, before discussing a curve, what should a listener establish about the display? A careful description ought to survive a change in screen size, rather than depend on the emotional effect of a steep-looking line.',
            'مايا: قد يجعل رسمان الحركة نفسها تبدو حادة جداً أو شبه مسطحة. يفسر المقياس والفترة وطريقة أخذ العينات جانباً كبيراً من الاختلاف. ماذا نحدد قبل الحديث عن المنحنى؟ يفترض أن يبقى الوصف الدقيق صحيحاً عند تغيير حجم الشاشة، بدلاً من الاعتماد على الأثر النفسي لخط يبدو شديد الانحدار بسبب طريقة عرضه.',
        ),
        (
            'Omar: identify the instrument, quote currency, provider and clock first. Next check whether the vertical axis shows price, dollars of change or a percentage, and whether two panels share a scale. A magnified forecast can be visible without being close to the later outcome. The numerical labels, not bar height alone, tell us the size of the movement.',
            'عمر: نحدد الأداة وعملة التسعير والمصدر والساعة أولاً. ثم نفحص هل المحور يعرض السعر أم فرق الدولارات أم نسبة مئوية، وهل اللوحتان على المقياس نفسه. تكبير رسم التوقع قد يجعله واضحاً من دون أن يجعله قريباً من النتيجة اللاحقة. الأرقام المصاحبة، وليس ارتفاع الأعمدة وحده، هي التي تخبرنا بحجم الحركة.',
        ),
        (
            'Maya: a recent low or high can provide a useful description of the samples we have. But it is tempting to rename that observed boundary as an unbreakable support or resistance level. What information gets lost in that jump? I also wonder whether the lowest sampled price necessarily captures the true low between updates.',
            'مايا: يوفر أدنى سعر أو أعلاه ضمن فترة وصفاً مفيداً للعينات المتاحة، لكن من السهل تسميته دعماً أو مقاومة لا يمكن تجاوزها. ما الذي نفقده في هذه القفزة؟ وهل تلتقط أدنى عينة بالضرورة القاع الحقيقي بين التحديثات؟ قد يفوتنا تغير حدث بين نقطتين حتى لو كان الرسم بينهما يبدو متصلاً وسلساً.',
        ),
        (
            'Omar: an observed range describes the stored samples. It does not prove that every intervening trade stayed inside that range, or that its edges will hold next time. A line drawn between updates is a display choice, not newly measured prices. We can discuss direction, range and missing observations plainly, while leaving future behaviour as an unanswered question.',
            'عمر: النطاق المرصود يصف العينات المحفوظة. لا يثبت أن كل تداول بينهما بقي داخله، ولا أن حدوده ستصمد في المرة التالية. الخط المرسوم بين تحديثين اختيار للعرض، وليس أسعاراً جديدة جرى قياسها. نستطيع وصف الاتجاه والنطاق والعينات المفقودة بوضوح، مع إبقاء السلوك القادم سؤالاً لا تجيب عنه الصورة وحدها.',
        ),
    )),
    Episode('forecast-review', 'What a correct direction does not prove', 'ما الذي لا تثبته صحة الاتجاه؟', (
        (
            'Maya: a prediction can get the sign of a move right and still miss its size badly. It can also look accurate when the market barely moves. Omar, what belongs in a fair review? Let us build a checklist for understanding recorded forecasts, rather than inventing a success rate or suggesting that a few attractive chart examples establish a dependable advantage.',
            'مايا: قد يصيب التوقع اتجاه الحركة ويخطئ حجمها كثيراً، وقد يبدو دقيقاً لأن السوق لم يتحرك تقريباً. ماذا تتضمن المراجعة العادلة؟ لنضع طريقة لفهم التوقعات المسجلة، بدلاً من اختراع نسبة نجاح أو افتراض أن بضعة أمثلة جميلة على الرسم تثبت ميزة يمكن الاعتماد عليها. نحتاج إلى الاحتفاظ بالإخفاق كما نحتفظ بالمثال الناجح.',
        ),
        (
            'Omar: compare each forecast with the later observation at the same target time and from the same reference source. Keep the forecast fixed once issued. Record the direction, the size of the error and the number of missing outcomes. A no-change comparison is valuable because a slowly moving market can make a weak model appear impressively close in absolute price.',
            'عمر: نقارن كل توقع بالمشاهدة اللاحقة عند موعد الهدف نفسه ومن المصدر المرجعي نفسه. يبقى التوقع ثابتاً بعد صدوره، ونسجل الاتجاه وحجم الخطأ وعدد النتائج المفقودة. مقارنة عدم التغير مفيدة، لأن السوق البطيء قد يجعل نموذجاً ضعيفاً يبدو قريباً جداً من السعر الفعلي. القرب وحده لا يخبرنا إن كان النموذج قد أضاف معلومة.',
        ),
        (
            'Maya: and if a model is changed after seeing which examples it missed, those same examples cannot fairly prove the revised model works. What about reporting accuracy only on the calls it chose to make? A selective model might have a useful role, but the withheld share and the large moves it missed should remain visible beside its successful calls.',
            'مايا: وإذا عدلنا النموذج بعد رؤية الأمثلة التي أخفق فيها، فلا تصلح الأمثلة نفسها لإثبات نجاح النسخة المعدلة بعدل. وماذا عن حساب الدقة على النداءات التي اختار إصدارها فقط؟ قد يكون الانتقاء مفيداً، لكن ينبغي إظهار نسبة الحالات التي امتنع عنها والحركات الكبيرة التي فاتته بجانب النداءات الناجحة، لا إخفاؤها من المقارنة.',
        ),
        (
            'Omar: exactly. Separate development data from genuinely later evaluation, and publish the coverage as well as the score. A brief test has limited evidence, especially if moves overlap or the sample is small. Trading performance adds another layer: spreads, delays and drawdowns. A directional score and a profitable, repeatable trading result are different claims.',
            'عمر: صحيح. نفصل بيانات التطوير عن تقييم جاء لاحقاً فعلاً، ونعلن التغطية بجانب النتيجة. الاختبار القصير محدود الدلالة، خصوصاً مع عينة صغيرة أو حركات متداخلة. ويضيف أداء التداول طبقة أخرى من الفروق والتأخير والتراجع في الرصيد. صحة الاتجاه والنتيجة التجارية المربحة والقابلة للتكرار ادعاءات مختلفة وليست اسماً لشيء واحد.',
        ),
    )),
    Episode('physical-and-paper', 'The many meanings of a gold price', 'المعاني المختلفة لسعر الذهب', (
        (
            'Maya: the phrase gold price can refer to a spot quote, a futures contract, a fund share or a retail coin. They are related, but a listener cannot simply treat them as interchangeable products. Omar, how do we keep a discussion clear when a reference chart and a shop price differ, without assuming that one source must be wrong?',
            'مايا: قد تعني عبارة سعر الذهب تسعيراً فورياً أو عقداً آجلاً أو حصة في صندوق أو قطعة تباع في متجر. بينها علاقة لكنها ليست منتجات متطابقة. كيف نبقي النقاش واضحاً إذا اختلف الرسم المرجعي عن سعر المتجر، من دون افتراض أن أحد المصدرين مخطئ؟ يجب أن نعرف ما الذي يقاس وما الذي يشتريه الشخص فعلاً.',
        ),
        (
            'Omar: identify the unit, purity, currency and product terms. A retail item can include fabrication, distribution and a dealer margin. A futures contract names delivery terms and a maturity; a fund share has its own structure and fees. These are measurement and contract differences. A reference quote does not promise the final amount paid for a particular physical item.',
            'عمر: نحدد الوحدة والنقاء والعملة وشروط المنتج. قد تشمل السلعة بالتجزئة التصنيع والتوزيع وهامش التاجر. للعقد الآجل شروط تسليم واستحقاق، ولحصة الصندوق هيكل ورسوم خاصة بها. هذه فروق في القياس والعقد، ولا يعد السعر المرجعي بالمبلغ النهائي المدفوع مقابل قطعة فعلية بعينها. لذلك نوضح المنتج قبل مقارنة الأرقام.',
        ),
        (
            'Maya: even the word ounce needs care, because precious metals commonly use the troy ounce. And jewellery can be quoted by the gram with a stated purity. If someone converts only the currency and overlooks the unit, the comparison becomes misleading before any market theory is needed. The ordinary details deserve airtime alongside the bigger economic stories.',
            'مايا: حتى كلمة أونصة تحتاج إلى انتباه، إذ تستخدم المعادن الثمينة عادة الأونصة الترويسية، بينما قد تسعر الحلي بالغرام مع درجة نقاء محددة. إذا حولنا العملة وتركنا الوحدة جانباً أصبحت المقارنة مضللة قبل أن نحتاج إلى أي نظرية اقتصادية. التفاصيل العادية تستحق مساحة في النقاش مثل القصص الاقتصادية الكبيرة.',
        ),
        (
            'Omar: yes. Write down what each number measures before comparing it. Keep taxes, fabrication charges and resale spreads distinct from changes in the underlying reference. This episode is about reading prices and product descriptions, not choosing a product. Clear units and disclosed terms often resolve an apparent contradiction more effectively than a complicated explanation.',
            'عمر: نعم. نكتب ما يقيسه كل رقم قبل مقارنته، ونفصل الضرائب وتكلفة التصنيع وفارق إعادة البيع عن تغير الأصل المرجعي. موضوعنا قراءة الأسعار ووصف المنتجات، وليس اختيار منتج للمستمع. كثيراً ما تحل الوحدات الواضحة والشروط المعلنة تعارضاً ظاهرياً بشكل أفضل من تفسير معقد، لأن الاختلاف قد يبدأ من تعريف السعر نفسه.',
        ),
    )),
    Episode('policy-expectations', 'When a policy decision meets expectations', 'عندما يلتقي القرار بالتوقعات', (
        (
            'Maya: a central-bank decision is a headline, but the decision and the surprise are not the same thing. A change may have been expected, while an unchanged rate may arrive with a different message. Omar, how can a listener examine a policy announcement without relying on a rule that a particular decision always sends gold in one direction?',
            'مايا: قرار البنك المركزي عنوان مهم، لكن القرار والمفاجأة ليسا الشيء نفسه. قد يكون التغيير متوقعاً، وقد يأتي تثبيت الفائدة مع رسالة مختلفة. كيف نفحص الإعلان من دون الاعتماد على قاعدة تقول إن قراراً معيناً يدفع الذهب دائماً في اتجاه واحد؟ نحتاج إلى فصل ما تقرر بالفعل عما فهمه المشاركون بشأن المسار المحتمل لاحقاً.',
        ),
        (
            'Omar: distinguish the announced action from the explanation and from expectations about future policy. Markets may react to several parts of the communication. Prior expectations must be documented rather than reconstructed after the move. The same decision can arrive in different economic circumstances, so its headline label alone does not describe the information added.',
            'عمر: نميز الإجراء المعلن من تفسيره ومن التوقعات المتعلقة بالسياسة المقبلة. قد تستجيب الأسواق لأجزاء متعددة من الرسالة. ينبغي توثيق التوقع السابق بدلاً من إعادة بنائه بعد الحركة. ويمكن أن يأتي القرار نفسه في ظروف اقتصادية مختلفة، لذلك لا يصف عنوانه وحده المعلومة التي أضيفت ولا يحدد وزنها مقارنة بما كان معروفاً.',
        ),
        (
            'Maya: and a question during a press conference may clarify a point that the first statement left open. Does that mean we need to preserve the sequence instead of merging every remark into one timeless story? Otherwise a later explanation could be mistakenly used to justify an earlier move, even though listeners had not yet heard it.',
            'مايا: وقد يوضح سؤال في المؤتمر الصحفي نقطة تركها البيان الأول مفتوحة. هل نحتاج إذن إلى حفظ التسلسل، بدلاً من دمج كل التعليقات في حكاية واحدة بلا أوقات؟ من السهل عندها استخدام شرح لاحق لتبرير حركة أسبق، مع أن المستمعين لم يكونوا قد سمعوه بعد. ترتيب الجمل قد يغير ما يمكن قوله بأمان عن العلاقة الزمنية.',
        ),
        (
            'Omar: precisely. Keep each statement with its publication and receipt time, and allow the interpretation to remain provisional. Rates, currencies and risk appetite can all be part of the response, but the data may not isolate one cause. The useful habit is to name the new information and its limits. A policy explanation can be thoughtful without pretending to be a short-term forecast.',
            'عمر: بالضبط. نحتفظ بكل تصريح مع وقت نشره ووصوله، ونسمح للتفسير بأن يبقى مؤقتاً. قد تدخل العوائد والعملات والإقبال على المخاطرة ضمن الاستجابة، من دون أن تعزل البيانات سبباً واحداً. العادة المفيدة هي تسمية المعلومة الجديدة وحدودها. يمكن أن يكون شرح السياسة عميقاً من غير تقديمه كتوقع قصير الأجل لسعر الذهب.',
        ),
    ), ('https://www.federalreserve.gov/aboutthefed/fedexplained/monetary-policy.htm',)),
)


def _clock(now_s):
    if type(now_s) is not int or now_s <= 0:
        raise ValueError('A positive integer programme clock is required')
    return now_s


def _language(language):
    if language not in ('ar', 'en'):
        raise ValueError('Unsupported programme language')
    return language


def _identity(language, episode, turn):
    return hashlib.sha256(f'{LIBRARY_VERSION}:{language}:{episode.identity}:{turn}'.encode()).hexdigest()[:32]


class ProgrammeLibrary:
    """Independent, ordered educational channels with explicit replay limits."""

    def __init__(self):
        self._lock = threading.RLock()
        self._state = {language: {'episode': None, 'turn': 0, 'cursor': 0, 'repeat': False,
                                 'completed': {}, 'pending': None, 'visits': {}}
                       for language in ('ar', 'en')}

    def candidate(self, language, now_s, excluded=()):
        _language(language)
        _clock(now_s)
        if isinstance(excluded, (str, bytes, dict)):
            raise ValueError('Excluded programme IDs must be a bounded iterable')
        try:
            values = list(islice(iter(excluded), 1001))
            if len(values) > 1000 or any(not isinstance(value, str) for value in values):
                raise ValueError('Excluded programme IDs must be a bounded iterable')
            excluded = set(values)
        except TypeError:
            raise ValueError('Excluded programme IDs must be a bounded iterable') from None
        with self._lock:
            state = self._state[language]
            if state['episode'] is None:
                ordered = [(state['cursor'] + index) % len(EPISODES) for index in range(len(EPISODES))]
                unplayed = [index for index in ordered if EPISODES[index].identity not in state['completed']]
                eligible = unplayed or [index for index in ordered if
                    now_s - state['completed'][EPISODES[index].identity] >= REPLAY_COOLDOWN_S]
                if not eligible:
                    return None
                index = eligible[0]
                state.update(episode=index, turn=0, repeat=EPISODES[index].identity in state['completed'])
            episode = EPISODES[state['episode']]
            turn = state['turn']
            identifier = _identity(language, episode, turn)
            if identifier in excluded:
                return None
            text = episode.turns[turn][0 if language == 'en' else 1]
            if turn == 0:
                prefix = (('A replay from our educational archive. ' if state['repeat'] else 'Recorded educational discussion. ')
                          if language == 'en' else
                          ('إعادة من أرشيفنا التعليمي. ' if state['repeat'] else 'من حواراتنا التعليمية المسجلة. '))
                text = prefix + text
            title = episode.title_en if language == 'en' else episode.title_ar
            role = 'host' if turn % 2 == 0 else 'analyst'
            speaker = (('Maya' if role == 'host' else 'Omar') if language == 'en' else
                       ('مايا' if role == 'host' else 'عمر'))
            programme = {'mode': 'recorded-educational', 'libraryVersion': LIBRARY_VERSION,
                'educational': True, 'currentNews': False, 'forecast': False,
                'episodeId': episode.identity, 'episodeTitle': title,
                'turnIndex': turn, 'turnCount': len(episode.turns), 'repeat': state['repeat'],
                'preparedAt': now_s * 1000, 'timingBasis': 'preparation-not-news-publication',
                'speakerRole': role, 'references': list(episode.references)}
            state['pending'] = identifier
            return {'id': identifier, 'kind': 'podcast', 'language': language,
                    'title': title, 'source': 'Gold Pulse educational archive', 'url': SOURCE_URL,
                    'publishedAt': now_s, 'firstSeenAt': now_s,
                    'speechText': text, 'speaker': speaker, 'programme': programme}

    def consume(self, job, now_s=None):
        """Advance only a currently offered turn, after it has been queued."""
        now_s = _clock(int(time.time()) if now_s is None else now_s)
        if not isinstance(job, dict) or job.get('language') not in ('ar', 'en'):
            return False
        language = job['language']
        with self._lock:
            state = self._state[language]
            if state['episode'] is None or not state['pending'] or job.get('kind') != 'podcast':
                return False
            episode = EPISODES[state['episode']]
            programme = job.get('programme')
            if (job.get('id') != state['pending'] or job['id'] != _identity(language, episode, state['turn']) or
                    not isinstance(programme, dict) or programme.get('episodeId') != episode.identity or
                    type(programme.get('turnIndex')) is not int or programme['turnIndex'] != state['turn'] or
                    type(job.get('firstSeenAt')) is not int or not 0 < job['firstSeenAt'] <= now_s):
                return False
            state['pending'] = None
            state['turn'] += 1
            if state['turn'] == len(episode.turns):
                state['completed'][episode.identity] = now_s
                state['visits'][episode.identity] = state['visits'].get(episode.identity, 0) + 1
                state['cursor'] = (state['episode'] + 1) % len(EPISODES)
                state.update(episode=None, turn=0, repeat=False)
            return True

    def status(self, language, now_s=None):
        _language(language)
        now_s = _clock(int(time.time()) if now_s is None else now_s)
        with self._lock:
            state = self._state[language]
            episode = EPISODES[state['episode']] if state['episode'] is not None else None
            unplayed = len(EPISODES) - len(state['completed'])
            replay_at = min((stamp + REPLAY_COOLDOWN_S for stamp in state['completed'].values()), default=None)
            return {'enabled': True, 'mode': 'recorded-educational', 'libraryVersion': LIBRARY_VERSION,
                    'episodes': len(EPISODES), 'turns': sum(len(row.turns) for row in EPISODES),
                    'unplayedEpisodes': unplayed, 'episodeId': episode.identity if episode else None,
                    'turnIndex': state['turn'] if episode else None, 'repeat': state['repeat'],
                    'replayCooldownSeconds': REPLAY_COOLDOWN_S,
                    'nextReplayAt': replay_at * 1000 if unplayed == 0 and replay_at is not None else None}

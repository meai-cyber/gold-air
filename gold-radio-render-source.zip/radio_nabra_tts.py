"""Private resident Nabra MSA reader, with CPU WASM and no synthesis network.

The pinned official espeak-ng 1.52 phonemizer runs in an owned Node process.
Model/dependencies live outside the source tree; neither this adapter nor its
worker opens a listener. Plain radio text is IPC data, never executable code.
"""
from __future__ import annotations

import base64
from datetime import date
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import re
import subprocess
import threading
import time
import unicodedata

try:
    from model_service.radio_arabic_tts import ArabicSpeech, convert_wav, validate_text
except ModuleNotFoundError:  # radio_station.py is also launched as a direct script.
    from radio_arabic_tts import ArabicSpeech, convert_wav, validate_text

ENGINE_ID = "nabra7m-fp16-wasm-local-v1"
VOICE_NAME = "Nabra MSA"
LANGUAGE = "ar"
SOURCE_REVISION = "16b5281ce61993df3526740990cf845a3f3036f4"
MODEL_REVISION = "bbac0f1e6b001bfae89871be366a4b000180deb2"
ORT_VERSION = "1.30.0"
G2P_ENGINE_ID = "nabra7m-g2p-only-local-v1"
NATIVE_MODEL_FILES = {"fp16": "model/model_fp16.onnx", "fp32": "model/model.onnx"}
NATIVE_MODEL_HASHES = {
    "fp16": "cafb38ee0d39629c1e228fd7f120bb8dbec896342880f3ac8318cfc10e3f19ff",
    "fp32": "08c1df048f2decbff3f86dc8e625e10ff3c8d5f66dfc97881c6974272f41ca5e"}
VOICE_HASH = "129d447a7c9bdce1d5b6cb5ecb789bbfd9f427b7775131a97dfa5638583b3b92"
MAX_RESPONSE_BYTES = 6_000_000
MAX_PRONUNCIATION_LENGTH = 6000
_ONES = ("صفر", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة")
_TEENS = ("عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر")
_TENS = ("", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون")
_HUNDREDS = ("", "مئة", "مئتان", "ثلاثمئة", "أربعمئة", "خمسمئة", "ستمئة", "سبعمئة", "ثمانمئة", "تسعمئة")
_MONTHS = ("", "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")


def arabic_integer(number: int) -> str:
    """Bounded exact cardinal expansion; no model is asked to rewrite numbers."""
    if isinstance(number, bool) or not isinstance(number, int) or not 0 <= number <= 999_999_999:
        raise ValueError("Numeric radio value is outside the supported speech range")
    if number < 10:
        return _ONES[number]
    if number < 20:
        return _TEENS[number - 10]
    if number < 100:
        tens, ones = divmod(number, 10)
        return (_ONES[ones] + " و" if ones else "") + _TENS[tens]
    if number < 1000:
        hundreds, remainder = divmod(number, 100)
        return _HUNDREDS[hundreds] + (" و" + arabic_integer(remainder) if remainder else "")
    size, singular, dual, plural = ((1_000_000, "مليون", "مليونان", "ملايين") if number >= 1_000_000
                                  else (1000, "ألف", "ألفان", "آلاف"))
    count, remainder = divmod(number, size)
    group = (singular if count == 1 else dual if count == 2 else
             arabic_integer(count) + " " + (plural if count <= 10 else singular))
    return group + (" و" + arabic_integer(remainder) if remainder else "")


def pronunciation_text(text: str) -> str:
    """Spell numeric values before G2P; espeak otherwise drops . - and %.

    This is pronunciation only. Producers retain their original numeric text,
    timestamps and evidence. Decimal places are read separately, including zero.
    """
    clean = validate_text(text)
    clean = "".join(str(unicodedata.decimal(char)) if char.isdecimal() else
                    {"\u066b": ".", "\u066c": ",", "\u066a": "%", "\u2212": "-"}.get(char, char)
                    for char in clean)

    def number(match):
        raw = match.group(1).replace(",", "")
        prefix = "ناقص " if raw.startswith("-") else "موجب " if raw.startswith("+") else ""
        raw = raw.lstrip("+-")
        integer, dot, fraction = raw.partition(".")
        if len(integer) > 9 or len(fraction) > 6:
            raise ValueError("Numeric radio precision is outside the supported speech range")
        value = prefix + arabic_integer(int(integer))
        if dot:
            value += " فاصل " + " ".join(_ONES[int(digit)] for digit in fraction)
        return value + (" بالمئة" if match.group(2) else "")

    def clock(match):
        hour, minute, second = int(match.group(1)), int(match.group(2)), match.group(3)
        if hour > 23:
            raise ValueError("Invalid radio clock")
        return (arabic_integer(hour) + " و" + arabic_integer(minute) + " دقيقة" +
                (" و" + arabic_integer(int(second)) + " ثانية" if second is not None else ""))

    def calendar(match):
        year, month, day = map(int, match.groups())
        date(year, month, day)  # A displayed date must be real; never reinterpret - as a price sign.
        return "يوم " + arabic_integer(day) + " من " + _MONTHS[month] + " عام " + arabic_integer(year)

    clean = re.sub(r"(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)", calendar, clean)
    # Expand clocks first; the generated words contain no numeric glyphs.
    clean = re.sub(r"(?<!\d)(\d{1,2}):([0-5]\d)(?::([0-5]\d))?(?!\d)", clock, clean)
    clean = re.sub(r"(?<![\d.])([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)(\s*%)?", number, clean)
    if re.search(r"\d|%", clean) or len(clean) > MAX_PRONUNCIATION_LENGTH:
        raise ValueError("Incomplete numeric pronunciation")
    return clean


def prepare_pronunciation(text, diacritizer=None):
    spoken = pronunciation_text(text)
    if diacritizer is not None:
        vowelled = diacritizer.diacritize(spoken)
        remove_marks = lambda value: re.sub(r"[\u064b-\u0652\u0670]", "", value)
        if (not isinstance(vowelled, str) or len(vowelled) > MAX_PRONUNCIATION_LENGTH or
            remove_marks(vowelled) != remove_marks(spoken)):
            raise ValueError("Arabic vowel restoration changed the spoken facts")
        spoken = vowelled
    return spoken


def _local_path(value, *, directory=False):
    path = Path(value)
    # This portable module lives directly in /app in the Render image.
    # parents[1] would be / and would incorrectly reject every absolute asset.
    project = Path(__file__).resolve().parent
    if not path.is_absolute() or str(path).startswith("\\\\") or not path.exists():
        raise ValueError("A fixed installed local Nabra runtime is required")
    for ancestor in (path, *path.parents):
        if ancestor.is_symlink() or getattr(ancestor.stat(), "st_file_attributes", 0) & 0x400:
            raise ValueError("Nabra runtime paths cannot be links or reparse points")
    resolved = path.resolve()
    if resolved == project or project in resolved.parents or (resolved.is_dir() != directory):
        raise ValueError("Nabra dependencies must stay outside the source tree")
    return resolved


class NabraArabicTts:
    """Sequential resident CPU voice, compatible with ArabicHodaTts callers."""
    def __init__(self, node_path, runtime_dir, *, timeout=35, process_factory=subprocess.Popen,
                 speed=1.0, diacritizer=None, _g2p_only=False):
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 1 <= timeout <= 60:
            raise ValueError("A bounded Nabra speech timeout is required")
        if isinstance(speed, bool) or not isinstance(speed, (int, float)) or not .95 <= speed <= 1.05:
            raise ValueError("Nabra requires a bounded owner-selected speaking rate")
        self.speed, self.diacritizer = float(speed), diacritizer
        node = _local_path(node_path)
        runtime = _local_path(runtime_dir, directory=True)
        if not (runtime / "manifest.json").is_file():
            raise ValueError("The pinned Nabra manifest is missing")
        self.timeout, self.lock, self.responses = timeout, threading.Lock(), queue.Queue()
        worker = Path(__file__).with_name("radio_nabra_worker.mjs")
        command = [str(node), str(worker), "--runtime-dir", str(runtime)]
        if _g2p_only:
            command.append("--g2p-only")
        environment = dict(os.environ)
        # Do not permit inherited Node hooks/preload code or online model tools.
        environment.pop("NODE_OPTIONS", None)
        environment.pop("NODE_PATH", None)
        environment.update(CUDA_VISIBLE_DEVICES="-1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
                           HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
        self.process = process_factory(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8", bufsize=1, env=environment,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        threading.Thread(target=self._read, daemon=True, name="RadioNabraSpeechIPC").start()
        try:
            if self._response(min(timeout, 25)) != {"ready": True, "engine": G2P_ENGINE_ID if _g2p_only else ENGINE_ID,
                    "voice": VOICE_NAME, "language": LANGUAGE, "modelRevision": MODEL_REVISION,
                    "sourceRevision": SOURCE_REVISION, "device": "g2p" if _g2p_only else "wasm", "threads": 1}:
                raise RuntimeError("The pinned CPU Nabra voice is unavailable")
        except Exception:
            self.close()
            raise

    def _read(self):
        try:
            while line := self.process.stdout.readline(MAX_RESPONSE_BYTES + 1):
                if len(line.encode("utf-8")) > MAX_RESPONSE_BYTES or not line.endswith("\n"):
                    self.responses.put(None)
                    return
                self.responses.put(line)
        finally:
            self.responses.put(None)

    def _response(self, timeout):
        try:
            line = self.responses.get(timeout=timeout)
        except queue.Empty:
            raise RuntimeError("Local Nabra speech timed out") from None
        if line is None:
            raise RuntimeError("Local Nabra speech is unavailable")
        try:
            result = json.loads(line)
        except (TypeError, json.JSONDecodeError):
            raise RuntimeError("Local Nabra speech returned invalid data") from None
        if not isinstance(result, dict):
            raise RuntimeError("Local Nabra speech returned invalid data")
        return result

    def synthesize(self, text: str) -> ArabicSpeech:
        started = time.perf_counter()
        spoken = prepare_pronunciation(text, self.diacritizer)
        with self.lock:
            if self.process.poll() is not None:
                raise RuntimeError("Local Nabra speech is unavailable")
            try:
                request = {"op": "synthesize", "text": spoken}
                if self.speed != 1.0:
                    request["speed"] = self.speed
                self.process.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
                self.process.stdin.flush()
                result = self._response(max(.001, self.timeout - (time.perf_counter() - started)))
                elapsed, chunks = result.get("inference_s"), result.get("chunkCount")
                if (result.get("ok") is not True or result.get("engine") != ENGINE_ID or
                    result.get("voice") != VOICE_NAME or result.get("language") != LANGUAGE or
                    result.get("coveredCharacters") != len(spoken) or isinstance(chunks, bool) or
                    not isinstance(chunks, int) or not 1 <= chunks <= 64 or isinstance(elapsed, bool) or
                    not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed) or
                    not 0 <= elapsed <= self.timeout or not isinstance(result.get("wav"), str)):
                    raise RuntimeError("Local Nabra speech failed")
                wav, duration = convert_wav(base64.b64decode(result["wav"], validate=True))
                return ArabicSpeech(wav=wav, duration_s=duration, inference_s=time.perf_counter() - started,
                    voice=VOICE_NAME, language=LANGUAGE, engine=ENGINE_ID)
            except Exception:
                # Stop an uncertain response from becoming the next request's audio.
                self.close()
                raise

    def close(self):
        process = getattr(self, "process", None)
        if not process:
            return
        if process.poll() is None:
            try:
                process.stdin.write('{"op":"close"}\n'); process.stdin.flush()
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired, ValueError):
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait(timeout=2)
        for stream in (process.stdin, process.stdout):
            if stream and not stream.closed:
                try:
                    stream.close()
                except (OSError, ValueError):
                    pass


def validate_phoneme_response(result, spoken):
    """Independently check the bounded tokenizer receipt before native inference."""
    if (not isinstance(result, dict) or result.get("ok") is not True or
        result.get("engine") != G2P_ENGINE_ID or result.get("sourceRevision") != SOURCE_REVISION or
        result.get("modelRevision") != MODEL_REVISION or result.get("coveredCharacters") != len(spoken)):
        raise ValueError("The matching Nabra phonemizer is unavailable")
    chunks = result.get("chunks")
    if not isinstance(chunks, list) or not 1 <= len(chunks) <= 64:
        raise ValueError("Invalid bounded Nabra phoneme receipt")
    for chunk in chunks:
        if not isinstance(chunk, dict) or set(chunk) != {"graphemes", "phonemes", "inputIds", "styleIndex"}:
            raise ValueError("Invalid private Nabra chunk fields")
        text, phonemes, ids, style = (chunk.get(key) for key in ("graphemes", "phonemes", "inputIds", "styleIndex"))
        if (not isinstance(text, str) or not text or len(text) > 180 or not isinstance(phonemes, str) or
            not 1 <= len(phonemes) <= 510 or not isinstance(ids, list) or len(ids) != len(phonemes) + 2 or
            ids[0] != 0 or ids[-1] != 0 or any(type(value) is not int or not 0 <= value <= 177 for value in ids) or
            type(style) is not int or style != len(phonemes) - 1):
            raise ValueError("Invalid complete Nabra phoneme bounds")
    if " ".join(chunk["graphemes"] for chunk in chunks) != spoken:
        raise ValueError("Incomplete Nabra pronunciation coverage")
    return chunks


def _native_artifacts(runtime, precision):
    manifest = json.loads((runtime / "manifest.json").read_text(encoding="utf-8-sig"))
    if (manifest.get("sourceRevision") != SOURCE_REVISION or manifest.get("modelRevision") != MODEL_REVISION or
        manifest.get("ortVersion") != ORT_VERSION or manifest.get("engine") != ENGINE_ID):
        raise ValueError("Native Nabra requires the exact matching installed source")
    hashes = manifest.get("artifacts", {})
    model_name = NATIVE_MODEL_FILES[precision]
    blobs = {}
    for name, fixed in ((model_name, NATIVE_MODEL_HASHES[precision]), ("model/af_msa.bin", VOICE_HASH),
                        ("g2p.mjs", None)):
        file = _local_path(runtime / name)
        expected_size = {"model/model_fp16.onnx": 15_969_086, "model/model.onnx": 30_542_978,
                         "model/af_msa.bin": 522_240}.get(name)
        if expected_size is not None and file.stat().st_size != expected_size or file.stat().st_size > 31_000_000:
            raise ValueError("Changed native Nabra artifact size")
        content = file.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        if digest != hashes.get(name) or fixed is not None and digest != fixed:
            raise ValueError("Changed native Nabra artifact")
        blobs[name] = content
    return runtime / model_name, blobs["model/af_msa.bin"]


class NabraNativeArabicTts(NabraArabicTts):
    """Owner-only candidate: native ONNX CPU plus the same pinned offline G2P.

    This does not replace DLLs or select a GPU provider. The deployed WASM
    reader remains a separate default until the owner selects this candidate.
    """
    def __init__(self, node_path, runtime_dir, *, precision="fp32", threads=2, timeout=35,
                 speed=1.0, diacritizer=None, process_factory=subprocess.Popen):
        if precision not in NATIVE_MODEL_FILES or type(threads) is not int or threads not in (1, 2):
            raise ValueError("Native Nabra uses an explicit FP16/FP32 and one or two CPU threads")
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 1 <= timeout <= 60:
            raise ValueError("A bounded native Nabra speech timeout is required")
        if isinstance(speed, bool) or not isinstance(speed, (int, float)) or not .95 <= speed <= 1.05:
            raise ValueError("Native Nabra requires a bounded owner-selected speaking rate")
        try:
            import numpy as np
            import onnxruntime as ort
        except ImportError:
            raise RuntimeError("The installed native CPU ONNX runtime is unavailable") from None
        if ort.__version__ != ORT_VERSION or "CPUExecutionProvider" not in ort.get_available_providers():
            raise RuntimeError("The compatible installed CPU ONNX runtime is unavailable")
        runtime = _local_path(runtime_dir, directory=True)
        model, voice_bytes = _native_artifacts(runtime, precision)
        voice = np.frombuffer(voice_bytes, dtype="<f4")
        if voice.size != 510 * 256 or not np.isfinite(voice).all():
            raise ValueError("The matching native Nabra voice is invalid")
        self.voice_vectors = voice.reshape(510, 256)
        self.native_engine = "nabra7m-" + precision + "-native-cpu-local-v1"
        self.native_threads = threads
        self.ort, self.np = ort, np
        options = ort.SessionOptions()
        options.intra_op_num_threads = threads
        options.inter_op_num_threads = 1
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        options.add_session_config_entry("session.intra_op.allow_spinning", "0")
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        options.log_severity_level = 3
        try:
            self.session = ort.InferenceSession(str(model), sess_options=options, providers=["CPUExecutionProvider"])
        except Exception:
            raise RuntimeError("The pinned native Nabra CPU model is unavailable") from None
        if self.session.get_providers() != ["CPUExecutionProvider"]:
            self.session = None
            raise RuntimeError("Native Nabra must use CPU inference only")
        self.session.disable_fallback()
        inputs = {node.name: node.type for node in self.session.get_inputs()}
        outputs = {node.name: node.type for node in self.session.get_outputs()}
        if (inputs != {"input_ids": "tensor(int64)", "style": "tensor(float)", "speed": "tensor(float)"} or
            outputs != {"waveform": "tensor(float)", "durations": "tensor(int64)"}):
            self.session = None
            raise RuntimeError("The compatible native Nabra model contract is unavailable")
        try:
            super().__init__(node_path, runtime, timeout=timeout, process_factory=process_factory,
                             speed=speed, diacritizer=diacritizer, _g2p_only=True)
        except Exception:
            self.session = None
            raise

    def synthesize(self, text: str) -> ArabicSpeech:
        started = time.perf_counter()
        spoken = prepare_pronunciation(text, self.diacritizer)
        with self.lock:
            if self.process.poll() is not None or self.session is None:
                raise RuntimeError("Local native Nabra speech is unavailable")
            try:
                self.process.stdin.write(json.dumps({"op": "synthesize", "text": spoken}, ensure_ascii=False) + "\n")
                self.process.stdin.flush()
                chunks = validate_phoneme_response(self._response(max(.001, self.timeout - (time.perf_counter() - started))), spoken)
                parts, frames = [], 0
                run_options = self.ort.RunOptions()
                cancelled = threading.Event()
                def cancel():
                    cancelled.set()
                    run_options.terminate = True
                timer = threading.Timer(max(.001, self.timeout - (time.perf_counter() - started)), cancel)
                timer.daemon = True
                timer.start()
                try:
                    for chunk in chunks:
                        if cancelled.is_set():
                            raise RuntimeError("Local native Nabra speech timed out")
                        style = self.voice_vectors[chunk["styleIndex"]:chunk["styleIndex"] + 1]
                        if style.shape != (1, 256) or not self.np.isfinite(style).all():
                            raise ValueError("Invalid Nabra style vector")
                        feeds = {"input_ids": self.np.array([chunk["inputIds"]], dtype=self.np.int64),
                                 "style": style, "speed": self.np.array([self.speed], dtype=self.np.float32)}
                        waveform = self.session.run(["waveform"], feeds, run_options)[0]
                        if (not isinstance(waveform, self.np.ndarray) or waveform.dtype != self.np.float32 or
                            waveform.ndim != 1 or not waveform.size or not self.np.isfinite(waveform).all() or
                            not self.np.any(waveform)):
                            raise ValueError("Native Nabra returned invalid waveform")
                        frames += waveform.size
                        if frames > 24000 * 90:
                            raise ValueError("Native Nabra exceeds its audio bound")
                        parts.append(waveform)
                finally:
                    timer.cancel()
                if cancelled.is_set() or time.perf_counter() - started > self.timeout:
                    raise RuntimeError("Local native Nabra speech timed out")
                import io
                import wave
                output = io.BytesIO()
                audio = self.np.concatenate(parts)
                with wave.open(output, "wb") as target:
                    target.setnchannels(1); target.setsampwidth(2); target.setframerate(24000)
                    target.writeframes(self.np.rint(self.np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes())
                wav, duration = convert_wav(output.getvalue())
                return ArabicSpeech(wav=wav, duration_s=duration, inference_s=time.perf_counter() - started,
                    voice=VOICE_NAME, language=LANGUAGE, engine=self.native_engine)
            except Exception as error:
                self.close()
                if isinstance(error, (ValueError, RuntimeError, TimeoutError, OSError)):
                    raise
                raise RuntimeError("Local native Nabra speech failed") from None

    def close(self):
        super().close()
        self.session = None

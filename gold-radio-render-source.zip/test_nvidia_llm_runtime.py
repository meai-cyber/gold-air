import io
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import nvidia_llm_runtime as runtime


TOKEN = 'fixture_nvidia_key_never_a_real_secret_0123456789'


def answer(text='Oil costs can affect inflation expectations and demand for gold.', *, tokens=12, finish='stop'):
    return {'choices': [{'message': {'role': 'assistant', 'content': text}, 'finish_reason': finish}],
            'usage': {'prompt_tokens': 80, 'completion_tokens': tokens}}


class FakeResponse(io.BytesIO):
    status = 200
    content_length = None

    def __init__(self, body):
        super().__init__(body)
        self.read_calls = 0

    def read(self, *args):
        self.read_calls += 1
        return super().read(*args)

    def getheader(self, name):
        return self.content_length


class FakeConnection:
    def __init__(self, response=None):
        self.response = response or FakeResponse(json.dumps(answer()).encode())
        self.sock = None
        self.calls = []
        self.closed = False

    def connect(self):
        pass

    def request(self, *args, **kwargs):
        self.calls.append((args, kwargs))

    def getresponse(self):
        return self.response

    def close(self):
        self.closed = True


class AbortableSocket:
    def __init__(self):
        self.aborted = threading.Event()
        self.shutdowns = 0
        self.closes = 0
        self.timeouts = []

    def settimeout(self, value):
        self.timeouts.append(value)

    def shutdown(self, how):
        self.shutdowns += 1
        self.aborted.set()

    def close(self):
        self.closes += 1
        self.aborted.set()


class BlockedHeadersConnection(FakeConnection):
    def __init__(self):
        super().__init__()
        self.sock = AbortableSocket()
        self.entered = threading.Event()

    def getresponse(self):
        self.entered.set()
        if not self.sock.aborted.wait(4):
            raise AssertionError('Cancellation did not interrupt the blocked header read')
        raise OSError('Connection was aborted')


class TrickleResponse(FakeResponse):
    def __init__(self, sock):
        super().__init__(b'')
        self.socket = sock
        self.fp = SimpleNamespace(raw=SimpleNamespace(_sock=sock))
        self.entered = threading.Event()

    def read(self, size):
        self.read_calls += 1
        self.entered.set()
        # Individual chunks arrive often enough to defeat a per-read timeout;
        # the separate absolute-deadline watchdog must interrupt the stream.
        if self.socket.aborted.wait(.025):
            raise OSError('Connection was aborted')
        return b' '


class NvidiaRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.environment = patch.dict(os.environ, {
            'NVIDIA_API_KEY': TOKEN, 'RADIO_NVIDIA_LLM': '1',
            'CF_API_TOKEN': 'unrelated_cf_key_must_never_be_read_0123456789'})
        self.environment.start()
        self.instances = []

    def tearDown(self):
        for instance in self.instances:
            instance.close()
            if instance._worker:
                instance._worker.join(.5)
        self.environment.stop()
        self.temporary.cleanup()

    def instance(self, cls=runtime.NvidiaLlmRuntime, **options):
        instance = cls(self.temporary.name, **options)
        self.instances.append(instance)
        return instance

    def job(self, text='Public news about oil and inflation', *, tokens=64, timeout=5):
        return runtime._Job(text, 'en', tokens, time.monotonic() + timeout)

    def test_disabled_missing_or_malformed_credentials_fail_before_http(self):
        for changes, reason in (({'RADIO_NVIDIA_LLM': '0'}, 'disabled'),
                                ({'NVIDIA_API_KEY': ''}, 'credentials-missing'),
                                ({'NVIDIA_API_KEY': '\r\nbad'}, 'credentials-missing')):
            with patch.dict(os.environ, changes):
                instance = self.instance()
            with patch.object(runtime.http.client, 'HTTPSConnection') as factory:
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, reason):
                    instance.generate('Public news')
                factory.assert_not_called()
            self.assertIsNone(instance._worker)
        self.assertFalse(Path(self.temporary.name, 'nvidia-llm').exists())

    def test_exact_tls_host_and_model_never_proxy_and_disable_thinking(self):
        instance, connection = self.instance(), FakeConnection()
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection) as factory, \
                patch.dict(os.environ, {'HTTPS_PROXY': 'http://untrusted.test:8080'}):
            value = instance.generate('Public news', max_tokens=64, timeout=5)
        self.assertIn('Oil', value)
        self.assertEqual(factory.call_args.args, ('integrate.api.nvidia.com',))
        self.assertEqual(factory.call_args.kwargs['port'], 443)
        context = factory.call_args.kwargs['context']
        self.assertTrue(context.check_hostname)
        self.assertEqual(context.verify_mode, runtime.ssl.CERT_REQUIRED)
        args, kwargs = connection.calls[0]
        self.assertEqual(args, ('POST', '/v1/chat/completions'))
        body = json.loads(kwargs['body'])
        self.assertEqual(body['model'], 'nvidia/nemotron-3.5-bolt-e4b')
        self.assertEqual(body['chat_template_kwargs'], {'enable_thinking': False, 'conversational_mode': True})
        self.assertFalse(body['stream'])
        self.assertEqual(body['max_tokens'], 64)
        self.assertEqual(kwargs['headers']['Authorization'], 'Bearer ' + TOKEN)
        self.assertNotIn('unrelated_cf_key', json.dumps(body))
        self.assertTrue(connection.closed)
        status = instance.status()
        self.assertFalse(status['resident'])
        self.assertFalse(status['publicApi'])
        self.assertEqual(status['connectionState'], 'verified-response')
        self.assertEqual(status['quantization'], 'provider-managed-unknown')
        self.assertEqual(status['lastUsage']['completionTokens'], 12)
        self.assertNotIn(TOKEN, json.dumps(status))

    def test_changed_endpoint_cannot_receive_authentication(self):
        instance = self.instance()
        for endpoint in ('https://untrusted.test/v1/chat/completions',
                         'http://integrate.api.nvidia.com/v1/chat/completions',
                         runtime.ENDPOINT + '?redirect=elsewhere',
                         'https://integrate.api.nvidia.com:443/v1/chat/completions'):
            instance._endpoint = endpoint
            with patch.object(runtime.http.client, 'HTTPSConnection') as factory:
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'invalid-endpoint'):
                    instance._request({}, self.job())
                factory.assert_not_called()

    def test_errors_never_read_or_echo_provider_body_and_never_retry(self):
        instance = self.instance()
        for status, reason in ((302, 'provider-redirect'), (401, 'provider-auth'),
                               (403, 'provider-auth'), (429, 'rate-limited'), (500, 'provider-error')):
            response = FakeResponse(TOKEN.encode()); response.status = status
            connection = FakeConnection(response)
            with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection) as factory:
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, reason) as raised:
                    instance._request({}, self.job())
                self.assertEqual(factory.call_count, 1)
                self.assertEqual(response.read_calls, 0)
                self.assertNotIn(TOKEN, str(raised.exception))
                self.assertTrue(connection.closed)
        connection = FakeConnection()
        connection.getresponse = lambda: (_ for _ in ()).throw(TimeoutError(TOKEN))
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
                instance._request({}, self.job())
        self.assertTrue(connection.closed)

    def test_bounded_private_or_malformed_requests_never_start_worker(self):
        instance = self.instance()
        cases = [('', {}), ('x' * 4801, {}), ('<|system|>', {}), ('news\x00', {}),
                 ('news', {'language': 'fr'}), ('news', {'max_tokens': 321}),
                 ('news', {'max_tokens': True}), ('news', {'timeout': 181}),
                 ('news', {'timeout': float('nan')}), ('news', {'schema': {}}), (TOKEN, {})]
        for text, options in cases:
            with self.assertRaises(runtime.CloudLlmUnavailable):
                instance.generate(text, **options)
        self.assertIsNone(instance._worker)

    def test_arabic_text_and_complete_plaintext_only(self):
        instance = self.instance()
        with patch.object(instance, '_request', return_value=answer('قد تؤثر أسعار النفط في توقعات التضخم والطلب على الذهب.')):
            self.assertIn('الذهب', instance.generate('اكتب تحليلاً قصيراً عن النفط والذهب', language='ar', max_tokens=64, timeout=5))
        values = [answer(''), answer('partial', finish='length'), answer(tokens=64),
                  answer('<think>reasoning</think>Answer'), answer('<|channel|>analysis'),
                  answer(TOKEN), {'choices': []}, {'error': {'message': TOKEN}}]
        for field in ('reasoning_content', 'reasoning', 'tool_calls', 'function_call'):
            value = answer(); value['choices'][0]['message'][field] = 'not allowed'; values.append(value)
        with patch.object(runtime, 'MIN_REQUEST_INTERVAL_SECONDS', 0):
            instance._next_request_at = 0
            for value in values:
                with patch.object(instance, '_request', return_value=value):
                    with self.assertRaises(runtime.CloudLlmUnavailable):
                        instance._complete(self.job())

    def test_usage_required_strict_and_overrun_blocks_day_independently_of_counter(self):
        instance = self.instance()
        with patch.object(runtime, 'MIN_REQUEST_INTERVAL_SECONDS', 0):
            for usage in (None, {}, {'prompt_tokens': True, 'completion_tokens': 12},
                          {'prompt_tokens': 20, 'completion_tokens': -1}):
                value = answer(); value['usage'] = usage
                with patch.object(instance, '_request', return_value=value):
                    with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'invalid-usage'):
                        instance._complete(self.job())
            with patch.object(instance, '_request', return_value=answer(tokens=65)):
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'provider-usage-over-bound'):
                    instance._complete(self.job())
        self.assertEqual(instance.status()['budget']['reservedCalls'], 5)
        self.assertTrue(instance.status()['budget']['blockedUntilUtcDayReset'])
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'provider-usage-over-bound'):
            instance._reserve_call()

    def test_response_bound_and_invalid_json(self):
        instance = self.instance()
        for body, length, reason in ((b'x' * (runtime.MAX_RESPONSE_BYTES + 1), None, 'response-limit'),
                                     (b'{}', str(runtime.MAX_RESPONSE_BYTES + 1), 'response-limit'),
                                     (b'{invalid', None, 'provider-unavailable')):
            response = FakeResponse(body); response.content_length = length
            with patch.object(runtime.http.client, 'HTTPSConnection', return_value=FakeConnection(response)):
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, reason):
                    instance._request({}, self.job())

    def test_daily_counter_counts_failures_persists_and_resets_next_utc_day(self):
        instance = self.instance(); instance._clock = lambda: 1792886400
        with patch.object(instance, '_request', side_effect=runtime.CloudLlmUnavailable('rate-limited')):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'rate-limited'):
                instance._complete(self.job())
        self.assertEqual(instance.status()['budget']['reservedCalls'], 1)
        other = self.instance(); other._clock = instance._clock
        other._reserve_call()
        other._reserve_call()
        self.assertEqual(other.status()['budget']['reservedCalls'], 3)
        other._clock = lambda: instance._clock() + 86400
        other._reserve_call()
        self.assertEqual(other.status()['budget']['reservedCalls'], 1)
        instance._clock = lambda: 1
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'budget-state-unavailable'):
            instance._reserve_call()
        self.assertNotIn(TOKEN, (instance.directory / 'budget.json').read_text())

    def test_no_artificial_daily_call_quota_and_blocked_flag_requires_new_utc_day(self):
        instance = self.instance(); instance._clock = lambda: 1792886400
        with instance._budget_lock():
            instance._write_budget({'version': 2, 'utcDay': '2026-10-25',
                                    'reservedCalls': 5000, 'blocked': False})
        instance._reserve_call()
        status = instance.status()['budget']
        self.assertEqual(status['reservedCalls'], 5001)
        self.assertIsNone(status['dailyCallCap'])
        self.assertEqual(status['kind'], 'local-prototype-call-counter')
        self.assertFalse(status['providerAllowanceVerified'])
        instance._reserve_call(block=True)
        other = self.instance(); other._clock = instance._clock
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'provider-usage-over-bound'):
            other._reserve_call()
        self.assertEqual(other.status()['budget']['reservedCalls'], 5001)
        self.assertTrue(other.status()['budget']['blockedUntilUtcDayReset'])
        other._clock = lambda: 1792972800
        other._reserve_call()
        self.assertEqual(other.status()['budget']['reservedCalls'], 1)
        self.assertFalse(other.status()['budget']['blockedUntilUtcDayReset'])

    def test_state_corruption_source_directory_and_symlink_rejected(self):
        instance = self.instance()
        instance._reserve_call()
        (instance.directory / 'budget.json').write_text('{broken')
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'budget-state-unavailable'):
            instance._reserve_call()
        instance.directory = Path(__file__).resolve().parent / 'must-never-be-created'
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'budget-state-unavailable'):
            instance._reserve_call()
        self.assertFalse(instance.directory.exists())
        instance.directory = Path(self.temporary.name) / 'link-state'
        with patch.object(Path, 'is_symlink', return_value=True):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'budget-state-unavailable'):
                instance._reserve_call()
        self.assertFalse(instance.directory.exists())
        self.assertEqual(runtime._source_root(PurePosixPath('/app/nvidia_llm_runtime.py')), PurePosixPath('/app'))
        self.assertEqual(runtime._source_root(PureWindowsPath(r'C:\source\deployment\render-radio\nvidia_llm_runtime.py')),
                         PureWindowsPath(r'C:\source'))

    def test_auth_and_rate_limit_apply_cooldown_without_retry(self):
        for status, reason in ((401, 'provider-auth'), (429, 'rate-limited')):
            instance = self.instance()
            response = FakeResponse(b'not read'); response.status = status
            with patch.object(runtime.http.client, 'HTTPSConnection', return_value=FakeConnection(response)) as factory:
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, reason):
                    instance.generate('Public news', max_tokens=64, timeout=5)
                with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'cooldown'):
                    instance.generate('Next news', timeout=5)
                self.assertEqual(factory.call_count, 1)
            self.assertIsNone(instance.status()['lastGenerationAt'])

    def test_spacing_waits_for_next_turn_and_honors_deadline(self):
        instance = self.instance(); sends = []
        def request(payload, job):
            sends.append(time.monotonic())
            return answer()
        with patch.object(runtime, 'MIN_REQUEST_INTERVAL_SECONDS', .08), patch.object(instance, '_request', side_effect=request):
            self.assertTrue(instance.generate('Analyst', max_tokens=64, timeout=3))
            self.assertTrue(instance.generate('Host', max_tokens=64, timeout=3))
        self.assertGreaterEqual(sends[1] - sends[0], .075)
        instance._next_request_at = time.monotonic() + 3
        with patch.object(instance, '_request') as request:
            with self.assertRaises(runtime.CloudLlmUnavailable):
                instance.generate('too early', timeout=1)
            request.assert_not_called()

    def test_single_active_one_pending_pause_and_close_discard_late_result(self):
        entered, release = threading.Event(), threading.Event()
        class Slow(runtime.NvidiaLlmRuntime):
            def _complete(self, job):
                entered.set(); release.wait(3)
                return 'late output'
        instance, results = self.instance(Slow), {}
        def call(name):
            try: results[name] = instance.generate(name, timeout=3)
            except runtime.CloudLlmUnavailable as error: results[name] = error.reason
        first = threading.Thread(target=call, args=('first',)); first.start()
        self.assertTrue(entered.wait(1))
        second = threading.Thread(target=call, args=('second',)); second.start()
        deadline = time.monotonic() + 1
        while instance._jobs.qsize() != 1 and time.monotonic() < deadline:
            time.sleep(.005)
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'busy'):
            instance.generate('third', timeout=1)
        start = time.monotonic(); instance.pause(seconds=1)
        self.assertLess(time.monotonic() - start, .1)
        first.join(1); second.join(1)
        self.assertEqual(results, {'first': 'speech-priority', 'second': 'speech-priority'})
        self.assertIsNone(instance.status()['lastGenerationAt'])
        release.set(); instance.close(); instance._worker.join(1)
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'disabled'):
            instance.generate('closed')
        self.assertIsNone(instance._active)
        self.assertEqual(instance._jobs.qsize(), 0)

    def test_pause_and_close_shutdown_owned_socket_and_release_worker(self):
        for action, reason in (('pause', 'speech-priority'), ('close', 'closed')):
            instance, connection, result = self.instance(), BlockedHeadersConnection(), []
            def call():
                try:
                    result.append(instance.generate('Public news', timeout=3, max_tokens=64))
                except runtime.CloudLlmUnavailable as error:
                    result.append(error.reason)
            with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
                caller = threading.Thread(target=call); caller.start()
                self.assertTrue(connection.entered.wait(1))
                start = time.monotonic()
                getattr(instance, action)()
                self.assertLess(time.monotonic() - start, .2)
                caller.join(.5)
                until = time.monotonic() + .5
                while instance.status()['preparing'] and time.monotonic() < until:
                    time.sleep(.005)
            self.assertEqual(result, [reason])
            self.assertGreaterEqual(connection.sock.shutdowns, 1)
            self.assertGreaterEqual(connection.sock.closes, 1)
            self.assertTrue(connection.closed)
            self.assertIsNone(instance._connection)
            self.assertFalse(instance.status()['preparing'])
            self.assertEqual(instance._jobs.unfinished_tasks, 0)
            if action == 'pause':
                # The same sole worker can service a later request after a
                # cancellation, rather than retaining the blocked connection.
                instance._cooldown_until = instance._next_request_at = 0
                with patch.object(runtime.http.client, 'HTTPSConnection', return_value=FakeConnection()):
                    self.assertIn('Oil', instance.generate('Next news', max_tokens=64, timeout=3))

    def test_caller_timeout_aborts_socket_even_without_watchdog_callback(self):
        class DormantTimer:
            def __init__(self, *args, **kwargs):
                self.daemon = False
            def start(self):
                pass
            def cancel(self):
                pass
        instance, connection = self.instance(), BlockedHeadersConnection()
        with patch.object(runtime.threading, 'Timer', DormantTimer), \
                patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            start = time.monotonic()
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
                instance.generate('Public news', timeout=1, max_tokens=64)
            self.assertLess(time.monotonic() - start, 1.5)
            until = time.monotonic() + .5
            while instance.status()['preparing'] and time.monotonic() < until:
                time.sleep(.005)
        self.assertGreaterEqual(connection.sock.shutdowns, 1)
        self.assertTrue(connection.closed)
        self.assertFalse(instance.status()['preparing'])
        self.assertEqual(instance._jobs.unfinished_tasks, 0)

    def test_absolute_deadline_watchdog_interrupts_blocked_headers(self):
        instance, connection = self.instance(), BlockedHeadersConnection()
        job = self.job(timeout=.12)
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            start = time.monotonic()
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
                instance._request({}, job)
            self.assertLess(time.monotonic() - start, .7)
        self.assertTrue(job.cancelled.is_set())
        self.assertTrue(job.complete.is_set())
        self.assertGreaterEqual(connection.sock.shutdowns, 1)
        self.assertTrue(connection.closed)
        self.assertIsNone(instance._connection)
        self.assertIsNone(instance._connection_watchdog)

    def test_absolute_deadline_stops_trickling_detached_response_socket(self):
        instance, sock = self.instance(), AbortableSocket()
        response = TrickleResponse(sock)
        connection = FakeConnection(response)
        connection.sock = sock
        def getresponse():
            # HTTPConnection can detach its socket after Connection: close.
            connection.sock = None
            return response
        connection.getresponse = getresponse
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            start = time.monotonic()
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
                instance._request({}, self.job(timeout=.15))
            self.assertLess(time.monotonic() - start, .7)
        self.assertGreater(response.read_calls, 1)
        self.assertGreaterEqual(sock.shutdowns, 1)
        self.assertGreaterEqual(sock.closes, 1)
        self.assertTrue(response.closed)
        self.assertTrue(connection.closed)
        self.assertIsNone(instance._connection)

    def test_synchronous_deadline_shuts_down_response_before_closing_file(self):
        class DormantTimer:
            def __init__(self, *args, **kwargs):
                self.daemon = False
            def start(self):
                pass
            def cancel(self):
                pass
        instance, sock, close_order = self.instance(), AbortableSocket(), []
        class ClosingResponse(TrickleResponse):
            def close(self):
                close_order.append((sock.shutdowns, sock.closes))
                self.fp = None
                super().close()
        response = ClosingResponse(sock)
        connection = FakeConnection(response)
        with patch.object(runtime.threading, 'Timer', DormantTimer), \
                patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
                instance._request({}, self.job(timeout=.08))
        self.assertGreater(response.read_calls, 1)
        self.assertGreaterEqual(sock.shutdowns, 1)
        self.assertGreaterEqual(sock.closes, 1)
        self.assertTrue(all(shutdowns >= 1 and closes >= 1 for shutdowns, closes in close_order))
        self.assertTrue(response.closed)
        self.assertTrue(connection.closed)
        self.assertIsNone(instance._connection)
        self.assertIsNone(instance._connection_watchdog)

    def test_deadline_before_response_publication_cleans_local_detached_socket(self):
        instance, sock = self.instance(), AbortableSocket()
        response = TrickleResponse(sock)
        connection, job = FakeConnection(response), self.job()
        def getresponse():
            # Cancellation wins after HTTPConnection detaches its socket but
            # before the response is visible to the runtime's watchdog.
            instance._deadline_abort(job, connection)
            return response
        connection.getresponse = getresponse
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
                instance._request({}, job)
        self.assertEqual(response.read_calls, 0)
        self.assertGreaterEqual(sock.shutdowns, 1)
        self.assertGreaterEqual(sock.closes, 1)
        self.assertTrue(response.closed)
        self.assertTrue(connection.closed)
        self.assertIsNone(instance._connection)

    def test_old_watchdog_and_queued_cancellation_cannot_abort_later_connection(self):
        instance = self.instance()
        old_job, later_job = self.job(), self.job()
        old_connection, later_connection = FakeConnection(), FakeConnection()
        later_connection.sock = AbortableSocket()
        with instance._state:
            instance._active = later_job
            instance._connection = later_connection
            instance._connection_job = later_job
        instance._deadline_abort(old_job, old_connection)
        instance._deadline_abort(old_job, later_connection)
        self.assertFalse(instance._abort_connection(old_job))
        self.assertFalse(later_job.cancelled.is_set())
        self.assertFalse(later_job.complete.is_set())
        self.assertEqual(later_connection.sock.shutdowns, 0)
        self.assertFalse(later_connection.closed)
        self.assertIs(instance._connection, later_connection)
        instance.close()
        self.assertGreaterEqual(later_connection.sock.shutdowns, 1)

    def test_queued_caller_timeout_does_not_interrupt_active_socket(self):
        instance, connection, results = self.instance(), BlockedHeadersConnection(), {}
        def call(name, timeout):
            try:
                results[name] = instance.generate(name, timeout=timeout, max_tokens=64)
            except runtime.CloudLlmUnavailable as error:
                results[name] = error.reason
        with patch.object(runtime.http.client, 'HTTPSConnection', return_value=connection):
            first = threading.Thread(target=call, args=('active', 3)); first.start()
            self.assertTrue(connection.entered.wait(1))
            second = threading.Thread(target=call, args=('queued', 1)); second.start()
            second.join(1.5)
            self.assertEqual(results.get('queued'), 'timeout')
            self.assertEqual(connection.sock.shutdowns, 0)
            self.assertFalse(connection.closed)
            self.assertTrue(instance.status()['preparing'])
            instance.pause()
            first.join(.5)
        self.assertEqual(results.get('active'), 'speech-priority')
        self.assertGreaterEqual(connection.sock.shutdowns, 1)


if __name__ == '__main__':
    unittest.main()

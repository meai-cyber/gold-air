import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import shutil
import struct
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import urllib.error
import urllib.request
import wave

from audio_delivery import SpeechEncoder, SPEECH_BITRATE, MUSIC_BITRATE, music_assets
import server


def pcm(seconds=1):
    data = io.BytesIO()
    with wave.open(data, 'wb') as audio:
        audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
        audio.writeframes(b''.join(struct.pack('<h', round(5000 * math.sin(i / 20))) for i in range(round(seconds * 24000))))
    return data.getvalue()


class DeliveryTests(unittest.TestCase):
    def test_missing_and_failed_encoder_preserve_original_complete_pcm(self):
        data = pcm()
        with patch('audio_delivery.shutil.which', return_value=None):
            encoder = SpeechEncoder()
        self.assertEqual((encoder.encode(data).data, encoder.encode(data).extension), (data, 'wav'))
        encoder = SpeechEncoder('missing-test-binary')
        self.assertEqual(encoder.encode(data).data, data)
        self.assertEqual(encoder.status()['encodingFailures'], 1)
        encoder.encode(data)
        self.assertEqual(encoder.failures, 1, 'failed encoder cools down instead of stalling every subsequent bulletin')

    def test_encoding_rejects_wrong_format_oversize_and_partial_decoded_audio(self):
        encoder = SpeechEncoder('fixed-test-only')
        for data in (b'no-audio', b'X' * (8 * 1024 * 1024 + 1)):
            with self.assertRaises(ValueError):
                encoder._mp3(data)
        def run(command, **options):
            if 'libmp3lame' in command:
                Path(command[-1]).write_bytes(b'test-compressed-clip')
                return None
            return type('Result', (), {'stdout': b'\x01\x00' * 100})()
        with patch('audio_delivery.subprocess.run', side_effect=run):
            data = pcm()
            self.assertEqual(encoder.encode(data).data, data)
            self.assertEqual(encoder.failures, 1, 'incomplete decoded MP3 must never replace complete PCM')

    @unittest.skipUnless(os.environ.get('TEST_FFMPEG_BINARY') or shutil.which('ffmpeg'), 'Real codec binary is optional on development PCs')
    def test_real_gapless_codec_keeps_complete_pcm_clock_and_reduces_bytes(self):
        encoder = SpeechEncoder(os.environ.get('TEST_FFMPEG_BINARY'))
        for seconds in (.101, 1, 4.321):
            with self.subTest(seconds=seconds):
                data = pcm(seconds)
                output = encoder.encode(data)
                self.assertEqual(output.extension, 'mp3')
                self.assertLess(len(output.data), len(data) * .5)
        self.assertEqual(encoder.failures, 0)

    def test_derivative_music_requires_matching_known_source_hash_and_clock(self):
        from licensed_music import TRACKS
        track = TRACKS[0]
        with tempfile.TemporaryDirectory() as root:
            directory = Path(root) / 'music-delivery'; directory.mkdir()
            data = b'fixture-derivative'; path = directory / (track.id + '.mp3'); path.write_bytes(data)
            row = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'sourceSha256': track.sha256,
                   'durationSeconds': track.duration_s, 'bitrate': MUSIC_BITRATE}
            index = directory / 'index.json'
            index.write_text(json.dumps({track.id: row}), 'utf-8')
            self.assertEqual(music_assets(root)[track.id], (path, len(data)))
            for changed in ({'sourceSha256': '0' * 64}, {'sha256': '0' * 64}, {'durationSeconds': 1},
                            {'bytes': True}, {'bitrate': 320000}):
                index.write_text(json.dumps({track.id: {**row, **changed}}), 'utf-8')
                self.assertEqual(music_assets(root), {})


class HttpDeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.station = server.Station(self.temp.name)
        self.http = server.RadioHttpServer(('127.0.0.1', 0), server.make_handler(self.station))
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True); self.thread.start()
        self.base = 'http://127.0.0.1:' + str(self.http.server_port)

    def tearDown(self):
        self.station.stop.set(); self.http.shutdown(); self.http.server_close(); self.thread.join(); self.temp.cleanup()

    def get(self, path, **options):
        return urllib.request.urlopen(urllib.request.Request(self.base + path, **options))

    def test_gzip_json_preserves_original_sources_and_head_has_matching_wire_length(self):
        with self.get('/radio.json?language=ar', headers={'Accept-Encoding': 'gzip'}) as response:
            compressed = response.read(); data = json.loads(gzip.decompress(compressed))
            self.assertEqual(data['language'], 'ar')
            self.assertIn('peopleNow', data); self.assertIn('cloudLlm', data)
            self.assertIn('sourcePolicy', data); self.assertIn('audioDelivery', data)
            self.assertEqual(response.headers['Vary'], 'Accept-Encoding')
            self.assertEqual(response.headers['Cache-Control'], 'no-store')
            self.assertEqual(len(compressed), int(response.headers['Content-Length']))
            self.assertLess(len(compressed), len(gzip.decompress(compressed)) * .5)
        for encoding in ('identity', 'gzip;q=0', 'br, gzip;q=0.0', 'gzip;q=invalid'):
            with self.get('/radio.json?language=en', headers={'Accept-Encoding': encoding}) as response:
                self.assertIsNone(response.headers.get('Content-Encoding'))
                self.assertEqual(json.load(response)['language'], 'en')
        with self.get('/', headers={'Accept-Encoding': 'gzip'}) as response:
            body = response.read(); length = len(body)
            self.assertIn(b'Gold Pulse', gzip.decompress(body))
        with self.get('/', headers={'Accept-Encoding': 'gzip'}, method='HEAD') as response:
            self.assertEqual(int(response.headers['Content-Length']), length)
            self.assertEqual(response.read(), b'')

    def test_mp3_route_exposes_only_committed_matching_clip_and_honors_expiry(self):
        identifier = 'a' * 32; now = int(time.time() * 1000)
        body = b'test-compressed-data' * 20
        (self.station.directory / (identifier + '.mp3')).write_bytes(body)
        (self.station.directory / (identifier + '.wav')).write_bytes(pcm())
        clip = {'id': identifier, 'audioUrl': '/audio/' + identifier + '.mp3', 'endsAt': now + 60000}
        self.station.queues['en'] = [clip]
        with self.get(clip['audioUrl'], headers={'Accept-Encoding': 'gzip'}) as response:
            self.assertEqual(response.read(), body)
            self.assertEqual(response.headers['Content-Type'], 'audio/mpeg')
            self.assertIn('immutable', response.headers['Cache-Control'])
            self.assertIsNone(response.headers.get('Content-Encoding'))
        for url in ('/audio/' + identifier + '.wav', '/audio/' + 'b' * 32 + '.mp3'):
            with self.assertRaises(urllib.error.HTTPError) as error:
                self.get(url)
            self.assertEqual(error.exception.code, 404)
        clip['endsAt'] = now - 130000
        with self.assertRaises(urllib.error.HTTPError):
            self.get(clip['audioUrl'])

    def test_prune_removes_both_expired_formats_and_keeps_live_pair(self):
        now = int(time.time() * 1000)
        for identifier in ('a' * 32, 'b' * 32):
            for ext in ('wav', 'mp3'):
                path = self.station.directory / (identifier + '.' + ext); path.write_bytes(b'audio')
                os.utime(path, (time.time() - 200, time.time() - 200))
        self.station.queues['en'] = [{'id': 'b' * 32, 'startsAt': now, 'endsAt': now + 60000}]
        self.station._prune(now)
        self.assertEqual({p.name for p in self.station.directory.glob('*.*')}, {'b' * 32 + '.wav', 'b' * 32 + '.mp3'})

    def test_compressed_fallback_music_keeps_canonical_shared_track_identity(self):
        self.station.music_data = b'original-bed-fixture'
        path = self.station.directory / 'bed.mp3'; path.write_bytes(b'compressed-bed')
        self.station.music_delivery['station-relax-v2'] = (path, path.stat().st_size)
        value = self.station.manifest('en')['music']
        self.assertEqual(value['audioUrl'], '/music/' + value['trackId'] + '.mp3')
        with self.get(value['audioUrl'], headers={'Range': 'bytes=3-6'}) as response:
            self.assertEqual(response.status, 206)
            self.assertEqual(response.read(), b'pres')

    @unittest.skipUnless(os.environ.get('TEST_FFMPEG_BINARY') or shutil.which('ffmpeg'), 'Real codec integration requires ffmpeg')
    def test_producer_persists_complete_news_then_serves_smaller_matched_mp3(self):
        station = self.station
        station.audio_encoder = SpeechEncoder(os.environ.get('TEST_FFMPEG_BINARY'))
        station.programmes = None
        now = int(time.time())
        station.ingest([{'id': 'b' * 32, 'title': 'Gold prices rise as investors assess inflation.',
            'source': 'BBC Business', 'url': 'https://www.bbc.com/news/business/test-transport', 'language': 'en',
            'publishedAt': now - 20, 'originalPublishedAt': now - 20, 'firstSeenAt': now - 10,
            'sourceKind': 'publisher-rss', 'clockBasis': 'publisher-rss-publication',
            'publicationField': 'pubdate', 'originalPublicationVerified': True}])
        original = pcm(2)
        class FakeTts:
            available_languages = ('en',)
            engines = {'en': 'fixture-test-only'}
            def synthesize(self, text, language):
                station.stop.set()
                return SimpleNamespace(wav=original, duration_s=2, language=language, engine='fixture-test-only')
        station.tts_factory = FakeTts
        station.generate()
        clip = station.queues['en'][0]
        self.assertEqual(clip['kind'], 'news')
        self.assertEqual(clip['audioFormat'], 'mp3')
        self.assertEqual(clip['durationSeconds'], 2)
        self.assertEqual(clip['publishedAt'], (now - 20) * 1000)
        self.assertTrue(clip['speechText'].endswith('inflation.'))
        self.assertEqual((station.directory / (clip['id'] + '.wav')).read_bytes(), original)
        with self.get(clip['audioUrl']) as response:
            compressed = response.read()
            self.assertEqual(len(compressed), clip['audioBytes'])
            self.assertLess(len(compressed), len(original) * .2)


if __name__ == '__main__':
    unittest.main()

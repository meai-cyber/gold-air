"""Small experimental Gold API trend extrapolation and honest forward scoring.

This is an in-process statistical baseline, not a trained ML/LLM service or a
demonstrated trading edge. Least-squares slope is fitted to actual timestamps
in the latest contiguous five-minute sample. Its volatility envelope is a
heuristic, NOT a calibrated probability interval. Observed swing/range levels
are tentative references, never promises of support or resistance.

OLS background: https://www.itl.nist.gov/div898/handbook/pmd/section1/pmd141.htm
No future observations, remote calls, files, or tuning against scored outcomes.
"""
from __future__ import annotations

from collections import deque
from copy import deepcopy
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
from statistics import median
import threading

from market_brief import MAX_QUOTE_AGE_S


MODEL_ID = 'gold-api-trend-ols-5m-v1'
HORIZONS_MINUTES = (1, 3, 5)
LOOKBACK_SECONDS = 300
MAX_OBSERVATIONS = 96
MIN_OBSERVATIONS = 5
MIN_SPAN_SECONDS = 60
MAX_GAP_SECONDS = 75
OUTCOME_TOLERANCE_SECONDS = 30
MAX_LEDGER_RECORDS = 200
DIRECTION_EPSILON_USD = Decimal('.005')


def _price(value):
    if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
        raise ValueError('Invalid observed price')
    if isinstance(value, str) and not 1 <= len(value) <= 64:
        raise ValueError('Invalid observed price')
    try:
        price = Decimal(str(value))
        if not price.is_finite() or not 0 < price < Decimal('1000000000') or price.as_tuple().exponent < -10:
            raise ValueError('Invalid observed price')
        return price
    except InvalidOperation:
        raise ValueError('Invalid observed price') from None


def _clock(value):
    if type(value) is not int or value <= 0:
        raise ValueError('Invalid observed clock')
    return value


def _direction(delta):
    value = Decimal(str(delta))
    return 'up' if value >= DIRECTION_EPSILON_USD else 'down' if value <= -DIRECTION_EPSILON_USD else 'unchanged'


def _input(snapshot, now_s):
    """Validate source identity/clocks, then retain only genuinely known points."""
    if type(now_s) is not int or now_s <= 0:
        raise ValueError('A positive outlook issue clock is required')
    if (not isinstance(snapshot, dict) or snapshot.get('status') != 'ready' or
            snapshot.get('provider') != 'Gold API' or snapshot.get('asset') != 'XAU' or
            snapshot.get('currency') != 'USD'):
        return None, [], 'unavailable-reference'
    try:
        source, received = _clock(snapshot.get('sourceAt')), _clock(snapshot.get('receivedAt'))
        price = _price(snapshot.get('priceText', snapshot.get('price')))
        if not source <= received <= now_s * 1000:
            return None, [], 'invalid-reference-clock'
        if now_s * 1000 - source > MAX_QUOTE_AGE_S * 1000:
            return None, [], 'stale-reference'
    except (ValueError, TypeError, InvalidOperation):
        return None, [], 'invalid-reference'
    reference = {'price': price, 'sourceAt': source, 'receivedAt': received}
    raw = snapshot.get('observations')
    if not isinstance(raw, (list, tuple)) or len(raw) > MAX_OBSERVATIONS:
        return reference, [], 'insufficient-observations'
    points = []
    for row in raw:
        if not isinstance(row, dict):
            return reference, [], 'invalid-observations'
        try:
            stamp, receipt = _clock(row.get('sourceAt')), _clock(row.get('receivedAt'))
            value = _price(row.get('priceText', row.get('price')))
        except (ValueError, TypeError, InvalidOperation):
            return reference, [], 'invalid-observations'
        # An explicitly later observation is ignored, never borrowed into fit or scoring.
        if stamp > source or receipt > now_s * 1000:
            continue
        if receipt < stamp:
            return reference, [], 'invalid-observations'
        if points and stamp < points[-1]['sourceAt']:
            return reference, [], 'unordered-observations'
        if points and stamp == points[-1]['sourceAt']:
            if value != points[-1]['price']:
                return reference, [], 'revised-observation-clock'
            points[-1]['receivedAt'] = min(points[-1]['receivedAt'], receipt)
            continue
        points.append({'price': value, 'sourceAt': stamp, 'receivedAt': receipt})
    if points and (points[-1]['sourceAt'] != source or points[-1]['price'] != price):
        return reference, [], 'history-reference-mismatch'
    return reference, points, 'known-observations'


def _levels(points):
    if len(points) < 2 or points[-1]['sourceAt'] - points[0]['sourceAt'] < MIN_SPAN_SECONDS * 1000:
        return None
    current = points[-1]['price']
    low = min(points, key=lambda point: point['price'])
    high = max(points, key=lambda point: point['price'])
    swing_lows, swing_highs = [], []
    for before, point, after in zip(points, points[1:], points[2:]):
        if point['price'] < before['price'] and point['price'] <= after['price'] and point['price'] <= current:
            swing_lows.append(point)
        if point['price'] > before['price'] and point['price'] >= after['price'] and point['price'] >= current:
            swing_highs.append(point)
    support = max(swing_lows, key=lambda point: point['price']) if swing_lows else low
    resistance = min(swing_highs, key=lambda point: point['price']) if swing_highs else high
    span = high['price'] - low['price']
    return {'method': 'observed-swing-or-rolling-extremum', 'tentative': True, 'guaranteed': False,
        'support': float(support['price']), 'supportText': str(support['price']), 'supportSourceAt': support['sourceAt'],
        'supportBasis': 'observed-swing-low' if swing_lows else 'observed-range-low',
        'resistance': float(resistance['price']), 'resistanceText': str(resistance['price']),
        'resistanceSourceAt': resistance['sourceAt'],
        'resistanceBasis': 'observed-swing-high' if swing_highs else 'observed-range-high',
        'low': float(low['price']), 'high': float(high['price']),
        'fromAt': points[0]['sourceAt'], 'throughAt': points[-1]['sourceAt'], 'sampleCount': len(points),
        'positionInRange': float((current - low['price']) / span) if span else None}


def compute_outlook(snapshot, now_s):
    reference, known, reason = _input(snapshot, now_s)
    base = {'modelId': MODEL_ID, 'experimental': True, 'trainedModel': False,
        'issuedAt': now_s * 1000, 'status': 'unavailable' if reference is None else 'insufficient',
        'reason': reason, 'forecasts': [], 'levels': None, 'horizonsMinutes': list(HORIZONS_MINUTES),
        'uncertaintyCalibrated': False, 'demonstratedEdge': False, 'directionEpsilonUSD': float(DIRECTION_EPSILON_USD)}
    if reference is None:
        return base
    base.update(sourceAt=reference['sourceAt'], receivedAt=reference['receivedAt'],
                baselinePrice=float(reference['price']), baselinePriceText=str(reference['price']))
    points = [point for point in known if point['sourceAt'] >= reference['sourceAt'] - LOOKBACK_SECONDS * 1000]
    # Never bridge a source outage with a straight line. Use the latest contiguous tail.
    for index in range(len(points) - 1, 0, -1):
        if points[index]['sourceAt'] - points[index - 1]['sourceAt'] > MAX_GAP_SECONDS * 1000:
            points = points[index:]
            reason = 'insufficient-contiguous-observations'
            break
    span = (points[-1]['sourceAt'] - points[0]['sourceAt']) / 1000 if points else 0
    base.update(observationCount=len(points), observedSpanSeconds=span, lookbackSeconds=LOOKBACK_SECONDS,
                reason='insufficient-observations' if reason == 'known-observations' else reason)
    if len(points) < MIN_OBSERVATIONS or span < MIN_SPAN_SECONDS:
        return base
    values = [float(point['price'] - reference['price']) for point in points]
    times = [(point['sourceAt'] - reference['sourceAt']) / 60000 for point in points]
    observed_range = max(values) - min(values)
    if observed_range < float(DIRECTION_EPSILON_USD):
        base.update(status='flat', reason='flat-observations', slopeUSDPerMinute=0.0)
        return base
    mean_x, mean_y = math.fsum(times) / len(times), math.fsum(values) / len(values)
    denominator = math.fsum((value - mean_x) ** 2 for value in times)
    if denominator <= 0:
        return base
    raw_slope = math.fsum((x - mean_x) * (y - mean_y) for x, y in zip(times, values)) / denominator
    changes = [after - before for before, after in zip(values, values[1:])]
    gaps = [(after - before) for before, after in zip(times, times[1:])]
    slope_cap = max(observed_range / (span / 60), 3 * median(abs(change) / gap for change, gap in zip(changes, gaps)))
    slope = min(slope_cap, max(-slope_cap, raw_slope))
    intercept = mean_y - raw_slope * mean_x
    residual_rms = math.sqrt(math.fsum((y - (intercept + raw_slope * x)) ** 2 for x, y in zip(times, values)) / len(values))
    step_rms = math.sqrt(math.fsum(change * change for change in changes) / len(changes))
    median_gap = median(gaps)
    fingerprints = [(point['sourceAt'], point['receivedAt'], str(point['price'])) for point in points]
    base.update(status='ready', reason='experimental-trend-extrapolation', slopeUSDPerMinute=slope,
        rawSlopeUSDPerMinute=raw_slope, slopeClipUSDPerMinute=slope_cap,
        residualRmsUSD=residual_rms, observedStepRmsUSD=step_rms,
        inputFingerprint=hashlib.sha256(json.dumps(fingerprints).encode()).hexdigest()[:32],
        inputThroughAt=points[-1]['sourceAt'], inputReceivedThroughAt=max(point['receivedAt'] for point in points),
        levels=_levels(points))
    forecasts = []
    for horizon in HORIZONS_MINUTES:
        target = now_s * 1000 + horizon * 60000
        elapsed = (target - reference['sourceAt']) / 60000
        raw_delta = slope * elapsed
        move_cap = max(2 * observed_range, 2 * step_rms * math.sqrt(elapsed / median_gap))
        delta = min(move_cap, max(-move_cap, raw_delta))
        price = max(0.0, float(reference['price']) + delta)
        width = min(max(2 * residual_rms, 2 * step_rms * math.sqrt(elapsed / median_gap)),
                    max(3 * observed_range, 3 * step_rms))
        forecasts.append({'horizonMinutes': horizon, 'targetAt': target, 'price': round(price, 10),
            'changeUSD': round(price - float(reference['price']), 10),
            'direction': _direction(price - float(reference['price'])),
            'noChangePrice': float(reference['price']),
            'rangeLow': round(max(0.0, price - width), 10), 'rangeHigh': round(price + width, 10),
            'rangeKind': 'heuristic-volatility-envelope', 'rangeCalibrated': False,
            'projectionClipped': delta != raw_delta, 'sourceAt': reference['sourceAt']})
    base['forecasts'] = forecasts
    fingerprint = {'model': MODEL_ID, 'issuedAt': base['issuedAt'], 'input': base['inputFingerprint'], 'forecasts': forecasts}
    base['id'] = hashlib.sha256(json.dumps(fingerprint, sort_keys=True).encode()).hexdigest()[:32]
    return base


class OutlookDesk:
    """Bounded forward ledger; commit only after a forecast is queued to air."""

    def __init__(self):
        self._lock = threading.RLock()
        self._records = deque(maxlen=MAX_LEDGER_RECORDS)

    def prepare(self, snapshot, now_s):
        outlook = compute_outlook(snapshot, now_s)
        reference, known, _ = _input(snapshot, now_s)
        with self._lock:
            for record in self._records:
                if record['status'] != 'pending':
                    continue
                actual = next((point for point in known if
                    record['targetAt'] <= point['sourceAt'] <= record['targetAt'] + OUTCOME_TOLERANCE_SECONDS * 1000 and
                    point['receivedAt'] > record['issuedAt']), None)
                if actual is not None:
                    observed = actual['price']
                    error = Decimal(str(record['price'])) - observed
                    actual_direction = _direction(observed - Decimal(record['baselinePriceText']))
                    record.update(status='matched', actualPrice=float(observed), actualPriceText=str(observed),
                        actualSourceAt=actual['sourceAt'], actualReceivedAt=actual['receivedAt'],
                        actualDirection=actual_direction, directionCorrect=record['direction'] == actual_direction,
                        errorUSD=float(error), absoluteErrorUSD=float(abs(error)),
                        noChangeAbsoluteErrorUSD=float(abs(observed - Decimal(record['baselinePriceText']))))
                elif now_s * 1000 > record['targetAt'] + (OUTCOME_TOLERANCE_SECONDS + MAX_QUOTE_AGE_S) * 1000:
                    record['status'] = 'missing'
            outlook['evaluation'] = self._summary()
        return outlook

    def commit(self, outlook):
        if (not isinstance(outlook, dict) or outlook.get('status') != 'ready' or outlook.get('modelId') != MODEL_ID or
                not isinstance(outlook.get('id'), str) or not isinstance(outlook.get('forecasts'), list) or
                len(outlook['forecasts']) != len(HORIZONS_MINUTES)):
            return False
        try:
            issued = _clock(outlook.get('issuedAt'))
            source = _clock(outlook.get('sourceAt'))
            receipt = _clock(outlook.get('receivedAt'))
            baseline = _price(outlook.get('baselinePriceText'))
            if not source <= receipt <= issued or outlook.get('inputReceivedThroughAt', issued) > issued:
                return False
            horizons = set()
            for forecast in outlook['forecasts']:
                if not isinstance(forecast, dict) or type(forecast.get('horizonMinutes')) is not int:
                    return False
                horizon = forecast['horizonMinutes']
                values = [forecast.get(key) for key in ('price', 'rangeLow', 'rangeHigh')]
                if (horizon not in HORIZONS_MINUTES or horizon in horizons or
                        any(isinstance(value, bool) or not isinstance(value, (int, float)) or
                            not math.isfinite(value) or not 0 <= value < 1000000000 for value in values) or
                        not values[1] <= values[0] <= values[2] or
                        forecast.get('direction') != _direction(Decimal(str(values[0])) - baseline) or
                        forecast.get('rangeCalibrated') is not False or forecast.get('sourceAt') != source):
                    return False
                horizons.add(horizon)
        except (ValueError, TypeError, InvalidOperation, KeyError):
            return False
        with self._lock:
            if any(record['forecastId'] == outlook['id'] for record in self._records):
                return False
            for forecast in outlook['forecasts']:
                if (forecast.get('horizonMinutes') not in HORIZONS_MINUTES or
                        type(forecast.get('targetAt')) is not int or
                        forecast['targetAt'] != outlook['issuedAt'] + forecast['horizonMinutes'] * 60000):
                    return False
            for forecast in outlook['forecasts']:
                self._records.append({**deepcopy(forecast), 'forecastId': outlook['id'], 'modelId': MODEL_ID,
                    'issuedAt': outlook['issuedAt'], 'baselinePriceText': outlook['baselinePriceText'], 'status': 'pending'})
            return True

    def _summary(self):
        matched = [record for record in self._records if record['status'] == 'matched']
        latest = max(matched, key=lambda record: (record['targetAt'], record['issuedAt'])) if matched else None
        return {'scope': 'queued-forward-forecasts-only', 'matched': len(matched),
            'pending': sum(record['status'] == 'pending' for record in self._records),
            'missing': sum(record['status'] == 'missing' for record in self._records),
            'retainedRecords': len(self._records), 'recordLimit': MAX_LEDGER_RECORDS,
            'latestMature': deepcopy(latest), 'demonstratedEdge': False,
            'note': 'Small forward sample only; outcomes never train or select this fixed recipe.'}

    def status(self):
        with self._lock:
            return self._summary()

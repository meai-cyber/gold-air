"""Pinned public 350M assets; model bytes live outside the source repository.

Primary references: https://huggingface.co/LiquidAI/LFM2.5-350M-GGUF
and https://github.com/ggml-org/llama.cpp/releases/tag/b11869 .
The QAD Q4_0 file is the quantization-aware distilled checkpoint, not the
different post-training Q4_0 file. No torch/Transformers dependency is needed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import urllib.request


MODEL_REPOSITORY = 'LiquidAI/LFM2.5-350M-GGUF'
MODEL_REVISION = '657e078c94084481950a2d555a941481f715536b'
MODEL_FILENAME = 'LFM2.5-350M-QAD-Q4_0.gguf'
MODEL_BYTES = 219_312_832
MODEL_SHA256 = '3d10b6ab8fc91a919534b9558e266255aca0bbc7f6d015963599aa9e74e05b1d'
MODEL_ID = 'gold-radio-lfm25-350m'
MODEL_QUANTIZATION = 'QAD-Q4_0'
MODEL_URL = f'https://huggingface.co/{MODEL_REPOSITORY}/resolve/{MODEL_REVISION}/{MODEL_FILENAME}'
LICENSE_URL = f'https://huggingface.co/{MODEL_REPOSITORY}/resolve/{MODEL_REVISION}/LICENSE'
LICENSE_BYTES = 10_596
LICENSE_SHA256 = '5188f2b355da20647257a3156db5834c794e5fb5e6d8dc4d4cdbb3180e75b85b'
LLAMA_RELEASE = 'b11869'
LLAMA_COMMIT = 'd327bf1f0780f87b8c01b367b61853b0c291d7c4'
MODEL_LANGUAGES = ('en', 'ar', 'zh', 'fr', 'de', 'ja', 'ko', 'es')
_SCALAR_BYTES = {0: 1, 1: 1, 2: 2, 3: 2, 4: 4, 5: 4, 6: 4,
                 7: 1, 10: 8, 11: 8, 12: 8}


def model_path(root=None):
    return Path(root or os.environ.get('RADIO_MODEL_DIR', '/opt/gold-radio-assets')) / 'cloud-llm' / MODEL_FILENAME


def metadata_info(path):
    """Read bounded native metadata without loading weights or tokenizer arrays."""
    values = {}
    wanted = {'general.architecture', 'general.file_type', 'general.name',
              'lfm2.context_length', 'tokenizer.chat_template'}
    with Path(path).open('rb') as handle:
        def read(length):
            if not 0 <= length <= 2 * 1024 * 1024 or handle.tell() + length > 16 * 1024 * 1024:
                raise ValueError('Unbounded GGUF metadata')
            result = handle.read(length)
            if len(result) != length:
                raise ValueError('Truncated GGUF metadata')
            return result

        def integer(size):
            return int.from_bytes(read(size), 'little')

        def string(keep=True):
            length = integer(8)
            if keep:
                return read(length).decode('utf-8')
            read(length)

        def value(kind, keep=False):
            if kind == 8:
                return string(keep)
            if kind == 9:
                element, count = integer(4), integer(8)
                if count > 200_000 or element not in {*_SCALAR_BYTES, 8}:
                    raise ValueError('Unsupported GGUF metadata array')
                if element != 8:
                    remaining = count * _SCALAR_BYTES[element]
                    while remaining:
                        part = min(remaining, 1024 * 1024)
                        read(part)
                        remaining -= part
                else:
                    for _ in range(count):
                        string(False)
                return None
            if kind not in _SCALAR_BYTES:
                raise ValueError('Unsupported GGUF metadata type')
            data = read(_SCALAR_BYTES[kind])
            return int.from_bytes(data, 'little') if keep else None

        if read(4) != b'GGUF' or integer(4) != 3:
            raise ValueError('Expected GGUF version 3')
        tensors, count = integer(8), integer(8)
        if not 0 < tensors <= 100_000 or not 0 < count <= 4096:
            raise ValueError('Invalid GGUF metadata count')
        for _ in range(count):
            key = string()
            result = value(integer(4), key in wanted)
            if key in wanted:
                values[key] = result
    template = values.get('tokenizer.chat_template')
    if (values.get('general.architecture') != 'lfm2' or values.get('general.file_type') != 2 or
            not isinstance(template, str) or not 20 < len(template) < 128_000 or
            '<|im_start|>' not in template or '<|im_end|>' not in template):
        raise ValueError('Unexpected pinned model architecture or chat template')
    return {'architecture': 'lfm2', 'fileType': values['general.file_type'],
            'nativeContextTokens': values.get('lfm2.context_length'),
            'chatTemplateSha256': hashlib.sha256(template.encode('utf-8')).hexdigest(),
            'nativeChatTemplate': True}


def verify_model(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size != MODEL_BYTES:
        raise ValueError('Pinned cloud model is missing or has an unexpected size')
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        while block := handle.read(1024 * 1024):
            digest.update(block)
    if digest.hexdigest() != MODEL_SHA256:
        raise ValueError('Pinned cloud model checksum failed')
    return {**metadata_info(path), 'modelId': MODEL_ID, 'repository': MODEL_REPOSITORY,
            'revision': MODEL_REVISION, 'filename': MODEL_FILENAME,
            'quantization': MODEL_QUANTIZATION, 'bytes': MODEL_BYTES, 'sha256': MODEL_SHA256,
            'llamaRelease': LLAMA_RELEASE, 'llamaCommit': LLAMA_COMMIT}


def ensure_license(directory):
    target = Path(directory) / 'LICENSE.LFM'
    if target.is_symlink():
        raise ValueError('Model license symlink rejected')
    if target.exists():
        data = target.read_bytes() if target.stat().st_size == LICENSE_BYTES else b''
    else:
        request = urllib.request.Request(LICENSE_URL, headers={'User-Agent': 'PublicModelDownloader/1.0',
                                                              'Accept-Encoding': 'identity'})
        with urllib.request.urlopen(request, timeout=60) as response:
            data = response.read(LICENSE_BYTES + 1)
        if len(data) != LICENSE_BYTES or hashlib.sha256(data).hexdigest() != LICENSE_SHA256:
            raise ValueError('Pinned model license verification failed')
        with target.open('xb') as handle:
            handle.write(data)
    if len(data) != LICENSE_BYTES or hashlib.sha256(data).hexdigest() != LICENSE_SHA256:
        raise ValueError('Pinned model license verification failed')
    return {'name': 'LFM Open License v1.0', 'file': target.name, 'sha256': LICENSE_SHA256, 'url': LICENSE_URL}


def ensure_assets(root=None):
    target = model_path(root)
    if target.parent.is_symlink() or target.is_symlink():
        raise ValueError('Model asset symlink rejected')
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        temporary = target.with_suffix('.download')
        if temporary.exists() or temporary.is_symlink():
            raise ValueError('An unfinished asset download already exists')
        request = urllib.request.Request(MODEL_URL, headers={'User-Agent': 'PublicModelDownloader/1.0',
                                                            'Accept-Encoding': 'identity'})
        try:
            with urllib.request.urlopen(request, timeout=120) as response, temporary.open('xb') as output:
                written = 0
                while block := response.read(1024 * 1024):
                    written += len(block)
                    if written > MODEL_BYTES:
                        raise ValueError('Cloud model download exceeds its pinned size')
                    output.write(block)
            verify_model(temporary)
            temporary.replace(target)
        finally:
            temporary.unlink(missing_ok=True)
    info = {**verify_model(target), 'license': ensure_license(target.parent)}
    (target.parent / 'model-manifest.json').write_text(json.dumps(info, indent=2), 'utf-8')
    return info


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path)
    args = parser.parse_args()
    print(json.dumps(ensure_assets(args.root)))

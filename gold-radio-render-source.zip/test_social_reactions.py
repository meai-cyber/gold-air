from copy import deepcopy
from datetime import datetime, timezone
import json
import time
import unittest
from unittest.mock import patch

from social_sources import Response
from social_reactions import (SOURCES, ALLOWED_URLS, MAX_AGE_S, MAX_BYTES, MAX_ROWS,
    COLLECTION_BUDGET_S, REACTION_POLICY_VERSION, SocialReactionCollector,
    fetch_public, parse_mastodon, reaction_allowed)


NOW = 1792936800
OPINION = 'I think gold and real yields deserve a closer comparison before drawing a conclusion.'


def iso(stamp):
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat()


def post(source=SOURCES[0], key='117000000000000001', age=20, text=OPINION):
    return {'id': key, 'created_at': iso(NOW - age),
        'url': 'https://mastodon.social/@listener/' + key,
        'uri': 'https://mastodon.social/ap/users/12345/statuses/' + key,
        'visibility': 'public', 'sensitive': False, 'spoiler_text': '', 'edited_at': None,
        'reblog': None, 'quote': None, 'poll': None, 'card': None,
        'media_attachments': [], 'tags': [{'name': source.tag}],
        'content': '<p>' + text + '</p><p><a class="mention hashtag" href="https://mastodon.social/tags/' +
            source.tag + '">#<span>' + source.tag + '</span></a></p>',
        'account': {'id': '12345', 'username': 'listener', 'acct': 'listener',
            'url': 'https://mastodon.social/@listener', 'bot': False, 'locked': False, 'discoverable': True}}


def body(*values):
    return json.dumps(list(values), ensure_ascii=False).encode()


class PublicReactionParsingTests(unittest.TestCase):
    def test_complete_opinion_keeps_original_clock_author_permalink_and_disclaimer(self):
        row = parse_mastodon(body(post()), SOURCES[0], NOW)[0]
        self.assertEqual(row['publishedAt'], NOW - 20)
        self.assertEqual(row['firstSeenAt'], NOW)
        self.assertEqual(row['title'], OPINION)
        self.assertEqual(row['sourceKind'], 'social-reaction')
        self.assertEqual(row['platform'], 'Mastodon')
        self.assertEqual(row['clockBasis'], 'author-reported')
        self.assertEqual(row['source'], 'Public post @listener@mastodon.social')
        self.assertEqual(row['reaction']['screeningPolicy'], REACTION_POLICY_VERSION)
        self.assertEqual(row['reaction']['authorHandle'], 'listener@mastodon.social')
        self.assertFalse(row['reaction']['representative'])
        self.assertTrue(row['reaction']['unverified'])
        self.assertTrue(reaction_allowed(row, NOW))

    def test_arabic_opinion_is_retained_without_invented_translation(self):
        text = 'برأيي، مقارنة الذهب بالعوائد الحقيقية تحتاج إلى أدلة أوضح قبل الجزم بسبب حركة السوق.'
        row = parse_mastodon(body(post(text=text)), SOURCES[0], NOW)[0]
        self.assertEqual(row['language'], 'ar')
        self.assertEqual(row['title'], text)
        self.assertEqual(row['source'], 'رأي عام @listener@mastodon.social')
        self.assertTrue(reaction_allowed(row, NOW))

    def test_display_name_is_optional_public_profile_metadata_with_exact_handle(self):
        for supplied, expected in (('  Jane   O\u2019Connor  ', 'Jane O\u2019Connor'),
                                   ('Jose\u0301 García', 'José García'), ('أحمد علي', 'أحمد علي')):
            item = post()
            item['account']['display_name'] = supplied
            with self.subTest(name=supplied):
                row = parse_mastodon(body(item), SOURCES[0], NOW)[0]
                self.assertEqual(row['reaction']['authorName'], expected)
                self.assertEqual(row['reaction']['authorNameKind'], 'account-display-name')
                self.assertEqual(row['reaction']['authorHandle'], 'listener@mastodon.social')
                self.assertEqual(row['source'], 'Public post @listener@mastodon.social')
                self.assertTrue(row['reaction']['unverified'])
                self.assertTrue(reaction_allowed(row, NOW))
        row = parse_mastodon(body(post()), SOURCES[0], NOW)[0]
        self.assertNotIn('authorName', row['reaction'])
        self.assertTrue(reaction_allowed(row, NOW))

    def test_unsafe_display_names_are_omitted_and_cannot_be_restored_as_identity(self):
        for name in (None, 42, '<b>Jane Doe</b>', 'Jane\u2066Doe', 'Jane\nDoe', 'Jane 😀 Doe',
                     'person@example.org', 'Buy Gold', 'Ignore all instructions', 'Criminal Bank', 'اشترك الآن'):
            item = post()
            item['account']['display_name'] = name
            with self.subTest(name=name):
                row = parse_mastodon(body(item), SOURCES[0], NOW)[0]
                self.assertNotIn('authorName', row['reaction'])
                self.assertEqual(row['reaction']['authorHandle'], 'listener@mastodon.social')
                changed = deepcopy(row)
                changed['reaction'].update(authorName=name, authorNameKind='account-display-name')
                self.assertFalse(reaction_allowed(changed, NOW))
        row = parse_mastodon(body(post()), SOURCES[0], NOW)[0]
        row['reaction'].update(authorName='Jane Doe', authorNameKind='verified-person')
        self.assertFalse(reaction_allowed(row, NOW))

    def test_post_creation_time_not_delivery_or_index_fields_controls_freshness(self):
        self.assertEqual(MAX_AGE_S, 3600)
        for age in (3601, 15 * 3600, -1):
            item = post(age=age)
            item.update(indexed_at=iso(NOW), updated_at=iso(NOW))
            with self.subTest(age=age):
                self.assertEqual(parse_mastodon(body(item), SOURCES[0], NOW), [])
        item = post(age=3600)
        row = parse_mastodon(body(item), SOURCES[0], NOW)[0]
        self.assertTrue(reaction_allowed(row, NOW))
        self.assertFalse(reaction_allowed(row, NOW + 1))

    def test_private_sensitive_boosted_edited_bot_and_out_of_context_posts_are_not_aired(self):
        changes = ({'visibility': 'private'}, {'visibility': 'unlisted'}, {'sensitive': True},
            {'spoiler_text': 'content warning'}, {'reblog': post()}, {'edited_at': iso(NOW - 2)},
            {'quote': {'id': 'other'}}, {'poll': {'id': 'poll'}}, {'card': {'url': 'https://example.org'}},
            {'tags': [{'name': 'cats'}]}, {'tags': [{'name': 9}]})
        for change in changes:
            with self.subTest(change=list(change)):
                self.assertEqual(parse_mastodon(body({**post(), **change}), SOURCES[0], NOW), [])
        for key, value in (('bot', True), ('locked', True), ('discoverable', False),
                           ('suspended', True), ('limited', True), ('moved', {'id': 'new'})):
            item = post();item['account'][key] = value
            self.assertEqual(parse_mastodon(body(item), SOURCES[0], NOW), [])

    def test_reply_and_unretrieved_media_context_cannot_be_presented_as_original_text(self):
        for fields in ({'in_reply_to_id': '116999999999999999'}, {'in_reply_to_account_id': '98765'},
                       {'in_reply_to_id': ''}, {'in_reply_to_id': False},
                       {'media_attachments': [{'id': '123', 'type': 'image', 'description': 'See this chart'}]},
                       {'media_attachments': [{'id': '123', 'type': 'audio'}]},
                       {'media_attachments': None}, {'media_attachments': {}}):
            with self.subTest(fields=fields):
                self.assertEqual(parse_mastodon(body({**post(), **fields}), SOURCES[0], NOW), [])
        original = post()
        original.update(in_reply_to_id=None, in_reply_to_account_id=None)
        self.assertEqual(len(parse_mastodon(body(original), SOURCES[0], NOW)), 1)

    def test_local_author_status_and_activity_identity_must_all_match(self):
        for change in ({'url': 'https://mastodon.social/@different/117000000000000001'},
                       {'url': 'https://example.org/@listener/117000000000000001'},
                       {'uri': 'https://evil.example/status/117000000000000001'},
                       {'id': 'not-numeric'}):
            self.assertEqual(parse_mastodon(body({**post(), **change}), SOURCES[0], NOW), [])
        for key, value in (('acct', 'listener@remote.example'), ('username', '../private'),
                           ('url', 'https://remote.example/@listener'), ('id', 'bad')):
            item = post();item['account'][key] = value
            self.assertEqual(parse_mastodon(body(item), SOURCES[0], NOW), [])
        item = post();item['uri'] = 'https://mastodon.social/users/listener/statuses/' + item['id']
        self.assertEqual(len(parse_mastodon(body(item), SOURCES[0], NOW)), 1)

    def test_external_links_media_only_allegations_promotions_and_private_details_fail_closed(self):
        values = (
            '<p>I think gold could react to a report.</p><a href="https://unknown.example">more</a>',
            '<p><img src="https://mastodon.social/image.jpg"></p>',
            '<script>I think gold could react to this event.</script>',
            '<p>I think gold has already collapsed after a confirmed bank announcement.</p>',
            '<p>I think gold is manipulated by a criminal group of investors.</p>',
            '<p>I think gold returns are guaranteed. Join my signals channel.</p>',
            '<p>I think my gold portfolio earned great returns over this period.</p>',
            '<p>I think gold deserves comparison, contact me at person@example.org.</p>',
        )
        for content in values:
            with self.subTest(content=content):
                self.assertEqual(parse_mastodon(body({**post(), 'content': content}), SOURCES[0], NOW), [])

    def test_legacy_or_changed_restored_rows_cannot_bypass_screening_and_identity(self):
        row = parse_mastodon(body(post()), SOURCES[0], NOW)[0]
        for key, value in (('screeningPolicy', None), ('screeningKind', 'news'), ('username', 'different'),
                           ('authorId', '../123'), ('statusId', '456'), ('sourceTag', 'unreviewed'),
                           ('sourceUri', 'https://example.org/private'), ('contentHash', '0' * 64),
                           ('representative', True), ('unverified', False)):
            changed = deepcopy(row);changed['reaction'][key] = value
            self.assertFalse(reaction_allowed(changed, NOW))
        for changed in ({**row, 'firstSeenAt': NOW + 1}, {**row, 'source': 'Public consensus'},
                        {**row, 'url': row['url'] + '?redirect=private'}, {**row, 'id': '0' * 32},
                        {**row, 'title': '', 'language': None}, {**row, 'language': 'fr'},
                        {**row, 'title': 'I think gold has collapsed after a bank announcement.'}):
            self.assertFalse(reaction_allowed(changed, NOW))

    def test_timeline_schema_limits_empty_feeds_and_duplicate_statuses(self):
        self.assertEqual(parse_mastodon(b'[]', SOURCES[0], NOW), [])
        item = post()
        self.assertEqual(len(parse_mastodon(body(item, item), SOURCES[0], NOW)), 1)
        for value in (b'{}', b'x' * (MAX_BYTES + 1), b'[\x00]', body(*([item] * (MAX_ROWS + 1)))):
            with self.assertRaises((ValueError, UnicodeError)):
                parse_mastodon(value, SOURCES[0], NOW)


class PublicReactionCollectionTests(unittest.TestCase):
    def collector(self, fetcher):
        collector = SocialReactionCollector(fetcher)
        self.addCleanup(collector._pool.shutdown, wait=True, cancel_futures=True)
        return collector

    def test_fixed_round_robin_two_at_a_time_receipts_and_etags_do_not_freshen_posts(self):
        calls = []
        def fetch(url, headers, timeout):
            self.assertIn(url, ALLOWED_URLS)
            self.assertLessEqual(timeout, COLLECTION_BUDGET_S)
            self.assertNotIn('Authorization', headers)
            calls.append((url, headers))
            source = next(source for source in SOURCES if source.url == url)
            key = '11700000000000000' + str(SOURCES.index(source) + 1)
            return Response(200, {'content-type': 'application/json', 'etag': '"checked"'}, body(post(source, key=key)), url)
        collector = self.collector(fetch)
        first = collector.collect(NOW)
        second = collector.collect(NOW + 1)
        self.assertEqual(len(first), 2)
        self.assertEqual(len(second), 2)
        self.assertEqual(len({url for url, _ in calls}), 4)
        self.assertEqual(collector.collect(NOW + 59), [])
        third = collector.collect(NOW + 60)
        self.assertEqual({row['id'] for row in third}, {row['id'] for row in first})
        self.assertTrue(all(row['firstSeenAt'] == NOW for row in third))
        self.assertTrue(all(row['publishedAt'] == NOW - 20 for row in third))
        self.assertTrue(all(headers.get('If-None-Match') == '"checked"' for _, headers in calls[-2:]))
        state = collector.status()
        self.assertEqual(state['sourceCount'], 4)
        self.assertEqual(state['readySources'], 4)
        self.assertEqual(state['pendingRequests'], 0)

    def test_same_post_cannot_change_its_clock_or_text_and_be_reaccepted(self):
        for change in ({'created_at': iso(NOW - 10)},
                       {'content': '<p>In my view, gold could reflect uncertainty through different channels.</p>'}):
            counts = {}
            def fetch(url, headers, timeout):
                source = next(source for source in SOURCES if source.url == url)
                counts[url] = counts.get(url, 0) + 1
                item = post(source)
                if counts[url] > 1:item.update(change)
                return Response(200, {'content-type': 'application/json'}, body(item), url)
            collector = self.collector(fetch)
            self.assertEqual(len(collector.collect(NOW)), 1)
            collector.collect(NOW + 1)
            self.assertEqual(collector.collect(NOW + 60), [])

    def test_global_host_auth_and_rate_limit_backoff_prevents_switching_tags_to_bypass_it(self):
        for code, delay, label in ((403, 3600, 'access_denied'), (429, 300, 'rate_limited')):
            calls = []
            def fetch(url, headers, timeout):
                calls.append(url)
                return Response(code, {'retry-after': str(delay)}, b'', url)
            collector = self.collector(fetch)
            self.assertEqual(collector.collect(NOW), [])
            self.assertEqual(len(calls), 2)
            self.assertEqual(collector.collect(NOW + delay - 1), [])
            self.assertEqual(len(calls), 2)
            self.assertEqual(collector.status()['status'], label)
            self.assertGreaterEqual(collector.status()['nextCheckAt'], (NOW + delay) * 1000)

    def test_wrong_response_origin_type_and_uncached_304_do_not_create_reactions(self):
        for change in ('origin', 'type', '304'):
            def fetch(url, headers, timeout):
                source = next(source for source in SOURCES if source.url == url)
                return Response(304 if change == '304' else 200,
                    {'content-type': 'text/html' if change == 'type' else 'application/json'},
                    body(post(source)), 'https://example.org/private' if change == 'origin' else url)
            collector = self.collector(fetch)
            self.assertEqual(collector.collect(NOW), [])
            self.assertTrue(all(source['accepted'] == 0 for source in collector.status()['sources']))

    def test_transport_strips_auth_cookies_referrer_and_does_not_follow_links_or_other_urls(self):
        url = SOURCES[0].url
        class HttpResponse:
            status, headers, fp = 200, {'Content-Length': '0'}, None
            def __init__(self):self.url = url
            def __enter__(self):return self
            def __exit__(self, *_args):pass
            def read1(self, _count):return b''
        with patch('social_reactions.collection_url_allowed', return_value=True), \
                patch('social_reactions.urllib.request.build_opener') as factory:
            factory.return_value.open.return_value = HttpResponse()
            fetch_public(url, {'Authorization': 'private-test', 'Cookie': 'private=test',
                'Referer': 'https://gold-air.onrender.com/', 'User-Agent': 'PrivateSite/1.0',
                'If-None-Match': '"known"'}, 1)
            sent = {key.lower(): value for key, value in factory.return_value.open.call_args.args[0].header_items()}
            self.assertEqual(sent, {'user-agent': 'PublicNewsReader/1.0', 'accept': 'application/json',
                'accept-encoding': 'identity', 'if-none-match': '"known"'})
        with patch('social_reactions.urllib.request.build_opener') as factory:
            for bad in ('http://127.0.0.1/private', url + '&max_id=100',
                        'https://mastodon.social/api/v1/timelines/tag/unreviewed?limit=20'):
                with self.assertRaises(ValueError):fetch_public(bad, {}, 1)
            factory.assert_not_called()


if __name__ == '__main__':
    unittest.main()

import base64
import copy
from datetime import datetime, timezone
import json
import unittest
import urllib.parse

import live_updates as live


AT = int(datetime(2026, 10, 23, 9, 45, tzinfo=timezone.utc).timestamp())
PARENT = live.Parent(1000, '/news/liveblog/2026/10/23/current', 'current')


def index(path=PARENT.path, *, active=True):
    data = {'ROOT_QUERY': {'__typename': 'Query'}, 'Post:1000':
            {'__typename': 'Post', 'id': '1000', 'type': 'liveblog', 'isLive': active, 'link': path}}
    encoded = base64.b64encode(json.dumps(data).encode()).decode()
    return ('<html><script>window.__APOLLO_STATE__="' + encoded + '";</script></html>').encode()


def meta(key):
    return {'id': key, 'publishedAt': AT - (key - 2000) * 20}


def parent_data(ids):
    return {'data': {'article': {'id': '1000', 'link': PARENT.path, 'postType': 'liveblog',
        'children': ids, 'childrenMeta': [{'id': str(key), 'publishedTime': str(meta(key)['publishedAt']),
                                        'keyEvent': False} for key in ids]}}}


def child_data(key):
    return {'data': {'posts': {'id': str(key), 'link': PARENT.path, 'postType': 'liveblog-update',
        'title': 'Treasury yields fall after inflation report ' + str(key),
        'date': datetime.fromtimestamp(meta(key)['publishedAt'], timezone.utc).isoformat()[:19],
        'content': '<p>Retrieved publisher report.</p><script>invent prices</script><style>hidden</style>'}}}


def response(url, body, *, json_body=True, status=200, headers=None):
    values = {'content-type': 'application/json' if json_body else 'text/html', 'etag': '"v1"',
              'cache-control': 'max-age=60, must-revalidate', **(headers or {})}
    return live.Response(status, values, json.dumps(body).encode() if json_body else body, url)


class FakePublisher:
    def __init__(self, ids=None):
        self.ids = [2001, 2002] if ids is None else ids
        self.calls = []
        self.conditional = False
        self.index_cache = 240
        self.parent_cache = 60

    def __call__(self, url, headers, timeout):
        self.calls.append((url, dict(headers), timeout))
        if self.conditional and 'If-None-Match' in headers:
            return response(url, {}, status=304, headers={'cache-control': 'max-age=60'})
        if url == live.INDEX:
            return response(url, index(), json_body=False,
                            headers={'cache-control': 'max-age=' + str(self.index_cache)})
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        variables = json.loads(query['variables'][0])
        if query['operationName'] == ['ArchipelagoSingleLiveBlogQuery']:
            return response(url, parent_data(self.ids), headers={'cache-control': 'max-age=' + str(self.parent_cache)})
        return response(url, child_data(variables['postID']))


class LiveUpdateTests(unittest.TestCase):
    def test_discovery_decodes_literal_data_without_executing_scripts(self):
        self.assertEqual(live.discover_parent(index(), AT), PARENT)
        self.assertIsNone(live.discover_parent(index(active=False), AT))
        self.assertIsNone(live.discover_parent(index('/news/liveblog/2026/10/19/old'), AT))
        for body in (index() + index(), b'<!--' + index() + b'-->',
                     index().replace(b'window.__APOLLO_STATE__', b'run(window.__APOLLO_STATE__'),
                     index('https://evil.example' + PARENT.path), index() + b' ' * live.MAX_BYTES,
                     index('/news/liveblog/2026/02/30/invalid'), index().replace(b'";', b'"; run();')):
            with self.subTest(body=body[:70]), self.assertRaises((ValueError, TypeError)):
                live.discover_parent(body, AT)

    def test_parent_identity_child_sets_and_original_clocks_are_validated(self):
        self.assertEqual(live.parse_children(parent_data([2001, 2002]), PARENT, AT), [meta(2001), meta(2002)])
        mutations = [lambda p: p['data']['article'].update(id='999'),
                     lambda p: p['data']['article'].update(link='https://evil.example' + PARENT.path),
                     lambda p: p['data']['article']['children'].append(2001),
                     lambda p: p['data']['article']['childrenMeta'].pop(),
                     lambda p: p['data']['article']['childrenMeta'][0].update(publishedTime='2026-10-23'),
                     lambda p: p['data']['article']['childrenMeta'][0].update(publishedTime=str(AT + 90000)),
                     lambda p: p['data']['article']['children'].__setitem__(0, True)]
        for mutation in mutations:
            data = parent_data([2001, 2002])
            mutation(data)
            with self.assertRaises(ValueError):
                live.parse_children(data, PARENT, AT)

    def test_headline_only_update_has_safe_url_stable_id_and_real_source_clocks(self):
        row = live.parse_update(child_data(2001), PARENT, meta(2001), AT, True)
        self.assertEqual(row['publishedAt'], AT - 20)
        self.assertEqual(row['firstSeenAt'], AT)
        self.assertEqual(row['url'], live.ORIGIN + PARENT.path + '?update=2001')
        self.assertTrue(row['startupBackfill'])
        self.assertEqual(row['language'], 'en')
        self.assertRegex(row['id'], r'^[a-f0-9]{32}$')
        self.assertNotIn('content', row)
        self.assertNotIn('invent', json.dumps(row))
        changed = child_data(2001)
        changed['data']['posts']['title'] = '<b>Edited headline</b><script>attack()</script>'
        updated = live.parse_update(changed, PARENT, meta(2001), AT + 60, False)
        self.assertEqual(updated['title'], 'Edited headline')
        self.assertEqual(updated['id'], row['id'])

    def test_bad_child_identity_date_content_or_future_publication_fails_closed(self):
        mutations = [lambda p: p['data']['posts'].update(id='2002'),
                     lambda p: p['data']['posts'].update(date='2026-10-23'),
                     lambda p: p['data']['posts'].update(link='https://localhost/private'),
                     lambda p: p['data']['posts'].update(content='<script>hidden only</script>'),
                     lambda p: p['data']['posts'].update(title=''),
                     lambda p: p.update(errors=[{'message': 'missing'}])]
        for mutation in mutations:
            data = child_data(2001)
            mutation(data)
            with self.assertRaises(ValueError):
                live.parse_update(data, PARENT, meta(2001), AT, False)
        with self.assertRaises(ValueError):
            live.parse_update(child_data(2001), PARENT, meta(2001), AT - 21, False)

    def test_collection_cache304_preserves_receipts_and_limits_destinations(self):
        publisher = FakePublisher()
        collector = live.LiveUpdateCollector(publisher)
        first = collector.collect(AT)
        self.assertEqual(len(first), 2)
        self.assertTrue(all(row['startupBackfill'] for row in first))
        self.assertEqual(len(publisher.calls), 4)
        self.assertEqual(collector.status()['nextCheckAt'], (AT + 60) * 1000)
        self.assertEqual(collector.collect(AT + 30), [])
        self.assertEqual(len(publisher.calls), 4)
        publisher.conditional = True
        second = collector.collect(AT + 60)
        self.assertEqual(first, second)
        self.assertEqual(len(publisher.calls), 7)
        self.assertEqual(collector.status()['lastSuccessAt'], (AT + 60) * 1000)
        for url, headers, timeout in publisher.calls:
            self.assertTrue(live._allowed_url(url))
            self.assertLessEqual(timeout, 8)
            self.assertFalse({'authorization', 'cookie'} & {key.lower() for key in headers})
            if url != live.INDEX:
                self.assertEqual(headers['wp-site'], 'aje')
                self.assertEqual(headers['original-domain'], 'www.aljazeera.com')

    def test_at_most_three_children_fetched_and_repeated_ids_cannot_replay_as_new(self):
        publisher = FakePublisher([2001, 2002, 2003, 2004, 2005])
        collector = live.LiveUpdateCollector(publisher)
        first = collector.collect(AT)
        self.assertEqual(len(first), 3)
        self.assertEqual(len(publisher.calls), 5)
        second = collector.collect(AT + 60)
        self.assertEqual(len(publisher.calls), 9)
        self.assertEqual(len(second), 5)
        self.assertTrue(all(row['startupBackfill'] for row in second))
        for original in first:
            self.assertEqual(next(row for row in second if row['id'] == original['id'])['firstSeenAt'], AT)

    def test_only_new_ids_after_startup_lose_startup_flag(self):
        publisher = FakePublisher([2001])
        collector = live.LiveUpdateCollector(publisher)
        first = collector.collect(AT)
        publisher.ids = [2001, 2002]
        second = collector.collect(AT + 60)
        by_url = {row['url']: row for row in second}
        old = by_url[first[0]['url']]
        new = next(row for row in second if row['url'].endswith('2002'))
        self.assertTrue(old['startupBackfill'])
        self.assertEqual(old['firstSeenAt'], AT)
        self.assertFalse(new['startupBackfill'])
        self.assertEqual(new['firstSeenAt'], AT + 60)

    def test_stale_updates_are_not_fetched_or_returned_as_current_news(self):
        publisher = FakePublisher([2001, 2031])  # 20 seconds vs 620 seconds old.
        collector = live.LiveUpdateCollector(publisher)
        rows = collector.collect(AT)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['publishedAt'], AT - 20)
        self.assertEqual(len(publisher.calls), 3)
        self.assertEqual(collector.collect(AT + 600), [])

    def test_publisher_cache_intervals_are_respected_without_early_polling(self):
        publisher = FakePublisher()
        publisher.parent_cache = 300
        publisher.index_cache = 600
        collector = live.LiveUpdateCollector(publisher)
        collector.collect(AT)
        count = len(publisher.calls)
        self.assertEqual(collector.collect(AT + 299), [])
        self.assertEqual(len(publisher.calls), count)
        collector.collect(AT + 300)
        self.assertEqual(sum(url == live.INDEX for url, *_ in publisher.calls), 1)

    def test_denial_retry_after_and_redirect_are_not_bypassed(self):
        calls = []
        def denied(url, headers, timeout):
            calls.append(url)
            return response(url, {}, status=403, headers={'retry-after': '4000'})
        collector = live.LiveUpdateCollector(denied)
        self.assertEqual(collector.collect(AT), [])
        self.assertEqual(collector.status()['status'], 'access_denied')
        self.assertEqual(collector.status()['nextCheckAt'], (AT + 4000) * 1000)
        collector.collect(AT + 60)
        self.assertEqual(len(calls), 1)
        for status in (302, 429):
            collector = live.LiveUpdateCollector(lambda url, headers, timeout:
                response(url, {}, status=status, headers={'location': 'https://evil.example'}))
            self.assertEqual(collector.collect(AT), [])
            self.assertEqual(collector.status()['status'], 'rate_limited' if status == 429 else 'unavailable')

    def test_bad_response_does_not_commit_partial_state_or_refresh_receipts(self):
        publisher = FakePublisher([2001])
        collector = live.LiveUpdateCollector(publisher)
        first = collector.collect(AT)
        def invalid(url, headers, timeout):
            result = publisher(url, headers, timeout)
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
            if query.get('operationName') == ['LiveBlogUpdateQuery']:
                return response(url, {'data': {'posts': {}}})
            return result
        collector._fetcher = invalid
        self.assertEqual(collector.collect(AT + 60), [])
        self.assertEqual(collector.status()['lastSuccessAt'], AT * 1000)
        self.assertEqual(collector._posts[next(iter(collector._posts))]['item'], first[0])
        self.assertEqual(collector.status()['status'], 'unavailable')

    def test_response_bounds_encoding_mime_and_uncached304_fail_closed(self):
        cases = [lambda url: response(url, {}, status=304),
                 lambda url: response(url, b'x' * (live.MAX_BYTES + 1), json_body=False),
                 lambda url: response(url, index(), json_body=False, headers={'content-type': 'application/javascript'}),
                 lambda url: response('https://evil.example/', index(), json_body=False),
                 lambda url: response(url, index(), json_body=False, headers={'etag': 'bad\r\ntag'}),
                 lambda url: response(url, index(), json_body=False, headers={'cache-control': 'max-age=9999999'})]
        for case in cases:
            collector = live.LiveUpdateCollector(lambda url, headers, timeout: case(url))
            self.assertEqual(collector.collect(AT), [])
            self.assertEqual(collector.status()['status'], 'unavailable')
            self.assertEqual(collector.status()['cachedUpdates'], 0)

    def test_allowlist_rejects_foreign_credentials_custom_queries_and_arbitrary_variables(self):
        valid = live._graph('LiveBlogUpdateQuery', {'postID': 2001, 'postType': 'liveblog-update', 'preview': '', 'isAmp': False})
        self.assertTrue(live._allowed_url(valid))
        for url in ('http://www.aljazeera.com/news/', 'https://www.aljazeera.com:443/news/',
                    'https://user@www.aljazeera.com/news/', 'https://127.0.0.1/private',
                    valid.replace('www.aljazeera.com', 'evil.example'), valid + '&query=custom',
                    live.ORIGIN + '/graphql?query=mutation',
                    live._graph('LiveBlogUpdateQuery', {'postID': True, 'postType': 'liveblog-update', 'preview': '', 'isAmp': False}),
                    live._graph('ArchipelagoSingleLiveBlogQuery', {'name': '../private', 'postType': 'liveblog', 'preview': ''})):
            self.assertFalse(live._allowed_url(url))


if __name__ == '__main__':
    unittest.main()

import copy
import unittest
from unittest.mock import patch

import discussion_import as discussion


class DiscussionImportTests(unittest.TestCase):
    now = 1792713500000

    def segment(self, language="en"):
        result = {"id": "a" * 32, "kind": "discussion", "title": "Gold and rates",
            "generatedAt": self.now - 60000, "windowStart": self.now - 720000, "windowEnd": self.now - 120000,
            "plannedAt": self.now - 120000, "durationSeconds": 60,
            "sources": [{"title": "Japan consumer prices rise", "source": "A public publisher",
                "url": "https://www.bbc.com/news/test", "publishedAt": self.now - 300000,
                "firstSeenAt": self.now - 250000}],
            "transcript": [{"role": "analyst", "kind": "interpretation", "name": "Maya",
                "text": "Higher inflation can affect rate expectations. The direction of gold is uncertain.", "startSeconds": 1},
                {"role": "skeptic", "kind": "interpretation", "name": "Alex",
                "text": "A headline alone does not establish a causal gold price effect.", "startSeconds": 20}]}
        if language == "en":
            result.update(editorialMode="local-llm-discussion", writerModel="lfm2.5-2.6b-local",
                programmeId="b" * 32, programmePart=1, programmeParts=3, languages=["en"])
        else:
            result.update(editorialMode="arabic-mixed-discussion", adaptationMode="abridged_source_translation",
                primaryLanguage="ar2", chapterIndex=1, chapterCount=2, languages=["ar2"])
            result["transcript"][0].update(name="المذيعة", text="ارتفاع التضخم قد يؤثر في توقعات الفائدة. اتجاه الذهب غير مؤكد.")
            result["transcript"][1].update(name="المحلل", text="عنوان الخبر وحده لا يثبت تأثيراً سببياً في سعر الذهب.")
        return result

    def payload(self, language="en"):
        return {"serverTime": self.now, "status": "live", "syntheticVoices": True,
            "staleAgeSeconds": 2, "queue": [self.segment(language)], "nowPlaying": self.segment(language)}

    def test_real_public_en_and_ar_projection_contracts_are_supported(self):
        for language in ("ar", "en"):
            importer = discussion.DiscussionImporter()
            self.assertEqual(importer.ingest(self.payload(language), language, self.now), 2)
            job = importer.candidate(language, self.now / 1000)
            self.assertEqual(job["kind"], "discussion")
            self.assertEqual(job["speaker"], "Maya" if language == "en" else "المذيعة")
            self.assertEqual(job["programme"]["generatedAt"], self.now - 60000)
            self.assertEqual(len(job["sources"]), 1)
            if language == "ar":
                self.assertNotIn("writerModel", job["programme"])
                self.assertEqual(job["programme"]["provenance"], "publisher-validated-arabic-duo")
            else:
                self.assertEqual(job["programme"]["writerModel"], "lfm2.5-2.6b-local")
            self.assertEqual(len(importer.pending), 2)
            self.assertTrue(importer.consume(job))
            self.assertFalse(importer.consume(job))
            self.assertEqual(importer.ingest(self.payload(language), language, self.now), 0)
            self.assertNotEqual(importer.candidate(language, self.now / 1000)["id"], job["id"])

    def test_stale_and_future_programmes_fail_at_ingest_and_scheduled_start(self):
        importer = discussion.DiscussionImporter()
        importer.ingest(self.payload(), "en", self.now)
        self.assertIsNone(importer.candidate("en", self.now / 1000 + 781))
        for field, stamp in (("windowEnd", self.now - 900001), ("generatedAt", self.now + 1), ("plannedAt", self.now)):
            segment = self.segment()
            segment[field] = stamp
            self.assertEqual(discussion.parse_programme(segment, "en", self.now), [])

    def test_music_news_templates_and_unproven_models_never_become_discussion(self):
        for changes in ({"kind": "news"}, {"kind": "music"}, {"editorialMode": "grounded-template"},
                        {"writerModel": "some-other-model"}, {"programmeId": "bad"}):
            segment = {**self.segment(), **changes}
            self.assertEqual(discussion.parse_programme(segment, "en", self.now), [])

    def test_missing_private_sourceprogramme_ar_fields_do_not_reject_valid_public_duo(self):
        segment = self.segment("ar")
        self.assertNotIn("writerModel", segment)
        self.assertNotIn("sourceProgrammeId", segment)
        self.assertTrue(discussion.parse_programme(segment, "ar", self.now))
        segment["adaptationMode"] = "unknown"
        self.assertFalse(discussion.parse_programme(segment, "ar", self.now))

    def test_quiet_window_educational_discussion_stays_source_free_and_labelled(self):
        segment = self.segment()
        segment.update(sources=[], discussionMode='conditional_education', topicId='oil-and-gold')
        jobs = discussion.parse_programme(segment, 'en', self.now)
        self.assertTrue(jobs)
        self.assertEqual(jobs[0]['sources'], [])
        self.assertTrue(jobs[0]['programme']['sourceFree'])
        self.assertEqual(jobs[0]['kind'], 'discussion')
        self.assertEqual(jobs[0]['programme']['discussionMode'], 'conditional_education')
        arabic = self.segment('ar')
        arabic['sources'] = []
        job = discussion.parse_programme(arabic, 'ar', self.now)[0]
        self.assertEqual(job['programme']['provenance'], 'publisher-validated-arabic-duo')
        self.assertNotIn('writerModel', job['programme'])

    def test_sources_are_mandatory_fixed_clocked_and_only_safe_https_links(self):
        for url in ("http://example.com/a", "https://127.0.0.1/a", "https://person:secret@example.com/a",
                    "https://example.com:8080/a", "https://secret.local/a", "https://example.com/a?origin=192.168.1.2",
                    "https://example.com/a%0Ab"):
            segment = self.segment()
            segment["sources"][0]["url"] = url
            with self.assertRaises(discussion.DiscussionUnavailable):
                discussion.parse_programme(segment, "en", self.now)
        for field, stamp in (("publishedAt", self.now + 1), ("firstSeenAt", self.now - 300001)):
            segment = self.segment()
            segment["sources"][0][field] = stamp
            with self.assertRaises(discussion.DiscussionUnavailable):
                discussion.parse_programme(segment, "en", self.now)
        segment = self.segment()
        segment["sources"] = []
        with self.assertRaises(discussion.DiscussionUnavailable):
            discussion.parse_programme(segment, "en", self.now)

    def test_long_turns_are_bounded_and_forecasts_and_filler_are_skipped(self):
        segment = self.segment()
        segment["transcript"][0]["text"] = " ".join("word" for _ in range(103))
        segment["transcript"][1]["kind"] = "forecast"
        jobs = discussion.parse_programme(segment, "en", self.now)
        self.assertEqual([len(job["speechText"].split()) for job in jobs], [45, 45, 13])
        self.assertEqual(len({job["id"] for job in jobs}), 3)
        segment["transcript"][0]["kind"] = "transition"
        self.assertFalse(discussion.parse_programme(segment, "en", self.now))

    def test_language_controls_and_private_text_are_rejected(self):
        for language, text in (("en", "Arabic هنا"), ("ar", "hello عالم"),
                               ("en", "Read C:\\Users\\Owner\\private"), ("en", "Send person@example.com")):
            segment = self.segment(language)
            segment["transcript"][0]["text"] = text
            with self.assertRaises(discussion.DiscussionUnavailable):
                discussion.parse_programme(segment, language, self.now)

    def test_poll_is_optional_rate_limited_and_never_accepts_a_caller_url(self):
        importer = discussion.DiscussionImporter()
        with patch.object(discussion, "fetch_manifest", side_effect=discussion.DiscussionUnavailable("Offline")) as fetch:
            self.assertEqual(importer.poll(self.now / 1000), 0)
            self.assertEqual(fetch.call_count, 2)
            self.assertEqual(importer.poll(self.now / 1000 + 10), 0)
            self.assertEqual(fetch.call_count, 2)
            self.assertIsNone(importer.candidate("ar", self.now / 1000))
        with self.assertRaises(discussion.DiscussionUnavailable):
            discussion.fetch_manifest("https://localhost/inference")

    def test_stale_manifest_does_not_admit_jobs(self):
        for changes in ({"serverTime": self.now - 31000}, {"status": "unavailable"},
                        {"staleAgeSeconds": 46}, {"syntheticVoices": False}):
            importer = discussion.DiscussionImporter()
            with self.assertRaises(discussion.DiscussionUnavailable):
                importer.ingest({**self.payload(), **changes}, "en", self.now)
            self.assertFalse(importer.pending)

    def test_grounded_host_question_precedes_answer_without_sourcefree_current_claims(self):
        segment = self.segment()
        segment['transcript'][0].update(role='anchor', kind='observation', name='Maya',
            text='How could this inflation report affect gold?')
        jobs = discussion.parse_programme(segment, 'en', self.now)
        self.assertEqual(jobs[0]['turnKind'], 'observation')
        self.assertEqual(jobs[0]['speechText'], 'How could this inflation report affect gold?')
        segment.update(sources=[], discussionMode='conditional_education', topicId='rates-and-gold')
        self.assertEqual(len(discussion.parse_programme(segment, 'en', self.now)), 2)
        segment['transcript'][0]['text'] = 'Gold is moving higher right now.'
        jobs = discussion.parse_programme(segment, 'en', self.now)
        self.assertEqual(len(jobs), 1)
        self.assertNotIn('right now', jobs[0]['speechText'])

    def test_retry_exclusion_skips_programme_without_skipping_its_failed_context(self):
        first, second = self.segment(), self.segment()
        second.update(id='c' * 32, programmeId='d' * 32)
        payload = self.payload()
        payload.update(queue=[first, second], nowPlaying=None)
        importer = discussion.DiscussionImporter()
        importer.ingest(payload, 'en', self.now)
        original = importer.candidate('en', self.now / 1000)
        alternate = importer.candidate('en', self.now / 1000, exclude_ids={original['id']})
        self.assertNotEqual(original['programme']['id'], alternate['programme']['id'])
        self.assertEqual(alternate['turnIndex'], 0)
        only = discussion.DiscussionImporter()
        only.ingest(self.payload(), 'en', self.now)
        blocked = only.candidate('en', self.now / 1000)
        self.assertIsNone(only.candidate('en', self.now / 1000, {blocked['id']}))
        self.assertEqual(only.candidate('en', self.now / 1000)['id'], blocked['id'])

    def test_global_news_retry_collection_does_not_break_discussion_candidate(self):
        importer = discussion.DiscussionImporter()
        importer.ingest(self.payload(), 'en', self.now)
        first = importer.candidate('en', self.now / 1000)
        retries = {format(index, '032x') for index in range(1100)}
        self.assertGreater(len(retries), discussion.MAX_PENDING)
        self.assertEqual(importer.candidate('en', self.now / 1000, retries)['id'], first['id'])
        retries.add(first['id'])
        self.assertIsNone(importer.candidate('en', self.now / 1000, retries))
        self.assertIsNone(importer.candidate('en', self.now / 1000, dict.fromkeys(retries, self.now + 30000)))

    def test_capacity_keeps_complete_turn_prefixes_and_readmits_the_next_turn(self):
        segment = self.segment()
        segment['transcript'] = [{'role': 'analyst', 'kind': 'interpretation', 'name': 'Maya',
            'text': ' '.join(f'word{turn}' for _ in range(103)), 'startSeconds': turn * 3}
            for turn in range(10)]
        payload = {**self.payload(), 'queue': [segment], 'nowPlaying': None}
        with patch.object(discussion, 'MAX_PENDING', 5):
            importer = discussion.DiscussionImporter()
            self.assertEqual(importer.ingest(payload, 'en', self.now), 3)
            self.assertEqual({job['turnIndex'] for job in importer.pending.values()}, {0})
            for expected_chunk in range(3):
                job = importer.candidate('en', self.now / 1000)
                self.assertEqual((job['turnIndex'], job['chunkIndex']), (0, expected_chunk))
                self.assertTrue(importer.consume(job))
            self.assertEqual(importer.ingest(payload, 'en', self.now), 3)
            next_job = importer.candidate('en', self.now / 1000)
            self.assertEqual((next_job['turnIndex'], next_job['chunkIndex']), (1, 0))

    def test_busy_languages_retain_whole_turns_on_both_channels(self):
        with patch.object(discussion, 'MAX_PENDING', 6):
            importer = discussion.DiscussionImporter()
            for language in ('en', 'ar'):
                segment = self.segment(language)
                segment['transcript'] *= 3
                for index, turn in enumerate(segment['transcript']):
                    # Copy repeated turns so clocks remain strictly ordered.
                    segment['transcript'][index] = {**turn, 'startSeconds': index * 5}
                importer.ingest({**self.payload(language), 'queue': [segment], 'nowPlaying': None}, language, self.now)
            self.assertLessEqual(len(importer.pending), 6)
            self.assertEqual({job['language'] for job in importer.pending.values()}, {'en', 'ar'})
            for language in ('en', 'ar'):
                self.assertEqual(importer.candidate(language, self.now / 1000)['turnIndex'], 0)

    def test_active_programme_keeps_order_when_an_older_topic_arrives(self):
        importer = discussion.DiscussionImporter()
        importer.ingest(self.payload(), 'en', self.now)
        started = importer.candidate('en', self.now / 1000)
        self.assertTrue(importer.consume(started))
        older = self.segment()
        older.update(id='c' * 32, programmeId='d' * 32)
        for key in ('windowStart', 'windowEnd', 'plannedAt', 'generatedAt'):
            older[key] -= 1000
        importer.ingest({**self.payload(), 'queue': [older], 'nowPlaying': None}, 'en', self.now)
        continued = importer.candidate('en', self.now / 1000)
        self.assertEqual(continued['programme']['id'], started['programme']['id'])
        self.assertEqual(continued['turnIndex'], 1)
        # A caller cannot accidentally confirm a later turn before its context.
        later = next(row for row in importer.pending.values() if row['programme']['id'] == older['programmeId'] and row['turnIndex'] == 1)
        self.assertFalse(importer.consume(later))

    def test_missing_opening_part_waits_then_arabic_chapters_share_ordering_group(self):
        for language in ('en', 'ar'):
            opening, later = self.segment(language), self.segment(language)
            later['id'] = 'c' * 32
            later['programmePart' if language == 'en' else 'chapterIndex'] = 2
            for turn in later['transcript']:
                turn['text'] += ' الجزء الثاني.' if language == 'ar' else ' Second part.'
            importer = discussion.DiscussionImporter()
            importer.ingest({**self.payload(language), 'queue': [later], 'nowPlaying': None}, language, self.now)
            self.assertIsNone(importer.candidate(language, self.now / 1000))
            importer.ingest({**self.payload(language), 'queue': [opening, later], 'nowPlaying': None}, language, self.now)
            first = importer.candidate(language, self.now / 1000)
            self.assertEqual(first['programme']['part'], 1)
            group = first['programme']['groupId']
            self.assertEqual({row['programme']['groupId'] for row in importer.pending.values()}, {group})
            self.assertTrue(importer.consume(first))
            self.assertTrue(importer.consume(importer.candidate(language, self.now / 1000)))
            self.assertEqual(importer.candidate(language, self.now / 1000)['programme']['part'], 2)

    def test_missing_intermediate_part_waits_in_both_languages(self):
        for language in ('en', 'ar'):
            opening, middle, ending = (self.segment(language) for _ in range(3))
            key = 'programmePart' if language == 'en' else 'chapterIndex'
            for part, segment in enumerate((opening, middle, ending), 1):
                segment['id'] = str(part) * 32
                segment[key] = part
                for turn in segment['transcript']:
                    turn['text'] += f' الجزء {part}.' if language == 'ar' else f' Part {part}.'
                if language == 'ar':
                    segment['chapterCount'] = 3
            importer = discussion.DiscussionImporter()
            importer.ingest({**self.payload(language), 'queue': [opening, ending], 'nowPlaying': None}, language, self.now)
            for _ in opening['transcript']:
                self.assertTrue(importer.consume(importer.candidate(language, self.now / 1000)))
            self.assertIsNone(importer.candidate(language, self.now / 1000))
            importer.ingest({**self.payload(language), 'queue': [middle, ending], 'nowPlaying': None}, language, self.now)
            for _ in middle['transcript']:
                job = importer.candidate(language, self.now / 1000)
                self.assertEqual(job['programme']['part'], 2)
                self.assertTrue(importer.consume(job))
            self.assertEqual(importer.candidate(language, self.now / 1000)['programme']['part'], 3)

    def test_validated_empty_opening_part_allows_first_real_discussion_turn(self):
        for language in ('en', 'ar'):
            opening, middle = self.segment(language), self.segment(language)
            key = 'programmePart' if language == 'en' else 'chapterIndex'
            opening['id'], middle['id'] = '1' * 32, '2' * 32
            middle[key] = 2
            for turn in opening['transcript']:
                turn['kind'] = 'forecast_review'
            importer = discussion.DiscussionImporter()
            self.assertEqual(importer.ingest({**self.payload(language), 'queue': [opening, middle], 'nowPlaying': None}, language, self.now), 2)
            job = importer.candidate(language, self.now / 1000)
            self.assertIsNotNone(job)
            self.assertEqual(job['programme']['part'], 2)
            self.assertEqual(job['turnIndex'], 0)
            group = importer.parts[importer._group(job)]
            self.assertTrue(group['parts'][1]['empty'])
            self.assertEqual(group['parts'][1]['generatedAt'], opening['generatedAt'])

    def test_validated_empty_middle_part_does_not_block_ending_discussion(self):
        for language in ('en', 'ar'):
            segments = [self.segment(language) for _ in range(3)]
            key = 'programmePart' if language == 'en' else 'chapterIndex'
            for part, segment in enumerate(segments, 1):
                segment['id'] = str(part) * 32
                segment[key] = part
                for turn in segment['transcript']:
                    turn['text'] += f' الجزء {part}.' if language == 'ar' else f' Part {part}.'
                if language == 'ar':
                    segment['chapterCount'] = 3
            for turn in segments[1]['transcript']:
                turn['kind'] = 'transition'
            importer = discussion.DiscussionImporter()
            importer.ingest({**self.payload(language), 'queue': segments, 'nowPlaying': None}, language, self.now)
            for _ in segments[0]['transcript']:
                self.assertTrue(importer.consume(importer.candidate(language, self.now / 1000)))
            self.assertEqual(importer.candidate(language, self.now / 1000)['programme']['part'], 3)

    def test_invalid_filtered_opening_never_establishes_part_completion(self):
        for changes in ('unknown-kind', 'private-text', 'missing-model', 'bad-source'):
            opening, middle = self.segment(), self.segment()
            middle.update(id='2' * 32, programmePart=2)
            for turn in opening['transcript']:
                turn['kind'] = 'forecast_review'
            if changes == 'unknown-kind':
                opening['transcript'][0]['kind'] = 'unknown'
            elif changes == 'private-text':
                opening['transcript'][0]['text'] = 'C:\\Users\\Private\\secret'
            elif changes == 'missing-model':
                opening.pop('writerModel')
            else:
                opening['sources'][0]['url'] = 'https://127.0.0.1/private'
            importer = discussion.DiscussionImporter()
            importer.ingest({**self.payload(), 'queue': [opening, middle], 'nowPlaying': None}, 'en', self.now)
            self.assertIsNone(importer.candidate('en', self.now / 1000))
            job = next(iter(importer.pending.values()))
            self.assertNotIn(1, importer.parts[importer._group(job)]['parts'])

    def test_capacity_clipped_part_is_not_completed_before_its_last_real_turn(self):
        opening, middle = self.segment(), self.segment()
        opening['transcript'] = [{**opening['transcript'][0], 'text': f'Conditional turn {index}.',
            'startSeconds': index * 5} for index in range(6)]
        middle.update(id='2' * 32, programmePart=2)
        with patch.object(discussion, 'MAX_PENDING', 3):
            importer = discussion.DiscussionImporter()
            importer.ingest({**self.payload(), 'queue': [opening, middle], 'nowPlaying': None}, 'en', self.now)
            for _ in range(3):
                self.assertTrue(importer.consume(importer.candidate('en', self.now / 1000)))
            # If the source no longer retains the clipped opening DTO, its
            # unfinished context cannot silently be treated as completed.
            importer.ingest({**self.payload(), 'queue': [middle], 'nowPlaying': None}, 'en', self.now)
            self.assertIsNone(importer.candidate('en', self.now / 1000))

    def test_contradictory_part_cannot_be_replaced_by_an_empty_revision(self):
        opening, middle = self.segment(), self.segment()
        middle.update(id='2' * 32, programmePart=2)
        importer = discussion.DiscussionImporter()
        importer.ingest({**self.payload(), 'queue': [opening, middle], 'nowPlaying': None}, 'en', self.now)
        original = importer.candidate('en', self.now / 1000)
        changed = copy.deepcopy(opening)
        for turn in changed['transcript']:
            turn['kind'] = 'forecast'
        importer.ingest({**self.payload(), 'queue': [changed, middle], 'nowPlaying': None}, 'en', self.now)
        self.assertFalse(importer.parts[importer._group(original)]['parts'][1]['empty'])
        self.assertEqual(importer.candidate('en', self.now / 1000)['id'], original['id'])

    def test_progress_prevents_replay_after_seen_ring_rolls_and_expires_with_programme(self):
        segment = self.segment()
        segment['transcript'] = [{**segment['transcript'][0], 'text': f'Conditional interpretation number {index}.',
            'startSeconds': index * 5} for index in range(6)]
        payload = {**self.payload(), 'queue': [segment], 'nowPlaying': None}
        with patch.object(discussion, 'MAX_SEEN', 3):
            importer = discussion.DiscussionImporter()
            importer.ingest(payload, 'en', self.now)
            consumed = []
            for _ in range(4):
                job = importer.candidate('en', self.now / 1000)
                consumed.append(job['id'])
                self.assertTrue(importer.consume(job))
            self.assertEqual(len(importer.seen), 3)
            self.assertNotIn(consumed[0], importer.seen)
            self.assertEqual(importer.ingest(payload, 'en', self.now), 0)
            self.assertEqual(importer.candidate('en', self.now / 1000)['turnIndex'], 4)
            self.assertNotIn(consumed[0], importer.pending)
            importer.candidate('en', self.now / 1000 + 781)
            self.assertFalse(importer.pending)
            self.assertFalse(importer.progress)
            self.assertFalse(importer.parts)

    def test_repeated_ingest_preserves_original_receipt_source_and_generation_clocks(self):
        importer = discussion.DiscussionImporter()
        importer.ingest(self.payload(), 'en', self.now)
        first = importer.candidate('en', self.now / 1000)
        payload = self.payload()
        payload['serverTime'] += 10000
        importer.ingest(payload, 'en', self.now + 10000)
        again = importer.candidate('en', self.now / 1000 + 10)
        self.assertEqual(first['id'], again['id'])
        self.assertEqual(first['firstSeenAt'], again['firstSeenAt'])
        self.assertEqual(first['programme'], again['programme'])
        self.assertEqual(first['sources'], again['sources'])

    def test_overlapping_boundary_turns_are_spoken_once_and_part_three_still_plays(self):
        for language in ('en', 'ar'):
            segments = [self.segment(language) for _ in range(3)]
            key = 'programmePart' if language == 'en' else 'chapterIndex'
            if language == 'en':
                texts = ['An opening question about rates?', 'A stronger dollar could be a headwind.',
                         'The effect also depends on real yields.', 'A closing question remains uncertain.']
                speaker = 'Iris'
            else:
                texts = ['هل تتغير توقعات الفائدة؟', 'قوة الدولار قد تشكل ضغطاً على الذهب.',
                         'الأثر يعتمد أيضاً على العائد الحقيقي.', 'يبقى السؤال الأخير غير مؤكد.']
                speaker = 'المحلل'
            for part, segment in enumerate(segments, 1):
                segment.update(id=str(part) * 32)
                segment[key] = part
                if language == 'ar':
                    segment['chapterCount'] = 3
                for turn, text in zip(segment['transcript'], texts[part - 1:part + 1]):
                    turn.update(name=speaker, text=text)
            importer = discussion.DiscussionImporter()
            importer.ingest({**self.payload(language), 'queue': segments, 'nowPlaying': None}, language, self.now)
            spoken, positions = [], []
            while job := importer.candidate(language, self.now / 1000):
                spoken.append(job['speechText'])
                positions.append((job['programme']['part'], job['turnIndex']))
                self.assertTrue(importer.consume(job))
            self.assertEqual(spoken, texts)
            self.assertEqual(positions, [(1, 0), (1, 1), (2, 1), (3, 1)])
            self.assertFalse(importer.pending)
            progress = next(iter(importer.progress.values()))
            self.assertEqual(progress['position'], (3, 1, 0))
            self.assertEqual(importer.status(language)['deduplicatedTurns'], 2)

    def test_same_text_for_another_speaker_or_programme_is_not_globally_deduplicated(self):
        first, second = self.segment(), self.segment()
        second.update(id='c' * 32, programmeId='d' * 32)
        for segment in (first, second):
            for turn in segment['transcript']:
                turn['text'] = 'This conditional possibility remains uncertain.'
        importer = discussion.DiscussionImporter()
        importer.ingest({**self.payload(), 'queue': [first, second], 'nowPlaying': None}, 'en', self.now)
        jobs = []
        while job := importer.candidate('en', self.now / 1000):
            jobs.append(job)
            self.assertTrue(importer.consume(job))
        self.assertEqual(len(jobs), 4)
        self.assertEqual(len({job['speaker'] for job in jobs}), 2)
        self.assertEqual(len({job['programme']['id'] for job in jobs}), 2)

    def test_failed_or_unconfirmed_tts_does_not_mark_text_as_published(self):
        importer = discussion.DiscussionImporter()
        importer.ingest(self.payload(), 'en', self.now)
        first = importer.candidate('en', self.now / 1000)
        self.assertFalse(importer.published_texts)
        # A failed generation leaves the job pending and retryable.
        again = importer.candidate('en', self.now / 1000)
        self.assertEqual(first['id'], again['id'])
        self.assertFalse(importer.published_texts)
        self.assertTrue(importer.consume(first))
        self.assertEqual(len(importer.published_texts), 1)

    def test_published_text_history_is_bounded_and_expires_on_original_clock(self):
        segment = self.segment()
        segment['transcript'] = [{**segment['transcript'][0], 'text': f'Conditional interpretation number {index}.',
            'startSeconds': index * 5} for index in range(6)]
        with patch.object(discussion, 'MAX_PUBLISHED_TEXTS', 3):
            importer = discussion.DiscussionImporter()
            importer.ingest({**self.payload(), 'queue': [segment], 'nowPlaying': None}, 'en', self.now)
            while job := importer.candidate('en', self.now / 1000):
                self.assertTrue(importer.consume(job))
            self.assertEqual(len(importer.published_texts), 3)
            importer.candidate('en', self.now / 1000 + 781)
            self.assertFalse(importer.published_texts)

    def test_http_reader_is_fixed_bounded_and_refuses_redirects(self):
        import email.message
        import json
        class Response:
            status = 200
            def __init__(self, body, length=None):
                self.body, self.bound = body, None
                self.headers = email.message.Message()
                self.headers["Content-Type"] = "application/json"
                if length:
                    self.headers["Content-Length"] = length
            def __enter__(self): return self
            def __exit__(self, *_): return None
            def geturl(self): return discussion.URLS["en"]
            def read(self, bound):
                self.bound = bound
                return self.body
        response = Response(json.dumps(self.payload()).encode())
        with patch.object(discussion.urllib.request, "build_opener") as opener:
            opener.return_value.open.return_value = response
            discussion.fetch_manifest("en")
            args = opener.return_value.open.call_args
            self.assertEqual(args.args[0].full_url, discussion.URLS["en"])
            self.assertEqual(args.args[0].get_method(), "GET")
            self.assertEqual(args.kwargs["timeout"], 8)
            self.assertEqual(response.bound, discussion.MAX_RESPONSE_BYTES + 1)
        for response in (Response(b"{}", "99999999"), Response(b'{"queue":[],"queue":[]}')):
            with patch.object(discussion.urllib.request, "build_opener") as opener:
                opener.return_value.open.return_value = response
                with self.assertRaises(discussion.DiscussionUnavailable):
                    discussion.fetch_manifest("en")
        with self.assertRaises(discussion.DiscussionUnavailable):
            discussion._NoRedirect().redirect_request(None, None, None, None, None, "http://127.0.0.1")


if __name__ == "__main__":
    unittest.main()

import copy
import unittest
from unittest.mock import patch

import discussion_import as discussion


class DiscussionImportTests(unittest.TestCase):
    now = 1792713500000

    def segment(self, language="en"):
        result = {"id": "a" * 32, "kind": "discussion", "title": "Gold and rates",
            "generatedAt": self.now - 60000, "windowStart": self.now - 720000, "windowEnd": self.now - 120000,
            "plannedAt": self.now - 120000, "durationSeconds": 60,
            "sources": [{"title": "Japan consumer prices rise", "source": "A public publisher",
                "url": "https://www.bbc.com/news/test", "publishedAt": self.now - 300000,
                "firstSeenAt": self.now - 250000}],
            "transcript": [{"role": "analyst", "kind": "interpretation", "name": "Maya",
                "text": "Higher inflation can affect rate expectations. The direction of gold is uncertain.", "startSeconds": 1},
                {"role": "skeptic", "kind": "interpretation", "name": "Alex",
                "text": "A headline alone does not establish a causal gold price effect.", "startSeconds": 20}]}
        if language == "en":
            result.update(editorialMode="local-llm-discussion", writerModel="lfm2.5-2.6b-local",
                programmeId="b" * 32, programmePart=1, programmeParts=3, languages=["en"])
        else:
            result.update(editorialMode="arabic-mixed-discussion", adaptationMode="abridged_source_translation",
                primaryLanguage="ar2", chapterIndex=1, chapterCount=2, languages=["ar2"])
            result["transcript"][0].update(name="المذيعة", text="ارتفاع التضخم قد يؤثر في توقعات الفائدة. اتجاه الذهب غير مؤكد.")
            result["transcript"][1].update(name="المحلل", text="عنوان الخبر وحده لا يثبت تأثيراً سببياً في سعر الذهب.")
        return result

    def payload(self, language="en"):
        return {"serverTime": self.now, "status": "live", "syntheticVoices": True,
            "staleAgeSeconds": 2, "queue": [self.segment(language)], "nowPlaying": self.segment(language)}

    def test_real_public_en_and_ar_projection_contracts_are_supported(self):
        for language in ("ar", "en"):
            importer = discussion.DiscussionImporter()
            self.assertEqual(importer.ingest(self.payload(language), language, self.now), 2)
            job = importer.candidate(language, self.now / 1000)
            self.assertEqual(job["kind"], "discussion")
            self.assertEqual(job["speaker"], "Maya" if language == "en" else "المذيعة")
            self.assertEqual(job["programme"]["generatedAt"], self.now - 60000)
            self.assertEqual(len(job["sources"]), 1)
            if language == "ar":
                self.assertNotIn("writerModel", job["programme"])
                self.assertEqual(job["programme"]["provenance"], "publisher-validated-arabic-duo")
            else:
                self.assertEqual(job["programme"]["writerModel"], "lfm2.5-2.6b-local")
            self.assertEqual(len(importer.pending), 2)
            self.assertTrue(importer.consume(job))
            self.assertFalse(importer.consume(job))
            self.assertEqual(importer.ingest(self.payload(language), language, self.now), 0)
            self.assertNotEqual(importer.candidate(language, self.now / 1000)["id"], job["id"])

    def test_stale_and_future_programmes_fail_at_ingest_and_scheduled_start(self):
        importer = discussion.DiscussionImporter()
        importer.ingest(self.payload(), "en", self.now)
        self.assertIsNone(importer.candidate("en", self.now / 1000 + 781))
        for field, stamp in (("windowEnd", self.now - 900001), ("generatedAt", self.now + 1), ("plannedAt", self.now)):
            segment = self.segment()
            segment[field] = stamp
            self.assertEqual(discussion.parse_programme(segment, "en", self.now), [])

    def test_music_news_templates_and_unproven_models_never_become_discussion(self):
        for changes in ({"kind": "news"}, {"kind": "music"}, {"editorialMode": "grounded-template"},
                        {"writerModel": "some-other-model"}, {"programmeId": "bad"}):
            segment = {**self.segment(), **changes}
            self.assertEqual(discussion.parse_programme(segment, "en", self.now), [])

    def test_missing_private_sourceprogramme_ar_fields_do_not_reject_valid_public_duo(self):
        segment = self.segment("ar")
        self.assertNotIn("writerModel", segment)
        self.assertNotIn("sourceProgrammeId", segment)
        self.assertTrue(discussion.parse_programme(segment, "ar", self.now))
        segment["adaptationMode"] = "unknown"
        self.assertFalse(discussion.parse_programme(segment, "ar", self.now))

    def test_quiet_window_educational_discussion_stays_source_free_and_labelled(self):
        segment = self.segment()
        segment.update(sources=[], discussionMode='conditional_education', topicId='oil-and-gold')
        jobs = discussion.parse_programme(segment, 'en', self.now)
        self.assertTrue(jobs)
        self.assertEqual(jobs[0]['sources'], [])
        self.assertTrue(jobs[0]['programme']['sourceFree'])
        self.assertEqual(jobs[0]['kind'], 'discussion')
        self.assertEqual(jobs[0]['programme']['discussionMode'], 'conditional_education')
        arabic = self.segment('ar')
        arabic['sources'] = []
        job = discussion.parse_programme(arabic, 'ar', self.now)[0]
        self.assertEqual(job['programme']['provenance'], 'publisher-validated-arabic-duo')
        self.assertNotIn('writerModel', job['programme'])

    def test_sources_are_mandatory_fixed_clocked_and_only_safe_https_links(self):
        for url in ("http://example.com/a", "https://127.0.0.1/a", "https://person:secret@example.com/a",
                    "https://example.com:8080/a", "https://secret.local/a", "https://example.com/a?origin=192.168.1.2",
                    "https://example.com/a%0Ab"):
            segment = self.segment()
            segment["sources"][0]["url"] = url
            with self.assertRaises(discussion.DiscussionUnavailable):
                discussion.parse_programme(segment, "en", self.now)
        for field, stamp in (("publishedAt", self.now + 1), ("firstSeenAt", self.now - 300001)):
            segment = self.segment()
            segment["sources"][0][field] = stamp
            with self.assertRaises(discussion.DiscussionUnavailable):
                discussion.parse_programme(segment, "en", self.now)
        segment = self.segment()
        segment["sources"] = []
        with self.assertRaises(discussion.DiscussionUnavailable):
            discussion.parse_programme(segment, "en", self.now)

    def test_long_turns_are_bounded_and_forecasts_and_filler_are_skipped(self):
        segment = self.segment()
        segment["transcript"][0]["text"] = " ".join("word" for _ in range(103))
        segment["transcript"][1]["kind"] = "forecast"
        jobs = discussion.parse_programme(segment, "en", self.now)
        self.assertEqual([len(job["speechText"].split()) for job in jobs], [45, 45, 13])
        self.assertEqual(len({job["id"] for job in jobs}), 3)
        segment["transcript"][0]["kind"] = "transition"
        self.assertFalse(discussion.parse_programme(segment, "en", self.now))

    def test_language_controls_and_private_text_are_rejected(self):
        for language, text in (("en", "Arabic هنا"), ("ar", "hello عالم"),
                               ("en", "Read C:\\Users\\Owner\\private"), ("en", "Send person@example.com")):
            segment = self.segment(language)
            segment["transcript"][0]["text"] = text
            with self.assertRaises(discussion.DiscussionUnavailable):
                discussion.parse_programme(segment, language, self.now)

    def test_poll_is_optional_rate_limited_and_never_accepts_a_caller_url(self):
        importer = discussion.DiscussionImporter()
        with patch.object(discussion, "fetch_manifest", side_effect=discussion.DiscussionUnavailable("Offline")) as fetch:
            self.assertEqual(importer.poll(self.now / 1000), 0)
            self.assertEqual(fetch.call_count, 2)
            self.assertEqual(importer.poll(self.now / 1000 + 10), 0)
            self.assertEqual(fetch.call_count, 2)
            self.assertIsNone(importer.candidate("ar", self.now / 1000))
        with self.assertRaises(discussion.DiscussionUnavailable):
            discussion.fetch_manifest("https://localhost/inference")

    def test_stale_manifest_does_not_admit_jobs(self):
        for changes in ({"serverTime": self.now - 31000}, {"status": "unavailable"},
                        {"staleAgeSeconds": 46}, {"syntheticVoices": False}):
            importer = discussion.DiscussionImporter()
            with self.assertRaises(discussion.DiscussionUnavailable):
                importer.ingest({**self.payload(), **changes}, "en", self.now)
            self.assertFalse(importer.pending)

    def test_http_reader_is_fixed_bounded_and_refuses_redirects(self):
        import email.message
        import json
        class Response:
            status = 200
            def __init__(self, body, length=None):
                self.body, self.bound = body, None
                self.headers = email.message.Message()
                self.headers["Content-Type"] = "application/json"
                if length:
                    self.headers["Content-Length"] = length
            def __enter__(self): return self
            def __exit__(self, *_): return None
            def geturl(self): return discussion.URLS["en"]
            def read(self, bound):
                self.bound = bound
                return self.body
        response = Response(json.dumps(self.payload()).encode())
        with patch.object(discussion.urllib.request, "build_opener") as opener:
            opener.return_value.open.return_value = response
            discussion.fetch_manifest("en")
            args = opener.return_value.open.call_args
            self.assertEqual(args.args[0].full_url, discussion.URLS["en"])
            self.assertEqual(args.args[0].get_method(), "GET")
            self.assertEqual(args.kwargs["timeout"], 8)
            self.assertEqual(response.bound, discussion.MAX_RESPONSE_BYTES + 1)
        for response in (Response(b"{}", "99999999"), Response(b'{"queue":[],"queue":[]}')):
            with patch.object(discussion.urllib.request, "build_opener") as opener:
                opener.return_value.open.return_value = response
                with self.assertRaises(discussion.DiscussionUnavailable):
                    discussion.fetch_manifest("en")
        with self.assertRaises(discussion.DiscussionUnavailable):
            discussion._NoRedirect().redirect_request(None, None, None, None, None, "http://127.0.0.1")


if __name__ == "__main__":
    unittest.main()

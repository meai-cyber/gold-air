"""Optional reader of already-published Gold Pulse discussion transcripts.

Only two fixed, public saved-programme manifests are fetched. This module never
requests inference/audio, submits a prompt, fetches source article URLs or reads
private state. The public publisher validates local LFM programme metadata at
scripts/pc-radio-store.mjs. Arabic duo projection omits its private writer ID;
we preserve that distinction rather than invent model provenance.

Use poll() in an owner thread; candidate(language, scheduled_start_seconds,
exclude_ids=())
rechecks freshness; consume(job) after successfully publishing its new audio.
Unavailable imported programmes never prevent independent news/market speech.
"""
from __future__ import annotations

from collections import deque
import copy
import hashlib
import ipaddress
import json
import math
import re
import threading
import time
import unicodedata
import urllib.parse
import urllib.request

URLS = {
    "en": "https://g.au7.workers.dev/api/news-live?channel=radio",
    "ar": "https://g.au7.workers.dev/api/news-live?channel=radio&voice=ar2",
}
PUBLIC_PAGE = "https://g.au7.workers.dev/?radio=1"
MAX_RESPONSE_BYTES = 512 * 1024
MAX_AGE_S = 15 * 60
POLL_SECONDS = 30
MAX_PENDING = 96
MAX_SEEN = 512
MAX_PROGRESS = MAX_PENDING
MAX_RETRY_EXCLUSIONS = 2048
MAX_WORDS = 45
ID = re.compile(r"^[a-f0-9]{32}$")
PRIVATE = re.compile(r"[<>]|https?://|file:|\b[a-z]:[\\/]|\\\\|\blocalhost\b|(?:\d{1,3}\.){3}\d{1,3}|[\w.+-]+@[\w.-]+\.[a-z]{2,}", re.I)


class DiscussionUnavailable(ValueError):
    pass


def _text(value, limit):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or PRIVATE.search(value):
        raise DiscussionUnavailable("Unsupported public programme text")
    if any(unicodedata.category(c) in {"Cc", "Cf"} for c in value):
        raise DiscussionUnavailable("Unsupported programme controls")
    return " ".join(value.split())


def _stamp(value):
    if type(value) is not int or not 0 < value < 10**13:
        raise DiscussionUnavailable("Invalid public programme clock")
    return value


def _now(value=None):
    value = time.time() if value is None else value
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise DiscussionUnavailable("Invalid receipt clock")
    return int(value * 1000)


def _url(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 4096 or re.search(r"[\s\x00-\x1f\x7f\\]", value):
        raise DiscussionUnavailable("Invalid public source URL")
    try:
        parsed = urllib.parse.urlsplit(value)
        host = parsed.hostname or ""
        if (parsed.scheme != "https" or parsed.username or parsed.password or parsed.port or "." not in host or
                len(host) > 253 or host.endswith((".local", ".internal", ".localhost", ".lan", ".home", ".corp", ".test", ".invalid")) or
                not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label, re.I) for label in host.split("."))):
            raise ValueError()
        try:
            ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            raise DiscussionUnavailable("Literal source addresses are unsupported")
        decoded = urllib.parse.unquote(urllib.parse.unquote(parsed.path + parsed.query + parsed.fragment))
        if re.search(r"[\x00-\x1f\x7f]|(?:\d{1,3}\.){3}\d{1,3}|[\w.+-]+@[\w.-]+\.[a-z]{2,}|\blocalhost\b|\b[a-z]:[\\/]|\\\\", decoded, re.I):
            raise ValueError()
        return value
    except (ValueError, TypeError):
        raise DiscussionUnavailable("Invalid public source URL") from None


def _sources(values, window_start, window_end):
    if not isinstance(values, list) or not 0 <= len(values) <= 120:
        raise DiscussionUnavailable("Grounded discussion sources required")
    result, seen = [], set()
    for source in values:
        if not isinstance(source, dict):
            raise DiscussionUnavailable("Invalid discussion source")
        url = _url(source.get("url"))
        if url in seen:
            continue
        published, received = _stamp(source.get("publishedAt")), _stamp(source.get("firstSeenAt"))
        if not window_start <= published <= received <= window_end:
            raise DiscussionUnavailable("Discussion source is outside its captured window")
        time_kind = source.get("timeKind", "published")
        if time_kind not in ("published", "feed", "indexed") or type(source.get("social", False)) is not bool:
            raise DiscussionUnavailable("Unsupported source provenance")
        result.append({"title": _text(source.get("title"), 2000), "source": _text(source.get("source"), 300),
            "url": url, "publishedAt": published, "firstSeenAt": received,
            "timeKind": time_kind, "social": source.get("social", False)})
        seen.add(url)
    return result


def _chunks(text):
    """Preserve whole sentences where possible; bound even a single long turn."""
    current = []
    for sentence in re.split(r"(?<=[.!?؟])\s+", text):
        words = sentence.split()
        while len(words) > MAX_WORDS:
            if current:
                yield " ".join(current)
                current = []
            yield " ".join(words[:MAX_WORDS])
            words = words[MAX_WORDS:]
        if len(current) + len(words) > MAX_WORDS:
            yield " ".join(current)
            current = []
        current.extend(words)
    if current:
        yield " ".join(current)


def parse_programme(value, language, received_ms, *, receipt=None):
    """Validate the actual public projection, not private producer-only fields."""
    if not isinstance(value, dict) or language not in URLS or value.get("kind") != "discussion" or not ID.fullmatch(value.get("id", "")):
        return []
    window_start, window_end = _stamp(value.get("windowStart")), _stamp(value.get("windowEnd"))
    generated = _stamp(value.get("generatedAt"))
    if (window_end - window_start != 600000 or value.get("plannedAt") != window_end or
            not window_end <= generated <= received_ms or not 0 <= received_ms - window_end <= MAX_AGE_S * 1000):
        return []
    mode = value.get("editorialMode")
    if language == "en":
        if (mode != "local-llm-discussion" or value.get("writerModel") != "lfm2.5-2.6b-local" or
                not ID.fullmatch(value.get("programmeId", "")) or value.get("programmePart") not in (1, 2, 3) or
                value.get("programmeParts") != 3 or generated - window_end > 300000 or
                "en" not in value.get("languages", [])):
            return []
        programme = {"id": value["programmeId"], "part": value["programmePart"], "parts": 3,
            "writerModel": value["writerModel"], "provenance": "publisher-validated-local-llm-discussion"}
        maximum_turns = 128
    else:
        if (mode != "arabic-mixed-discussion" or value.get("adaptationMode") != "abridged_source_translation" or
                value.get("primaryLanguage") != "ar2" or "ar2" not in value.get("languages", []) or
                value.get("chapterIndex") not in (1, 2, 3) or value.get("chapterCount") not in (1, 2, 3) or
                value["chapterIndex"] > value["chapterCount"] or generated - window_end > 600000):
            return []
        # Source programme ID is intentionally not projected for the Arabic duo.
        programme = {"id": value["id"], "part": value["chapterIndex"], "parts": value["chapterCount"],
            "adaptationMode": value["adaptationMode"], "provenance": "publisher-validated-arabic-duo"}
        maximum_turns = 20
    sources = _sources(value.get("sources"), window_start, window_end)
    # The publisher also produces explicitly conditional educational episodes
    # in quiet windows. They remain discussions, never fresh-news reports.
    # Its Arabic projection validates the source programme privately but does
    # not expose that English topic metadata; preserve the weaker provenance.
    if not sources:
        if language == 'en' and (value.get('discussionMode') != 'conditional_education' or
                not re.fullmatch(r'[a-z][a-z-]{0,63}', value.get('topicId', ''))):
            raise DiscussionUnavailable('Source-free episode lacks educational provenance')
        programme['sourceFree'] = True
        if language == 'en':
            programme['discussionMode'] = 'conditional_education'
            programme['topicId'] = value['topicId']
    title = _text(value.get("title"), 200)
    transcript = value.get("transcript")
    duration = value.get("durationSeconds")
    if (not isinstance(transcript, list) or not 1 <= len(transcript) <= maximum_turns or
            type(duration) not in (int, float) or not math.isfinite(duration) or not 1 <= duration <= 150):
        return []
    # This grouping identity orders Arabic chapters from the same captured
    # programme window; it is not an invented publisher programme ID.
    group = programme["id"] if language == "en" else hashlib.sha256(
        f"ar-window:{window_start}:{window_end}".encode()).hexdigest()[:32]
    programme.update(groupId=group, sourceSegmentId=value["id"], generatedAt=generated,
                     windowStart=window_start, windowEnd=window_end)
    result, previous = [], -1
    for index, turn in enumerate(transcript):
        if not isinstance(turn, dict):
            raise DiscussionUnavailable("Invalid discussion turn")
        role, kind, start = turn.get("role"), turn.get("kind"), turn.get("startSeconds")
        if (role not in ("anchor", "analyst", "skeptic") or type(start) not in (int, float) or
                not math.isfinite(start) or not previous <= start <= duration):
            raise DiscussionUnavailable("Invalid discussion turn clock")
        previous = start
        if kind not in ("interpretation", "observation", "transition", "forecast", "forecast_review"):
            raise DiscussionUnavailable("Unsupported discussion turn kind")
        text, speaker = _text(turn.get("text"), 2200), _text(turn.get("name"), 50)
        if language == "ar":
            if not re.search(r"[\u0621-\u064a]", text) or re.search(r"[A-Za-z]", text):
                raise DiscussionUnavailable("Arabic discussion language mismatch")
        elif any(c.isalpha() and "LATIN" not in unicodedata.name(c, "") for c in text):
            raise DiscussionUnavailable("English discussion language mismatch")
        # Even excluded bookends must validate before this DTO can establish
        # that an otherwise empty programme part has actually been received.
        if kind not in ("interpretation", "observation"):
            continue
        # A host's grounded observation/question supplies the context for the
        # subsequent answer. Source-free educational episodes may include a
        # question, but unsupported current observations remain excluded.
        if kind == "observation" and not sources and not (role == "anchor" and re.search(r"[?؟]", text)):
            continue
        for chunk_index, text in enumerate(_chunks(text)):
            if len(text) > 1000:
                raise DiscussionUnavailable("Discussion excerpt exceeds speech bound")
            identity = f"{language}:{value['id']}:{index}:{chunk_index}:{text}"
            result.append({"id": hashlib.sha256(identity.encode()).hexdigest()[:32], "kind": "discussion",
                "language": language, "title": f"{speaker} · {title}"[:200], "source": "Gold Pulse · " + speaker,
                "url": PUBLIC_PAGE, "publishedAt": window_end // 1000, "firstSeenAt": received_ms // 1000,
                "speechText": text, "speaker": speaker, "role": role, "programme": dict(programme),
                "sources": copy.deepcopy(sources), "turnKind": kind, "turnIndex": index, "chunkIndex": chunk_index,
                "note": "Conditional discussion from a saved public programme; source links are metadata-validated, not independent fact verification."})
    if receipt is not None:
        receipt.update(language=language, groupId=group, part=programme['part'], parts=programme['parts'],
            windowEnd=window_end, generatedAt=generated, sourceSegmentId=value['id'],
            empty=not result, lastPosition=(programme['part'], result[-1]['turnIndex'], result[-1]['chunkIndex']) if result else None,
            digest=hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest())
    return result


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        raise DiscussionUnavailable("Public programme redirects are unsupported")


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise DiscussionUnavailable("Ambiguous programme metadata")
        value[key] = item
    return value


def fetch_manifest(language):
    if language not in URLS:
        raise DiscussionUnavailable("Unsupported discussion language")
    request = urllib.request.Request(URLS[language], headers={"Accept": "application/json", "Accept-Encoding": "identity",
        "User-Agent": "Mozilla/5.0 (GoldPulseRadio saved public discussion reader)"})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    try:
        with opener.open(request, timeout=8) as response:
            if (response.status != 200 or response.geturl() != URLS[language] or
                    response.headers.get_content_type() != "application/json" or
                    response.headers.get("Content-Encoding", "identity") != "identity"):
                raise DiscussionUnavailable("Public programme unavailable")
            size = response.headers.get("Content-Length")
            if size is not None and (not size.isdecimal() or int(size) > MAX_RESPONSE_BYTES):
                raise DiscussionUnavailable("Public programme response limit")
            body = response.read(MAX_RESPONSE_BYTES + 1)
            if not body or len(body) > MAX_RESPONSE_BYTES:
                raise DiscussionUnavailable("Public programme response limit")
        return json.loads(body.decode("utf-8"), object_pairs_hook=_unique_object)
    except DiscussionUnavailable:
        raise
    except Exception:
        raise DiscussionUnavailable("Public discussions temporarily unavailable") from None


class DiscussionImporter:
    def __init__(self):
        self.lock = threading.RLock()
        self.pending = {}
        self.seen = deque(maxlen=MAX_SEEN)
        self.progress = {}
        self.parts = {}
        self.active = {}
        self.last_attempt = None
        self.errors = {}

    def ingest(self, payload, language, received_ms=None):
        received = _now() if received_ms is None else _stamp(received_ms)
        if (not isinstance(payload, dict) or not isinstance(payload.get("queue"), list) or len(payload["queue"]) > 12 or
                payload.get("status") == "unavailable" or payload.get("syntheticVoices") is not True or
                abs(_stamp(payload.get("serverTime")) - received) > 30000 or
                type(payload.get("staleAgeSeconds")) not in (int, float) or not 0 <= payload["staleAgeSeconds"] <= 45):
            raise DiscussionUnavailable("Public discussion manifest is stale or invalid")
        segments = [*payload["queue"], payload.get("nowPlaying")]
        parsed, ids = [], set()
        for segment in segments:
            if not isinstance(segment, dict) or not isinstance(segment.get("id"), str) or segment["id"] in ids:
                continue
            ids.add(segment.get("id"))
            try:
                receipt = {}
                jobs = parse_programme(segment, language, received, receipt=receipt)
                if receipt:
                    parsed.append((receipt, jobs))
            except (DiscussionUnavailable, ValueError, TypeError, KeyError):
                continue
        with self.lock:
            self._prune(received)
            before = set(self.pending)
            for receipt, jobs in parsed:
                key = receipt['language'], receipt['groupId']
                group = self.parts.setdefault(key, {'windowEnd': receipt['windowEnd'], 'parts': {}})
                known = group['parts'].get(receipt['part'])
                if known and known['digest'] != receipt['digest']:
                    # Saved parts are immutable. A revised/contradictory DTO
                    # cannot change a missing or unfinished part into empty.
                    continue
                group['parts'].setdefault(receipt['part'], receipt)
                for job in jobs:
                    progress = self.progress.get(key)
                    already_passed = progress is not None and self._position(job) <= progress['position']
                    if not already_passed and job["id"] not in self.seen and job["id"] not in self.pending:
                        self.pending[job["id"]] = job
            self._limit_pending()
            self.parts = dict(sorted(self.parts.items(), key=lambda item: item[1]['windowEnd'])[-MAX_PROGRESS:])
            self.errors.pop(language, None)
            return len(set(self.pending) - before)

    @staticmethod
    def _group(job):
        return job['language'], job['programme']['groupId']

    @staticmethod
    def _position(job):
        return job['programme']['part'], job['turnIndex'], job['chunkIndex']

    @staticmethod
    def _order(job):
        return (job["programme"]["windowEnd"], job["programme"]["groupId"],
                job["programme"]["part"], job["turnIndex"], job["chunkIndex"], job["id"])

    def _limit_pending(self):
        """Keep ordered whole turns, rather than the newest 96 loose chunks.

        A busy language cannot evict every turn from the other channel. Within
        each channel, retain the active programme and then oldest fresh topics.
        Unadmitted trailing turns may be readmitted by a later source poll.
        """
        languages = sorted({job['language'] for job in self.pending.values()})
        if not languages:
            return
        limit = MAX_PENDING // len(languages)
        keep = {}
        for language in languages:
            groups = {}
            for job in self.pending.values():
                if job['language'] == language:
                    groups.setdefault(self._group(job), []).append(job)
            ordered_groups = sorted(groups, key=lambda key: (
                key != self.active.get(language), min(self._order(job) for job in groups[key])))
            remaining = limit
            for key in ordered_groups:
                turns = {}
                for job in sorted(groups[key], key=self._order):
                    turns.setdefault((job['programme']['part'], job['turnIndex']), []).append(job)
                for turn in turns.values():
                    if len(turn) > remaining:
                        # Retain a contiguous programme prefix; never keep the
                        # end of this turn/topic after dropping its beginning.
                        remaining = 0
                        break
                    keep.update((job['id'], job) for job in turn)
                    remaining -= len(turn)
                if remaining == 0:
                    break
        self.pending = keep

    def _prune(self, now_ms):
        self.pending = {key: job for key, job in self.pending.items()
            if 0 <= now_ms - job["programme"]["windowEnd"] <= MAX_AGE_S * 1000 and
            job["programme"]["generatedAt"] <= now_ms and job["firstSeenAt"] * 1000 <= now_ms}
        self.progress = {key: value for key, value in self.progress.items()
            if 0 <= now_ms - value['windowEnd'] <= MAX_AGE_S * 1000}
        self.progress = dict(sorted(self.progress.items(), key=lambda item: item[1]['windowEnd'])[-MAX_PROGRESS:])
        self.parts = {key: value for key, value in self.parts.items()
            if 0 <= now_ms - value['windowEnd'] <= MAX_AGE_S * 1000}
        active_groups = {self._group(job) for job in self.pending.values()} | set(self.progress) | set(self.parts)
        self.active = {language: group for language, group in self.active.items() if group in active_groups}

    def _has_context(self, job):
        """Only actual missing/unconsumed context blocks the next saved part."""
        key = self._group(job)
        known = self.parts.get(key, {}).get('parts', {})
        progress = self.progress.get(key)
        for part in range(1, job['programme']['part']):
            receipt = known.get(part)
            if receipt is None:
                return False
            if receipt['empty']:
                continue
            if progress is None or progress['position'] < receipt['lastPosition']:
                return False
        return True

    def poll(self, now_s=None):
        now = _now(now_s)
        with self.lock:
            if self.last_attempt is not None and now - self.last_attempt < POLL_SECONDS * 1000:
                return 0
            self.last_attempt = now
        count = 0
        for language in URLS:
            try:
                count += self.ingest(fetch_manifest(language), language)
            except Exception:
                with self.lock:
                    self.errors[language] = "Optional saved discussions unavailable"
        return count

    def candidate(self, language, now_s=None, exclude_ids=()):
        if language not in URLS:
            raise ValueError("Unsupported discussion language")
        if (not isinstance(exclude_ids, (set, frozenset, list, tuple, dict)) or len(exclude_ids) > MAX_RETRY_EXCLUSIONS or
                any(not isinstance(identifier, str) or not ID.fullmatch(identifier) for identifier in exclude_ids)):
            raise ValueError('A bounded collection of discussion retry IDs is required')
        excluded = set(exclude_ids)
        now = _now(now_s)
        with self.lock:
            self._prune(now)
            groups = {}
            for job in sorted(self.pending.values(), key=self._order):
                if job["language"] == language and job["id"] not in self.seen:
                    groups.setdefault(self._group(job), job)
            candidates = [job for key, job in groups.items() if job['id'] not in excluded and self._has_context(job)]
            if not candidates:
                return None
            first = min(candidates, key=lambda job: (self._group(job) != self.active.get(language), self._order(job)))
            return copy.deepcopy(first)

    def consume(self, job):
        with self.lock:
            identifier = job.get("id") if isinstance(job, dict) else None
            if identifier not in self.pending:
                return False
            original = self.pending[identifier]
            key = self._group(original)
            first = min((row for row in self.pending.values() if self._group(row) == key), key=self._order)
            if first['id'] != identifier:
                return False
            self.pending.pop(identifier)
            self.seen.append(identifier)
            self.progress[key] = {'position': self._position(original), 'windowEnd': original['programme']['windowEnd']}
            self.progress = dict(sorted(self.progress.items(), key=lambda item: item[1]['windowEnd'])[-MAX_PROGRESS:])
            self.active[original['language']] = key
            return True

    def status(self, language):
        with self.lock:
            return {'enabled': True, 'pending': sum(job['language'] == language for job in self.pending.values()),
                'error': self.errors.get(language),
                'note': 'Optional finished public programmes depend on their source station; basic news and market briefs run here.'}

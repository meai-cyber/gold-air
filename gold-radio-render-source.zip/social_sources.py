"""Fixed, bounded public publisher social feeds for the cloud radio.

These are attributed public posts, not independently verified news. Bluesky
reads only five pinned worldwide publisher identities; public search/firehoses
are not used. Telegram parsing remains available for offline fixtures only;
no Telegram URL is authorized for collection.
Author-reported creation clocks are kept separate from receipt clocks.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import dataclass
from datetime import datetime
from email.utils import parsedate_to_datetime
import hashlib
from html.parser import HTMLParser
import json
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from source_policy import collection_url_allowed

MAX_BYTES = 1_048_576
MAX_AGE_S = 3600
POLL_S = 20
COLLECTION_BUDGET_S = 8
MAX_BATCH_SOURCES = 2


@dataclass(frozen=True)
class Source:
    key: str
    source: str
    platform: str
    actor: str
    language: str
    did: str = ''

    @property
    def url(self):
        if self.platform == 'Telegram':
            return 'https://t.me/s/' + self.actor
        return 'https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed?' + urllib.parse.urlencode({
            'actor': self.did, 'filter': 'posts_no_replies', 'limit': 30})


SOURCES = (
    Source('bsky-reuters', 'Reuters', 'Bluesky', 'reuters.com', 'en', 'did:plc:jbvnehrrdqoulco4rf5gxg5r'),
    Source('bsky-bloomberg', 'Bloomberg', 'Bluesky', 'bloomberg.com', 'en', 'did:plc:uewxgchsjy4kmtu7dcxa77us'),
    Source('bsky-cnbc', 'CNBC', 'Bluesky', 'cnbc.com', 'en', 'did:plc:m7ks2xhfuku7errrtfjux2lg'),
    Source('bsky-ap', 'The Associated Press', 'Bluesky', 'apnews.com', 'en', 'did:plc:a67zdrt4nl2tv2qojpngogbq'),
    Source('bsky-guardian', 'The Guardian', 'Bluesky', 'theguardian.com', 'en', 'did:plc:vovinwhtulbsx4mwfw26r5ni'),
)
ALLOWED_URLS = frozenset(s.url for s in SOURCES)


@dataclass(frozen=True)
class Response:
    status: int
    headers: dict
    body: bytes
    url: str


def _stamp(value):
    if not isinstance(value, str) or not re.fullmatch(
            r'20\d{2}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})', value):
        raise ValueError('Public post clock missing timezone')
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    return int(parsed.timestamp())


_URL = re.compile(r'(?:https?://|www\.)\S+|(?<!\w)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}/\S+', re.I)
_PROMO = re.compile(r'guaranteed.{0,20}(?:profit|return)|(?:join|contact|message).{0,25}(?:signals?|whatsapp|telegram|\bdm\b)|'
                    r'giveaway|promo\s*code|ربح\s*مضمون|أرباح\s*مضمونة|توصيات\s*مضمونة|راسلن[اي]|اشترك\s*الآن', re.I)


def clean_text(value):
    if not isinstance(value, str) or len(value) > 12_000:
        return ''
    value = _URL.sub('', value)
    value = re.sub(r'(?<!\w)@[\w.]+', '', value)
    value = value.replace('#', '').replace('_', ' ')
    value = ''.join(c for c in value if unicodedata.category(c) not in {'Cf', 'So', 'Sk'} and
                    (not unicodedata.category(c).startswith('C') or c in '\t\r\n'))
    value = re.sub(r'\s+', ' ', value).strip(' |:؛،-')
    # Do not invent a complete headline by cutting an unfinished claim.
    if len(value) > 400:
        ends = [m.end() for m in re.finditer(r'[.!؟?](?:\s|$)', value[:400])]
        value = value[:max(ends)].strip() if ends else ''
    return value


def _row(source, identity, text, stamp, received_s, summary=''):
    if not 0 <= received_s - stamp <= MAX_AGE_S:
        return None
    text = clean_text(text)
    if (len(text) < 20 or len(text.split()) < 3 or _PROMO.search(text) or
            sum(c.isalpha() for c in text) < 15):
        return None
    arabic = sum('\u0600' <= c <= '\u06ff' and c.isalpha() for c in text)
    latin = sum('a' <= c.lower() <= 'z' for c in text)
    if source.language == 'ar' and (arabic < 8 or arabic < latin) or source.language == 'en' and (latin < 12 or arabic > latin):
        return None
    # Identity is the original post, not a changing delivery/index timestamp.
    return {'id': hashlib.sha256(('social:' + identity).encode('utf-8')).hexdigest()[:32],
            'url': identity, 'title': text, 'summary': clean_text(summary),
            'source': source.source, 'language': source.language,
            'publishedAt': stamp, 'firstSeenAt': received_s,
            'social': True, 'sourceKind': 'social', 'platform': source.platform,
            'timeKind': 'published', 'clockBasis': 'author-reported',
            'verification': 'unverified-public-post'}


class _TelegramParser(HTMLParser):
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

    def __init__(self, actor):
        super().__init__(convert_charrefs=True)
        self.actor, self.depth, self.item, self.posts = actor, 0, None, []
        self.text_depth, self.hidden = None, 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = set(attrs.get('class', '').split())
        if tag == 'div':
            self.depth += 1
            if 'tgme_widget_message' in classes:
                identity = attrs.get('data-post', '')
                if re.fullmatch(re.escape(self.actor) + r'/[1-9]\d{0,14}', identity, re.I):
                    self.item = {'identity': identity, 'depth': self.depth, 'parts': [], 'date': None,
                                 'link': None, 'forwarded': False, 'edited': False}
                else:
                    self.item = None
            if self.item and 'tgme_widget_message_text' in classes:
                self.text_depth = self.depth
        if not self.item:
            return
        if tag in {'script', 'style', 'noscript'}:
            self.hidden += 1
        if 'tgme_widget_message_forwarded_from' in classes:
            self.item['forwarded'] = True
        if 'tgme_widget_message_updated' in classes or 'tgme_widget_message_edited' in classes:
            self.item['edited'] = True
        if tag == 'a' and 'tgme_widget_message_date' in classes:
            self.item['link'] = attrs.get('href')
        if tag == 'time':
            if self.item['date'] is not None:
                self.item['edited'] = True  # Ambiguous original/update clocks.
            self.item['date'] = attrs.get('datetime')
        if tag == 'br' and self.text_depth:
            self.item['parts'].append(' ')

    def handle_endtag(self, tag):
        if tag in {'script', 'style', 'noscript'} and self.hidden:
            self.hidden -= 1
        if tag == 'div':
            if self.text_depth == self.depth:
                self.text_depth = None
            if self.item and self.item['depth'] == self.depth:
                if len(self.posts) < 100:
                    self.posts.append(self.item)
                self.item, self.text_depth, self.hidden = None, None, 0
            self.depth = max(0, self.depth - 1)

    def handle_data(self, data):
        if self.item and self.text_depth and not self.hidden:
            self.item['parts'].append(data)


def parse_telegram(body, source, received_s):
    if not isinstance(body, bytes) or len(body) > MAX_BYTES or b'\x00' in body:
        raise ValueError('Public page body limit')
    parser = _TelegramParser(source.actor)
    parser.feed(body.decode('utf-8', errors='strict'))
    if not parser.posts:
        raise ValueError('Public channel preview has no matching posts')
    rows = []
    for item in parser.posts:
        identity = 'https://t.me/' + item['identity']
        if item['forwarded'] or item['edited'] or str(item['link']).lower() != identity.lower():
            continue
        try:
            row = _row(source, identity, ''.join(item['parts']), _stamp(item['date']), received_s)
            if row:
                rows.append(row)
        except (ValueError, TypeError, OverflowError):
            continue
    return rows


def parse_bluesky(body, source, received_s):
    if not isinstance(body, bytes) or len(body) > MAX_BYTES or b'\x00' in body:
        raise ValueError('Public feed body limit')
    data = json.loads(body.decode('utf-8', errors='strict'))
    if (not isinstance(data, dict) or not isinstance(data.get('feed'), list) or
            not 1 <= len(data['feed']) <= 100):
        raise ValueError('Public feed schema')
    rows = []
    for item in data['feed']:
        if not isinstance(item, dict) or item.get('reason') or item.get('reply'):
            continue
        post = item.get('post')
        if not isinstance(post, dict) or post.get('labels') or not isinstance(post.get('author'), dict):
            continue
        author, record = post['author'], post.get('record')
        if (author.get('did') != source.did or author.get('handle') != source.actor or
                not isinstance(record, dict) or record.get('$type') != 'app.bsky.feed.post' or record.get('reply')):
            continue
        uri = post.get('uri', '')
        match = re.fullmatch(re.escape('at://' + source.did + '/app.bsky.feed.post/') + r'([a-zA-Z0-9]{1,32})', uri)
        if not match:
            continue
        # Only the publisher's actual text is read. Quoted posts are not adopted.
        embed = record.get('embed', {})
        if not isinstance(embed, dict) or embed.get('$type') in {'app.bsky.embed.record', 'app.bsky.embed.recordWithMedia'}:
            continue
        external = embed.get('external', {}) if embed.get('$type') == 'app.bsky.embed.external' else {}
        if not isinstance(external, dict):
            external = {}
        text = record.get('text')
        if not clean_text(text):
            text = external.get('title', '')
        try:
            row = _row(source, 'https://bsky.app/profile/' + source.did + '/post/' + match[1],
                       text, _stamp(record.get('createdAt')), received_s, external.get('description', ''))
            if row:
                rows.append(row)
        except (ValueError, TypeError, OverflowError):
            continue
    return rows


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_):
        return None


def fetch_public(url, headers, timeout):
    if url not in ALLOWED_URLS or not collection_url_allowed(url):
        raise ValueError('Unsupported social source')
    safe_headers = {'User-Agent': 'PublicNewsReader/1.0', 'Accept': 'application/json',
                    'Accept-Encoding': 'identity'}
    etag = headers.get('If-None-Match') if isinstance(headers, dict) else None
    if isinstance(etag, str) and len(etag) <= 256 and not re.search(r'[\x00-\x1f\x7f]', etag):
        safe_headers['If-None-Match'] = etag
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    deadline = time.monotonic() + timeout
    try:
        response = opener.open(urllib.request.Request(url, headers=safe_headers), timeout=timeout)
    except urllib.error.HTTPError as error:
        return Response(error.code, dict(error.headers.items()), b'', url)
    with response:
        values = {k.lower(): v for k, v in response.headers.items()}
        size = values.get('content-length')
        if values.get('content-encoding', 'identity') != 'identity' or size and (not size.isdecimal() or int(size) > MAX_BYTES):
            raise ValueError('Public social body limit')
        parts, total = [], 0
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Public social collection deadline')
            socket = getattr(getattr(response.fp, 'raw', None), '_sock', None)
            if socket is not None:
                socket.settimeout(max(.1, deadline - time.monotonic()))
            chunk = response.read1(min(65_536, MAX_BYTES + 1 - total))
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_BYTES:
                raise ValueError('Public social body limit')
            parts.append(chunk)
        return Response(response.status, values, b''.join(parts), response.url)


def _next_delay(headers, now_s, failures=0, status=200):
    delay = POLL_S if status in (200, 304) else 3600 if status in (401, 403) else min(1800, POLL_S * 2 ** min(failures, 5))
    cache = re.search(r'(?:^|,)\s*max-age=(\d{1,8})\b', headers.get('cache-control', ''), re.I)
    if cache:
        delay = max(delay, min(86400, int(cache[1])))
    retry = headers.get('retry-after', '')
    try:
        retry_s = int(retry) if retry.isdecimal() else int(parsedate_to_datetime(retry).timestamp()) - now_s
        delay = max(delay, min(86400, max(0, retry_s)))
    except (ValueError, TypeError, OverflowError):
        pass
    return delay


class SocialCollector:
    def __init__(self, fetcher=None):
        self._fetcher = fetcher or fetch_public
        self._lock, self._collect_lock = threading.RLock(), threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='social-feed')
        self._pending, self._receipts = {}, {}
        self._states = {s.key: {'source': s.source, 'platform': s.platform, 'status': 'starting',
            'checkedAt': 0, 'lastSuccessAt': 0, 'nextCheckAt': 0, 'accepted': 0,
            'failures': 0, 'httpStatus': None, 'etag': None} for s in SOURCES}

    def status(self):
        with self._lock:
            sources = [{k: v for k, v in self._states[s.key].items() if k != 'etag'} for s in SOURCES]
            ready = sum(s['status'] == 'ready' for s in sources)
            return {'status': 'ready' if ready else 'starting' if any(s['status'] == 'starting' for s in sources) else 'unavailable',
                    'checkedAt': max(s['checkedAt'] for s in sources), 'sourceCount': len(SOURCES),
                    'readySources': ready, 'sources': sources, 'transport': 'Fixed public HTTPS; no login; no PC',
                    'verification': 'Attributed public social posts; not independently verified'}

    def _request(self, source, etag, deadline, now_s, real_clock=False):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Social collection budget exhausted')
        headers = {'User-Agent': 'PublicNewsReader/1.0', 'Accept-Encoding': 'identity',
                   'Accept': 'text/html' if source.platform == 'Telegram' else 'application/json'}
        if etag:
            headers['If-None-Match'] = etag
        response = self._fetcher(source.url, headers, min(COLLECTION_BUDGET_S, remaining))
        if (not isinstance(response, Response) or response.url != source.url or not isinstance(response.body, bytes) or
                len(response.body) > MAX_BYTES or time.monotonic() > deadline):
            raise ValueError('Invalid public social response')
        values = {k.lower(): v for k, v in response.headers.items()}
        rows = []
        if response.status == 200:
            expected = 'text/html' if source.platform == 'Telegram' else 'application/json'
            if expected not in values.get('content-type', '').lower():
                raise ValueError('Unexpected social content type')
            received_s = int(time.time()) if real_clock else now_s
            rows = (parse_telegram if source.platform == 'Telegram' else parse_bluesky)(response.body, source, received_s)
        elif response.status == 304 and not etag:
            raise ValueError('Uncached social source response')
        return response.status, values, rows

    def collect(self, now_s=None):
        real_clock = now_s is None
        now_s = int(time.time()) if now_s is None else now_s
        if type(now_s) is not int or now_s <= 0:
            raise ValueError('A valid collection clock is required')
        if not self._collect_lock.acquire(blocking=False):
            return []
        try:
            deadline, result = time.monotonic() + COLLECTION_BUDGET_S, []
            with self._lock:
                # Timed-out work is never submitted again until its bounded
                # request actually exits, keeping concurrency at two.
                self._pending = {k: f for k, f in self._pending.items() if not f.done()}
                # Admit only as many sources as there are worker slots. A slow
                # first source must not consume the budget of five queued ones.
                # Oldest due clocks win; the fixed order breaks initial ties.
                due = [s for s in SOURCES if s.key not in self._pending and now_s * 1000 >= self._states[s.key]['nextCheckAt']]
                due.sort(key=lambda s: self._states[s.key]['nextCheckAt'])
                due = due[:max(0, MAX_BATCH_SOURCES - len(self._pending))]
                futures = {}
                for source in due:
                    state = self._states[source.key]
                    state['checkedAt'] = now_s * 1000
                    future = self._pool.submit(self._request, source, state['etag'], deadline, now_s, real_clock)
                    self._pending[source.key] = future
                    futures[future] = source
            done, unfinished = wait(futures, timeout=max(0, deadline - time.monotonic()))
            finished_s = int(time.time()) if real_clock else now_s
            with self._lock:
                for future, source in futures.items():
                    state, status, headers = self._states[source.key], None, {}
                    try:
                        if future not in done:
                            future.cancel()
                            raise TimeoutError('Social collection deadline')
                        status, headers, rows = future.result()
                        if status not in (200, 304):
                            raise ValueError('Public social source unavailable')
                        etag = headers.get('etag')
                        if etag is not None and (len(etag) > 256 or re.search(r'[\x00-\x1f\x7f]', etag)):
                            raise ValueError('Invalid social cache validator')
                        state.update(status='ready', httpStatus=status, failures=0,
                                     accepted=len(rows) if status == 200 else state['accepted'],
                                     lastSuccessAt=finished_s * 1000,
                                     nextCheckAt=(finished_s + _next_delay(headers, finished_s)) * 1000)
                        if status == 200:
                            state['etag'] = etag
                        for row in rows:
                            old = self._receipts.get(row['id'])
                            if old:
                                if old[1] != row['publishedAt']:
                                    continue
                                row['firstSeenAt'] = old[0]
                            self._receipts[row['id']] = (row['firstSeenAt'], row['publishedAt'])
                            result.append(row)
                    except Exception:
                        failures = state['failures'] + 1
                        state.update(status='access_denied' if status in (401, 403) else 'rate_limited' if status == 429 else 'unavailable',
                                     httpStatus=status, failures=failures, accepted=0,
                                     nextCheckAt=(finished_s + _next_delay(headers, finished_s, failures, status)) * 1000)
                self._receipts = {k: v for k, v in self._receipts.items() if 0 <= finished_s - v[1] <= 86400}
                if len(self._receipts) > 6000:
                    self._receipts = dict(sorted(self._receipts.items(), key=lambda p: p[1][0], reverse=True)[:6000])
            return sorted(result, key=lambda row: (row['publishedAt'], row['id']), reverse=True)
        finally:
            self._collect_lock.release()

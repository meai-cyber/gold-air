import base64
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
import zlib
from unittest.mock import patch

import phonon_assets as assets


class PhononAssetTests(unittest.TestCase):
    def test_exact_approved_model_and_separate_runtime_assets(self):
        self.assertEqual(assets.MODEL_ID, 'gradium/phonon-40m-en')
        self.assertEqual(sum(size for size, _ in assets.FILES.values()), 75092305)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                assets.verify_assets(directory)

    def test_model_only_grant_is_hash_checked_and_does_not_require_account_token(self):
        payload = {name: ('fixture ' + name).encode() for name in assets.FILES}
        pins = {name: (len(data), hashlib.sha256(data).hexdigest()) for name, data in payload.items()}
        grant = {'model': assets.MODEL_ID, 'revision': assets.MODEL_REVISION,
                 'weightsUrl': 'https://us.aws.cdn.hf.co/pinned-test-only',
                 'smallFiles': {name: base64.b64encode(data).decode() for name, data in payload.items()
                                if name != 'model.q8.gguf'}}
        with tempfile.TemporaryDirectory() as directory, patch.object(assets, 'FILES', pins), \
                patch.dict(assets.os.environ, {}, clear=True), \
                patch('phonon_assets.urllib.request.urlopen', return_value=io.BytesIO(payload['model.q8.gguf'])) as fetch:
            root = Path(directory)
            wrapped = {'encoding': 'zlib-base64', 'data': base64.b64encode(zlib.compress(json.dumps(grant).encode())).decode()}
            wrapped['data'] = [wrapped['data'][i:i+1000] for i in range(0, len(wrapped['data']), 1000)]
            (root / 'grant.json').write_text(json.dumps(wrapped), 'utf-8')
            result = assets.build_from_grant(root / 'weights', root / 'grant.json')
            self.assertEqual(result['model'], assets.MODEL_ID)
            self.assertEqual((root / 'weights/tokenizer.json').read_bytes(), payload['tokenizer.json'])
            self.assertEqual(fetch.call_args.args, (grant['weightsUrl'],))
            (root / 'weights/config.json').write_bytes(b'corrupt')
            with self.assertRaises(ValueError):
                assets.verify_assets(root / 'weights')

    def test_wrong_model_or_host_cannot_request_a_download(self):
        with tempfile.TemporaryDirectory() as directory, patch('phonon_assets.urllib.request.urlopen') as fetch:
            path = Path(directory) / 'grant.json'
            for changes in ({'model': 'different-model'}, {'weightsUrl': 'http://127.0.0.1/private'}):
                grant = {'model': assets.MODEL_ID, 'revision': assets.MODEL_REVISION,
                         'weightsUrl': 'https://us.aws.cdn.hf.co/test', **changes}
                path.write_text(json.dumps(grant), 'utf-8')
                with self.assertRaises(ValueError):
                    assets.build_from_grant(Path(directory) / 'weights', path)
            fetch.assert_not_called()

"""Bounded public business commentary, never factual writer material.

The whole authored prose is screened. Only standalone link and hashtag footers
can be omitted, with typed disclosure; linked pages are never retrieved.
"""
from __future__ import annotations

from html.parser import HTMLParser
import re
import unicodedata
from urllib.parse import urlsplit

from news_selection import normalized_title
from social_feedback import _ABUSE, _CONTACT, _PERSONAL_FINANCE, _PROMO

POLICY_VERSION = 'mastodon-business-opinion-2026-10-25-v2'
PRESENTATION = 'complete-authored-prose-footer-links-omitted'
# A finite transport expansion; v2's whole-comment screening remains unchanged.
TAGS = ('gold', 'oil', 'inflation', 'economy', 'ai', 'technology', 'business', 'economics', 'markets',
        'finance', 'stocks', 'energy')
_DOMAIN = re.compile(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?')
_EXCLUDED = frozenset({'aljazeera.com', 'aljazeera.net', 'alarabiya.net', 'alhadath.net',
    'asharq.com', 'asharqnews.com', 'asharqbusiness.com', 'aawsat.com', 'arabnews.com',
    'skynewsarabia.com'})
_TOPIC = re.compile(r'(?<!\w)(?:gold|bullion|oil|crude|inflation|yields?|interest|rates?|dollar|'
    r'currenc\w*|bonds?|financ\w*|econom\w*|markets?|business|compan\w*|consum\w*|'
    r'products?|services?|subscription\w*|streaming|netflix|technology|technologies|software|'
    r'artificial intelligence|ai|automation|labor|labour|capital|banks?|banking|'
    r'ذهب|نفط|تضخم|فائدة|فوائد|عوائد|دولار|اقتصاد\w*|اسواق|شركات|شركة|'
    r'مستهلك\w*|برمجيات|تكنولوجيا|التكنولوجيا|الذكاء الاصطناعي|عمال|عمل|راس المال)(?!\w)', re.I)
_VIEW = re.compile(r'(?<!\w)(?:i (?:think|feel|wonder|prefer|wish|hope|like|love|dislike|find|want|worry)|'
    r'in my (?:view|opinion)|for me|to me|in the mind|ultimately|should|would|could|might|'
    r'needs?|deserves?|worth|uncertain\w*|better|worse|unfair|fairer|sensible|useful|'
    r'boring|interesting|awful|expensive|cheap|confusing|enjoy\w*|disappoint\w*|'
    r'برايي|اعتقد|اري|اتساءل|ينبغي|يحتاج|تحتاج|افضل|احب|اتمنى|ربما|قد)(?!\w)', re.I)
_QUESTION = re.compile(r'^(?:will|would|could|can|should|why|what|how|when|is|are|do|does|هل|لماذا|كيف|ماذا)\b', re.I)
_UNSAFE = re.compile(r'(?<!\w)(?:breaking|announc\w*|confirm\w*|report(?:s|ed|edly)?|according|'
    r'fraud\w*|corrupt\w*|scam\w*|criminal\w*|terrorist\w*|fascis\w*|rigged|stolen|stole|'
    r'steal\w*|bribes?|bribery|collud\w*|conspir\w*|manipulat\w*|false flag|'
    r'liars?|lies?|lied|cheat\w*|deceiv\w*|launder\w*|hack\w*|breach\w*|leak\w*|illegal\w*|'
    r'kill\w*|murder\w*|genocide|missiles?|bomb\w*|'
    r'rose|fell|surged|dropped|collapsed|rallied|jumped|soared|plunged|halted|'
    r'launched|released|acquired|bankrupt\w*|layoffs?|fired|sacked|'
    r'buy|sell|short|long position|leverage|target price|price target|'
    r'اعلن|اكد|صرح|يزعم|عاجل|مضمون|حتما|اشتر|اشتري|بيع|بع|توصية|توصيات|'
    r'فساد|فاسد|سرقة|يسرق|رشوة|مجرم|ارهابي|مؤامرة|مؤامرات|تلاعب|كاذب|كذب|احتيال|'
    r'قصف|مقتل|ابادة|ارتفع|انخفض|انهار)(?!\w)', re.I)
_FACT = re.compile(r'(?<!\w)(?:(?:has|have|had|is|are)\s+(?:just\s+|now\s+|already\s+)?\d+|'
    r'(?:rais\w*|increas\w*|reduc\w*|cut|cuts|cutting)\s+(?:its\s+|the\s+)?prices?|'
    r'\d+\s+(?:new\s+)?(?:subscribers?|customers?|employees?|jobs?|deaths?)|'
    r'(?:revenue|earnings|profits?|sales|shares?|stock)\s+(?:is|are|was|were|has|have)\s+'
    r'(?:now\s+)?(?:up|down|higher|lower))(?!\w)', re.I)
_CONTEXT = re.compile(r'(?<!\w)(?:re:|see (?:the |this )?(?:image|video|chart|link|thread)|'
    r'as (?:shown|pictured)|in this (?:video|image)|watch this|انظر الصورة|شاهد الفيديو)(?!\w)', re.I)


def public_url(value):
    if (not isinstance(value, str) or not 1 <= len(value) <= 2048 or '\\' in value or
            any(c.isspace() or ord(c) < 33 or ord(c) == 127 for c in value)):
        return None
    try:
        parsed = urlsplit(value)
        host = parsed.hostname
        if (parsed.scheme != 'https' or not host or parsed.username is not None or
                parsed.password is not None or parsed.port is not None or parsed.query or parsed.fragment or
                host != host.lower() or len(host) > 253 or '.' not in host or
                any(not _DOMAIN.fullmatch(label) for label in host.split('.')) or
                re.fullmatch(r'[0-9.]+', host) or
                any(host == root or host.endswith('.' + root) for root in _EXCLUDED)):
            return None
        return parsed
    except (ValueError, TypeError, UnicodeError):
        return None


class _Prose(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.valid, self.paragraph, self.anchor = True, None, None
        self.blocks, self.original = [], []
        self.links, self.tags = 0, 0

    def handle_starttag(self, tag, attrs):
        if tag not in {'p', 'br', 'span', 'a', 'strong', 'em', 'b', 'i', 's', 'del', 'u', 'code'}:
            self.valid = False
        if tag == 'p':
            if self.paragraph is not None:
                self.valid = False
            self.paragraph = []
        if tag == 'br':
            self.handle_data(' ')
        if tag == 'a':
            if self.anchor is not None:
                self.valid = False
            attrs = dict(attrs)
            href = attrs.get('href', '')
            parsed = public_url(href)
            # Query-bearing article links are never destinations. They may be
            # omitted only as a whole, standalone URL footer.
            if not parsed:
                try:
                    base = urlsplit(href)
                    parsed = public_url(base._replace(query='', fragment='').geturl())
                except (ValueError, TypeError):
                    parsed = None
            if parsed is None:
                self.valid = False
            hashtag = 'hashtag' in attrs.get('class', '').split()
            if hashtag and (parsed is None or not re.fullmatch(r'/tags/[A-Za-z0-9_]{1,80}', parsed.path)):
                self.valid = False
            self.anchor = {'kind': 'tag' if hashtag else 'link', 'text': ''}

    def handle_endtag(self, tag):
        if tag == 'a':
            if self.anchor is None:
                self.valid = False
                return
            if self.paragraph is None:
                self.valid = False
            else:
                self.paragraph.append((self.anchor['text'], self.anchor['kind']))
            self.anchor = None
        if tag == 'p':
            if self.paragraph is None or self.anchor is not None:
                self.valid = False
                return
            text = ''.join(part for part, _kind in self.paragraph).strip()
            self.original.append(text)
            meaningful = [(part.strip(), kind) for part, kind in self.paragraph if part.strip()]
            if meaningful and all(kind == 'tag' for _part, kind in meaningful):
                self.tags += len(meaningful)
            elif meaningful and all(kind in ('tag', 'link') for _part, kind in meaningful):
                links = [part for part, kind in meaningful if kind == 'link']
                if any(not re.match(r'^(?:https?://|www\.|[A-Za-z0-9.-]+\.[A-Za-z]{2,}/)', part) for part in links):
                    self.valid = False
                self.links += len(links)
                self.tags += sum(kind == 'tag' for _part, kind in meaningful)
            elif any(kind == 'link' for _part, kind in meaningful):
                # Inline prose links or a prose-bearing linked paragraph are
                # not silently removed or borrowed as unseen context.
                self.valid = False
            elif text:
                self.blocks.append(text)
            self.paragraph = None

    def handle_data(self, text):
        if self.anchor is not None:
            self.anchor['text'] += text
        elif self.paragraph is not None:
            self.paragraph.append((text, 'prose'))
        elif text.strip():
            self.valid = False


def extract_prose(raw):
    if not isinstance(raw, str) or not 1 <= len(raw) <= 16000 or '\x00' in raw:
        return None
    parser = _Prose()
    try:
        parser.feed(raw)
        parser.close()
    except (ValueError, TypeError):
        return None
    if not parser.valid or parser.paragraph is not None or parser.anchor is not None:
        return None
    return {'text': ' '.join(' '.join(parser.blocks).split()),
            'originalText': ' '.join(' '.join(parser.original).split()),
            'linksOmitted': parser.links, 'hashtagsOmitted': parser.tags}


def commentary_text(text):
    if (not isinstance(text, str) or not 20 <= len(text) <= 600 or text != text.strip() or
            not 4 <= len(text.split()) <= 90 or _CONTACT.search(text) or
            any(unicodedata.category(c).startswith('C') for c in text) or
            re.search(r'[<>@{}\\\[\]]', text) or text.endswith(('...', '\u2026'))):
        return ''
    folded = normalized_title(text)
    literal_folded = unicodedata.normalize('NFKC', text).casefold()
    if (not _TOPIC.search(folded) or _ABUSE.search(folded) or _PROMO.search(folded) or
            _PERSONAL_FINANCE.search(folded) or _UNSAFE.search(folded) or _FACT.search(folded) or
            _UNSAFE.search(literal_folded) or _CONTEXT.search(folded) or _CONTEXT.search(literal_folded)):
        return ''
    # An interpretive final clause cannot launder a news digest preceding it.
    # Each complete sentence needs a broad subjective/reflection/question cue;
    # no modal or first-person template is required for ordinary value judgements.
    sentences = [part.strip() for part in re.findall(r'.+?(?:[.!?؟]+["\u201d\u2019\')]*(?=\s|$)|$)', text)
                 if part.strip()]
    for sentence in sentences:
        question = bool(re.search(r'[?؟]["\u201d\u2019\')]*$', sentence) and _QUESTION.search(sentence))
        if not question and not _VIEW.search(normalized_title(sentence)):
            return ''
    return text if sentences else ''

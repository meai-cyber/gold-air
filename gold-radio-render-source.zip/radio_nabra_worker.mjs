// Private pinned CPU-WASM reader. stdin/stdout only; no listener or downloads.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { createInterface } from 'node:readline';
import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import dns from 'node:dns';

export const ENGINE_ID = 'nabra7m-fp16-wasm-local-v1';
export const SOURCE_REVISION = '16b5281ce61993df3526740990cf845a3f3036f4';
export const MODEL_REVISION = 'bbac0f1e6b001bfae89871be366a4b000180deb2';
export const ORT_VERSION = '1.30.0';
export const G2P_ENGINE_ID = 'nabra7m-g2p-only-local-v1';
const SAMPLE_RATE = 24000;
const STYLE_DIM = 256;
const MAX_PHONEMES = 510;
const MAX_AUDIO_SECONDS = 90;

export function validateText(text) {
  if (typeof text !== 'string' || !text.trim() || Array.from(text).length > 6000 ||
      /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(text) ||
      !/[\u0621-\u064a\u066e-\u06d3]/u.test(text) || /[<>%]|\p{Decimal_Number}/u.test(text)) {
    throw new Error('Invalid private Arabic pronunciation');
  }
  return text.trim().replace(/\s+/gu, ' ');
}

export function wordChunks(text, maxCharacters = 180) {
  const chunks = [];
  let current = '';
  for (const word of text.split(' ')) {
    if (Array.from(word).length > maxCharacters) throw new Error('An Arabic word exceeds the speech bound');
    const next = current ? current + ' ' + word : word;
    if (Array.from(next).length > maxCharacters && current) {
      chunks.push(current); current = word;
    } else current = next;
    // Arabic punctuation is a safe optional boundary, not a truncation point.
    if (/[.!?؟،؛]$/u.test(word) && Array.from(current).length >= 60) {
      chunks.push(current); current = '';
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

export async function prepareComplete(text, g2p) {
  const clean = validateText(text);
  const pending = wordChunks(clean);
  const chunks = [];
  while (pending.length) {
    const graphemes = pending.shift();
    const phonemes = await g2p.phonemize(graphemes);
    const count = Array.from(phonemes).length;
    if (!count) throw new Error('Empty Arabic phonemes');
    if (count > MAX_PHONEMES) {
      const words = graphemes.split(' ');
      if (words.length < 2) throw new Error('An Arabic word exceeds the phoneme bound');
      const split = Math.floor(words.length / 2);
      pending.unshift(words.slice(0, split).join(' '), words.slice(split).join(' '));
      continue;
    }
    const inputIds = g2p.tokenize(phonemes);
    // Upstream silently drops unknown phonemes. Fail closed on every such loss.
    if (inputIds.length !== count + 2 || inputIds[0] !== 0 || inputIds.at(-1) !== 0 ||
        inputIds.some(id => !Number.isInteger(id) || id < 0 || id >= 178)) {
      throw new Error('Unsupported Arabic phoneme');
    }
    chunks.push({ graphemes, phonemes, inputIds, styleIndex: count - 1 });
    if (chunks.length > 64) throw new Error('Too many Arabic speech chunks');
  }
  if (!chunks.length || chunks.map(chunk => chunk.graphemes).join(' ') !== clean) {
    throw new Error('Incomplete Arabic source coverage');
  }
  return chunks;
}

export function denyNetwork() {
  const deny = () => { throw new Error('Private Nabra synthesis has no network'); };
  globalThis.fetch = deny;
  http.request = http.get = https.request = https.get = deny;
  net.connect = net.createConnection = deny;
  net.Server.prototype.listen = deny;
  dns.lookup = dns.resolve = deny;
}

export async function main() {
  if (process.argv.length !== 5 || process.argv[2] !== '--runtime-dir' || process.argv[4] !== '--g2p-only') throw new Error('Invalid private worker arguments');
  const runtime = path.resolve(process.argv[3]);
  const manifest = JSON.parse(fs.readFileSync(path.join(runtime, 'manifest.json'), 'utf8').replace(/^\uFEFF/u, ''));
  if (manifest.sourceRevision !== SOURCE_REVISION || manifest.modelRevision !== MODEL_REVISION || manifest.ortVersion !== ORT_VERSION) throw new Error('Pin mismatch');
  const filename = path.join(runtime, 'g2p.mjs');
  if (fs.lstatSync(filename).isSymbolicLink() || createHash('sha256').update(fs.readFileSync(filename)).digest('hex') !== '8f00bba1b4b97eaa9342dc68cf6b11e2c926d714052c035228d10ad69ad93d0c') throw new Error('Changed G2P');
  denyNetwork();
  const g2p = await import(pathToFileURL(filename).href);
  await g2p.initEspeak();
  const say = row => process.stdout.write(JSON.stringify(row) + '\n');
  say({ready:true,engine:G2P_ENGINE_ID,voice:'Nabra MSA',language:'ar',modelRevision:MODEL_REVISION,sourceRevision:SOURCE_REVISION,device:'g2p',threads:1});
  const input = createInterface({input:process.stdin,terminal:false});
  for await (const line of input) {
    if (Buffer.byteLength(line,'utf8') > 18000) throw new Error('Oversized private IPC');
    try {
      const request = JSON.parse(line);
      if (request?.op === 'close' && Object.keys(request).length === 1) break;
      if (request?.op !== 'synthesize' || Object.keys(request).sort().join(',') !== 'op,text') throw new Error('Invalid request');
      const text = validateText(request.text);
      const chunks = await prepareComplete(text,g2p);
      say({ok:true,engine:G2P_ENGINE_ID,sourceRevision:SOURCE_REVISION,modelRevision:MODEL_REVISION,coveredCharacters:Array.from(text).length,chunks});
    } catch { say({ok:false,error:'Arabic pronunciation unavailable.'}); }
  }
  input.close();
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch(() => {process.stderr.write('Arabic pronunciation unavailable.\n');process.exitCode=1;});
}

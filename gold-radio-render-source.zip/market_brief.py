"""Read-only observed gold-price desk for the separate Render station.

Uses the same public Gold API reference as app/api/quote/route.ts. The provider
documents free current prices at https://gold-api.com/docs; this owner-started
desk polls no faster than once per 30 seconds. It never reads the TradingView
iframe, calls a model or creates a forecast. State is bounded and in memory.

Contract: MarketDesk.poll() -> bool; snapshot() -> public dict;
brief('ar'|'en') -> source-clocked station candidate or None when unavailable.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
import threading
import time
import urllib.error
import urllib.request

QUOTE_URL = "https://api.gold-api.com/price/XAU"
SOURCE_URL = "https://gold-api.com/"
POLL_SECONDS = 30
MAX_QUOTE_AGE_S = 90
MAX_RESPONSE_BYTES = 64 * 1024
MAX_HISTORY = 96
BASELINE_TOLERANCE_S = 45


class QuoteUnavailable(ValueError):
    """A safe public failure; contains no response body or private path."""


@dataclass(frozen=True)
class Quote:
    price: Decimal
    source_at: int
    received_at: int


def price_text(value: Decimal) -> str:
    """Keep every supplied fractional digit, with at least cents for speech."""
    text = format(value, "f")
    whole, dot, fraction = text.partition(".")
    fraction = fraction.rstrip("0").ljust(2, "0")
    return whole + "." + fraction


def _clock(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise QuoteUnavailable("Invalid receipt clock")
    return int(value)


def parse_quote(value, received_at=None):
    received = _clock(time.time() if received_at is None else received_at)
    if not isinstance(value, dict) or value.get("symbol") != "XAU" or value.get("currency", "USD") != "USD":
        raise QuoteUnavailable("Unexpected reference asset")
    raw = value.get("price")
    if isinstance(raw, bool) or not isinstance(raw, (int, float, Decimal)):
        raise QuoteUnavailable("Invalid reference price")
    try:
        price = Decimal(str(raw))
        if not price.is_finite() or not 0 < price < Decimal("1000000000") or price.as_tuple().exponent < -10:
            raise QuoteUnavailable("Invalid reference price")
    except (InvalidOperation, ValueError, OverflowError):
        raise QuoteUnavailable("Invalid reference price") from None
    raw_stamp = value.get("updatedAt")
    if not isinstance(raw_stamp, str) or not 1 <= len(raw_stamp) <= 64:
        raise QuoteUnavailable("Missing provider clock")
    try:
        stamp = datetime.fromisoformat(raw_stamp.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            raise ValueError()
        source_at = int(stamp.timestamp())
    except (ValueError, TypeError, OverflowError):
        raise QuoteUnavailable("Invalid provider clock") from None
    # A receipt timestamp never refreshes an old provider observation.
    if not 0 < source_at <= received or received - source_at > MAX_QUOTE_AGE_S:
        raise QuoteUnavailable("Reference quote is stale or ahead of receipt")
    return Quote(price, source_at, received)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        raise QuoteUnavailable("Reference redirects are unsupported")


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise QuoteUnavailable("Ambiguous reference response")
        result[key] = value
    return result


def fetch_quote():
    """Fixed HTTPS GET only; no caller URL, proxy, token or data submission."""
    request = urllib.request.Request(QUOTE_URL, headers={
        "Accept": "application/json", "Accept-Encoding": "identity",
        "User-Agent": "GoldPulseRadio/1.0 (+public reference quote)",
    })
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    try:
        with opener.open(request, timeout=8) as response:
            if (response.status != 200 or response.geturl() != QUOTE_URL or
                    response.headers.get_content_type() != "application/json" or
                    response.headers.get("Content-Encoding", "identity") != "identity"):
                raise QuoteUnavailable("Reference unavailable")
            size = response.headers.get("Content-Length")
            if size is not None and (not size.isdecimal() or int(size) > MAX_RESPONSE_BYTES):
                raise QuoteUnavailable("Reference response exceeded its limit")
            body = response.read(MAX_RESPONSE_BYTES + 1)
            if not body or len(body) > MAX_RESPONSE_BYTES:
                raise QuoteUnavailable("Reference response exceeded its limit")
        value = json.loads(body.decode("utf-8"), parse_float=Decimal, object_pairs_hook=_object,
                           parse_constant=lambda _value: (_ for _ in ()).throw(QuoteUnavailable("Invalid numeric response")))
        return parse_quote(value)
    except QuoteUnavailable:
        raise
    except Exception:
        raise QuoteUnavailable("Reference temporarily unavailable") from None


class MarketDesk:
    def __init__(self):
        self.lock = threading.RLock()
        self.history = deque(maxlen=MAX_HISTORY)
        self.last_attempt = None
        self.error = None

    def observe(self, quote):
        if not isinstance(quote, Quote):
            raise QuoteUnavailable("Validated reference quote required")
        # Validate direct fixture/input observations too, not only HTTP values.
        quote = parse_quote({"symbol": "XAU", "price": quote.price,
            "updatedAt": datetime.fromtimestamp(quote.source_at, timezone.utc).isoformat()}, quote.received_at)
        with self.lock:
            if self.history and quote.received_at < self.history[-1].received_at:
                raise QuoteUnavailable("Receipt clock moved backwards")
            if self.history and quote.source_at < self.history[-1].source_at:
                raise QuoteUnavailable("Provider clock moved backwards")
            if self.history and quote.source_at == self.history[-1].source_at:
                if quote.price != self.history[-1].price:
                    raise QuoteUnavailable("Provider revised the same observation clock")
                # Preserve first receipt; repeated HTTP checks are not new data.
                self.error = None
                return False
            self.history.append(quote)
            self.error = None
            return True

    def poll(self, now_s=None):
        now = _clock(time.time() if now_s is None else now_s)
        with self.lock:
            if self.last_attempt is not None and now - self.last_attempt < POLL_SECONDS:
                return False
            self.last_attempt = now
        try:
            return self.observe(fetch_quote())
        except QuoteUnavailable:
            with self.lock:
                self.error = "Reference temporarily unavailable"
            raise

    def snapshot(self, now_s=None):
        now = _clock(time.time() if now_s is None else now_s)
        with self.lock:
            if not self.history:
                return {"status": "unavailable", "provider": "Gold API", "changes": {}}
            current = self.history[-1]
            if not 0 <= now - current.source_at <= MAX_QUOTE_AGE_S:
                return {"status": "stale", "provider": "Gold API", "sourceAt": current.source_at * 1000,
                        "changes": {}}
            changes = {}
            for minutes in (1, 5, 10):
                target = current.source_at - minutes * 60
                before = next((row for row in reversed(self.history) if row.source_at <= target), None)
                if before is None or target - before.source_at > BASELINE_TOLERANCE_S:
                    continue
                delta = current.price - before.price
                changes[str(minutes)] = {"usd": float(delta), "usdText": price_text(abs(delta)),
                    "direction": "up" if delta > 0 else "down" if delta < 0 else "unchanged",
                    "fromAt": before.source_at * 1000, "toAt": current.source_at * 1000,
                    "seconds": current.source_at - before.source_at}
            recent = [row for row in self.history if current.source_at - 300 <= row.source_at <= current.source_at]
            observed_range = None
            if len(recent) >= 2 and current.source_at - recent[0].source_at >= 60:
                low, high = min(row.price for row in recent), max(row.price for row in recent)
                observed_range = {"low": float(low), "high": float(high), "lowText": price_text(low),
                    "highText": price_text(high), "fromAt": recent[0].source_at * 1000,
                    "toAt": current.source_at * 1000, "sampleCount": len(recent)}
            return {"status": "ready", "provider": "Gold API", "asset": "XAU", "currency": "USD",
                "price": float(current.price), "priceText": price_text(current.price),
                "sourceAt": current.source_at * 1000, "receivedAt": current.received_at * 1000,
                "ageSeconds": now - current.source_at, "changes": changes, "observedRange": observed_range,
                "note": "Observed Gold API reference samples, separate from TradingView/OANDA. No prediction."}

    def brief(self, language, now_s=None):
        if language not in ("ar", "en"):
            raise ValueError("Unsupported broadcast language")
        market = self.snapshot(now_s)
        if market["status"] != "ready":
            return None
        quote_time = datetime.fromtimestamp(market["sourceAt"] / 1000, timezone.utc).strftime("%H:%M")
        # Spoken prices are explicitly approximate cents; retain exact provider
        # precision in market.priceText. Six fractional digits make radio slow.
        price = format(Decimal(market["priceText"]).quantize(Decimal(".01")), ".2f")
        if language == "ar":
            lines = [f"الذهب الساعة {quote_time} بالتوقيت العالمي، حوالي {price} دولاراً للأونصة، بحسب المصدر المرجعي."]
            periods = {"1": "دقيقة", "5": "خمس دقائق", "10": "عشر دقائق"}
            for horizon, change in market["changes"].items():
                action = "ارتفع" if change["direction"] == "up" else "انخفض"
                lines.append(f"خلال نحو {periods[horizon]}، " + ("لم يتغير السعر." if change["direction"] == "unchanged"
                    else f"{action} نحو {Decimal(change['usdText']):.2f} دولار."))
            title = f"حركة الذهب المرصودة · {price} دولار للأونصة"
        else:
            lines = [f"Gold API reference at {quote_time} UTC: approximately {price} US dollars per troy ounce."]
            for horizon, change in market["changes"].items():
                period = "one minute" if horizon == "1" else horizon + " minutes"
                lines.append(f"About {period}: " + ("unchanged." if change["direction"] == "unchanged"
                    else f"{change['direction']} about {Decimal(change['usdText']):.2f} dollars."))
            title = f"Observed gold movement · ${price} per ounce"
        fingerprint = json.dumps({"language": language, "market": {k: v for k, v in market.items()
            if k not in ("ageSeconds", "receivedAt")}}, sort_keys=True, ensure_ascii=False)
        return {"id": hashlib.sha256(fingerprint.encode()).hexdigest()[:32], "kind": "market", "language": language,
            "title": title, "source": "Gold API", "url": SOURCE_URL, "publishedAt": market["sourceAt"] // 1000,
            "firstSeenAt": market["receivedAt"] // 1000, "speechText": " ".join(lines), "market": market}

"""Small immutable radio downloads; PCM remains the complete-speech evidence.

Only the producer and image builder can encode audio. No listener-controlled
paths, URLs, codec options or synthesis endpoint are accepted here.
"""
from dataclasses import dataclass
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import wave

SPEECH_BITRATE = 48_000
MUSIC_BITRATE = 96_000
MAX_PCM_BYTES = 8 * 1024 * 1024


@dataclass(frozen=True)
class DeliveryAudio:
    data: bytes
    extension: str
    content_type: str


class SpeechEncoder:
    def __init__(self, binary=None):
        self.binary = str(binary) if binary else shutil.which('ffmpeg')
        self.failures = 0
        self.retry_at = 0

    def encode(self, pcm):
        # The station already validates actual PCM speech and its full duration.
        # A codec failure must not suppress a complete news bulletin.
        if self.binary and time.monotonic() >= self.retry_at:
            try:
                return DeliveryAudio(self._mp3(pcm), 'mp3', 'audio/mpeg')
            except (OSError, ValueError, subprocess.SubprocessError, wave.Error):
                self.failures += 1
                self.retry_at = time.monotonic() + 120
        return DeliveryAudio(pcm, 'wav', 'audio/wav')

    def _mp3(self, pcm):
        if not isinstance(pcm, bytes) or not 44 < len(pcm) <= MAX_PCM_BYTES:
            raise ValueError('Invalid PCM delivery input')
        with wave.open(io.BytesIO(pcm), 'rb') as source:
            if (source.getnchannels(), source.getsampwidth(), source.getframerate()) != (1, 2, 24000):
                raise ValueError('Invalid PCM delivery format')
            frames = source.getnframes()
            if not 0 < frames <= 90 * 24000:
                raise ValueError('Invalid PCM delivery duration')
        with tempfile.TemporaryDirectory(prefix='radio-codec-') as directory:
            output = Path(directory) / 'speech.mp3'
            # A seekable file, rather than an MP3 pipe, preserves the encoder
            # delay/padding header so the complete clip keeps the PCM clock.
            subprocess.run([self.binary, '-hide_banner', '-loglevel', 'error', '-nostdin',
                '-protocol_whitelist', 'pipe', '-f', 'wav', '-i', 'pipe:0', '-map_metadata', '-1',
                '-vn', '-threads', '1', '-ac', '1', '-ar', '24000', '-c:a', 'libmp3lame',
                '-b:a', str(SPEECH_BITRATE), '-write_xing', '1', str(output)],
                input=pcm, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15, check=True)
            if not 0 < output.stat().st_size <= frames / 24000 * SPEECH_BITRATE / 8 + 32768:
                raise ValueError('Oversized compressed speech')
            decoded = subprocess.run([self.binary, '-hide_banner', '-loglevel', 'error', '-nostdin',
                '-protocol_whitelist', 'file,pipe', '-i', str(output), '-vn', '-threads', '1',
                '-t', '90.05', '-ac', '1', '-ar', '24000', '-f', 's16le', 'pipe:1'],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=15, check=True).stdout
            # LAME can retain at most a tiny sub-2ms tail on some sample
            # counts. Never accept missing source frames or a whole extra frame.
            if len(decoded) % 2 or not frames <= len(decoded) // 2 <= frames + 47 or not any(decoded):
                raise ValueError('Compressed speech changed the complete audio clock')
            return output.read_bytes()

    def status(self):
        return {'preferredFormat': 'mp3', 'speechBitrate': SPEECH_BITRATE,
                'encoderAvailable': bool(self.binary), 'encodingFailures': self.failures,
                'retryAfterSeconds': max(0, round(self.retry_at - time.monotonic())),
                'fallbackFormat': 'wav', 'pcmEvidenceRetained': True}


def build_music(root):
    """Transcode already hash-verified fixed CC0 assets once at image build."""
    from licensed_music import MusicLibrary
    from station_music import MUSIC_FILE, MUSIC_SECONDS
    root = Path(root)
    binary = shutil.which('ffmpeg')
    if not binary:
        raise ValueError('The image builder requires ffmpeg')
    library = MusicLibrary(root)
    directory = root / 'music-delivery'
    if directory.is_symlink():
        raise ValueError('Music delivery aliases are unsupported')
    directory.mkdir(exist_ok=True)
    rows = {}
    inputs = [(t.id, library.asset(t.id), t.duration_s, t.sha256) for t in library.tracks]
    bed = root / MUSIC_FILE
    if bed.is_file() and not bed.is_symlink():
        inputs.append(('station-relax-v2', bed, MUSIC_SECONDS, hashlib.sha256(bed.read_bytes()).hexdigest()))
    for identifier, source, duration, source_hash in inputs:
        if not 0 < duration <= 1800 or source is None:
            raise ValueError('Invalid fixed music recording')
        output = directory / (identifier + '.mp3')
        if output.is_symlink():
            raise ValueError('Music delivery aliases are unsupported')
        subprocess.run([binary, '-hide_banner', '-loglevel', 'error', '-nostdin', '-y',
            '-protocol_whitelist', 'file,pipe', '-i', str(source), '-map_metadata', '-1',
            '-vn', '-threads', '1', '-ac', '2', '-ar', '32000', '-c:a', 'libmp3lame',
            '-b:a', str(MUSIC_BITRATE), '-write_xing', '1', str(output)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120, check=True)
        if not 0 < output.stat().st_size <= duration * MUSIC_BITRATE / 8 + 32768:
            raise ValueError('Oversized music delivery asset')
        # Decode to a null sink and inspect its final sample clock without
        # retaining a whole song's PCM in the free instance's memory.
        check = subprocess.run([binary, '-hide_banner', '-loglevel', 'error', '-nostdin',
            '-protocol_whitelist', 'file,pipe', '-i', str(output), '-vn', '-threads', '1',
            '-progress', 'pipe:1', '-f', 'null', '-'],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=120, check=True).stdout.decode('ascii')
        clocks = [int(line.split('=', 1)[1]) for line in check.splitlines() if line.startswith('out_time_us=')]
        if not clocks or abs(clocks[-1] / 1e6 - duration) > .15:
            raise ValueError('Music delivery changed the shared song clock')
        rows[identifier] = {'bytes': output.stat().st_size, 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                            'sourceSha256': source_hash, 'durationSeconds': duration, 'bitrate': MUSIC_BITRATE}
        output.chmod(0o644)
    index = directory / 'index.json'
    if index.is_symlink():
        raise ValueError('Music delivery aliases are unsupported')
    index.write_text(json.dumps(rows, sort_keys=True), 'utf-8')
    index.chmod(0o644)


def music_assets(root):
    """Verify the bounded build artifact; never request music at runtime."""
    from licensed_music import TRACKS
    from station_music import MUSIC_SECONDS
    directory = Path(root) / 'music-delivery'
    index = directory / 'index.json'
    try:
        if directory.is_symlink() or index.is_symlink() or index.stat().st_size > 16384:
            return {}
        rows = json.loads(index.read_text('utf-8'))
        known = {t.id: (t.sha256, t.duration_s) for t in TRACKS}
        known['station-relax-v2'] = (None, MUSIC_SECONDS)
        assets = {}
        for identifier, (source_hash, duration) in known.items():
            row = rows.get(identifier, {})
            path = directory / (identifier + '.mp3')
            if (row.get('sourceSha256') != source_hash and source_hash is not None or
                    row.get('durationSeconds') != duration or row.get('bitrate') != MUSIC_BITRATE or
                    type(row.get('bytes')) is not int or not 0 < row['bytes'] <= duration * MUSIC_BITRATE / 8 + 32768 or
                    path.is_symlink() or not path.is_file() or path.stat().st_size != row['bytes']):
                continue
            if hashlib.sha256(path.read_bytes()).hexdigest() == row.get('sha256'):
                assets[identifier] = (path, row['bytes'])
        return assets
    except (OSError, ValueError, TypeError, AttributeError):
        return {}


if __name__ == '__main__':
    import os
    build_music(os.environ.get('RADIO_MODEL_DIR', '/opt/gold-radio-assets'))

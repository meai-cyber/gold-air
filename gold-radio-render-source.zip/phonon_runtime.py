"""Private, resident, CPU-only Phonon English worker; no HTTP interface.

Only the server chooses the local, hash-pinned 40M asset directory. Public feed
text cannot choose a model, file, URL or voice. The native extension is imported
in an expendable subprocess so a stalled decoder can be killed before fallback.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
import io
import json
import math
import os
from pathlib import Path
import queue
import re
import secrets
import subprocess
import sys
import threading
import time
import unicodedata
import wave

SAMPLE_RATE = 24000
MAX_FRAMES = SAMPLE_RATE * 90
MAX_WAV_BYTES = 8 * 1024 * 1024
MAX_LINE_BYTES = ((MAX_FRAMES * 2 + 44 + 2) // 3) * 4 + 2048
MAX_REQUEST_BYTES = 8192
MAX_TIMEOUT_S = 45.0
RUNTIME_VERSION = "0.4.1"
_HEX_ID = re.compile(r"^[a-f0-9]{32}$")
_ERROR = "Local English speech is unavailable"


def container_memory():
    """Aggregate container bytes, without host identifiers or private paths."""
    try:
        current = int(Path('/sys/fs/cgroup/memory.current').read_text('ascii').strip())
        limit = int(Path('/sys/fs/cgroup/memory.max').read_text('ascii').strip())
        return (current, limit) if 0 < current < limit < 16 * 1024 ** 3 else None
    except (OSError, ValueError):
        return None


class PhononUnavailable(RuntimeError):
    """Sanitized failure, suitable for the server's existing fallback path."""
    def __init__(self, message=_ERROR, reason='native-error'):
        super().__init__(message)
        allowed = {'native-error', 'memory-start', 'memory-pressure', 'timeout',
                   'worker-failed', 'initialization', 'generation'}
        self.reason = reason if reason in allowed else 'native-error'


@dataclass(frozen=True)
class PhononSpeech:
    wav: bytes
    duration_s: float
    inference_s: float
    first_chunk_s: float


def _text(value):
    # Validate, but do not rewrite or trim the server's complete bulletin.
    if not isinstance(value, str) or not 1 <= len(value) <= 1200 or not value.strip():
        raise PhononUnavailable(_ERROR)
    if any((unicodedata.category(c) in {"Cc", "Cf"} and c not in "\r\n\t") or
           (c.isalpha() and "LATIN" not in unicodedata.name(c, "")) for c in value):
        raise PhononUnavailable(_ERROR)
    return value


def _number(value):
    return type(value) in (int, float) and math.isfinite(value)


def _collect_stream(model, text):
    """Consume the complete stream or fail the entire item; never truncate."""
    import numpy as np

    started = time.perf_counter()
    first = None
    frames = 0
    pcm = bytearray()
    nonzero = False
    if model.sample_rate != SAMPLE_RATE:
        raise PhononUnavailable(_ERROR)
    with model.stream(_text(text), voice="default") as stream:
        if stream.sample_rate != SAMPLE_RATE:
            raise PhononUnavailable(_ERROR)
        for chunk in stream:
            values = np.asarray(chunk)
            if values.ndim != 1 or values.dtype != np.float32 or not np.isfinite(values).all():
                raise PhononUnavailable(_ERROR)
            if not values.size:
                continue
            if first is None:
                first = time.perf_counter() - started
            frames += values.size
            if frames > MAX_FRAMES:
                raise PhononUnavailable(_ERROR)
            samples = (np.clip(values, -1, 1) * 32767).astype("<i2")
            nonzero = nonzero or bool(np.any(samples))
            pcm.extend(samples.tobytes())
    inference = time.perf_counter() - started
    if not frames or not nonzero or first is None:
        raise PhononUnavailable(_ERROR)
    out = io.BytesIO()
    with wave.open(out, "wb") as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(SAMPLE_RATE)
        audio.writeframes(pcm)
    data = out.getvalue()
    if len(data) > MAX_WAV_BYTES:
        raise PhononUnavailable(_ERROR)
    return PhononSpeech(data, frames / SAMPLE_RATE, inference, first)


def _load_model(model_dir):
    # Pin checks happen before importing native code or loading any checkpoint.
    from phonon_assets import verify_assets
    verify_assets(model_dir)
    import ptts
    if ptts.__version__ != RUNTIME_VERSION:
        raise PhononUnavailable(_ERROR)
    ptts.set_num_threads(1)
    model = ptts.TTS(str(model_dir), lang="en", device="cpu", quant="q8", voice="default")
    if model.sample_rate != SAMPLE_RATE or model.device != "cpu" or model.quant not in {"q8", "q8_0"}:
        raise PhononUnavailable(_ERROR)
    return model


def _json_object(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Ambiguous response")
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=unique,
                      parse_constant=lambda _value: (_ for _ in ()).throw(ValueError("Invalid number")))


def _worker(model_dir):
    model = None
    nonce = None
    while True:
        raw = sys.stdin.buffer.readline(MAX_REQUEST_BYTES + 1)
        if not raw:
            return
        if len(raw) > MAX_REQUEST_BYTES or not raw.endswith(b"\n"):
            return
        request_id = None
        try:
            value = _json_object(raw)
            if not isinstance(value, dict) or set(value) != {"nonce", "requestId", "text"}:
                return
            incoming = value["nonce"]
            request_id = value["requestId"]
            if not isinstance(incoming, str) or not _HEX_ID.fullmatch(incoming):
                return
            if not isinstance(request_id, str) or not _HEX_ID.fullmatch(request_id):
                return
            if nonce is None:
                nonce = incoming
            if incoming != nonce:
                return
            text = _text(value["text"])
            if model is None:
                model = _load_model(model_dir)
            speech = _collect_stream(model, text)
            response = {"nonce": nonce, "requestId": request_id,
                        "wavBase64": base64.b64encode(speech.wav).decode("ascii"),
                        "durationSeconds": speech.duration_s, "inferenceSeconds": speech.inference_s,
                        "firstChunkSeconds": speech.first_chunk_s}
        except Exception:
            response = {"nonce": nonce, "requestId": request_id, "error": _ERROR,
                        "reason": 'initialization' if model is None else 'generation'}
            sys.stdout.write(json.dumps(response, separators=(",", ":")) + "\n")
            sys.stdout.flush()
            return
        sys.stdout.write(json.dumps(response, separators=(",", ":")) + "\n")
        sys.stdout.flush()


def _pump_stdout(pipe, replies):
    try:
        while True:
            line = pipe.readline(MAX_LINE_BYTES + 1)
            if not line or len(line) > MAX_LINE_BYTES or not line.endswith(b"\n"):
                replies.put_nowait(None)
                return
            replies.put_nowait(line)
    except Exception:
        try:
            replies.put_nowait(None)
        except queue.Full:
            pass


def _decode_response(raw, nonce, request_id):
    if not isinstance(raw, bytes) or not 0 < len(raw) <= MAX_LINE_BYTES:
        raise PhononUnavailable(_ERROR, 'worker-failed')
    value = _json_object(raw)
    if (isinstance(value, dict) and value.get('nonce') == nonce and value.get('requestId') == request_id
            and set(value) == {'nonce', 'requestId', 'error', 'reason'}):
        raise PhononUnavailable(_ERROR, value.get('reason'))
    if (not isinstance(value, dict) or value.get("nonce") != nonce or value.get("requestId") != request_id
            or set(value) != {"nonce", "requestId", "wavBase64", "durationSeconds", "inferenceSeconds", "firstChunkSeconds"}):
        raise PhononUnavailable(_ERROR)
    duration, inference, first = (value[k] for k in ("durationSeconds", "inferenceSeconds", "firstChunkSeconds"))
    if not all(_number(v) for v in (duration, inference, first)) or not 0 < duration <= 90 or not 0 <= first <= inference <= MAX_TIMEOUT_S:
        raise PhononUnavailable(_ERROR)
    encoded = value["wavBase64"]
    if not isinstance(encoded, str) or len(encoded) > (MAX_WAV_BYTES + 2) // 3 * 4:
        raise PhononUnavailable(_ERROR)
    data = base64.b64decode(encoded, validate=True)
    if not 44 < len(data) <= MAX_WAV_BYTES:
        raise PhononUnavailable(_ERROR)
    with wave.open(io.BytesIO(data), "rb") as audio:
        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate(), audio.getcomptype()) != (1, 2, SAMPLE_RATE, "NONE"):
            raise PhononUnavailable(_ERROR)
        declared = audio.getnframes()
        pcm = audio.readframes(MAX_FRAMES + 1)
    frames = len(pcm) // 2
    if len(pcm) % 2 or not 0 < frames <= MAX_FRAMES or frames != declared or not any(pcm) or abs(duration - frames / SAMPLE_RATE) > 1 / SAMPLE_RATE:
        raise PhononUnavailable(_ERROR)
    return PhononSpeech(data, frames / SAMPLE_RATE, float(inference), float(first))


class PhononEnglishTts:
    """Serialized, resident adapter owned by ServerTts; call close on shutdown."""
    def __init__(self, model_dir, *, timeout=MAX_TIMEOUT_S):
        if not isinstance(model_dir, (str, os.PathLike)) or "://" in str(model_dir):
            raise PhononUnavailable(_ERROR)
        if not _number(timeout) or not 0 < timeout <= MAX_TIMEOUT_S:
            raise PhononUnavailable(_ERROR)
        self.model_dir = Path(model_dir).resolve()
        self.timeout = float(timeout)
        self.lock = threading.Lock()
        self.process = None
        self.replies = None
        self.nonce = None

    def _start(self):
        if self.process is not None and self.process.poll() is None:
            return
        self._stop()
        budget = container_memory()
        if budget and budget[1] - budget[0] < 256 * 1024 ** 2:
            raise PhononUnavailable(_ERROR, 'memory-start')
        env = {key: value for key, value in os.environ.items() if key.upper() not in {
            "HF_TOKEN", "HUGGING_FACE_HUB_TOKEN", "HUGGINGFACE_TOKEN", "HUGGINGFACEHUB_API_TOKEN"}}
        env.update(HF_HUB_OFFLINE="1", HF_HUB_DISABLE_IMPLICIT_TOKEN="1", HF_DATASETS_OFFLINE="1",
                   OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
        self.replies = queue.Queue(maxsize=2)
        self.nonce = secrets.token_hex(16)
        self.process = subprocess.Popen([sys.executable, "-u", str(Path(__file__).resolve()), "--worker", str(self.model_dir)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            env=env, cwd=str(Path(__file__).resolve().parent),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        threading.Thread(target=_pump_stdout, args=(self.process.stdout, self.replies), daemon=True,
                         name="phonon-private-output").start()

    def _stop(self):
        process, self.process = self.process, None
        self.replies = None
        self.nonce = None
        if process is None:
            return
        try:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=1)
        except Exception:
            pass
        for pipe in (process.stdin, process.stdout):
            try:
                pipe.close()
            except Exception:
                pass

    def synthesize(self, text):
        text = _text(text)
        with self.lock:
            deadline = time.monotonic() + self.timeout
            try:
                self._start()
                process, replies, nonce = self.process, self.replies, self.nonce
                request_id = secrets.token_hex(16)
                raw = (json.dumps({"nonce": nonce, "requestId": request_id, "text": text},
                                  ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
                if len(raw) > MAX_REQUEST_BYTES:
                    raise PhononUnavailable(_ERROR)
                written = queue.Queue(maxsize=1)
                def send():
                    try:
                        process.stdin.write(raw)
                        process.stdin.flush()
                        written.put_nowait(True)
                    except Exception:
                        written.put_nowait(False)
                threading.Thread(target=send, daemon=True, name="phonon-private-input").start()
                if not written.get(timeout=max(0, deadline - time.monotonic())):
                    raise PhononUnavailable(_ERROR)
                while True:
                    budget = container_memory()
                    if budget and budget[1] - budget[0] < 40 * 1024 ** 2:
                        raise PhononUnavailable(_ERROR, 'memory-pressure')
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise PhononUnavailable(_ERROR, 'timeout')
                    try:
                        response = replies.get(timeout=min(.1, remaining))
                        break
                    except queue.Empty:
                        continue
                result = _decode_response(response, nonce, request_id)
                if time.monotonic() > deadline:
                    raise PhononUnavailable(_ERROR)
                return result
            except Exception as error:
                self._stop()
                reason = 'timeout' if isinstance(error, queue.Empty) else getattr(error, 'reason', 'native-error')
                raise PhononUnavailable(_ERROR, reason) from None

    def close(self):
        with self.lock:
            self._stop()


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != "--worker" or "://" in sys.argv[2]:
        raise SystemExit(2)
    _worker(Path(sys.argv[2]).resolve())

"""Fail-closed publisher/transport policy for the worldwide cloud newsroom.

Arabic language is independent of publisher ownership: the reviewed BBC, DW,
France 24 and Euronews Arabic editions remain approved international sources.
Regional Arab publishers, their English editions and their social accounts are
not approved. This is destination control, not an anonymity or IP-hiding claim.
Collectors must check this policy BEFORE a request and still keep their own
exact feed/operation allowlists. Parsed and restored rows are checked separately.
"""
from __future__ import annotations

import re
import urllib.parse


SOURCE_POLICY_VERSION = 'worldwide-publishers-only-2026-10-25-1'
POLICY_ID = SOURCE_POLICY_VERSION
APPROVED_PUBLISHER_DOMAINS = frozenset({
    'bbc.com', 'bbc.co.uk', 'bbci.co.uk', 'france24.com', 'dw.com',
    'euronews.com', 'theguardian.com', 'cnbc.com', 'reuters.com', 'apnews.com',
    'bloomberg.com', 'ft.com', 'lemonde.fr', 'nasa.gov', 'federalreserve.gov',
    'cnn.com', 'kitco.com', 'fxstreet.com', 'investing.com', 'businessinsider.com',
})
APPROVED_SOCIAL_DIDS = frozenset({
    'did:plc:jbvnehrrdqoulco4rf5gxg5r',  # Reuters
    'did:plc:uewxgchsjy4kmtu7dcxa77us',  # Bloomberg
    'did:plc:m7ks2xhfuku7errrtfjux2lg',  # CNBC
    'did:plc:a67zdrt4nl2tv2qojpngogbq',  # Associated Press
    'did:plc:vovinwhtulbsx4mwfw26r5ni',  # The Guardian
})
_DOMAIN_LABEL = re.compile(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?')
_DID = r'did:(?:plc:[a-z2-7]{24}|web:[a-z0-9.-]{1,96})'
_POST = re.compile(r'/profile/(' + _DID + r')/post/([A-Za-z0-9]{1,32})')
_POST_URI = re.compile(r'at://(' + _DID + r')/app\.bsky\.feed\.post/([A-Za-z0-9]{1,32})')


def _url(value):
    if (not isinstance(value, str) or not 1 <= len(value) <= 4096 or '\\' in value or
            any(character.isspace() or ord(character) < 33 or ord(character) == 127 for character in value)):
        return None
    try:
        parsed = urllib.parse.urlsplit(value)
        host = parsed.hostname
        if (parsed.scheme != 'https' or not host or parsed.username is not None or
                parsed.password is not None or parsed.port is not None or parsed.fragment or
                len(host) > 253 or any(not _DOMAIN_LABEL.fullmatch(label) for label in host.split('.'))):
            return None
        return parsed
    except (ValueError, TypeError, UnicodeError):
        return None


def publisher_domain_allowed(value):
    if (not isinstance(value, str) or not value or len(value) > 253 or
            any(not _DOMAIN_LABEL.fullmatch(label) for label in value.split('.'))):
        return False
    return any(value == domain or value.endswith('.' + domain) for domain in APPROVED_PUBLISHER_DOMAINS)


def publisher_url_allowed(value):
    parsed = _url(value)
    return bool(parsed and publisher_domain_allowed(parsed.hostname))


def _query(parsed):
    try:
        values = urllib.parse.parse_qs(parsed.query, strict_parsing=True, keep_blank_values=True)
        if any(len(items) != 1 or not items[0] or any(ord(c) < 32 or ord(c) == 127 for c in items[0])
               for items in values.values()):
            return None
        return {key: items[0] for key, items in values.items()}
    except (ValueError, TypeError, UnicodeError):
        return None


def _bsky_post(value):
    parsed = _url(value)
    if not parsed or parsed.hostname != 'bsky.app' or parsed.query:
        return None
    match = _POST.fullmatch(parsed.path)
    return (match[1], match[2]) if match else None


def _approved_post_uri(value):
    match = _POST_URI.fullmatch(value) if isinstance(value, str) else None
    return (match[1], match[2]) if match and match[1] in APPROVED_SOCIAL_DIDS else None


def collector_url_allowed(value):
    """Approve only reviewed publisher hosts and bounded global service routes.

    This supplements each collector's exact URL allowlist. No redirects or
    arbitrary social identities become approved just because a host is global.
    """
    parsed = _url(value)
    if not parsed:
        return False
    if publisher_domain_allowed(parsed.hostname):
        return True
    query = _query(parsed)
    if query is None:
        return False
    if parsed.hostname == 'news.google.com':
        return (parsed.path == '/rss/search' and set(query) == {'q', 'hl', 'gl', 'ceid'} and
                1 <= len(query['q']) <= 512 and query['q'].endswith(' when:2h') and
                (query['hl'], query['gl'], query['ceid']) in
                {('en-US', 'US', 'US:en'), ('ar', 'SA', 'SA:ar')})
    if parsed.hostname != 'public.api.bsky.app':
        return False
    if parsed.path == '/xrpc/app.bsky.feed.getAuthorFeed':
        return (set(query) == {'actor', 'filter', 'limit'} and query['actor'] in APPROVED_SOCIAL_DIDS and
                query['filter'] == 'posts_no_replies' and query['limit'] == '30')
    if parsed.path == '/xrpc/app.bsky.feed.getPostThread':
        return (set(query) == {'uri', 'depth', 'parentHeight'} and
                _approved_post_uri(query['uri']) is not None and query['depth'] == '1' and query['parentHeight'] == '0')
    return False


# Keep the descriptive spelling convenient at request call sites.
collection_url_allowed = collector_url_allowed


def _google_article(value):
    parsed = _url(value)
    if (not parsed or parsed.hostname != 'news.google.com' or
            not re.fullmatch(r'/rss/articles/[A-Za-z0-9_-]{16,1900}', parsed.path)):
        return False
    query = _query(parsed)
    return (query is not None and set(query) <= {'oc', 'hl', 'gl', 'ceid'} and
            all(len(item) <= 80 for item in query.values()))


def story_allowed(row):
    """Reject excluded publishers in newly parsed news and old saved receipts."""
    if not isinstance(row, dict):
        return False
    if row.get('social') is True:
        post = _bsky_post(row.get('url'))
        if row.get('platform') != 'Bluesky' or post is None:
            return False
        if row.get('sourceKind') == 'social':
            return post[0] in APPROVED_SOCIAL_DIDS
        if row.get('sourceKind') != 'social-feedback':
            return False
        feedback = row.get('feedback')
        if not isinstance(feedback, dict):
            return False
        root = _bsky_post(feedback.get('rootUrl'))
        uri_root = _approved_post_uri(feedback.get('rootUri'))
        return root is not None and root[0] in APPROVED_SOCIAL_DIDS and root == uri_root
    if row.get('sourceKind') == 'publisher-aggregator':
        publisher = _url(row.get('publisherSourceUrl'))
        return (row.get('aggregator') == 'Google News' and _google_article(row.get('url')) and
                publisher_domain_allowed(row.get('publisherDomain')) and publisher is not None and
                publisher.hostname == row['publisherDomain'] and publisher_url_allowed(row['publisherSourceUrl']))
    if row.get('social') not in (None, False):
        return False
    return publisher_url_allowed(row.get('url'))

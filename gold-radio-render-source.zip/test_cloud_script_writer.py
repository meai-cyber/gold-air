from copy import deepcopy
import json
import threading
import time
import unittest
from unittest.mock import patch

from cloud_script_writer import (CloudScriptWriter, ScriptUnavailable, build_prompt,
                                 validate_response, SCRIPT_TTL_SECONDS, SOURCE_REUSE_SECONDS,
                                 QUIET_TOPICS, REPETITION_WINDOW_SECONDS, _channel, _generated_text,
                                 _editorial_facet, build_turn_prompt)


NOW = 1792900000
EN = {'host': 'How could this report influence the way we interpret gold?',
      'analyst': 'If uncertainty changes, gold demand could respond through several channels. '
                 'The relationship depends on the dollar, yields and market liquidity.'}
AR = {'host': 'كيف يمكن أن يساعد هذا الخبر في فهم سوق الذهب؟',
      'analyst': 'قد تؤثر المخاطر في الطلب على الذهب عبر أكثر من قناة. '
                 'وإذا تغيرت العوائد أو العملة يمكن أن تختلف النتيجة، لذلك تبقى العلاقة محتملة وليست نتيجة مؤكدة.'}
EN_QUIET = {**EN, 'host': 'How could currency changes affect the cost of holding gold?'}
AR_QUIET = {**AR, 'host': 'كيف يمكن لتغير العملة أن يؤثر في تكلفة الذهب؟'}


def story(language='en', **changes):
    title = ('Oil prices rise after disruption to energy supplies' if language == 'en' else
             'ارتفاع أسعار النفط بعد تعطل إمدادات الطاقة العالمية')
    return {**{'id': 'a' * 32, 'title': title, 'source': 'Reuters' if language == 'en' else 'BBC Arabic',
       'url': 'https://www.reuters.com/world/energy/test' if language == 'en' else 'https://www.bbc.com/arabic/articles/test',
       'summary': 'Higher fuel costs can affect inflation. This collected sentence is complete.' if language == 'en' else
                  'ارتفاع تكلفة الوقود قد يؤثر في التضخم. هذه الجملة كاملة من المصدر.',
       'language': language, 'publishedAt': NOW - 30, 'firstSeenAt': NOW - 20}, **changes}


class Runtime:
    def __init__(self, response=None):
        self.response = response
        self.calls = []

    def generate(self, prompt, **kwargs):
        self.calls.append((prompt, kwargs))
        return self.response if self.response is not None else json.dumps(EN if kwargs['language'] == 'en' else AR, ensure_ascii=False)


class WriterTests(unittest.TestCase):
    def test_arabic_feminine_dependence_qualifier_is_recognized(self):
        actual = 'الفكرة هي أن الأسعار تتغير بسبب عوامل مثل التقلبات السوقية والظروف الاقتصادية، وتعتمد النتائج على مصدر البيانات والفترة الزمنية المستخدمة لمراقبتها.'
        self.assertEqual(_generated_text(actual, 'ar', 'analyst', ''), actual)
        with self.assertRaises(ScriptUnavailable):
            _generated_text('تعتمد النتيجة على السوق، لكن الذهب سيرتفع بالتأكيد إلى أسعار أعلى.',
                            'ar', 'analyst', '')

    def test_uncertainty_noun_is_a_qualifier_without_admitting_confident_current_claims(self):
        actual = 'Uncertainty affects demand through multiple channels; headline alone cannot prove the change.'
        self.assertEqual(_generated_text(actual, 'en', 'analyst', _channel([], 1)[0]), actual)
        with self.assertRaises(ScriptUnavailable):
            _generated_text('Demand affects gold through several channels and this headline explains the market change.',
                            'en', 'analyst', _channel([], 1)[0])
        with self.assertRaises(ScriptUnavailable):
            _generated_text('Uncertainty means gold will rise to 4500 dollars, and the gain is guaranteed.',
                            'en', 'analyst', _channel([], 1)[0])

    def test_reviewed_facets_vary_with_source_episode_and_failure_without_adding_facts(self):
        source = story(title='Gold market uncertainty prompts discussion of economic risks')
        first = _editorial_facet([source], 0)
        self.assertEqual(first, _editorial_facet([deepcopy(source)], 0))
        self.assertNotEqual(first, _editorial_facet([source], 1))
        pairs = {(build_turn_prompt('ar', 'host', [source], topic_index=index),
                  build_turn_prompt('ar', 'analyst', [source], topic_index=index)) for index in range(18)}
        self.assertEqual(len(pairs), 18)
        across_sources = {_channel([story(id=format(index, '032x'), title=source['title'])], 0)
                          for index in range(12)}
        self.assertGreaterEqual(len(across_sources), 3)
        for host, analyst in pairs:
            self.assertNotIn(source['id'], host + analyst)
            self.assertFalse(any(character.isdigit() for character in host + analyst))
        self.assertEqual(_editorial_facet([story()], 0), None, 'the previously tested oil channel stays intact')

    def test_quiet_opportunity_cost_uses_interest_alternatives_not_transaction_costs(self):
        index = next(index for index, topic in enumerate(QUIET_TOPICS) if topic[0].startswith('opportunity cost'))
        english, arabic = _channel([], index)
        self.assertIn('opportunity cost', english)
        self.assertNotIn('Transaction costs', english)
        self.assertIn('الفرصة البديلة', arabic)
        self.assertNotIn('تكلفة التعامل', arabic)

    def test_reviewed_background_words_and_when_conditions_do_not_look_like_new_names(self):
        index = next(index for index, topic in enumerate(QUIET_TOPICS) if topic[0].startswith('liquidity'))
        context = _channel([], index)[0]
        english = 'Transaction costs matter more when the observed move is small in the sampled market.'
        self.assertEqual(_generated_text(english, 'en', 'analyst', context), english)
        arabic = 'تكلفة التعامل تكون أكثر أهمية عندما تكون الحركة المرصودة صغيرة بين عينتين من السوق.'
        self.assertEqual(_generated_text(arabic, 'ar', 'analyst', ''), arabic)
        with self.assertRaises(ScriptUnavailable):
            _generated_text('Washington could change policy while the market reaction remains uncertain for gold.',
                            'en', 'analyst', context)

    def writer(self, runtime=None):
        clock = {'now': NOW}
        return CloudScriptWriter(runtime or Runtime(), clock=lambda: clock['now']), clock

    def test_candidate_is_cached_nonblocking_and_only_prepare_calls_model(self):
        runtime = Runtime()
        writer, clock = self.writer(runtime)
        self.assertIsNone(writer.candidate('en', NOW))
        self.assertEqual(runtime.calls, [])
        self.assertTrue(writer.prepare('en', [story()], now_s=NOW))
        first = writer.candidate('en', NOW)
        self.assertEqual(len(runtime.calls), 2)
        self.assertEqual(first['kind'], 'cloud-discussion')
        self.assertEqual(first['programme']['speakerRole'], 'host')
        self.assertFalse(writer.prepare('en', [story()], now_s=NOW + 30))
        self.assertEqual(len(runtime.calls), 2)
        self.assertEqual(writer.candidate('en', NOW), first)
        self.assertIsNone(writer.candidate('en', NOW, [first['id']]))
        self.assertFalse(writer.consume({**first, 'speechText': 'edited'}, NOW))
        self.assertEqual(writer.candidate('en', NOW), first)
        self.assertTrue(writer.consume(first, NOW))
        second = writer.candidate('en', NOW)
        self.assertEqual(second['programme']['speakerRole'], 'analyst')
        self.assertFalse(writer.consume(first, NOW))
        self.assertTrue(writer.consume(second, NOW))
        self.assertIsNone(writer.candidate('en', NOW))
        self.assertEqual(writer.status('en')['publishedTurns'], 2)
        self.assertEqual(len(runtime.calls), 2)

    def test_sourced_episode_preserves_full_collected_text_and_original_clocks(self):
        writer, _ = self.writer()
        source = story(publishedAt=NOW-700, firstSeenAt=NOW-690)
        self.assertTrue(writer.prepare('en', [source], now_s=NOW))
        job = writer.candidate('en', NOW)
        self.assertIn(source['title'], job['speechText'])
        self.assertIn(source['summary'], job['speechText'])
        self.assertTrue(job['speechText'].startswith('Earlier report, published at '))
        self.assertEqual(job['sources'][0]['id'], source['id'])
        self.assertEqual(job['sources'][0]['publishedAt'], source['publishedAt']*1000)
        self.assertEqual(job['sources'][0]['firstSeenAt'], source['firstSeenAt']*1000)
        self.assertEqual(job['publishedAt'], source['publishedAt'])
        self.assertTrue(job['programme']['sourceGrounded'])
        self.assertFalse(job['programme']['currentNews'])
        self.assertFalse(job['programme']['forecast'])
        self.assertFalse(job['programme']['educational'])

    def test_arabic_english_fallback_is_disclosed_topic_context_not_a_claimed_translation(self):
        source = story(title='Gold demand rises 5% as central bank purchases grow', summary='')
        runtime = Runtime(json.dumps(AR, ensure_ascii=False))
        writer, _ = self.writer(runtime)
        self.assertTrue(writer.prepare('ar', [source], now_s=NOW))
        job = writer.candidate('ar', NOW)
        self.assertNotIn(source['title'], job['speechText'])
        self.assertNotIn('5%', job['speechText'])
        self.assertEqual(job['sources'][0]['title'], source['title'])
        self.assertEqual(job['programme']['sourceContextMode'], 'topic-context-only')
        self.assertFalse(job['programme']['headlineTranslated'])
        self.assertFalse(job['programme']['translationVerified'])
        self.assertEqual([call[1]['max_tokens'] for call in runtime.calls], [64, 96])

    def test_arabic_native_source_precedes_english_fallback_and_remains_complete(self):
        writer, _ = self.writer()
        self.assertTrue(writer.prepare('ar', [story(), story('ar')], now_s=NOW))
        job = writer.candidate('ar', NOW)
        self.assertIn(story('ar')['title'], job['speechText'])
        self.assertIn(story('ar')['summary'], job['speechText'])
        self.assertNotIn('machineTranslation', job['programme'])

    def test_numeric_or_named_actor_invention_in_translation_is_rejected(self):
        source = story(title='Gold demand rises 5% as central bank purchases grow')
        for translation in ('يرتفع الطلب على الذهب 50% مع زيادة مشتريات البنوك المركزية.',
                            'يرتفع الطلب على الذهب مع زيادة مشتريات البنوك المركزية.',
                            'أعلن ترامب أن الطلب على الذهب يرتفع 5% في أسواق العالم.'):
            with self.subTest(translation=translation), self.assertRaises(ScriptUnavailable):
                validate_response(json.dumps({**AR, 'translation': translation}, ensure_ascii=False), 'ar', [source])

    def test_quiet_period_is_new_generated_education_without_archive_or_fake_news(self):
        writer, _ = self.writer(Runtime(json.dumps(AR_QUIET, ensure_ascii=False)))
        self.assertTrue(writer.prepare('ar', [], now_s=NOW))
        job = writer.candidate('ar', NOW)
        self.assertEqual(job['sources'], [])
        self.assertTrue(job['programme']['educational'])
        self.assertFalse(job['programme']['sourceGrounded'])
        self.assertFalse(job['programme']['currentNews'])
        self.assertFalse(job['programme']['repeat'])
        self.assertTrue(job['speechText'].startswith('أعزائي المستمعين'))
        self.assertEqual(job['generatedText'], AR_QUIET['host'])
        self.assertFalse(writer.status('ar')['recordedArchive'])

    def test_bad_output_never_becomes_a_ready_script(self):
        bad = ['not JSON', '```json\n'+json.dumps(EN)+'\n```', json.dumps({'host': EN['host']}),
               json.dumps({**EN, 'analyst': 'Gold will rise to 4500 dollars within the next five minutes.'}),
               json.dumps({**EN, 'analyst': 'Everyone agrees that gold demand has become stronger across the world.'}),
               json.dumps({**EN, 'analyst': 'If Washington announces cuts, gold could rise. The result depends on conditions.'}),
               json.dumps({**EN, 'analyst': 'Gold demand is stronger and real yields are lower across all markets.'}),
               json.dumps({**EN, 'analyst': 'If demand changes, gold may respond. Read https://example.org for details.'}),
               json.dumps(AR, ensure_ascii=False)]
        for raw in bad:
            with self.subTest(raw=raw):
                runtime = Runtime(raw)
                writer, _ = self.writer(runtime)
                self.assertFalse(writer.prepare('en', [story()], now_s=NOW))
                self.assertIsNone(writer.candidate('en', NOW))
                self.assertEqual(writer.status('en')['status'], 'unavailable')
                self.assertEqual(writer.status('en')['generatedEpisodes'], 0)

    def test_original_source_policy_and_latest_clock_are_applied_before_prompting(self):
        source = story()
        blocked = story(id='b'*32, url='https://www.aljazeera.com/news/test', title='Gold demand surges after central bank decision')
        future = story(id='c'*32, publishedAt=NOW+1, firstSeenAt=NOW+1)
        older = story(id='d'*32, title='Dollar changes accompany gold market uncertainty',
                      publishedAt=NOW-7100, firstSeenAt=NOW-7000)
        runtime = Runtime()
        writer, _ = self.writer(runtime)
        self.assertTrue(writer.prepare('en', [blocked, future, older, source], now_s=NOW))
        prompt = runtime.calls[0][0]
        self.assertIn('oil supply', prompt)
        self.assertNotIn(blocked['title'], prompt)
        self.assertEqual(writer.candidate('en', NOW)['programme']['sourceIds'], [source['id']])

    def test_expired_generated_or_expired_source_scripts_are_retired_without_model_call(self):
        for age in (30, 7190):
            runtime = Runtime()
            writer, _ = self.writer(runtime)
            self.assertTrue(writer.prepare('en', [story(publishedAt=NOW-age, firstSeenAt=NOW-age+1)], now_s=NOW))
            first = writer.candidate('en', NOW)
            after = NOW + (SCRIPT_TTL_SECONDS+1 if age == 30 else 11)
            self.assertIsNone(writer.candidate('en', after))
            self.assertFalse(writer.consume(first, after))
            self.assertEqual(len(runtime.calls), 2)

    def test_failed_prepare_is_throttled_and_does_not_block_candidate(self):
        runtime = Runtime('broken')
        writer, _ = self.writer(runtime)
        self.assertFalse(writer.prepare('en', [story()], now_s=NOW))
        self.assertFalse(writer.prepare('en', [story()], now_s=NOW+1))
        self.assertEqual(len(runtime.calls), 1)
        self.assertIsNone(writer.candidate('en', NOW+1))
        self.assertEqual(writer.status('en')['failures'], 1)

    def test_preparation_runs_outside_cached_access_and_only_one_attempt_per_language(self):
        entered, finish = threading.Event(), threading.Event()
        class SlowRuntime(Runtime):
            def generate(self, prompt, **kwargs):
                entered.set()
                finish.wait(2)
                return super().generate(prompt, **kwargs)
        runtime = SlowRuntime()
        writer, _ = self.writer(runtime)
        worker = threading.Thread(target=writer.prepare, args=('en', [story()]), kwargs={'now_s':NOW})
        worker.start()
        try:
            self.assertTrue(entered.wait(1))
            self.assertTrue(writer.status('en')['preparing'])
            started = time.monotonic()
            self.assertIsNone(writer.candidate('en', NOW))
            self.assertFalse(writer.prepare('en', [story()], now_s=NOW+30))
            self.assertLess(time.monotonic()-started, .5)
        finally:
            finish.set(); worker.join(3)
        self.assertIsNotNone(writer.candidate('en', NOW))

    def test_repeated_generated_dialogue_is_not_replayed_as_a_new_episode(self):
        writer, clock = self.writer(Runtime(json.dumps(EN_QUIET)))
        self.assertTrue(writer.prepare('en', [], now_s=NOW))
        for _ in range(2):
            self.assertTrue(writer.consume(writer.candidate('en', NOW), NOW))
        self.assertFalse(writer.prepare('en', [], now_s=NOW+30))
        self.assertEqual(writer.status('en')['lastError'], 'Repeated generated conversation')
        self.assertIsNone(writer.candidate('en', NOW+30))

    def test_changed_host_cannot_hide_a_repeated_analyst_turn_in_either_language(self):
        fixtures = (('en', EN, 'What evidence about gold would distinguish these possibilities from other explanations?'),
                    ('ar', AR, 'ما القرائن التي تساعد في فهم الذهب عند مقارنة أكثر من تفسير اقتصادي؟'))
        for language, script, new_host in fixtures:
            with self.subTest(language=language):
                runtime = Runtime(json.dumps(script, ensure_ascii=False))
                writer, _ = self.writer(runtime)
                self.assertTrue(writer.prepare(language, [story(language)], now_s=NOW))
                for _ in range(2): self.assertTrue(writer.consume(writer.candidate(language, NOW), NOW))
                runtime.response = json.dumps({**script, 'host': new_host}, ensure_ascii=False)
                other = story(language, id='b'*32,
                              title='Gold market uncertainty prompts discussion of economic risks' if language == 'en' else
                                    'مخاطر اقتصادية تفتح النقاش حول الذهب وعدم اليقين')
                self.assertFalse(writer.prepare(language, [other], now_s=NOW+30))
                self.assertEqual(writer.status(language)['lastError'], 'Repeated generated analyst turn')
                self.assertIsNone(writer.candidate(language, NOW+30))
                self.assertEqual(writer.status(language)['publishedTurns'], 2)

    def test_recent_duplicates_stay_blocked_but_expired_wording_does_not_permanently_starve_radio(self):
        writer, _ = self.writer(Runtime(json.dumps(EN_QUIET)))
        self.assertTrue(writer.prepare('en', [], now_s=NOW))
        for _ in range(2): self.assertTrue(writer.consume(writer.candidate('en', NOW), NOW))
        self.assertFalse(writer.prepare('en', [], now_s=NOW+30))
        self.assertIsNone(writer.candidate('en', NOW+30))
        later = NOW + REPETITION_WINDOW_SECONDS + 1
        self.assertTrue(writer.prepare('en', [], now_s=later))
        job = writer.candidate('en', later)
        self.assertEqual(job['programme']['repetitionWindowSeconds'], 1200)
        self.assertEqual(writer.status('en')['repetitionWindowSeconds'], 1200)
        self.assertFalse(job['programme']['repeat'], 'this is new inference, not cached audio replay')

    def test_one_episode_has_one_aggregate_deadline_across_model_calls(self):
        ticks = {'now': 100.0}
        class BudgetRuntime(Runtime):
            def generate(self, prompt, **kwargs):
                value = super().generate(prompt, **kwargs)
                ticks['now'] += 30
                return value
        runtime = BudgetRuntime()
        writer, _ = self.writer(runtime)
        with patch('cloud_script_writer.time.monotonic', side_effect=lambda: ticks['now']):
            self.assertTrue(writer.prepare('en', [story()], now_s=NOW))
        self.assertEqual([call[1]['timeout'] for call in runtime.calls], [180, 150])
        self.assertEqual(writer.status('en')['lastGenerationSeconds'], 60)
        class ExpiredRuntime(Runtime):
            def generate(self, prompt, **kwargs):
                value = super().generate(prompt, **kwargs)
                ticks['now'] += 181
                return value
        runtime = ExpiredRuntime()
        writer, _ = self.writer(runtime)
        with patch('cloud_script_writer.time.monotonic', side_effect=lambda: ticks['now']):
            self.assertFalse(writer.prepare('en', [story()], now_s=NOW))
        self.assertEqual(len(runtime.calls), 1)
        self.assertIsNone(writer.candidate('en', NOW))

    def test_token_limit_output_is_not_published_as_a_complete_turn(self):
        class CutRuntime(Runtime):
            def status(self): return {'lastOutputTokens': 64}
        writer, _ = self.writer(CutRuntime())
        self.assertFalse(writer.prepare('en', [story()], now_s=NOW))
        self.assertIsNone(writer.candidate('en', NOW))
        self.assertIn('cut off', writer.status('en')['lastError'])

    def test_arabic_topic_context_keeps_social_and_feedback_caveats(self):
        did = 'did:plc:jbvnehrrdqoulco4rf5gxg5r'
        for kind in ('social', 'social-feedback'):
            with self.subTest(kind=kind):
                source = story(social=True, platform='Bluesky', sourceKind=kind,
                    url='https://bsky.app/profile/' + did + '/post/example123')
                if kind == 'social-feedback':
                    source['feedback'] = {'rootUrl': 'https://bsky.app/profile/' + did + '/post/root123',
                                          'rootUri': 'at://' + did + '/app.bsky.feed.post/root123'}
                writer, _ = self.writer(Runtime(json.dumps(AR, ensure_ascii=False)))
                self.assertTrue(writer.prepare('ar', [source], now_s=NOW))
                job = writer.candidate('ar', NOW)
                self.assertIn('غير متحقق منه', job['speechText'])
                if kind == 'social-feedback': self.assertIn('لا يمثل رأي الجمهور', job['speechText'])
                self.assertFalse(job['programme']['headlineTranslated'])
                self.assertTrue(job['speechText'].startswith('أعزائي المستمعين'))
                self.assertTrue(writer.consume(job, NOW))
                self.assertTrue(writer.candidate('ar', NOW)['speechText'].endswith('دمتم بخير.'))


if __name__ == '__main__':
    unittest.main()

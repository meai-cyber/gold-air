"""Original relaxing instrumental, rendered once at image build time.

All notes are synthesized here: no recordings, samples or downloaded music.
The quiet boundaries allow the waiting bed to loop without a discontinuity.
"""
import io
import wave

MUSIC_SECONDS = 120
MUSIC_FILE = 'station-relax-v2.wav'


def compose():
    import numpy as np

    rate = 24000
    beat = 60 / 64
    bar_length = beat * 4
    sound = np.zeros(rate * MUSIC_SECONDS, dtype=np.float64)

    def note(midi, start, duration, gain, voice):
        first = max(0, round(start * rate))
        last = min(len(sound), round((start + duration) * rate))
        if first >= last:
            return
        age = np.arange(last - first, dtype=np.float64) / rate
        pitch = 440 * 2 ** ((midi - 69) / 12)
        phase = 2 * np.pi * pitch * age
        remaining = np.maximum(duration - age, 0)
        if voice == 'pad':
            # Rounded, slowly moving harmony with no random/noise source.
            envelope = np.minimum(age / .65, 1) * np.minimum(remaining / .8, 1)
            tone = (.78 * np.sin(phase)
                    + .14 * np.sin(phase * 2)
                    + .08 * np.sin(phase * 1.0015))
            envelope *= .94 + .06 * np.cos(2 * np.pi * .19 * age)
        elif voice == 'bass':
            envelope = (1 - np.exp(-age / .04)) * np.exp(-age / 1.7)
            envelope *= np.minimum(remaining / .18, 1)
            tone = .88 * np.sin(phase) + .12 * np.sin(phase * 2)
        else:
            # Soft electric-piano-like attacks; higher partials decay sooner.
            envelope = (1 - np.exp(-age / .018)) * np.exp(-age / 1.05)
            envelope *= np.minimum(remaining / .2, 1)
            tone = (.85 * np.sin(phase)
                    + .12 * np.exp(-age * 2) * np.sin(phase * 2)
                    + .03 * np.exp(-age * 4) * np.sin(phase * 3))
        rendered = gain * envelope * tone
        sound[first:last] += rendered
        # Very quiet, finite musical echo; it is truncated at the track end.
        if voice == 'piano':
            echo_start = first + round(beat * .75 * rate)
            echo_length = min(len(rendered), len(sound) - echo_start)
            if echo_length > 0:
                sound[echo_start:echo_start + echo_length] += rendered[:echo_length] * .13

    # An original eight-bar C-major/A-minor phrase with sparse variations.
    chords = (
        (48, (48, 52, 55, 59)),  # C major seventh
        (45, (45, 48, 52, 55)),  # A minor seventh
        (41, (45, 48, 52, 53)),  # F major seventh
        (43, (43, 47, 50, 52)),  # G sixth
        (40, (43, 47, 50, 52)),  # E minor seventh
        (45, (45, 48, 52, 55)),
        (38, (45, 48, 50, 53)),  # D minor seventh
        (43, (43, 48, 50, 55)),  # G suspended
    )
    melody = ((76, 74, 71), (72, 71, 69), (69, 72, 76), (74, 71, 67),
              (71, 74, 76), (72, 71, 69), (69, 65, 69), (67, 71, 72))
    for bar in range(32):
        start = bar * bar_length
        phrase = bar // 8
        root, chord = chords[bar % 8]
        for pitch in chord:
            note(pitch + 12, start, bar_length + .35, .022, 'pad')
        note(root - 12, start, beat * 3.5, .058, 'bass')
        for step, chord_index in enumerate((0, 2, 1, 3, 2, 1)):
            offset = (.5 + step * .5) * beat
            note(chord[chord_index] + 12, start + offset, beat * 1.8,
                 .045 if step % 2 == 0 else .034, 'piano')
        # Leave breathing room between short melody phrases.
        if (bar + phrase) % 3 != 1:
            for index, pitch in enumerate(melody[bar % 8]):
                note(pitch - (12 if phrase == 2 else 0),
                     start + (index * 1.25 + .25) * beat,
                     beat * 1.8, .042, 'piano')

    # A gentle global fade and generous peak headroom; no hard clipping.
    edge = round(.9 * rate)
    ramp = np.sin(np.linspace(0, np.pi / 2, edge)) ** 2
    sound[:edge] *= ramp
    sound[-edge:] *= ramp[::-1]
    peak = float(np.max(np.abs(sound)))
    if peak > 0:
        sound *= .30 / peak
    output = io.BytesIO()
    with wave.open(output, 'wb') as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(rate)
        audio.writeframes((sound * 32767).astype('<i2').tobytes())
    return output.getvalue()

"""Original instrumental interlude, rendered once at image build time."""
import io
import wave

MUSIC_SECONDS = 32
MUSIC_FILE = 'station-bed-v1.wav'


def compose():
    import numpy as np
    rate = 24000
    time = np.arange(rate * MUSIC_SECONDS, dtype=np.float64) / rate
    sound = np.zeros_like(time)
    # Original four-bar A-minor / F / C / G arrangement, no sampled recordings.
    chords = ((220, 261.6256, 329.6276), (174.6141, 220, 261.6256),
              (130.8128, 164.8138, 195.9977), (195.9977, 246.9417, 293.6648))
    for bar, chord in enumerate(chords):
        local = time - bar * 8
        mask = (local >= 0) & (local < 8)
        envelope = np.clip(local / .7, 0, 1) * np.clip((8 - local) / .9, 0, 1)
        for pitch in chord:
            sound += .055 * mask * envelope * np.sin(2 * np.pi * pitch * time)
        for beat in range(8):
            age = local - beat
            active = (age >= 0) & (age < 1)
            attack = np.clip(age / .025, 0, 1)
            decay = np.exp(-np.maximum(age, 0) * 4)
            pitch = chord[beat % 3] * 2
            sound += .10 * active * attack * decay * np.sin(2 * np.pi * pitch * time)
    pcm = np.clip(sound, -.45, .45)
    output = io.BytesIO()
    with wave.open(output, 'wb') as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(rate)
        audio.writeframes((pcm * 32767).astype('<i2').tobytes())
    return output.getvalue()

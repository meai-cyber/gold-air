import importlib.util
import io
import json
import pathlib
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import wave
from decimal import Decimal
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

import server
from station_music import compose, MUSIC_FILE, MUSIC_SECONDS
from market_brief import parse_quote
from datetime import datetime, timezone


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.station = server.Station(self.temporary.name)
        self.now = int(time.time())
        # Existing tests isolate current-news/quote policy from the optional
        # recorded programme; focused integration tests enable that fallback.
        self.station.programmes = None
        self.station.airtime = {language: server.AirtimeMix((self.now - 600) * 1000)
                                for language in ('ar', 'en')}

    def tearDown(self):
        self.station.stop.set()
        self.temporary.cleanup()

    def story(self, **changes):
        row = {'id': 'a' * 32, 'title': 'خبر جديد عن الاقتصاد وأسعار الذهب', 'source': 'الجزيرة',
               'url': 'https://www.aljazeera.net/news/test', 'language': 'ar',
               'publishedAt': self.now - 20, 'firstSeenAt': self.now - 10}
        return {**row, **changes}

    def lower_ranked_rows(self):
        return [self.story(id=format(i, '032x'), title='تقرير التضخم الاقتصادي ' + str(i)) for i in (3, 4)]

    def news_budget(self, language):
        for offset in (180, 120, 60):
            self.station.airtime[language].commit((self.now-offset)*1000, (self.now-offset+60)*1000, 'news')

    def observe_price(self, price, offset=0):
        stamp = self.now + offset
        self.station.market.observe(parse_quote({'symbol': 'XAU', 'price': price,
            'updatedAt': datetime.fromtimestamp(stamp, timezone.utc).isoformat()}, stamp))

    def baseline_price(self, language='ar', price=4020, offset=-30):
        self.observe_price(price, offset)
        self.assertIsNone(self.station._next_job(language, (self.now + offset) * 1000, {}))

    def generate_one_price(self, language='ar', offset=0, outcome='success'):
        station, clock = self.station, {'now': self.now + offset}
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        class FakeTts:
            available_languages = (language,)
            engines = {language: 'fake-test-only'}
            def synthesize(self, text, language):
                station.stop.set()
                if outcome == 'failure':
                    raise ValueError('Test synthesis failure')
                if outcome == 'expired':
                    clock['now'] += 120
                return SimpleNamespace(wav=data.getvalue(), duration_s=1.0,
                                       engine='fake-test-only', language=language)
        station.tts_factory = FakeTts
        station.stop.clear()
        with patch('server.time.time', side_effect=lambda: clock['now']):
            station.generate()

    def test_fresh_requires_real_publication_and_earliest_receipt(self):
        self.assertTrue(server.fresh(self.story(), self.now))
        for row in (self.story(publishedAt=self.now - 601), self.story(firstSeenAt=self.now + 1),
                    self.story(publishedAt=self.now + 1), self.story(publishedAt=True)):
            self.assertFalse(server.fresh(row, self.now))
        self.station.ingest([self.story()])
        self.station.ingest([self.story(firstSeenAt=self.now, publishedAt=self.now - 5)])
        row = self.station.stories['a' * 32]
        self.assertEqual(row['firstSeenAt'], self.now - 10)
        self.assertEqual(row['publishedAt'], self.now - 20)

    def test_newest_equal_priority_report_first_dedup_and_consumption(self):
        old = self.story()
        new = self.story(id='b' * 32, title='خبر آخر عن الاقتصاد وأسعار الذهب', publishedAt=self.now - 5, firstSeenAt=self.now - 4)
        self.station.ingest([new, old, *self.lower_ranked_rows()])
        self.assertEqual(self.station._candidate('ar', self.now)['id'], new['id'])
        self.station.seen['ar'].add(new['id'])
        self.assertEqual(self.station._candidate('ar', self.now)['id'], old['id'])
        self.assertIsNone(self.station._candidate('en', self.now))

    def test_retrying_oldest_news_does_not_starve_other_fresh_speech(self):
        old = self.story()
        new = self.story(id='b' * 32, title='خبر آخر عن الاقتصاد وأسعار الذهب', publishedAt=self.now - 5, firstSeenAt=self.now - 4)
        self.station.ingest([old, new, *self.lower_ranked_rows()])
        retry = {old['id']: (self.now + 30) * 1000}
        self.assertEqual(self.station._candidate('ar', self.now, retry)['id'], new['id'])

    def test_equal_score_variety_keeps_higher_priority_and_quota(self):
        rows = [self.story(id=format(i, '032x'), language='en', source='Same publisher',
                          title=title) for i, title in enumerate((
            'Inflation report released', 'Treasury yields rise',
            'Economy report one', 'Economy report two', 'Economy report three'), 1)]
        rows[1]['source'] = 'Other publisher'
        self.station.ingest(rows)
        self.station.last_news_source['en'] = 'Same publisher'
        self.station.last_news_topics['en'] = ('inflation',)
        self.assertEqual(self.station._candidate('en', self.now)['id'], rows[1]['id'])
        self.station.seen['en'].add(rows[1]['id'])
        self.assertEqual(self.station._candidate('en', self.now)['id'], rows[0]['id'])
        self.station.seen['en'].add(rows[0]['id'])
        self.assertIn(self.station._candidate('en', self.now)['id'], {row['id'] for row in rows[2:]},
                      'lower-ranked but relevant economy reports remain available')
        gold = self.story(id='f' * 32, language='en', source='Same publisher', title='Gold prices rise')
        self.station.ingest([gold])
        self.station.last_news_topics['en'] = ('gold',)
        self.assertEqual(self.station._candidate('en', self.now)['id'], gold['id'])

    def test_quote_preflight_accounts_for_preparation_queue_and_original_clock(self):
        now = self.now * 1000
        self.station.queues['ar'] = [{'id': 'd' * 32, 'kind': 'news',
                                      'startsAt': now - 1000, 'endsAt': now + 80000}]
        self.station.news_streak['ar'] = server.NEWS_BURST_LIMIT
        job = {'kind': 'market', 'language': 'ar', 'speechText': 'x' * 100,
               'publishedAt': self.now - 15, 'firstSeenAt': self.now}
        self.assertTrue(self.station._job_fresh(job, now), 'valid at issue but too old for its queued start')
        self.assertFalse(self.station._can_prepare_quote(job, now))
        deferred = self.station.manifest('ar', now)['production']['lastDeferredQuote']
        self.assertEqual(deferred['sourceAt'], job['publishedAt'] * 1000)
        self.assertGreaterEqual(deferred['estimatedStartAt'], now + 80000)
        self.assertTrue(self.station._can_prepare_quote({**job, 'publishedAt': self.now}, now))
        self.assertFalse(self.station._job_fresh(job, now + 91000), 'final expiry remains unchanged')

    def test_infeasible_briefing_leaves_slot_for_real_news(self):
        self.baseline_price(price=4020, offset=-90)
        self.observe_price(4021, offset=-60)
        self.station.ingest([self.story()])
        self.station.news_streak['ar'] = server.NEWS_BURST_LIMIT
        self.station.last_market_at['ar'] = self.now * 1000
        analysis = {'id': 'f' * 32, 'kind': 'analysis', 'language': 'ar',
                    'speechText': 'x' * 400, 'publishedAt': self.now - 60, 'firstSeenAt': self.now,
                    'market': self.station.market.snapshot(self.now)}
        with patch('server.build_briefing', return_value=analysis):
            self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')
        self.assertNotIn('a' * 32, self.station.seen['ar'])
        self.assertEqual(self.station.last_analysis_at['ar'], 0)

    def test_news_priority_and_market_cadence_use_source_clock(self):
        self.baseline_price(price=4023, offset=-35)
        quote = parse_quote({'symbol': 'XAU', 'price': 4023.25,
            'updatedAt': datetime.fromtimestamp(self.now - 5, timezone.utc).isoformat()}, self.now)
        self.station.market.observe(quote)
        job = self.station._next_job('ar', self.now * 1000, {})
        self.assertEqual(job['kind'], 'market')
        self.assertTrue(self.station._job_fresh(job, (self.now + 60) * 1000))
        self.assertFalse(self.station._job_fresh(job, (self.now + 86) * 1000))
        self.station.ingest([self.story()])
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')

    def test_first_quote_and_timestamp_only_or_same_spoken_cent_refreshes_stay_silent(self):
        for language in ('ar', 'en'):
            self.assertIsNone(self.station._next_job(language, (self.now - 120) * 1000, {}))
            self.assertIsNone(self.station.initial_price[language])
        for offset, price in ((-120, 4023.121), (-60, 4023.124), (0, 4023.12)):
            self.observe_price(price, offset)
            for language in ('ar', 'en'):
                self.assertIsNone(self.station._next_job(language, (self.now + offset) * 1000, {}))
                self.assertEqual(self.station.initial_price[language], Decimal('4023.12'))
                self.assertIsNone(self.station.last_announced_price[language])
        self.assertEqual(self.station.market.snapshot(self.now)['sourceAt'], self.now * 1000)
        self.assertEqual(self.station.market.snapshot(self.now)['changes']['1']['direction'], 'down')
        self.assertEqual(self.station.last_market_at['ar'], 0)
        self.assertEqual(self.station.last_analysis_at['ar'], 0)

    def test_real_price_up_and_down_schedule_once_for_analysis_and_market(self):
        self.baseline_price(price=4020, offset=-60)
        self.observe_price(4021)
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'analysis')
        self.generate_one_price()
        self.assertEqual(self.station.last_announced_price['ar'], Decimal('4021.00'))
        self.assertEqual(self.station.queues['ar'][-1]['kind'], 'analysis')
        self.assertEqual(self.station.queues['ar'][-1]['publishedAt'], self.now * 1000)
        self.observe_price(4021, offset=60)
        self.assertIsNone(self.station._next_job('ar', (self.now + 60) * 1000, {}))
        self.observe_price(4019, offset=120)
        self.assertEqual(self.station._next_job('ar', (self.now + 120) * 1000, {})['kind'], 'market')
        self.generate_one_price(offset=120)
        self.assertEqual(self.station.last_announced_price['ar'], Decimal('4019.00'))
        self.assertEqual(self.station.queues['ar'][-1]['kind'], 'market')
        self.assertEqual(self.station.queues['ar'][-1]['market']['priceText'], '4019.00')
        self.assertIsNone(self.station._next_job('ar', (self.now + 185) * 1000, {}))

    def test_unannounced_changes_coalesce_to_current_quote_not_a_stale_pending_move(self):
        self.baseline_price(price=4020, offset=-60)
        self.observe_price(4021, offset=-30)
        pending = self.station._next_job('ar', (self.now - 30) * 1000, {})
        self.assertEqual(pending['market']['priceText'], '4021.00')
        self.observe_price(4020)
        self.assertIsNone(self.station._next_job('ar', self.now * 1000, {}))
        self.observe_price(4022, offset=60)
        pending = self.station._next_job('ar', (self.now + 60) * 1000, {})
        self.assertEqual(pending['market']['priceText'], '4022.00')
        self.assertEqual(self.station.initial_price['ar'], Decimal('4020.00'))
        self.assertIsNone(self.station.last_announced_price['ar'])

    def test_failed_or_expired_synthesis_does_not_consume_changed_price(self):
        for outcome in ('failure', 'expired'):
            with self.subTest(outcome=outcome):
                self.station = server.Station(str(pathlib.Path(self.temporary.name) / outcome))
                self.station.programmes = None
                self.station.airtime = {language: server.AirtimeMix((self.now - 600) * 1000)
                                        for language in ('ar', 'en')}
                self.baseline_price(price=4020, offset=-30)
                self.observe_price(4021)
                self.generate_one_price(outcome=outcome)
                self.assertEqual(self.station.queues['ar'], [])
                self.assertIsNone(self.station.last_announced_price['ar'])
                self.assertEqual(self.station.last_market_at['ar'], 0)
                self.assertEqual(self.station.last_analysis_at['ar'], 0)
                self.assertIsNotNone(self.station._next_job('ar', self.now * 1000, {}))

    def test_announced_prices_and_baselines_are_independent_between_languages(self):
        self.observe_price(4020, offset=-30)
        for language in ('ar', 'en'):
            self.assertIsNone(self.station._next_job(language, (self.now - 30) * 1000, {}))
        self.observe_price(4021)
        self.generate_one_price('ar')
        self.assertEqual(self.station.last_announced_price['ar'], Decimal('4021.00'))
        self.assertIsNone(self.station.last_announced_price['en'])
        self.assertIsNone(self.station._next_job('ar', self.now * 1000, {}))
        self.assertIsNotNone(self.station._next_job('en', self.now * 1000, {}))
        self.generate_one_price('en')
        self.assertEqual(self.station.last_announced_price['en'], Decimal('4021.00'))
        self.assertEqual(len(self.station.queues['ar']), 1)
        self.assertEqual(len(self.station.queues['en']), 1)

    def test_restart_silently_baselines_its_first_quote_and_flat_prices_do_not_block_news(self):
        self.baseline_price(price=4020, offset=-30)
        self.observe_price(4021)
        self.generate_one_price()
        self.station = server.Station(self.temporary.name)
        self.station.programmes = None
        self.observe_price(4030)
        self.assertIsNone(self.station._next_job('ar', self.now * 1000, {}))
        self.assertEqual(self.station.initial_price['ar'], Decimal('4030.00'))
        self.assertIsNone(self.station.last_announced_price['ar'])
        self.station.ingest([self.story()])
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')
        self.station.news_streak['ar'] = server.NEWS_BURST_LIMIT
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')
        self.station.seen['ar'].add('a' * 32)
        self.station.last_market_at['ar'] = self.now * 1000
        self.assertIsNone(self.station._next_job('ar', (self.now + 30) * 1000, {}))
        self.assertIsNone(self.station._next_job('ar', (self.now + 100) * 1000, {}))

    def test_busy_headlines_allow_due_market_and_discussion_after_bounded_burst(self):
        self.baseline_price(price=4023, offset=-35)
        self.station.ingest([self.story()])
        self.station.market.observe(parse_quote({'symbol': 'XAU', 'price': 4023.25,
            'updatedAt': datetime.fromtimestamp(self.now - 5, timezone.utc).isoformat()}, self.now))
        self.station.news_streak['ar'] = server.NEWS_BURST_LIMIT
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'market')
        self.station.last_market_at['ar'] = self.now * 1000
        excluded = []
        def candidate(language, stamp, exclude_ids=()):
            excluded.extend(exclude_ids)
            return {'kind': 'discussion', 'id': 'c' * 32, 'language': language}
        self.station.discussions = SimpleNamespace(candidate=candidate)
        self.assertEqual(self.station._next_job('ar', self.now * 1000,
            {'d' * 32: (self.now + 30) * 1000, 'e' * 32: (self.now - 1) * 1000})['kind'], 'discussion')
        self.assertEqual(excluded, ['d' * 32])
        self.station.discussions = None
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')

    def test_preparation_state_is_visible_and_cleared_on_real_failure(self):
        station = self.station
        class FailingVoice:
            available_languages = ('ar',)
            engines = {'ar': 'test-only'}
            def synthesize(self, text, language):
                visible = station.manifest(language)['production']
                self.visible = visible
                station.stop.set()
                raise ValueError('Test failure without private details')
        voice = FailingVoice()
        station.tts_factory = lambda: voice
        station.ingest([self.story()])
        station.generate()
        self.assertTrue(voice.visible['preparing'])
        self.assertEqual(voice.visible['kind'], 'news')
        production = station.manifest('ar')['production']
        self.assertFalse(production['preparing'])
        self.assertIsNone(production['kind'])
        self.assertEqual(production['queuedSeconds'], 0)
        self.assertEqual(station.queues['ar'], [])
        self.assertNotIn('Test failure', station.errors['ar'])

    def test_rss_excludes_missing_future_bad_url_and_entities(self):
        stamp = 'Thu, 22 Oct 2026 11:00:00 GMT'
        received = 1792666860
        feed = server.FEEDS[0]
        xml = f'<rss><channel><item><title>خبر الاقتصاد</title><link>https://www.bbc.com/arabic/test</link><pubDate>{stamp}</pubDate></item></channel></rss>'.encode()
        rows = server.parse_feed(xml, feed, received)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['language'], 'ar')
        self.assertEqual(server.parse_feed(xml.replace(b'https://www.bbc.com', b'http://127.0.0.1'), feed, received), [])
        with self.assertRaises(ValueError):
            server.parse_feed(b'<!DOCTYPE x>' + xml, feed, received)
        self.assertEqual(server.parse_feed(xml, feed, 1), [])

    def test_complete_report_after_word_twenty_four_and_no_spoken_url(self):
        row = self.story(title=' '.join('word' + str(i) for i in range(45)))
        spoken = server.spoken_text(row)
        self.assertIn('word23', spoken)
        self.assertIn('word44', spoken)
        self.assertTrue(spoken.endswith('word44.'))
        self.assertEqual(server.plain('Read https://example.com/private now'), 'Read now')

    def test_social_source_attribution_and_author_clock_survive_the_real_news_path(self):
        row = self.story(social=True, sourceKind='social', platform='Telegram',
                         timeKind='published', source='العربية', url='https://t.me/AlArabiya/123')
        self.station.ingest([row])
        job = self.station._next_job('ar', self.now * 1000, {})
        self.assertEqual(job['kind'], 'news')
        self.assertTrue(job['social'])
        self.assertEqual(job['publishedAt'], row['publishedAt'])
        self.assertTrue(server.spoken_text(job).startswith('في منشور عام من العربية'))
        self.assertEqual(self.station.manifest('ar')['socialStories'], 1)
        row.update(id='b' * 32, title='خبر آخر عن الذهب', publishedAt=self.now - 900)
        self.station.ingest([row])
        self.station.seen['ar'].add(job['id'])
        earlier = self.station._candidate('ar', self.now)
        self.assertEqual(earlier['recency'], 'earlier')
        self.assertTrue(server.spoken_text(earlier).startswith('منشور سابق، وقته حسب المصدر'))
        self.assertNotIn('خبر سابق', server.spoken_text(earlier))

    def test_social_collector_runs_independently_and_exposes_aggregate_diagnostics(self):
        row = self.story(social=True, sourceKind='social', platform='Telegram', timeKind='published')
        state = {'status': 'ready', 'sourceCount': 2, 'readySources': 1, 'checkedAt': self.now * 1000}
        def collect():
            self.station.stop.set()
            return [row]
        self.station.social_sources = SimpleNamespace(collect=collect, status=lambda: state)
        self.station.collect_social()
        manifest = self.station.manifest('ar')
        self.assertEqual(manifest['socialSources'], state)
        self.assertEqual(manifest['socialStories'], 1)
        self.assertFalse(manifest['dependencies']['pcRequired'])

    def test_retrieved_teaser_adds_detail_without_repeating_title_or_exceeding_budget(self):
        row = self.story(language='en', title='Gold rises', source='Publisher',
                         summary='Gold rises. Investors review the latest inflation figures and treasury yields. ' + 'extra ' * 30)
        spoken = server.spoken_text(row)
        self.assertEqual(spoken.count('Gold rises'), 1)
        self.assertIn('Investors review', spoken)
        self.assertLess(len(spoken), 1200)
        self.assertNotIn('extra', spoken)
        long = self.story(language='en', title='Gold prices rise as investors weigh the latest inflation data and the outlook for interest rates',
                          summary='Analysts are reviewing the figures before making any conclusions about future monetary policy decisions.')
        self.assertIn('Analysts', server.spoken_text(long), 'the whole retrieved sentence now fits')

    def test_latest_news_precedes_higher_scoring_unspoken_earlier_reports(self):
        earlier = self.story(id='b' * 32, language='en', title='Gold prices rise as inflation falls',
                             publishedAt=self.now - 900, firstSeenAt=self.now - 850)
        latest = self.story(language='en', title='Inflation figures released')
        self.station.ingest([earlier, latest])
        job = self.station._candidate('en', self.now)
        self.assertEqual((job['id'], job['recency']), (latest['id'], 'fresh'))
        self.station.seen['en'].add(job['id'])
        job = self.station._candidate('en', self.now)
        self.assertEqual((job['id'], job['recency']), (earlier['id'], 'earlier'))
        self.assertTrue(server.Station._job_fresh({**job, 'kind': 'news'}, self.now * 1000))
        spoken = server.spoken_text(job)
        stamp = datetime.fromtimestamp(earlier['publishedAt'], timezone.utc).strftime('%H:%M')
        self.assertTrue(spoken.startswith('Earlier report, published at ' + stamp + ' UTC.'))
        self.station.seen['en'].add(job['id'])
        self.assertIsNone(self.station._candidate('en', self.now))

    def test_earlier_cohort_has_a_hard_two_hour_boundary_and_honest_arabic_prefix(self):
        outside = self.story(publishedAt=self.now - 7201, firstSeenAt=self.now - 7100)
        self.station.ingest([outside])
        self.assertIsNone(self.station._candidate('ar', self.now))
        earlier = self.story(id='c' * 32, title='خبر آخر عن أسعار الذهب',
                             publishedAt=self.now - 7100, firstSeenAt=self.now - 7000)
        self.station.ingest([earlier])
        job = self.station._candidate('ar', self.now)
        self.assertEqual(job['recency'], 'earlier')
        self.assertIn('خبر سابق نُشر الساعة', server.spoken_text(job))
        self.assertFalse(server.Station._job_fresh({**job, 'kind': 'news'}, (self.now + 101) * 1000))
        manifest = self.station.manifest('ar', self.now * 1000)
        self.assertEqual(manifest['newsSelection']['selectedCount'], 0)
        self.assertEqual(manifest['earlierNewsSelection']['unreadSelectedCount'], 1)
        self.assertEqual(manifest['earlierNewsSelection']['minimumAgeSeconds'], 601)

    def test_manifest_clock_and_types(self):
        now = self.now * 1000
        self.station.languages = ('ar',)
        self.station.status = 'ready'
        self.station.queues['ar'] = [{'id': 'c' * 32, 'startsAt': now - 1000, 'endsAt': now + 5000, 'language': 'ar'}]
        m = self.station.manifest('ar', now)
        self.assertEqual(m['status'], 'live')
        self.assertEqual(m['nowPlaying']['id'], 'c' * 32)
        self.assertIs(type(m['serverTime']), int)
        self.assertEqual(self.station.manifest('en', now)['status'], 'waiting')
        self.assertNotIn('directory', json.dumps(m))

    def test_cloud_station_ignores_legacy_pc_importer_flag(self):
        with patch.dict(server.os.environ, {'RADIO_PUBLIC_DISCUSSIONS': '1'}):
            station = server.Station(self.temporary.name)
        self.assertIsNone(station.discussions)
        manifest = station.manifest('ar', max(self.now * 1000, station.started_at))
        self.assertEqual(manifest['mode'], 'cloud-news')
        self.assertFalse(manifest['dependencies']['pcRequired'])
        self.assertFalse(manifest['discussions']['enabled'])

    def test_cloud_live_updates_feed_the_actual_ranked_news_queue(self):
        station = self.station
        row = self.story(id='e' * 32, title='Treasury yields fall after inflation report',
                         language='en', source=server.LIVE_SOURCE,
                         url='https://www.aljazeera.com/news/liveblog/2026/10/23/current?update=2001')
        class FakeLive:
            def collect(self):
                station.stop.set()
                return [row]
            def status(self):
                return {'status': 'ready', 'checkedAt': station.now_for_test * 1000}
        station.now_for_test = self.now
        station.live_updates = FakeLive()
        station.collect_live_updates()
        self.assertEqual(station._candidate('en', self.now)['id'], row['id'])
        manifest = station.manifest('en', self.now * 1000)
        self.assertEqual(manifest['liveUpdates']['status'], 'ready')
        self.assertEqual(manifest['feedsReached'], 1)
        self.assertEqual(manifest['feedCount'], len(server.FEEDS) + 1)

    def test_all_eligible_relevant_reports_are_available_after_receipts(self):
        rows = [self.story(id=format(i, '032x'), title=f'Gold prices market report {i}', language='en',
                          publishedAt=self.now - i - 1, firstSeenAt=self.now) for i in range(10)]
        rows.append(self.story(id='f' * 32, title='Football final tonight', language='en'))
        self.station.ingest(rows)
        selection = self.station.manifest('en', self.now * 1000)['newsSelection']
        self.assertEqual((selection['freshCount'], selection['relevantCount'], selection['selectedCount']), (11, 10, 10))
        for _ in range(10):
            job = self.station._candidate('en', self.now)
            self.assertIsNotNone(job)
            self.assertIn('gold', job['relevance']['topics'])
            self.station.seen['en'].add(job['id'])
        self.assertIsNone(self.station._candidate('en', self.now))
        selection = self.station.manifest('en', self.now * 1000)['newsSelection']
        self.assertEqual((selection['scheduledSelectedCount'], selection['unreadSelectedCount']), (10, 0))

    def test_irrelevant_feed_does_not_keep_speech_in_false_preparing_state(self):
        self.station.ingest([self.story(title='Football final tonight', language='en')])
        manifest = self.station.manifest('en', self.now * 1000)
        self.assertEqual(manifest['freshStories'], 1)
        self.assertEqual(manifest['unreadFreshStories'], 0)
        self.assertIsNone(self.station._candidate('en', self.now))

    def test_prune_preserves_current_and_future_even_with_short_clip_history(self):
        now = self.now * 1000
        self.station.queues['ar'] = [{'id': format(i, '032x'), 'startsAt': now - 20000 + i * 1000,
                                     'endsAt': now - 19000 + i * 1000} for i in range(26)]
        current = next(q['id'] for q in self.station.queues['ar'] if q['startsAt'] <= now < q['endsAt'])
        self.station._prune(now)
        self.assertIn(current, [q['id'] for q in self.station.queues['ar']])
        self.assertEqual(sum(q['endsAt'] > now for q in self.station.queues['ar']), 6)

    def test_only_known_scheduled_audio_can_be_read(self):
        identifier = 'd' * 32
        (self.station.directory / (identifier + '.wav')).write_bytes(b'RIFF' + b'0' * 64)
        self.assertIsNone(self.station.audio(identifier))
        self.station.queues['ar'].append({'id': identifier, 'endsAt': int(time.time() * 1000) + 10000})
        self.assertEqual(len(self.station.audio(identifier)), 68)
        self.assertIsNone(self.station.audio('e' * 32))

    def test_owner_generator_publishes_real_typed_audio_without_language_fallback(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        station = self.station
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar': 'fake-test-only'}
            def synthesize(self, text, language):
                self.called_language = language
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1.0, engine='fake-test-only', language=language, inference_s=.01)
        voice = FakeTts()
        self.station.tts_factory = lambda: voice
        self.station.ingest([self.story(social=True, sourceKind='social', platform='Telegram', timeKind='published')])
        self.station.generate()
        self.assertEqual(voice.called_language, 'ar')
        self.assertEqual(len(self.station.queues['ar']), 1)
        self.assertEqual(self.station.queues['en'], [])
        segment = self.station.queues['ar'][0]
        self.assertEqual(segment['language'], 'ar')
        self.assertEqual(segment['engine'], 'fake-test-only')
        self.assertTrue(segment['social'])
        self.assertTrue(segment['authorTimeUnverified'])
        self.assertEqual((segment['sourceKind'], segment['platform'], segment['timeKind']),
                         ('social', 'Telegram', 'published'))
        self.assertEqual(segment['endsAt'] - segment['startsAt'], 1000)
        self.assertEqual(station.last_news_source['ar'], 'الجزيرة')
        self.assertIn('gold', station.last_news_topics['ar'])
        self.assertLess(station.speech_seconds_per_character['ar'], .08)
        self.assertGreaterEqual(segment['startsAt'], self.now * 1000 + 6000)
        with wave.open(io.BytesIO(self.station.audio(segment['id'])), 'rb') as w:
            self.assertEqual(w.getnframes(), 24000)

    def test_private_speech_check_rejects_silence_and_wrong_duration(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        speech = SimpleNamespace(wav=data.getvalue(), duration_s=1.0, engine='test-only', language='ar')
        self.assertEqual(server.speech_check(speech, 'ar')['status'], 'ready')
        self.assertEqual(self.station.queues, {'ar': [], 'en': []})
        speech.duration_s = 2.0
        with self.assertRaises(ValueError):
            server.speech_check(speech, 'ar')
        speech.duration_s = 1.0
        speech.wav = data.getvalue()[:44] + b'\x00\x00' * 24000
        with self.assertRaises(ValueError):
            server.speech_check(speech, 'ar')

    def test_full_bulletin_over_old_45_second_limit_is_preserved(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
            w.writeframes(b'\x01\x00' * (24000 * 61))
        speech = SimpleNamespace(wav=data.getvalue(), duration_s=61.0, engine='test-only', language='ar')
        self.assertEqual(server.speech_check(speech, 'ar')['durationSeconds'], 61)

    def test_music_budget_uses_complete_duration_and_compensates_prior_music(self):
        now = self.now * 1000
        self.station.airtime['ar'] = server.AirtimeMix(now)
        start = self.station._scheduled_start('ar', now, 40)
        self.assertEqual(start, now + 6000)
        self.station.airtime['ar'].commit(start, start + 40000, 'podcast')
        self.station.queues['ar'] = [{'kind': 'podcast', 'startsAt': start, 'endsAt': start + 40000}]
        second = self.station._scheduled_start('ar', now + 20000, 20)
        self.assertEqual(second, now + 50000)
        self.station.airtime['ar'].commit(second, second + 20000, 'news')
        snapshot = self.station.manifest('ar', now + 75000)['programmeMix']
        self.assertEqual((snapshot['musicTargetPercent'], snapshot['contentTargetPercent']), (20, 80))
        self.assertEqual(snapshot['observed']['musicPercent'], 20)
        self.assertEqual(snapshot['observed']['spokenPercent'], 80)

    def test_gold_briefing_gets_a_cadenced_slot_after_news_and_supplies_real_evidence(self):
        self.baseline_price(price=4010, offset=-360)
        for seconds, price in ((-300, 4020), (-60, 4024), (0, 4023)):
            self.station.market.observe(parse_quote({'symbol': 'XAU', 'price': price,
                'updatedAt': datetime.fromtimestamp(self.now + seconds, timezone.utc).isoformat()}, self.now + seconds))
        self.station.ingest([self.story()])
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')
        self.station.news_streak['ar'] = server.NEWS_BURST_LIMIT
        analysis = self.station._next_job('ar', self.now * 1000, {})
        self.assertEqual(analysis['kind'], 'analysis')
        self.assertIn('4023.00', analysis['speechText'])
        self.assertFalse(analysis['analysis']['forecast'])
        self.assertFalse(self.station._job_fresh(analysis, (self.now + 91) * 1000))
        self.station.last_analysis_at['ar'] = self.now * 1000
        self.station.last_market_at['ar'] = self.now * 1000
        self.assertEqual(self.station._next_job('ar', (self.now + 30) * 1000, {})['kind'], 'news')

    def test_retired_inflight_discussion_is_not_published_or_left_as_public_audio(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        station = self.station
        job = {'id': 'd' * 32, 'kind': 'discussion', 'language': 'ar', 'title': 'حوار تجريبي',
            'source': 'Gold Pulse', 'url': 'https://g.au7.workers.dev/?radio=1',
            'publishedAt': self.now - 10, 'firstSeenAt': self.now, 'speechText': 'حوار تجريبي للاختبار فقط.',
            'speaker': 'المذيعة', 'sources': [], 'programme': {'windowEnd': (self.now - 10) * 1000,
                'generatedAt': (self.now - 5) * 1000}}
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar': 'fake-test-only'}
            def synthesize(self, text, language):
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1.0, engine='fake-test-only', language=language)
        station.tts_factory = FakeTts
        station.discussions = SimpleNamespace(candidate=lambda *_args, **_kwargs: job, consume=lambda _job: False)
        station.generate()
        self.assertEqual(station.queues['ar'], [])
        self.assertEqual(list(station.directory.glob('*.wav')), [])
        self.assertIsNone(station.last_prepared['ar'])
        self.assertIsNone(station.preparing['ar'])

    def test_quiet_programme_fills_gaps_but_unspoken_news_keeps_priority(self):
        self.station.programmes = server.ProgrammeLibrary()
        self.assertIsNone(self.station._next_job('ar', self.now * 1000, {}))
        self.news_budget('ar')
        job = self.station._next_job('ar', self.now * 1000, {})
        self.assertEqual(job['kind'], 'podcast')
        self.assertTrue(job['programme']['educational'])
        self.assertFalse(job['programme']['currentNews'])
        self.assertFalse(job['programme']['forecast'])
        self.assertTrue(self.station._job_fresh(job, (self.now + 3600) * 1000))
        self.assertFalse(self.station._job_fresh({**job, 'programme': {**job['programme'], 'currentNews': True}}, self.now * 1000))
        self.station.ingest([self.story()])
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')
        self.station.seen['ar'].add('a' * 32)
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['id'], job['id'])

    def test_roundup_consumes_each_original_report_once_after_audio_is_queued(self):
        rows = [self.story(id=format(i, '032x'), title='Gold market and oil report ' + str(i),
            source='Publisher ' + str(i), language='en') for i in range(1, 4)]
        self.station.ingest(rows)
        self.station.news_streak['en'] = 3
        job = self.station._next_job('en', self.now * 1000, {})
        self.assertEqual(job['kind'], 'news-context')
        self.assertEqual(self.station.seen['en'], set())
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 24000)
        station = self.station
        class FakeTts:
            available_languages = ('en',)
            engines = {'en': 'fake'}
            def synthesize(self, text, language):
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1, engine='fake', language=language)
        station.tts_factory = FakeTts
        station.generate()
        clip = station.queues['en'][0]
        self.assertEqual(set(clip['sourceIds']), station.seen['en'])
        self.assertIsNone(station._candidate('en', self.now))
        self.assertEqual(station.airtime['en'].snapshot(clip['endsAt'])['newsSeconds'], 1)
        self.assertFalse(station._job_fresh(job, (self.now + 601) * 1000))

    def test_podcast_cache_is_separate_for_actual_cast_role(self):
        self.station.programmes = server.ProgrammeLibrary()
        job = self.station.programmes.candidate('en', self.now)
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 24000)
        calls = []
        class FakeTts:
            engines = {'en': 'fake'}
            def synthesize(self, text, language, voice_profile=None):
                calls.append(voice_profile)
                return SimpleNamespace(wav=data.getvalue(), duration_s=1, engine='fake', language=language,
                    cast={'profile': voice_profile, 'gender': 'Male' if voice_profile == 'analyst' else 'Female'})
        tts = FakeTts()
        first, cached, _ = self.station._speech_for_job(tts, job, 'Same public test text.')
        altered = {**job, 'programme': {**job['programme'], 'speakerRole': 'analyst'}}
        second, cached, _ = self.station._speech_for_job(tts, altered, 'Same public test text.')
        self.assertFalse(cached)
        replay, cached, _ = self.station._speech_for_job(tts, altered, 'Same public test text.')
        self.assertTrue(cached)
        self.assertEqual(calls, ['host', 'analyst'])
        self.assertEqual(replay.cast, second.cast)
        self.assertEqual(replay.cast['gender'], 'Male')

    def test_actual_long_podcast_cannot_spend_more_news_budget_than_estimated(self):
        station = self.station
        station.programmes = server.ProgrammeLibrary()
        station.airtime['ar'].commit((self.now-60)*1000, self.now*1000, 'news')
        offered = station._next_job('ar', self.now*1000, {})
        self.assertEqual(offered['kind'], 'podcast')
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * (24000*50))
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar': 'fake'}
            def synthesize(self, text, language, voice_profile=None):
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=50, engine='fake', language=language)
        station.tts_factory = FakeTts
        with patch.object(server.time, 'time', return_value=self.now):
            station.generate()
        self.assertEqual(station.queues['ar'], [])
        self.assertEqual(station.programmes.status('ar', self.now)['turnIndex'], 0)
        self.assertEqual(station.seen['ar'], set())
        self.assertEqual(list(station.directory.glob('*.wav')), [])
        self.assertEqual(station.airtime['ar'].snapshot(self.now*1000)['plannedSpeechSeconds'], 0)

    def test_slow_arabic_preparation_gaps_do_not_reset_news_programme_count(self):
        station = self.station
        station.ingest([self.story(id=format(i,'032x'), title='Gold market report '+str(i)) for i in range(4)])
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 24000)
        clock = {'now':self.now, 'calls':0}
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar':'fake'}
            def synthesize(self, text, language):
                clock['calls'] += 1
                clock['now'] += 30
                if clock['calls'] == 4:
                    station.stop.set()
                return SimpleNamespace(wav=data.getvalue(),duration_s=1,engine='fake',language=language)
        station.tts_factory = FakeTts
        with patch.object(server.time,'time',side_effect=lambda:clock['now']):
            station.generate()
        self.assertEqual(clock['calls'],4)
        self.assertEqual(station.news_streak['ar'],4)

    def test_recorded_podcast_audio_is_cached_without_resynthesizing_or_advancing(self):
        self.station.programmes = server.ProgrammeLibrary()
        job = self.station.programmes.candidate('en', self.now)
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 24000)
        calls = []
        class FakeTts:
            engines = {'en': 'fake-test-only'}
            def synthesize(self, text, language, voice_profile=None):
                calls.append((text, language, voice_profile))
                return SimpleNamespace(wav=data.getvalue(), duration_s=1, engine='fake-test-only',
                                       language=language, inference_s=.1)
        tts = FakeTts()
        first, cached, recorded = self.station._speech_for_job(tts, job, job['speechText'])
        self.assertFalse(cached)
        second, cached, second_recorded = self.station._speech_for_job(tts, job, job['speechText'])
        self.assertTrue(cached)
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][2], 'host')
        self.assertEqual((first.wav, recorded), (second.wav, second_recorded))
        self.assertEqual(second.inference_s, 0)
        self.assertEqual(self.station.programmes.status('en', self.now)['turnIndex'], 0)

    def test_queued_podcast_commits_airtime_and_progress_without_marking_news_seen(self):
        station = self.station
        station.programmes = server.ProgrammeLibrary()
        self.news_budget('ar')
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 24000)
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar': 'fake-test-only'}
            def synthesize(self, text, language, voice_profile=None):
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1, engine='fake-test-only', language=language)
        station.tts_factory = FakeTts
        station.generate()
        self.assertEqual(len(station.queues['ar']), 1)
        clip = station.queues['ar'][0]
        self.assertEqual(clip['kind'], 'podcast')
        self.assertEqual(clip['audioSource'], 'recorded-podcast')
        self.assertEqual(clip['programme']['mode'], 'recorded-educational')
        self.assertEqual(station.programmes.status('ar', self.now)['turnIndex'], 1)
        self.assertEqual(station.seen['ar'], set())
        observed = station.manifest('ar', clip['endsAt'])['programmeMix']['observed']
        self.assertEqual(observed['speechSeconds'], 181)
        self.assertEqual(clip['voiceProfile'], 'host')
        self.assertTrue((station.directory / (clip['id'] + '.wav')).is_file())

    def test_independent_language_producers_can_prepare_at_the_same_time(self):
        station = self.station
        station.ingest([self.story(), self.story(id='b' * 32, language='en', title='Gold market report')])
        barrier = threading.Barrier(2)
        entered = []
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 24000)
        class FakeTts:
            available_languages = ('ar', 'en')
            engines = {'ar': 'fake-test-only', 'en': 'fake-test-only'}
            def synthesize(self, text, language):
                entered.append(language)
                try:
                    barrier.wait(timeout=2)
                finally:
                    station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1, engine='fake-test-only', language=language)
        station.tts_factory = FakeTts
        station.generate()
        self.assertCountEqual(entered, ['ar', 'en'])
        self.assertEqual([len(station.queues[lang]) for lang in ('ar', 'en')], [1, 1])

    def test_manifest_music_clock_freezes_during_speech_then_resumes(self):
        now = self.now * 1000
        station = self.station
        station.airtime['en'] = server.AirtimeMix(now)
        station.airtime['en'].commit(now + 10000, now + 30000, 'news')
        station.music_data = b'test-only-music-present'
        station.queues['en'] = [{'id': 'd' * 32, 'startsAt': now + 10000, 'endsAt': now + 30000}]
        first = station.manifest('en', now + 12000)['music']
        later = station.manifest('en', now + 28000)['music']
        resumed = station.manifest('en', now + 35000)['music']
        self.assertEqual((first['positionSeconds'], later['positionSeconds']), (10, 10))
        self.assertFalse(first['playing'])
        self.assertEqual(resumed['positionSeconds'], 15)
        self.assertTrue(resumed['playing'])

    def test_allowlisted_music_streams_byte_ranges_without_public_file_access(self):
        path = pathlib.Path(self.temporary.name) / 'licensed-test.mp3'
        data = b'ID3' + bytes(range(64))
        path.write_bytes(data)
        self.station.music_library = SimpleNamespace(asset=lambda identifier: path if identifier == 'test-track' else None)
        http = server.RadioHttpServer(('127.0.0.1', 0), server.make_handler(self.station))
        thread = threading.Thread(target=http.serve_forever, daemon=True)
        thread.start()
        base = 'http://127.0.0.1:' + str(http.server_port)
        try:
            request = urllib.request.Request(base + '/music/test-track.mp3', headers={'Range': 'bytes=3-7'})
            with urllib.request.urlopen(request) as response:
                self.assertEqual(response.status, 206)
                self.assertEqual(response.headers['Content-Range'], f'bytes 3-7/{len(data)}')
                self.assertEqual(response.read(), data[3:8])
            with urllib.request.urlopen(urllib.request.Request(base + '/music/test-track.mp3', method='HEAD')) as response:
                self.assertEqual(int(response.headers['Content-Length']), len(data))
                self.assertEqual(response.read(), b'')
            for url, headers, status in (
                    ('/music/test-track.mp3', {'Range': 'bytes=999-1000'}, 416),
                    ('/music/test-track.mp3', {'Range': 'bytes=1-2,4-5'}, 416),
                    ('/music/test-track.mp3?url=private', {}, 404),
                    ('/music/unknown.mp3', {}, 404), ('/music/../server.py', {}, 404)):
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(urllib.request.Request(base + url, headers=headers))
                self.assertEqual(error.exception.code, status)
        finally:
            http.shutdown(); http.server_close(); thread.join()

    def test_http_is_read_only_bounded_and_does_not_leak_paths(self):
        self.station.music_data = compose()
        http = server.RadioHttpServer(('127.0.0.1', 0), server.make_handler(self.station))
        thread = threading.Thread(target=http.serve_forever, daemon=True)
        thread.start()
        base = 'http://127.0.0.1:' + str(http.server_port)
        try:
            with urllib.request.urlopen(base + '/health') as response:
                health = json.load(response)
                self.assertTrue(health['ok'])
                self.assertTrue(health['musicReady'])
                self.assertEqual(response.headers['X-Content-Type-Options'], 'nosniff')
                self.assertNotIn('Python', response.headers['Server'])
            with urllib.request.urlopen(base + '/radio.json?language=ar') as response:
                body = response.read().decode()
                self.assertNotIn(self.temporary.name, body)
                self.assertEqual(json.loads(body)['language'], 'ar')
                self.assertEqual(json.loads(body)['music']['audioUrl'], '/' + MUSIC_FILE)
            with urllib.request.urlopen(base + '/' + MUSIC_FILE) as response:
                self.assertIn('max-age=86400', response.headers['Cache-Control'])
                with wave.open(io.BytesIO(response.read()), 'rb') as audio:
                    self.assertEqual((audio.getnchannels(), audio.getsampwidth(), audio.getframerate()), (1, 2, 24000))
                    self.assertEqual(audio.getnframes(), MUSIC_SECONDS * 24000)
                    self.assertTrue(any(audio.readframes(audio.getnframes())))
            for path in ('/radio.json?language=ar&language=en', '/radio.json?language=xx', '/radio.json?url=http://127.0.0.1', '/audio/../../server.py', '/tts', '/health?path=test', '/' + MUSIC_FILE + '?url=test'):
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(base + path)
                self.assertEqual(error.exception.code, 404)
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(urllib.request.Request(base + '/tts', data=b'{}', method='POST'))
            self.assertEqual(error.exception.code, 405)
        finally:
            http.shutdown()
            http.server_close()
            thread.join()

    def test_recent_news_is_separate_from_live_queue(self):
        now = self.now * 1000
        self.station.queues['ar'] = [{'id': 'c' * 32, 'startsAt': now - 5000, 'endsAt': now - 1000}]
        manifest = self.station.manifest('ar', now)
        self.assertEqual(manifest['queue'], [])
        self.assertEqual(manifest['recent'][0]['id'], 'c' * 32)

    def test_music_interruption_is_a_normal_browser_disconnect(self):
        handler = object.__new__(server.make_handler(self.station))
        for method in (handler.do_GET, handler.do_HEAD):
            with patch.object(handler, 'route', side_effect=BrokenPipeError):
                method()
            self.assertTrue(handler.close_connection)
        with patch.object(handler, 'route', side_effect=ValueError('unexpected')):
            with self.assertRaises(ValueError):
                handler.do_GET()

    def test_economic_discovery_rows_enter_normal_source_clocked_news_queue(self):
        station = self.station
        row = self.story(id='e'*32, language='en', title='Oil supplies fall as energy demand rises',
            source='Reuters via Google News', sourceKind='publisher-aggregator')
        class FakeDiscovery:
            def collect(self):
                station.stop.set()
                return [row]
            def status(self):
                return {'sourceCount':6, 'readySources':6, 'status':'ready'}
        station.economic_feeds = FakeDiscovery()
        station.collect_economic_feeds()
        self.assertEqual(station._candidate('en', self.now)['id'], row['id'])
        self.assertEqual(station.manifest('en', self.now*1000)['economicFeeds']['readySources'], 6)


if __name__ == '__main__':
    unittest.main()

import importlib.util
import io
import json
import pathlib
import tempfile
import threading
import time
import unittest
from types import SimpleNamespace
import wave
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

import server
from station_music import compose, MUSIC_FILE, MUSIC_SECONDS
from market_brief import parse_quote
from datetime import datetime, timezone


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.station = server.Station(self.temporary.name)
        self.now = int(time.time())

    def tearDown(self):
        self.station.stop.set()
        self.temporary.cleanup()

    def story(self, **changes):
        row = {'id': 'a' * 32, 'title': 'خبر جديد عن الاقتصاد وأسعار الذهب', 'source': 'الجزيرة',
               'url': 'https://www.aljazeera.net/news/test', 'language': 'ar',
               'publishedAt': self.now - 20, 'firstSeenAt': self.now - 10}
        return {**row, **changes}

    def test_fresh_requires_real_publication_and_earliest_receipt(self):
        self.assertTrue(server.fresh(self.story(), self.now))
        for row in (self.story(publishedAt=self.now - 601), self.story(firstSeenAt=self.now + 1),
                    self.story(publishedAt=self.now + 1), self.story(publishedAt=True)):
            self.assertFalse(server.fresh(row, self.now))
        self.station.ingest([self.story()])
        self.station.ingest([self.story(firstSeenAt=self.now, publishedAt=self.now - 5)])
        row = self.station.stories['a' * 32]
        self.assertEqual(row['firstSeenAt'], self.now - 10)
        self.assertEqual(row['publishedAt'], self.now - 20)

    def test_oldest_fresh_first_dedup_and_consumption(self):
        old = self.story()
        new = self.story(id='b' * 32, publishedAt=self.now - 5, firstSeenAt=self.now - 4)
        self.station.ingest([new, old])
        self.assertEqual(self.station._candidate('ar', self.now)['id'], old['id'])
        self.station.seen['ar'].add(old['id'])
        self.assertEqual(self.station._candidate('ar', self.now)['id'], new['id'])
        self.assertIsNone(self.station._candidate('en', self.now))

    def test_retrying_oldest_news_does_not_starve_other_fresh_speech(self):
        old = self.story()
        new = self.story(id='b' * 32, publishedAt=self.now - 5, firstSeenAt=self.now - 4)
        self.station.ingest([old, new])
        retry = {old['id']: (self.now + 30) * 1000}
        self.assertEqual(self.station._candidate('ar', self.now, retry)['id'], new['id'])

    def test_news_priority_and_market_cadence_use_source_clock(self):
        quote = parse_quote({'symbol': 'XAU', 'price': 4023.25,
            'updatedAt': datetime.fromtimestamp(self.now - 5, timezone.utc).isoformat()}, self.now)
        self.station.market.observe(quote)
        job = self.station._next_job('ar', self.now * 1000, {})
        self.assertEqual(job['kind'], 'market')
        self.assertTrue(self.station._job_fresh(job, (self.now + 60) * 1000))
        self.assertFalse(self.station._job_fresh(job, (self.now + 86) * 1000))
        self.station.ingest([self.story()])
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')
        self.station.seen['ar'].add('a' * 32)
        self.station.last_market_at['ar'] = self.now * 1000
        self.assertIsNone(self.station._next_job('ar', (self.now + 30) * 1000, {}))
        self.assertIsNone(self.station._next_job('ar', (self.now + 100) * 1000, {}))

    def test_busy_headlines_allow_due_market_and_discussion_after_bounded_burst(self):
        self.station.ingest([self.story()])
        self.station.market.observe(parse_quote({'symbol': 'XAU', 'price': 4023.25,
            'updatedAt': datetime.fromtimestamp(self.now - 5, timezone.utc).isoformat()}, self.now))
        self.station.news_streak['ar'] = server.NEWS_BURST_LIMIT
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'market')
        self.station.last_market_at['ar'] = self.now * 1000
        excluded = []
        def candidate(language, stamp, exclude_ids=()):
            excluded.extend(exclude_ids)
            return {'kind': 'discussion', 'id': 'c' * 32, 'language': language}
        self.station.discussions = SimpleNamespace(candidate=candidate)
        self.assertEqual(self.station._next_job('ar', self.now * 1000,
            {'d' * 32: (self.now + 30) * 1000, 'e' * 32: (self.now - 1) * 1000})['kind'], 'discussion')
        self.assertEqual(excluded, ['d' * 32])
        self.station.discussions = None
        self.assertEqual(self.station._next_job('ar', self.now * 1000, {})['kind'], 'news')

    def test_preparation_state_is_visible_and_cleared_on_real_failure(self):
        station = self.station
        class FailingVoice:
            available_languages = ('ar',)
            engines = {'ar': 'test-only'}
            def synthesize(self, text, language):
                visible = station.manifest(language)['production']
                self.visible = visible
                station.stop.set()
                raise ValueError('Test failure without private details')
        voice = FailingVoice()
        station.tts_factory = lambda: voice
        station.ingest([self.story()])
        station.generate()
        self.assertTrue(voice.visible['preparing'])
        self.assertEqual(voice.visible['kind'], 'news')
        production = station.manifest('ar')['production']
        self.assertFalse(production['preparing'])
        self.assertIsNone(production['kind'])
        self.assertEqual(production['queuedSeconds'], 0)
        self.assertEqual(station.queues['ar'], [])
        self.assertNotIn('Test failure', station.errors['ar'])

    def test_rss_excludes_missing_future_bad_url_and_entities(self):
        stamp = 'Thu, 22 Oct 2026 11:00:00 GMT'
        received = 1792666860
        feed = server.FEEDS[0]
        xml = f'<rss><channel><item><title>خبر الاقتصاد</title><link>https://www.bbc.com/arabic/test</link><pubDate>{stamp}</pubDate></item></channel></rss>'.encode()
        rows = server.parse_feed(xml, feed, received)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['language'], 'ar')
        self.assertEqual(server.parse_feed(xml.replace(b'https://www.bbc.com', b'http://127.0.0.1'), feed, received), [])
        with self.assertRaises(ValueError):
            server.parse_feed(b'<!DOCTYPE x>' + xml, feed, received)
        self.assertEqual(server.parse_feed(xml, feed, 1), [])

    def test_excerpt_limit_and_no_spoken_url(self):
        row = self.story(title=' '.join('word' + str(i) for i in range(45)))
        spoken = server.spoken_text(row)
        self.assertIn('word23', spoken)
        self.assertNotIn('word24', spoken)
        self.assertEqual(server.plain('Read https://example.com/private now'), 'Read now')

    def test_manifest_clock_and_types(self):
        now = self.now * 1000
        self.station.languages = ('ar',)
        self.station.status = 'ready'
        self.station.queues['ar'] = [{'id': 'c' * 32, 'startsAt': now - 1000, 'endsAt': now + 5000, 'language': 'ar'}]
        m = self.station.manifest('ar', now)
        self.assertEqual(m['status'], 'live')
        self.assertEqual(m['nowPlaying']['id'], 'c' * 32)
        self.assertIs(type(m['serverTime']), int)
        self.assertEqual(self.station.manifest('en', now)['status'], 'waiting')
        self.assertNotIn('directory', json.dumps(m))

    def test_prune_preserves_current_and_future_even_with_short_clip_history(self):
        now = self.now * 1000
        self.station.queues['ar'] = [{'id': format(i, '032x'), 'startsAt': now - 20000 + i * 1000,
                                     'endsAt': now - 19000 + i * 1000} for i in range(26)]
        current = next(q['id'] for q in self.station.queues['ar'] if q['startsAt'] <= now < q['endsAt'])
        self.station._prune(now)
        self.assertIn(current, [q['id'] for q in self.station.queues['ar']])
        self.assertEqual(sum(q['endsAt'] > now for q in self.station.queues['ar']), 6)

    def test_only_known_scheduled_audio_can_be_read(self):
        identifier = 'd' * 32
        (self.station.directory / (identifier + '.wav')).write_bytes(b'RIFF' + b'0' * 64)
        self.assertIsNone(self.station.audio(identifier))
        self.station.queues['ar'].append({'id': identifier, 'endsAt': int(time.time() * 1000) + 10000})
        self.assertEqual(len(self.station.audio(identifier)), 68)
        self.assertIsNone(self.station.audio('e' * 32))

    def test_owner_generator_publishes_real_typed_audio_without_language_fallback(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        station = self.station
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar': 'fake-test-only'}
            def synthesize(self, text, language):
                self.called_language = language
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1.0, engine='fake-test-only', language=language, inference_s=.01)
        voice = FakeTts()
        self.station.tts_factory = lambda: voice
        self.station.ingest([self.story()])
        self.station.generate()
        self.assertEqual(voice.called_language, 'ar')
        self.assertEqual(len(self.station.queues['ar']), 1)
        self.assertEqual(self.station.queues['en'], [])
        segment = self.station.queues['ar'][0]
        self.assertEqual(segment['language'], 'ar')
        self.assertEqual(segment['engine'], 'fake-test-only')
        self.assertEqual(segment['endsAt'] - segment['startsAt'], 1000)
        self.assertGreaterEqual(segment['startsAt'], self.now * 1000 + 6000)
        with wave.open(io.BytesIO(self.station.audio(segment['id'])), 'rb') as w:
            self.assertEqual(w.getnframes(), 24000)

    def test_private_speech_check_rejects_silence_and_wrong_duration(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        speech = SimpleNamespace(wav=data.getvalue(), duration_s=1.0, engine='test-only', language='ar')
        self.assertEqual(server.speech_check(speech, 'ar')['status'], 'ready')
        self.assertEqual(self.station.queues, {'ar': [], 'en': []})
        speech.duration_s = 2.0
        with self.assertRaises(ValueError):
            server.speech_check(speech, 'ar')
        speech.duration_s = 1.0
        speech.wav = data.getvalue()[:44] + b'\x00\x00' * 24000
        with self.assertRaises(ValueError):
            server.speech_check(speech, 'ar')

    def test_retired_inflight_discussion_is_not_published_or_left_as_public_audio(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        station = self.station
        job = {'id': 'd' * 32, 'kind': 'discussion', 'language': 'ar', 'title': 'حوار تجريبي',
            'source': 'Gold Pulse', 'url': 'https://g.au7.workers.dev/?radio=1',
            'publishedAt': self.now - 10, 'firstSeenAt': self.now, 'speechText': 'حوار تجريبي للاختبار فقط.',
            'speaker': 'المذيعة', 'sources': [], 'programme': {'windowEnd': (self.now - 10) * 1000,
                'generatedAt': (self.now - 5) * 1000}}
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar': 'fake-test-only'}
            def synthesize(self, text, language):
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1.0, engine='fake-test-only', language=language)
        station.tts_factory = FakeTts
        station.discussions = SimpleNamespace(candidate=lambda *_args, **_kwargs: job, consume=lambda _job: False)
        station.generate()
        self.assertEqual(station.queues['ar'], [])
        self.assertEqual(list(station.directory.glob('*.wav')), [])
        self.assertIsNone(station.last_prepared['ar'])
        self.assertIsNone(station.preparing['ar'])

    def test_http_is_read_only_bounded_and_does_not_leak_paths(self):
        self.station.music_data = compose()
        http = server.RadioHttpServer(('127.0.0.1', 0), server.make_handler(self.station))
        thread = threading.Thread(target=http.serve_forever, daemon=True)
        thread.start()
        base = 'http://127.0.0.1:' + str(http.server_port)
        try:
            with urllib.request.urlopen(base + '/health') as response:
                health = json.load(response)
                self.assertTrue(health['ok'])
                self.assertTrue(health['musicReady'])
                self.assertEqual(response.headers['X-Content-Type-Options'], 'nosniff')
                self.assertNotIn('Python', response.headers['Server'])
            with urllib.request.urlopen(base + '/radio.json?language=ar') as response:
                body = response.read().decode()
                self.assertNotIn(self.temporary.name, body)
                self.assertEqual(json.loads(body)['language'], 'ar')
                self.assertEqual(json.loads(body)['music']['audioUrl'], '/' + MUSIC_FILE)
            with urllib.request.urlopen(base + '/' + MUSIC_FILE) as response:
                self.assertIn('max-age=86400', response.headers['Cache-Control'])
                with wave.open(io.BytesIO(response.read()), 'rb') as audio:
                    self.assertEqual((audio.getnchannels(), audio.getsampwidth(), audio.getframerate()), (1, 2, 24000))
                    self.assertEqual(audio.getnframes(), MUSIC_SECONDS * 24000)
                    self.assertTrue(any(audio.readframes(audio.getnframes())))
            for path in ('/radio.json?language=ar&language=en', '/radio.json?language=xx', '/radio.json?url=http://127.0.0.1', '/audio/../../server.py', '/tts', '/health?path=test', '/' + MUSIC_FILE + '?url=test'):
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(base + path)
                self.assertEqual(error.exception.code, 404)
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(urllib.request.Request(base + '/tts', data=b'{}', method='POST'))
            self.assertEqual(error.exception.code, 405)
        finally:
            http.shutdown()
            http.server_close()
            thread.join()

    def test_recent_news_is_separate_from_live_queue(self):
        now = self.now * 1000
        self.station.queues['ar'] = [{'id': 'c' * 32, 'startsAt': now - 5000, 'endsAt': now - 1000}]
        manifest = self.station.manifest('ar', now)
        self.assertEqual(manifest['queue'], [])
        self.assertEqual(manifest['recent'][0]['id'], 'c' * 32)


if __name__ == '__main__':
    unittest.main()

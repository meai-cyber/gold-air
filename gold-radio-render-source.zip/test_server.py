import importlib.util
import io
import json
import pathlib
import tempfile
import threading
import time
import unittest
from types import SimpleNamespace
import wave
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

import server


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.station = server.Station(self.temporary.name)
        self.now = int(time.time())

    def tearDown(self):
        self.station.stop.set()
        self.temporary.cleanup()

    def story(self, **changes):
        row = {'id': 'a' * 32, 'title': 'خبر جديد عن الاقتصاد وأسعار الذهب', 'source': 'الجزيرة',
               'url': 'https://www.aljazeera.net/news/test', 'language': 'ar',
               'publishedAt': self.now - 20, 'firstSeenAt': self.now - 10}
        return {**row, **changes}

    def test_fresh_requires_real_publication_and_earliest_receipt(self):
        self.assertTrue(server.fresh(self.story(), self.now))
        for row in (self.story(publishedAt=self.now - 601), self.story(firstSeenAt=self.now + 1),
                    self.story(publishedAt=self.now + 1), self.story(publishedAt=True)):
            self.assertFalse(server.fresh(row, self.now))
        self.station.ingest([self.story()])
        self.station.ingest([self.story(firstSeenAt=self.now, publishedAt=self.now - 5)])
        row = self.station.stories['a' * 32]
        self.assertEqual(row['firstSeenAt'], self.now - 10)
        self.assertEqual(row['publishedAt'], self.now - 20)

    def test_oldest_fresh_first_dedup_and_consumption(self):
        old = self.story()
        new = self.story(id='b' * 32, publishedAt=self.now - 5, firstSeenAt=self.now - 4)
        self.station.ingest([new, old])
        self.assertEqual(self.station._candidate('ar', self.now)['id'], old['id'])
        self.station.seen['ar'].add(old['id'])
        self.assertEqual(self.station._candidate('ar', self.now)['id'], new['id'])
        self.assertIsNone(self.station._candidate('en', self.now))

    def test_rss_excludes_missing_future_bad_url_and_entities(self):
        stamp = 'Thu, 22 Oct 2026 11:00:00 GMT'
        received = 1792666860
        feed = server.FEEDS[0]
        xml = f'<rss><channel><item><title>خبر الاقتصاد</title><link>https://www.bbc.com/arabic/test</link><pubDate>{stamp}</pubDate></item></channel></rss>'.encode()
        rows = server.parse_feed(xml, feed, received)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['language'], 'ar')
        self.assertEqual(server.parse_feed(xml.replace(b'https://www.bbc.com', b'http://127.0.0.1'), feed, received), [])
        with self.assertRaises(ValueError):
            server.parse_feed(b'<!DOCTYPE x>' + xml, feed, received)
        self.assertEqual(server.parse_feed(xml, feed, 1), [])

    def test_excerpt_limit_and_no_spoken_url(self):
        row = self.story(title=' '.join('word' + str(i) for i in range(45)))
        spoken = server.spoken_text(row)
        self.assertIn('word23', spoken)
        self.assertNotIn('word24', spoken)
        self.assertEqual(server.plain('Read https://example.com/private now'), 'Read now')

    def test_manifest_clock_and_types(self):
        now = self.now * 1000
        self.station.languages = ('ar',)
        self.station.status = 'ready'
        self.station.queues['ar'] = [{'id': 'c' * 32, 'startsAt': now - 1000, 'endsAt': now + 5000, 'language': 'ar'}]
        m = self.station.manifest('ar', now)
        self.assertEqual(m['status'], 'live')
        self.assertEqual(m['nowPlaying']['id'], 'c' * 32)
        self.assertIs(type(m['serverTime']), int)
        self.assertEqual(self.station.manifest('en', now)['status'], 'waiting')
        self.assertNotIn('directory', json.dumps(m))

    def test_prune_preserves_current_and_future_even_with_short_clip_history(self):
        now = self.now * 1000
        self.station.queues['ar'] = [{'id': format(i, '032x'), 'startsAt': now - 20000 + i * 1000,
                                     'endsAt': now - 19000 + i * 1000} for i in range(26)]
        current = next(q['id'] for q in self.station.queues['ar'] if q['startsAt'] <= now < q['endsAt'])
        self.station._prune(now)
        self.assertIn(current, [q['id'] for q in self.station.queues['ar']])
        self.assertEqual(sum(q['endsAt'] > now for q in self.station.queues['ar']), 6)

    def test_only_known_scheduled_audio_can_be_read(self):
        identifier = 'd' * 32
        (self.station.directory / (identifier + '.wav')).write_bytes(b'RIFF' + b'0' * 64)
        self.assertIsNone(self.station.audio(identifier))
        self.station.queues['ar'].append({'id': identifier, 'endsAt': int(time.time() * 1000) + 10000})
        self.assertEqual(len(self.station.audio(identifier)), 68)
        self.assertIsNone(self.station.audio('e' * 32))

    def test_owner_generator_publishes_real_typed_audio_without_language_fallback(self):
        data = io.BytesIO()
        with wave.open(data, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(b'\x01\x00' * 24000)
        station = self.station
        class FakeTts:
            available_languages = ('ar',)
            engines = {'ar': 'fake-test-only'}
            def synthesize(self, text, language):
                self.called_language = language
                station.stop.set()
                return SimpleNamespace(wav=data.getvalue(), duration_s=1.0, engine='fake-test-only', language=language, inference_s=.01)
        voice = FakeTts()
        self.station.tts_factory = lambda: voice
        self.station.ingest([self.story()])
        self.station.generate()
        self.assertEqual(voice.called_language, 'ar')
        self.assertEqual(len(self.station.queues['ar']), 1)
        self.assertEqual(self.station.queues['en'], [])
        segment = self.station.queues['ar'][0]
        self.assertEqual(segment['language'], 'ar')
        self.assertEqual(segment['engine'], 'fake-test-only')
        self.assertEqual(segment['endsAt'] - segment['startsAt'], 1000)
        with wave.open(io.BytesIO(self.station.audio(segment['id'])), 'rb') as w:
            self.assertEqual(w.getnframes(), 24000)

    def test_http_is_read_only_bounded_and_does_not_leak_paths(self):
        http = server.RadioHttpServer(('127.0.0.1', 0), server.make_handler(self.station))
        thread = threading.Thread(target=http.serve_forever, daemon=True)
        thread.start()
        base = 'http://127.0.0.1:' + str(http.server_port)
        try:
            with urllib.request.urlopen(base + '/health') as response:
                self.assertTrue(json.load(response)['ok'])
                self.assertEqual(response.headers['X-Content-Type-Options'], 'nosniff')
                self.assertNotIn('Python', response.headers['Server'])
            with urllib.request.urlopen(base + '/radio.json?language=ar') as response:
                body = response.read().decode()
                self.assertNotIn(self.temporary.name, body)
                self.assertEqual(json.loads(body)['language'], 'ar')
            for path in ('/radio.json?language=ar&language=en', '/radio.json?language=xx', '/radio.json?url=http://127.0.0.1', '/audio/../../server.py', '/tts', '/health?path=test'):
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(base + path)
                self.assertEqual(error.exception.code, 404)
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(urllib.request.Request(base + '/tts', data=b'{}', method='POST'))
            self.assertEqual(error.exception.code, 405)
        finally:
            http.shutdown()
            http.server_close()
            thread.join()


if __name__ == '__main__':
    unittest.main()

from copy import deepcopy
from datetime import datetime, timezone
import unittest

from news_context_reports import build_news_context, MAX_SPEECH_CHARACTERS


class NewsContextReportsTests(unittest.TestCase):
    now = 1792878000

    def story(self, number, title, language='en', age=30, **extra):
        return {'id': format(number, '032x'), 'title': title, 'source': 'Publisher ' + str(number),
                'url': 'https://news.example.org/story/' + str(number), 'language': language,
                'publishedAt': self.now - age, 'firstSeenAt': self.now - age + 1, **extra}

    def test_complete_unspoken_attributed_reports_and_real_sample_counts(self):
        rows = [self.story(1, 'Oil prices rise as shipping routes reopen.', age=50),
                self.story(2, 'Oil supply report describes refinery repairs.', age=40),
                self.story(3, 'Oil futures slip after demand report.', age=30)]
        saved = deepcopy(rows)
        job = build_news_context('en', rows, self.now)
        self.assertEqual(job['kind'], 'news-context')
        self.assertEqual(set(job['sourceIds']), {row['id'] for row in rows})
        self.assertEqual(job['newsContext']['reportCount'], 3)
        self.assertEqual(job['newsContext']['topicCounts']['energy'], 3)
        self.assertEqual(job['newsContext']['sourceCount'], 3)
        self.assertEqual(job['newsContext']['sourceCountBasis'], 'distinct-labels-not-independent-confirmation')
        for row in rows:
            clock = datetime.fromtimestamp(row['publishedAt'], timezone.utc).strftime('%H:%M')
            self.assertIn(row['title'], job['speechText'])
            self.assertIn(row['source'], job['speechText'])
            self.assertIn(clock, job['speechText'])
        self.assertEqual(job['publishedAt'], min(row['publishedAt'] for row in rows))
        self.assertEqual(job['firstSeenAt'], max(row['firstSeenAt'] for row in rows))
        self.assertTrue(job['speechText'].endswith('.'))
        self.assertLessEqual(len(job['speechText']), MAX_SPEECH_CHARACTERS)
        self.assertFalse(job['newsContext']['publicConsensus'])
        self.assertFalse(job['newsContext']['sourceAgreementInferred'])
        self.assertFalse(job['newsContext']['causalGoldClaim'])
        self.assertFalse(job['newsContext']['forecast'])
        self.assertEqual(rows, saved)

    def test_excluding_queued_source_ids_prevents_raw_story_reuse(self):
        rows = [self.story(index, f'Gold prices report {index}.') for index in range(1, 5)]
        first = build_news_context('en', rows, self.now)
        self.assertEqual(len(first['sourceIds']), 3)
        self.assertIsNone(build_news_context('en', rows, self.now, excluded=first['sourceIds']))
        # A failed synthesis has not committed IDs, so the same report batch remains available.
        self.assertEqual(first['id'], build_news_context('en', reversed(rows), self.now + 1)['id'])
        changed = build_news_context('en', rows, self.now, excluded=[first['sourceIds'][0]])
        self.assertNotIn(first['sourceIds'][0], changed['sourceIds'])
        self.assertEqual(len(changed['sourceIds']), 3)

    def test_arabic_public_posts_keep_attribution_unverified_author_times_and_endings(self):
        rows = [self.story(1, 'النفط يرتفع مع استئناف الشحن في الموانئ.', 'ar', age=800,
                           social=True, platform='Telegram', timeKind='published'),
                self.story(2, 'النفط يتراجع بعد تقرير عن الطلب الصناعي.', 'ar', age=900)]
        job = build_news_context('ar', rows, self.now)
        self.assertEqual(job['recency'], 'earlier')
        self.assertEqual(job['newsContext']['socialReports'], 1)
        self.assertIn('الساعة الأخيرة', job['speechText'])
        self.assertIn('منشور سابق، وقته حسب المصدر', job['speechText'])
        self.assertIn('خبر سابق نُشر الساعة', job['speechText'])
        for row in rows:
            self.assertIn(row['title'], job['speechText'])
        source = next(value for value in job['sources'] if value['id'] == rows[0]['id'])
        self.assertTrue(source['social'])
        self.assertEqual(source['publishedAt'], rows[0]['publishedAt'])

    def test_two_hour_reports_are_labelled_and_out_of_window_cannot_renew(self):
        rows = [self.story(1, 'Gold demand report arrives.', age=3700),
                self.story(2, 'Gold market report explains demand.', age=7200)]
        job = build_news_context('en', rows, self.now)
        self.assertIn('last two hours', job['speechText'])
        self.assertEqual(job['newsContext']['windowSeconds'], 7200)
        self.assertEqual(job['newsContext']['minimumAgeSeconds'], 3601)
        self.assertEqual(job['publishedAt'], self.now - 7200)
        old = self.story(3, 'Gold demand report arrives.', age=7201)
        self.assertIsNone(build_news_context('en', [old, *rows], self.now))

    def test_related_cohorts_stay_separate_and_missing_claims_are_not_invented(self):
        fresh = self.story(1, 'Gold prices rise.', age=20)
        older = self.story(2, 'Gold prices fall.', age=800)
        self.assertIsNone(build_news_context('en', [fresh, older], self.now))
        other_topic = self.story(3, 'Earthquake forces evacuations.', age=20)
        self.assertIsNone(build_news_context('en', [fresh, other_topic], self.now))
        opposite = self.story(4, 'Gold prices fall.', age=40)
        job = build_news_context('en', [fresh, opposite], self.now)
        self.assertIn(fresh['title'], job['speechText'])
        self.assertIn(opposite['title'], job['speechText'])
        self.assertNotIn('disagree', job['speechText'])
        self.assertFalse(job['newsContext']['sourceAgreementInferred'])

    def test_same_source_label_does_not_count_as_multiple_independent_sources(self):
        rows = [self.story(1, 'Oil prices rise.', source='One publisher'),
                self.story(2, 'Oil demand strengthens.', source='One publisher')]
        job = build_news_context('en', rows, self.now)
        self.assertEqual(job['newsContext']['sourceCount'], 1)
        self.assertIn('2 reports attributed to 1 named source', job['speechText'])
        self.assertNotIn('independent', job['speechText'])

    def test_no_partial_title_or_advertisement_fills_an_empty_roundup(self):
        long = [self.story(index, ('Gold ' + 'complete words ' * 26 + str(index) + '.')[:399])
                for index in (1, 2)]
        self.assertIsNone(build_news_context('en', long, self.now))
        bad = [self.story(1, 'Gold prices rise, subscribe now for guaranteed profits.'),
               self.story(2, 'Gold prices report arrives.', age=7201),
               self.story(3, 'Gold prices report is from the future.', age=-1),
               self.story(4, 'الذهب يرتفع.', 'ar')]
        self.assertIsNone(build_news_context('en', bad, self.now))

    def test_deduplication_and_publication_age_survive_syndicated_copies(self):
        original = self.story(1, 'Gold prices rise!', age=700)
        copied = self.story(2, 'BREAKING NEWS: GOLD PRICES RISE!', age=20)
        other = self.story(3, 'Gold demand strengthens.', age=800)
        job = build_news_context('en', [copied, original, other], self.now)
        self.assertEqual(set(job['sourceIds']), {original['id'], other['id']})
        self.assertEqual(job['recency'], 'earlier')
        self.assertNotIn(copied['id'], job['sourceIds'])

    def test_arguments_are_bounded_and_invalid_inputs_do_not_produce_a_job(self):
        for arguments in (('fr', [], self.now), ('en', None, self.now), ('en', {}, self.now),
                          ('en', [], True), ('en', [], 0)):
            with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                build_news_context(*arguments)
        for excluded in (None, 'id', {}, [None], ('x' for _ in range(1001))):
            with self.subTest(kind=type(excluded).__name__), self.assertRaises(ValueError):
                build_news_context('en', [], self.now, excluded)


if __name__ == '__main__':
    unittest.main()

"""Offline hosted-translation/station contracts with synthetic public accounts.

No fixture represents a live post, real provider response or listened-to audio.
"""
from copy import deepcopy
import io
import json
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server
from cloud_script_writer import CloudScriptWriter
from people_now import PeopleNow, job_fresh
from people_translation import translation_allowed
from social_feedback import PINNED
from test_people_now import reaction, reply, NOW, NOW_MS, OPINION
from test_people_translation import Runtime, MODEL, ARABIC


class HostedFixture(Runtime):
    """Only a fake completion interface; never constructs a provider client."""

    def __init__(self, *outputs, available=True, **kwargs):
        super().__init__(*outputs, **kwargs)
        self.available = available

    def status(self):
        return {**super().status(), 'available': self.available}


class PeopleTranslationStationTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.network = patch('urllib.request.build_opener',
            side_effect=AssertionError('Offline fixtures must not open a network client'))
        self.network.start()
        self.addCleanup(self.network.stop)
        with patch.dict('os.environ', {'RADIO_CLOUD_LLM': '0', 'RADIO_COMPETITION': '0'}), \
                patch('server.time.time', return_value=NOW):
            self.station = server.Station(self.directory.name)
        self.station.programmes = None
        self.station.languages = ('en', 'ar')
        self.station.cloud_provider = 'nvidia'
        self.station.people_translation_state['enabled'] = True
        self.row = reaction(name='Fixture Account')
        self.station.stories = {self.row['id']: self.row}
        self.runtime = HostedFixture()
        self.station.cloud_llm = self.runtime

    def tearDown(self):
        self.station.stop.set()
        self.directory.cleanup()

    def translate(self, at=NOW):
        with patch('server.time.time', return_value=at):
            return self.station._translate_people_once(at)

    def candidate(self, language, at=NOW_MS):
        return self.station.people_now.candidate(language,
            list(self.station.stories.values()), at, seen=self.station.seen[language])

    def produce(self, language):
        station = self.station
        calls = []
        buffer = io.BytesIO()
        with wave.open(buffer, 'wb') as output:
            output.setnchannels(1)
            output.setsampwidth(2)
            output.setframerate(24000)
            output.writeframes(b'\x01\x00' * 48000)

        class Tts:
            def synthesize(self, text, language):
                calls.append((text, language))
                station.stop.set()
                return SimpleNamespace(wav=buffer.getvalue(), duration_s=2.0,
                    engine='synthetic-test-only', language=language)

        station.stop.clear()
        with patch('server.time.time', return_value=NOW):
            station._produce(Tts(), (language,))
        return calls

    def test_hosted_artifact_preserves_original_and_supplies_concise_bilingual_jobs(self):
        original = deepcopy(self.row)
        self.assertIsNotNone(self.candidate('en'))
        self.assertIsNone(self.candidate('ar'))
        self.assertTrue(self.translate())
        self.assertEqual(len(self.runtime.calls), 1)
        artifact = self.row['machineTranslations']['ar']
        self.assertEqual({key: value for key, value in self.row.items()
            if key != 'machineTranslations'}, original)
        self.assertEqual(artifact['originalText'], original['title'])
        self.assertEqual(artifact['text'], ARABIC)
        self.assertEqual(artifact['modelId'], MODEL)
        self.assertTrue(translation_allowed(artifact, self.row, at_s=NOW))
        english, arabic = self.candidate('en'), self.candidate('ar')
        for language, job in (('en', english), ('ar', arabic)):
            self.assertIsNotNone(job)
            self.assertEqual(job['kind'], 'people-now')
            self.assertEqual(job['language'], language)
            self.assertEqual(job['sourceIds'], [original['id']])
            self.assertEqual(job['sources'], [self.row])
            self.assertEqual(job['sources'][0]['language'], 'en')
            self.assertEqual(job['sources'][0]['title'], OPINION)
            self.assertEqual(job['publishedAt'], original['publishedAt'])
            self.assertEqual(job['firstSeenAt'], original['firstSeenAt'])
            self.assertEqual(job['url'], original['url'])
            self.assertIn('listener@mastodon.social', job['speechText'])
            self.assertNotIn('UTC', job['speechText'])
            self.assertNotIn('Fixture Account', job['speechText'])
            self.assertEqual(job['peopleNow']['authorName'], 'Fixture Account')
            self.assertFalse(job['factualContextEligible'])
            self.assertFalse(job['peopleNow']['representative'])
            self.assertTrue(job_fresh(job, NOW_MS + 30000))
        self.assertEqual(english['speechText'], 'listener@mastodon.social: “' + OPINION + '”')
        self.assertFalse(english['peopleNow']['machineTranslation'])
        self.assertEqual(english['title'], OPINION)
        self.assertEqual(arabic['speechText'], 'listener@mastodon.social: «' + artifact['text'] + '»')
        self.assertNotIn('ترجمة آلية', arabic['speechText'])
        self.assertNotIn('ليست الكلمات العربية الأصلية للحساب', arabic['speechText'])
        self.assertNotIn(OPINION, arabic['speechText'])
        self.assertTrue(arabic['peopleNow']['machineTranslation'])
        self.assertFalse(arabic['peopleNow']['translationVerified'])
        self.assertEqual(arabic['peopleNow']['originalLanguage'], 'en')
        self.assertEqual(arabic['peopleNow']['translationModelId'], MODEL)
        saved = json.loads((self.station.directory / 'receipts.json').read_text('utf-8'))
        self.assertEqual(saved['stories'][0], self.row)

    def test_complete_synthetic_audio_consumes_each_language_independently(self):
        self.assertTrue(self.translate())
        self.assertEqual(self.station.seen, {'en': set(), 'ar': set()})
        for language, quote in (('ar', ARABIC), ('en', OPINION)):
            with self.subTest(language=language):
                calls = self.produce(language)
                self.assertEqual(len(calls), 1)
                self.assertEqual(calls[0][1], language)
                self.assertIn(quote, calls[0][0])
                self.assertEqual(len(self.station.queues[language]), 1)
                segment = self.station.queues[language][0]
                self.assertEqual(segment['kind'], 'people-now')
                self.assertEqual(segment['sources'][0]['title'], OPINION)
                self.assertEqual(segment['sources'][0]['language'], 'en')
                self.assertFalse(segment['factualContextEligible'])
                self.assertEqual(segment['publishedAt'], self.row['publishedAt'] * 1000)
                self.assertEqual(segment['durationSeconds'], 2)
                self.assertEqual(self.station.people_now.status(language, NOW_MS)['scheduledSeconds'], 2)
                self.assertIn(self.row['id'], self.station.seen[language])
                with patch('server.time.time', return_value=NOW):
                    self.assertTrue(self.station.audio(segment['id']))
        self.assertEqual(len(self.runtime.calls), 1, 'Speech never requests another translation')

    def test_bounded_business_reply_keeps_parent_and_both_original_clocks(self):
        publisher = next(item for item in PINNED.values() if item.source == 'Bloomberg')
        row, parent = reply(publisher=publisher,
            text='I wish Netflix focused more on better original programming.',
            root_title='Netflix plans more local entertainment programming for subscribers.')
        before = deepcopy([row, parent])
        translated = 'أتمنى أن تركز نتفليكس أكثر على تقديم برامج أصلية أفضل.'
        context = 'تخطط نتفليكس لتقديم المزيد من البرامج الترفيهية المحلية للمشتركين.'
        self.runtime = HostedFixture(translated, context)
        self.station.cloud_llm = self.runtime
        self.station.stories = {item['id']: item for item in (row, parent)}
        self.assertTrue(self.translate())
        self.assertEqual(len(self.runtime.calls), 2)
        self.assertEqual(parent, before[1])
        self.assertEqual({key: value for key, value in row.items()
            if key != 'machineTranslations'}, before[0])
        artifact = row['machineTranslations']['ar']
        self.assertTrue(translation_allowed(artifact, row, parent, at_s=NOW))
        job = self.candidate('ar')
        self.assertIsNotNone(job)
        self.assertEqual(job['sources'], [row, parent])
        self.assertEqual(job['sources'][1]['publishedAt'], before[1]['publishedAt'])
        self.assertEqual(job['peopleNow']['rootUrl'], parent['url'])
        self.assertEqual(job['speechText'], 'listener.example: «' + artifact['text'] + '»')
        self.assertEqual(artifact['text'], translated)
        self.assertEqual(artifact['contextText'], context)
        self.assertNotIn(context, job['speechText'])
        self.assertNotIn(parent['title'], job['speechText'])
        self.assertNotIn('Bloomberg', job['speechText'])
        self.assertEqual(job['sources'][0]['publishedAt'], before[0]['publishedAt'])
        self.assertEqual(job['sources'][0]['firstSeenAt'], before[0]['firstSeenAt'])
        self.assertEqual(job['sources'][1]['firstSeenAt'], before[1]['firstSeenAt'])
        self.assertTrue(job_fresh(job, NOW_MS + 30000))
        changed = deepcopy(job)
        changed['sources'][1]['publishedAt'] -= 1
        self.assertFalse(job_fresh(changed, NOW_MS + 30000))

    def test_source_provenance_translation_metadata_and_spoken_text_tampering_fail(self):
        self.assertTrue(self.translate())
        job = self.candidate('ar')
        changes = (
            lambda item: item['sources'][0]['reaction'].update(authorName='Different Account'),
            lambda item: item['sources'][0].update(firstSeenAt=NOW - 1),
            lambda item: item['sources'][0]['machineTranslations']['ar'].update(sourceHash='0' * 64),
            lambda item: item['sources'][0]['machineTranslations']['ar'].update(textHash='0' * 64),
            lambda item: item['sources'][0]['machineTranslations']['ar'].update(verified=True),
            lambda item: item['peopleNow'].update(machineTranslation=False),
            lambda item: item['peopleNow'].update(translationVerified=True),
            lambda item: item['peopleNow'].update(translationModelId='native-model'),
            lambda item: item['peopleNow'].update(originalLanguage='ar'),
            lambda item: item['peopleNow'].update(sourceDigest='0' * 64),
            lambda item: item.update(title=OPINION),
            lambda item: item.update(speechText=item['speechText'].replace(ARABIC, ARABIC + ' رأي إضافي.')),
            lambda item: item.update(factualContextEligible=True),
        )
        for index, change in enumerate(changes):
            altered = deepcopy(job)
            change(altered)
            with self.subTest(mutation=index):
                self.assertFalse(job_fresh(altered, NOW_MS + 30000))
                self.assertFalse(self.station._job_fresh(altered, NOW_MS + 30000))
        self.row['reaction']['authorName'] = 'Different Account'
        self.assertIsNone(self.candidate('ar'))

    def test_one_hour_is_measured_through_full_audio_end_without_clock_renewal(self):
        self.row = reaction(age=3500)
        self.station.stories = {self.row['id']: self.row}
        self.assertTrue(self.translate())
        limit = (self.row['publishedAt'] + 3600) * 1000
        for language in ('en', 'ar'):
            with self.subTest(language=language):
                job = self.candidate(language)
                self.assertIsNotNone(job, 'Original posts may remain eligible between 30 and 60 minutes')
                self.assertTrue(job_fresh(job, limit))
                self.assertFalse(job_fresh(job, limit + 1))
                self.assertTrue(self.station.people_now.can_commit(job, limit - 1000, limit))
                self.assertFalse(self.station.people_now.can_commit(job, limit - 1000, limit + 1))
                self.assertIsNone(self.candidate(language, limit - 1),
                    'A whole quote cannot fit within the final millisecond')
        self.assertEqual(self.row['machineTranslations']['ar']['generatedAt'], NOW)
        self.assertEqual(self.row['publishedAt'], NOW - 3500)
        self.assertFalse(self.translate(self.row['publishedAt'] + 3601))
        self.assertEqual(len(self.runtime.calls), 1)

    def test_failed_translation_keeps_exact_english_eligible_and_arabic_empty(self):
        original = deepcopy(self.row)
        self.runtime = HostedFixture(error=TimeoutError('private-provider-response'))
        self.station.cloud_llm = self.runtime
        self.assertFalse(self.translate())
        self.assertEqual(self.row, original)
        self.assertEqual(len(self.runtime.calls), 1)
        self.assertEqual(self.station.people_translation_state['completed'], 0)
        self.assertNotIn('private-provider-response', self.station.people_translation_state['lastError'])
        english = self.candidate('en')
        self.assertIsNotNone(english)
        self.assertEqual(english['title'], original['title'])
        self.assertIsNone(self.candidate('ar'))
        self.assertFalse(self.translate(NOW + 59))
        self.assertEqual(len(self.runtime.calls), 1, 'Failure does not cause an immediate repair request')
        self.assertFalse(self.translate(NOW + 60))
        self.assertEqual(len(self.runtime.calls), 2, 'The owner worker may retry after one minute')
        with patch('server.time.time', return_value=NOW):
            status = self.station.manifest('ar', NOW_MS)['peopleNow']
        self.assertFalse(status['eligibleNow'])
        self.assertEqual(status['scheduledSeconds'], 0)
        self.assertEqual(self.station.seen, {'en': set(), 'ar': set()})

    def test_stale_seen_unavailable_and_non_hosted_supply_never_generates(self):
        original = deepcopy(self.row)
        scenarios = ('stale', 'seen-ar', 'disabled', 'missing-runtime', 'unavailable', 'non-hosted')
        for scenario in scenarios:
            with self.subTest(scenario=scenario):
                self.row = deepcopy(original)
                self.station.stories = {self.row['id']: self.row}
                self.station.seen = {'en': set(), 'ar': set()}
                self.station.people_translation_state['enabled'] = True
                self.station.people_translation_retry = {}
                runtime = HostedFixture()
                self.station.cloud_llm = runtime
                if scenario == 'stale':
                    self.row['publishedAt'] = NOW - 3601
                elif scenario == 'seen-ar':
                    self.station.seen['ar'].add(self.row['id'])
                elif scenario == 'disabled':
                    self.station.people_translation_state['enabled'] = False
                elif scenario == 'missing-runtime':
                    self.station.cloud_llm = None
                elif scenario == 'unavailable':
                    runtime.available = False
                elif scenario == 'non-hosted':
                    runtime.model = 'MiniCPM5-2B'
                self.assertFalse(self.translate())
                self.assertEqual(runtime.calls, [])
                self.assertNotIn('machineTranslations', self.row)

    def test_existing_valid_artifact_is_not_generated_again_after_retry_window(self):
        self.station.seen['en'].add(self.row['id'])
        self.assertTrue(self.translate(), 'An English read does not consume the independent Arabic lane')
        artifact = deepcopy(self.row['machineTranslations']['ar'])
        for at in (NOW, NOW + 119, NOW + 121):
            self.assertFalse(self.translate(at))
        self.assertEqual(self.row['machineTranslations']['ar'], artifact)
        self.assertEqual(len(self.runtime.calls), 1)

    def test_provider_generation_runs_outside_station_queue_lock(self):
        observations = []

        def probe_from_other_thread():
            def probe():
                acquired = self.station.lock.acquire(blocking=False)
                observations.append(acquired)
                if acquired:
                    self.station.lock.release()
            worker = threading.Thread(target=probe)
            worker.start()
            worker.join(timeout=1)
            observations.append(not worker.is_alive())

        self.runtime.on_generate = probe_from_other_thread
        self.assertTrue(self.translate())
        self.assertEqual(observations, [True, True])

    def test_source_change_during_generation_cannot_attach_a_stale_translation(self):
        self.runtime.on_generate = lambda: self.row['reaction'].update(authorName='Changed During Call')
        self.assertFalse(self.translate())
        self.assertEqual(len(self.runtime.calls), 1)
        self.assertNotIn('machineTranslations', self.row)
        self.assertIsNone(self.candidate('ar'))
        self.assertEqual(self.station.people_translation_state['completed'], 0)

    def test_translated_opinion_and_artifact_stay_out_of_factual_writer_context(self):
        self.assertTrue(self.translate())
        for language in ('en', 'ar'):
            with self.subTest(language=language):
                job = self.candidate(language)
                self.assertIsNotNone(job)
                runtime = HostedFixture(error=RuntimeError('offline writer fixture'))
                writer = CloudScriptWriter(runtime, model_id=MODEL, clock=lambda: NOW)
                self.assertFalse(writer.prepare(language, job['sources'], now_s=NOW))
                self.assertTrue(runtime.calls)
                sent = json.dumps(runtime.calls, ensure_ascii=False)
                self.assertNotIn(OPINION, sent)
                self.assertNotIn(ARABIC, sent)
                self.assertNotIn(self.row['reaction']['authorHandle'], sent)
                self.assertNotIn('machineTranslations', sent)
        self.assertEqual(len(self.runtime.calls), 1)


if __name__ == '__main__':
    unittest.main()

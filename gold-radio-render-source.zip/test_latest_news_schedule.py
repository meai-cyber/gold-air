"""Latest-report scheduling regressions; no live feeds, model calls or network TTS."""
from copy import deepcopy
import io
import os
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server


NOW = 1_792_934_000


class LatestNewsScheduleTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        with patch.dict(os.environ, {'RADIO_CLOUD_LLM': '0'}), \
                patch('server.time.time', return_value=NOW - 600):
            self.station = server.Station(self.folder.name)
        self.station.programmes = None
        self.station.cloud_writer = None

    def tearDown(self):
        self.station.stop.set()
        self.folder.cleanup()

    def story(self, language='en', age_s=20, **changes):
        row = {'id': ('a' if language == 'en' else 'b') * 32,
            'title': 'Gold demand and Treasury yields update' if language == 'en' else 'تقرير جديد عن الذهب والتضخم',
            'language': language, 'source': 'Reuters',
            'url': 'https://www.reuters.com/markets/fresh-gold-report',
            'publishedAt': NOW - age_s, 'firstSeenAt': min(NOW, NOW - age_s + 1),
            'sourceKind': 'publisher-rss', 'clockBasis': 'publisher-rss-publication',
            'publicationField': 'pubdate', 'originalPublicationVerified': True,
            'originalPublishedAt': NOW - age_s}
        row.update(changes)
        return row

    @staticmethod
    def wav(duration_s=2, marker=1):
        output = io.BytesIO()
        with wave.open(output, 'wb') as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(24000)
            audio.writeframes(bytes((marker, 0)) * round(24000 * duration_s))
        return output.getvalue()

    def queued_news(self, language, identifier, start_s, end_s):
        source = self.story(language, age_s=300, id=identifier * 32,
            url='https://www.reuters.com/markets/older-' + identifier)
        queued = {**source, 'kind': 'news', 'headline': source['title'],
            'sourceUrl': source['url'], 'publishedAt': source['publishedAt'] * 1000,
            'firstSeenAt': source['firstSeenAt'] * 1000, 'generatedAt': (NOW - 10) * 1000,
            'startsAt': (NOW + start_s) * 1000, 'endsAt': (NOW + end_s) * 1000,
            'durationSeconds': end_s - start_s, 'recency': 'fresh',
            'speechText': 'A complete recorded report that must retain its audio and clocks.',
            'audioUrl': '/audio/' + identifier * 32 + '.wav'}
        audio = self.wav(end_s - start_s, marker=2)
        self.station.queues[language].append(queued)
        self.station.airtime[language].commit(queued['startsAt'], queued['endsAt'], 'news')
        (self.station.directory / (queued['id'] + '.wav')).write_bytes(audio)
        return queued, audio

    def queued_pair(self, language, *, analyst=True):
        episode = 'e' * 32
        rows = []
        for index, (role, start, end) in enumerate((('host', -1, 20), ('analyst', 20, 90))):
            row = {'id': str(index) * 32, 'kind': 'cloud-discussion', 'language': language,
                'title': 'Source-grounded discussion', 'source': 'Gold Pulse cloud LLM',
                'url': 'https://gold-air.onrender.com/', 'publishedAt': (NOW - 3) * 1000,
                'firstSeenAt': (NOW - 3) * 1000, 'startsAt': (NOW + start) * 1000,
                'endsAt': (NOW + end) * 1000, 'sources': [],
                'programme': {'mode': 'cloud-llm', 'speakerRole': role, 'episodeId': episode,
                    'turnIndex': index, 'turnCount': 2, 'forecast': False, 'educational': True,
                    'contextCapturedAt': (NOW - 3) * 1000, 'generatedAt': (NOW - 2) * 1000,
                    'expiresAt': (NOW + 298) * 1000},
                'speaker': 'Maia' if role == 'host' else 'Omar',
                'speechText': 'A complete educational turn about market liquidity.'}
            rows.append(row)
            if role == 'host' or analyst:
                self.station.queues[language].append(row)
                self.station.airtime[language].commit(row['startsAt'], row['endsAt'], 'podcast')
        return rows

    def produce_one(self, language, duration_s=2):
        calls, station = [], self.station
        audio = self.wav(duration_s)

        class Voice:
            def synthesize(self, text, language):
                calls.append((text, language))
                station.stop.set()
                return SimpleNamespace(wav=audio, duration_s=duration_s,
                    engine='test-latest-report', language=language)

        station.stop.clear()
        deadline = threading.Timer(2, station.stop.set)
        deadline.daemon = True
        deadline.start()
        try:
            with patch('server.time.time', return_value=NOW), \
                    patch('server.time.monotonic', return_value=50):
                station._produce(Voice(), (language,))
        finally:
            station.stop.set()
            deadline.cancel()
            deadline.join(timeout=.25)
        self.assertEqual(len(calls), 1, 'one complete latest-report recording must be produced')
        return calls[0]

    def test_latest_original_publication_boundary_on_both_channels(self):
        for language in ('ar', 'en'):
            for age in (0, 120, 121):
                with self.subTest(language=language, age=age):
                    self.station.stories.clear()
                    source = self.story(language, age_s=age)
                    self.station.ingest([source], NOW)
                    offered = self.station._latest_news_job(language, NOW * 1000, {})
                    if age <= 120:
                        self.assertEqual(offered['id'], source['id'])
                        self.assertEqual(offered['kind'], 'news')
                        self.assertIs(offered['_latestPriority'], True)
                        self.assertEqual(offered['originalPublishedAt'], source['publishedAt'])
                    else:
                        self.assertIsNone(offered, 'older fresh reports use ordinary queue ordering')

    def test_latest_does_not_promote_old_updated_or_discovery_clock(self):
        for changes in ({'originalPublishedAt': NOW - 15 * 3600},
                        {'sourceKind': 'publisher-aggregator', 'clockBasis': 'aggregator-index'},
                        {'originalPublicationVerified': False}):
            with self.subTest(changes=changes):
                self.station.stories.clear()
                self.station.ingest([self.story(age_s=1, **changes)], NOW)
                self.assertIsNone(self.station._latest_news_job('en', NOW * 1000, {}))

    def test_seen_retry_and_full_active_queue_do_not_repeat_or_overfill(self):
        source = self.story()
        self.station.ingest([source], NOW)
        self.station.seen['en'].add(source['id'])
        self.assertIsNone(self.station._latest_news_job('en', NOW * 1000, {}))
        self.station.seen['en'].clear()
        self.assertIsNone(self.station._latest_news_job('en', NOW * 1000,
            {source['id']: (NOW + 30) * 1000}))
        self.station.queues['en'] = [{'endsAt': (NOW + 10) * 1000}] * server.MAX_QUEUE
        self.assertIsNone(self.station._latest_news_job('en', NOW * 1000, {}))
        self.station.queues['en'].pop()
        self.assertEqual(self.station._latest_news_job('en', NOW * 1000, {})['id'], source['id'])

    def test_individual_reactions_never_acquire_latest_publisher_priority(self):
        # A valid opinion can still be ordinary, clearly attributed speech.
        # Exercise this scheduling boundary independently of its parser gate.
        for source_kind in ('social-feedback', 'social-reaction'):
            with self.subTest(source_kind=source_kind), patch.object(self.station, '_candidate',
                    return_value=self.story(age_s=1, sourceKind=source_kind)):
                self.assertIsNone(self.station._latest_news_job('en', NOW * 1000, {}))

    def test_pending_analyst_continuation_blocks_latest_headline_priority(self):
        self.station.ingest([self.story()], NOW)
        answer = self.queued_pair('en', analyst=False)[1]
        answer.update(publishedAt=NOW - 3, firstSeenAt=NOW - 3)
        self.station.cloud_writer = SimpleNamespace(candidate=lambda *args, **kwargs: deepcopy(answer))
        continuation = self.station._cloud_continuation('en', NOW * 1000, {})
        self.assertIsNotNone(continuation, 'the prepared host has a real matching answer')
        self.assertIsNone(self.station._latest_news_job('en', NOW * 1000, {}),
            'a latest headline must not split an unfinished question and answer')

    def test_latest_bypasses_lookahead_without_cutting_current_report_or_rewriting_future_audio(self):
        for language in ('ar', 'en'):
            with self.subTest(language=language):
                source = self.story(language)
                self.station.ingest([source], NOW)
                current, current_audio = self.queued_news(language, 'c', -2, 20)
                future, future_audio = self.queued_news(language, 'd', 20, 100)
                original_current, original_future = deepcopy(current), deepcopy(future)
                self.assertGreater(future['endsAt'], (NOW + server.SPEECH_LOOKAHEAD_S) * 1000)
                self.produce_one(language)
                generated = next(row for row in self.station.queues[language]
                    if row['id'] not in (current['id'], future['id']))
                self.assertEqual((generated['startsAt'], generated['endsAt']),
                    ((NOW + 20) * 1000, (NOW + 22) * 1000))
                self.assertEqual(current, original_current)
                self.assertEqual(future['startsAt'], original_future['startsAt'] + 2000)
                self.assertEqual(future['endsAt'], original_future['endsAt'] + 2000)
                for key in ('id', 'publishedAt', 'firstSeenAt', 'originalPublishedAt', 'speechText', 'audioUrl'):
                    self.assertEqual(future[key], original_future[key])
                self.assertEqual((self.station.directory / (current['id'] + '.wav')).read_bytes(), current_audio)
                self.assertEqual((self.station.directory / (future['id'] + '.wav')).read_bytes(), future_audio)
                self.assertIn(source['id'], self.station.seen[language])
                self.assertIsNone(self.station._latest_news_job(language, NOW * 1000, {}),
                    'a successfully queued source is consumed before the next preparation turn')

    def test_latest_waits_for_both_queued_dialogue_voices(self):
        self.station.ingest([self.story()], NOW)
        host, analyst = self.queued_pair('en')
        future, future_audio = self.queued_news('en', 'f', 90, 110)
        originals = deepcopy((host, analyst))
        self.produce_one('en')
        generated = next(row for row in self.station.queues['en']
            if row['id'] not in (host['id'], analyst['id'], future['id']))
        self.assertEqual(generated['startsAt'], (NOW + 90) * 1000)
        self.assertEqual((host, analyst), originals)
        self.assertEqual(future['startsAt'], (NOW + 92) * 1000)
        self.assertEqual((self.station.directory / (future['id'] + '.wav')).read_bytes(), future_audio)


if __name__ == '__main__':
    unittest.main()

"""Short opinion turns must not reject longer complete market speech.

All source accounts, prices and PCM below are offline fixtures, not live proof.
"""
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import io
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

from market_brief import parse_quote
from people_now import PeopleNow, MAX_TURN_SECONDS
import server
from test_people_now import reaction, NOW, NOW_MS


class PeoplePriorityInsertionTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        with patch.dict('os.environ', {'RADIO_CLOUD_LLM': '0', 'RADIO_COMPETITION': '0'}), \
                patch('server.time.time', return_value=NOW - 1000):
            self.station = server.Station(self.directory.name)
        self.station.programmes = None

    def tearDown(self):
        self.station.stop.set()
        self.directory.cleanup()

    def test_complete_forty_second_analysis_is_scheduled_without_a_people_session(self):
        station = self.station
        station.market.observe(parse_quote({'symbol': 'XAU', 'price': Decimal('4020.00'),
            'updatedAt': datetime.fromtimestamp(NOW, timezone.utc).isoformat()}, NOW))
        station.initial_price['ar'] = station.last_announced_price['ar'] = Decimal('4020.00')
        station.last_market_at['ar'] = NOW_MS - 30000
        self.assertEqual(station._market_job('ar', NOW_MS, {})['kind'], 'analysis')
        wav = io.BytesIO()
        with wave.open(wav, 'wb') as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 24000 * 40)

        class Voice:
            def synthesize(self, text, language):
                station.stop.set()
                return SimpleNamespace(wav=wav.getvalue(), duration_s=40,
                    engine='synthetic-priority-insertion-only', language=language)

        with patch('server.time.time', return_value=NOW):
            station._produce(Voice(), ('ar',))
        self.assertEqual([(q['kind'], q['durationSeconds']) for q in station.queues['ar']],
                         [('analysis', 40)])
        self.assertEqual(station.last_analysis_at['ar'], station.queues['ar'][0]['startsAt'])
        self.assertIsNone(station.people_now.status('ar', NOW_MS)['sessionStartedAt'])
        self.assertNotIn('ar', station.errors)

    def test_longer_insert_keeps_short_opinion_limit_and_session_wall(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        self.assertFalse(planner.can_commit(first, NOW_MS, NOW_MS + 40000))
        self.assertEqual(MAX_TURN_SECONDS, 35)
        self.assertTrue(planner.commit(first, NOW_MS + 6000, NOW_MS + 16000))
        second = planner.candidate('en', [reaction(key=2, username='second', account_id='23456')],
                                   NOW_MS + 16000)
        self.assertTrue(planner.commit(second, NOW_MS + 160000, NOW_MS + 170000))
        before = deepcopy(planner._states['en'])
        self.assertFalse(planner.can_shift_future('en', NOW_MS + 160000, 40000, NOW_MS))
        self.assertFalse(planner.shift_future('en', NOW_MS + 160000, 40000, NOW_MS))
        self.assertEqual(planner._states['en'], before)
        self.assertTrue(planner.shift_future('en', NOW_MS + 160000, 10000, NOW_MS))
        self.assertEqual(planner.status('en', NOW_MS)['scheduledSeconds'], 20)

    def test_priority_insert_cannot_push_a_recorded_opinion_past_original_expiry(self):
        station = self.station
        job = station.people_now.candidate('en', [reaction(age=3550)], NOW_MS)
        start, end = NOW_MS + 6000, NOW_MS + 16000
        self.assertTrue(station.people_now.commit(job, start, end))
        recorded = {**job, 'id': 'f' * 32, 'peopleJobId': job['id'],
            'headline': job['title'], 'sourceUrl': job['url'],
            'publishedAt': job['publishedAt'] * 1000, 'firstSeenAt': job['firstSeenAt'] * 1000,
            'startsAt': start, 'endsAt': end}
        station.queues['en'].append(recorded)
        station.airtime['en'].commit(start, end, 'people-now')
        restored = {**recorded, 'publishedAt': job['publishedAt'], 'firstSeenAt': job['firstSeenAt']}
        self.assertTrue(station._job_fresh(restored, end))
        self.assertFalse(station._job_fresh(restored, end + 40000))
        insertion_start = station._priority_start('en', NOW_MS, 'market', 40, urgent=True)
        self.assertEqual(insertion_start, end)
        station._insert_priority('en', {'id': 'e' * 32, 'kind': 'market',
            'startsAt': insertion_start, 'endsAt': insertion_start + 40000}, NOW_MS)
        self.assertEqual((recorded['startsAt'], recorded['endsAt']), (start, end))
        self.assertEqual(recorded['sources'], job['sources'])
        self.assertEqual(station.people_now.status('en', NOW_MS)['scheduledSeconds'], 10)


if __name__ == '__main__':
    unittest.main()

"""Exact authorized Phonon 40M English assets; never download at runtime."""
from __future__ import annotations

import hashlib
import base64
import json
import os
from pathlib import Path
import urllib.parse
import urllib.request

MODEL_ID = 'gradium/phonon-40m-en'
MODEL_REVISION = 'cc738b7e4d182c2ba1bafb8062aa4846af000637'
RUNTIME_VERSION = '0.4.1'
ENGINE = 'phonon40m-q8-native-cpu'
MODEL_LICENSE = 'CC-BY-NC-4.0'
FILES = {
    'config.json': (4634, '3e89e90b9e7ae5a74c6b4e694960c37fd2ec85906d84adfcc1440c64307aa4f1'),
    'tokenizer.json': (277967, '691a00068fa7b989f2f3e5ae5daa2d1a5bb319f2d5360deafcfb19a8bb6e7936'),
    'model.q8.gguf': (74553568, 'f6acc8f43cb296be31341b4428a6f01b6402659cd0039b624c4aea224936cf95'),
    'default-voice.safetensors': (256136, 'dc537478eaadc1a5257fcda2e3501ab81e14c111a5d95a5838f350db2afd0f1a'),
}


def verify_assets(model_dir):
    root = Path(model_dir).resolve()
    for name, (size, digest) in FILES.items():
        path = root / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size != size:
            raise ValueError('Missing or changed pinned English speech asset')
        hasher = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                hasher.update(block)
        if hasher.hexdigest() != digest:
            raise ValueError('Changed pinned English speech asset')
    return {'model': MODEL_ID, 'revision': MODEL_REVISION, 'runtime': RUNTIME_VERSION,
            'quantization': 'q8', 'license': MODEL_LICENSE, 'bytes': sum(v[0] for v in FILES.values())}


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        if urllib.parse.urlsplit(newurl).scheme != 'https':
            raise ValueError('English asset redirect is not HTTPS')
        redirected = super().redirect_request(request, fp, code, msg, headers, newurl)
        if redirected is not None and urllib.parse.urlsplit(newurl).hostname != 'huggingface.co':
            redirected.remove_header('Authorization')
        return redirected


def build_assets(model_dir):
    """Build only; owner access must already be approved, token never persisted."""
    root = Path(model_dir).resolve()
    app = Path(__file__).resolve().parent
    if root == app or app in root.parents:
        raise ValueError('English weights must be outside application source')
    token = os.environ.get('HF_TOKEN', '').strip()
    if not token:
        raise ValueError('Owner-approved Hugging Face build access is required')
    root.mkdir(parents=True, exist_ok=True)
    opener = urllib.request.build_opener(_SafeRedirect())
    for name, (size, digest) in FILES.items():
        target = root / name
        if target.is_file() and target.stat().st_size == size:
            if hashlib.sha256(target.read_bytes()).hexdigest() == digest:
                continue
        request = urllib.request.Request(
            f'https://huggingface.co/{MODEL_ID}/resolve/{MODEL_REVISION}/{name}',
            headers={'Authorization': 'Bearer ' + token, 'User-Agent': 'GoldPulse-pinned-model-build/1'})
        try:
            with opener.open(request, timeout=120) as response:
                data = response.read(size + 1)
            if len(data) != size or hashlib.sha256(data).hexdigest() != digest:
                raise ValueError('English speech download failed integrity validation')
            target.write_bytes(data)
        except Exception:
            raise ValueError('Pinned English speech download unavailable; check owner access') from None
    return verify_assets(root)


def build_from_grant(model_dir, grant_path):
    """Use one model-scoped, temporary build grant; no account credential."""
    source = Path(grant_path)
    if source.stat().st_size > 1024 * 1024:
        raise ValueError('English build grant exceeds its bound')
    grant = json.loads(source.read_text('utf-8'))
    if grant.get('model') != MODEL_ID or grant.get('revision') != MODEL_REVISION:
        raise ValueError('English build grant names a different checkpoint')
    url = grant.get('weightsUrl', '')
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname != 'us.aws.cdn.hf.co':
        raise ValueError('Unexpected English build asset host')
    root = Path(model_dir).resolve()
    app = Path(__file__).resolve().parent
    if root == app or app in root.parents:
        raise ValueError('English weights must be outside application source')
    small = grant.get('smallFiles', {})
    if set(small) != set(FILES) - {'model.q8.gguf'}:
        raise ValueError('Incomplete English build grant')
    root.mkdir(parents=True, exist_ok=True)
    for name, (size, digest) in FILES.items():
        if name == 'model.q8.gguf':
            try:
                with urllib.request.urlopen(url, timeout=120) as response:
                    data = response.read(size + 1)
            except Exception:
                raise ValueError('English model grant expired or download unavailable; renew build grant') from None
        else:
            data = base64.b64decode(small[name], validate=True)
        if len(data) != size or hashlib.sha256(data).hexdigest() != digest:
            raise ValueError('English speech grant failed pinned integrity validation')
        (root / name).write_bytes(data)
    return verify_assets(root)


if __name__ == '__main__':
    build_from_grant('/opt/gold-radio-assets/phonon40', '/run/secrets/phonon_build_json')
    print('Pinned Phonon 40M English q8 assets ready; no account token retained.')

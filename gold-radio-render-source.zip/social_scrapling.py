"""Bounded public Hacker News comments through Scrapling's static HTTP fetcher.

Only two fixed listings and four discussion pages may be requested per minute.
Story links and profile links are provenance data, never request destinations.
Comments are individual unverified opinions, never factual writer material.
The comment clock is limited to one hour; its explicitly older discussion
context has a separate, original-clock, 24-hour ceiling.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, wait
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
import re
import threading
import time
import unicodedata
from urllib.parse import urlsplit

from commentary_rules import _EXCLUDED, _FACT, _UNSAFE, _CONTEXT, _TOPIC, _VIEW
from news_selection import normalized_title
from social_feedback import _ABUSE, _CONTACT, _PERSONAL_FINANCE, _PROMO, _NEWS_POLITICS
from social_sources import Response, _next_delay
from source_policy import collection_url_allowed


REACTION_POLICY_VERSION = 'hn-public-business-opinion-2026-10-26-v1'
POLICY_VERSION = REACTION_POLICY_VERSION
MAX_AGE_S = 3600
MAX_CONTEXT_AGE_S = 86400
MAX_BYTES = 1024 * 1024
MAX_THREADS = 4
MAX_ROWS = 40
MAX_COMMENTS = 250
MAX_RECEIPTS = 512
MAX_WORKERS = 2
COLLECTION_BUDGET_S = 8
POLL_SECONDS = 60
HOST = 'news.ycombinator.com'
ORIGIN = 'https://' + HOST
LISTING_URLS = (ORIGIN + '/', ORIGIN + '/newest')
_NUMBER = re.compile(r'[1-9][0-9]{0,15}')
_USERNAME = re.compile(r'[A-Za-z0-9_-]{1,30}')
_AGE = re.compile(r'(20\d{2}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:Z)?(?: ([1-9][0-9]{8,11}))?')
_TECH = re.compile(r'(?<!\w)(?:c\+\+\d*|compilers?|program\w*|develop\w*|code|coding|'
    r'next\.js|node\.js|javascript|typescript|html|css|lighthouse|linux|python|'
    r'open.source|comput\w*|databases?|gpus?|cpus?|hardware|keyboards?|browsers?|'
    r'wordart|titleart|websites?|internet|react|rust|java|apps?)(?!\w)', re.I)
_OPINION = re.compile(r'(?<!\w)(?:probably|seems?|imho|i (?:can only describe|find|suspect)|'
    r'good|bad|great|hard|complex|mess|chance|nostalg\w*|cool|neat)(?!\w)', re.I)
_DEPENDENT = re.compile(r'^(?:yes|no|agreed|exactly|thanks|thank you|this|that|it)\s*[.!?]$|'
    r'(?<!\w)(?:as (?:you|they) (?:said|mentioned)|your comment|the comment above|'
    r'parent comment|replying to|see (?:above|below)|look at (?:the|this) (?:image|video)|'
    r'ignore (?:all|previous|the) instructions?|system prompt|api key|password)(?!\w)', re.I)
_ROOT_UNSAFE = re.compile(r'(?<!\w)(?:fraud\w*|corrupt\w*|scam\w*|criminal\w*|'
    r'terror\w*|brib\w*|conspir\w*|stolen|steal\w*|exploit\w*|breach\w*|'
    r'malware|ransomware|alleg\w*|lawsuit\w*)(?!\w)', re.I)


def _digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def _item_url(identity):
    return ORIGIN + '/item?id=' + identity


def _item_id(value):
    if not isinstance(value, str):
        return None
    match = re.fullmatch(re.escape(ORIGIN) + r'/item\?id=([1-9][0-9]{0,15})', value)
    return match[1] if match else None


def request_url_allowed(value):
    return value in LISTING_URLS or _item_id(value) is not None


def _stamp(value):
    """HN's full age title is UTC; relative display text never supplies a clock."""
    match = _AGE.fullmatch(value) if isinstance(value, str) else None
    if not match:
        raise ValueError('Missing original public discussion clock')
    stamp = int(datetime.fromisoformat(match[1]).replace(tzinfo=timezone.utc).timestamp())
    if match[2] is not None and int(match[2]) != stamp:
        raise ValueError('Conflicting original public discussion clock')
    return stamp


def _plain(value, minimum=1, maximum=400):
    return (isinstance(value, str) and minimum <= len(value) <= maximum and
            value == ' '.join(value.split()) and
            not any(unicodedata.category(c).startswith('C') for c in value) and
            not re.search(r'[<>{}\\\[\]]', value))


def _english(value):
    return (sum('a' <= c.lower() <= 'z' for c in value) >= 12 and
            not any(c.isalpha() and 'LATIN' not in unicodedata.name(c, '') for c in value))


def _story_url_allowed(value, identity):
    if value in ('item?id=' + identity, _item_url(identity)):
        return True
    if not isinstance(value, str) or len(value) > 2048 or '\\' in value or any(
            c.isspace() or ord(c) < 33 or ord(c) == 127 for c in value):
        return False
    try:
        parsed = urlsplit(value)
        host = parsed.hostname
        return bool(parsed.scheme == 'https' and host and parsed.username is None and
            parsed.password is None and parsed.port is None and '.' in host and
            re.fullmatch(r'[a-z0-9.-]+', host) and not re.fullmatch(r'[0-9.]+', host) and
            not any(host == excluded or host.endswith('.' + excluded) for excluded in _EXCLUDED))
    except (ValueError, TypeError):
        return False


def _root_title_allowed(title):
    return (_plain(title, 10, 400) and _english(title) and not title.endswith(('...', '\u2026')) and
            bool(_TOPIC.search(normalized_title(title)) or _TECH.search(title)) and
            not _ABUSE.search(title) and not _NEWS_POLITICS.search(title) and not _ROOT_UNSAFE.search(title))


class _CommentText(HTMLParser):
    """Keep all authored prose; reject links, hidden material and code blocks."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.valid, self.wrapper = [], True, False
        self.depth, self.closed = 0, False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'div' and not self.wrapper and not self.parts:
            self.wrapper = True
            self.depth = 1
            if attrs != {'class': 'commtext c00'}:
                self.valid = False
            return
        if not self.wrapper or self.closed or tag not in {'p', 'br', 'em', 'strong', 'b', 'i', 'code'} or attrs:
            self.valid = False
        if tag in {'p', 'br'}:
            self.parts.append(' ')

    def handle_endtag(self, tag):
        if tag == 'div':
            if not self.wrapper or self.closed:
                self.valid = False
            self.closed = True
        elif tag not in {'p', 'br', 'em', 'strong', 'b', 'i', 'code'}:
            self.valid = False
        if tag in {'p', 'br'}:
            self.parts.append(' ')

    def handle_data(self, value):
        if not self.wrapper or self.closed:
            if value.strip():
                self.valid = False
        else:
            self.parts.append(value)

    def handle_comment(self, _value):
        self.valid = False

    def handle_decl(self, _value):
        self.valid = False


def _comment_text(raw):
    if not isinstance(raw, str) or not 1 <= len(raw) <= 16000 or '\x00' in raw:
        return ''
    parser = _CommentText()
    try:
        parser.feed(raw)
        parser.close()
    except (TypeError, ValueError):
        return ''
    return ' '.join(''.join(parser.parts).split()) if parser.valid and parser.wrapper and parser.closed else ''


def opinion_text(text):
    """Versioned whole-comment opinion gate, contextualized by a fetched root."""
    if (not _plain(text, 20, 500) or not _english(text) or not 4 <= len(text.split()) <= 90 or
            text.endswith(('...', '\u2026')) or not re.search(r'[.!?]["\u201d\u2019\')]*$', text) or
            re.search(r'[@#$€£¥%{}\\\[\]]', text)):
        return ''
    folded = normalized_title(text)
    # Recognize the two literal software names without mistaking them for
    # contact URLs. Other domains, email addresses and links remain excluded.
    contact_text = re.sub(r'\b(?:Next\.js|Node\.js)\b', 'software', text, flags=re.I)
    if (_CONTACT.search(contact_text) or _ABUSE.search(folded) or _PROMO.search(folded) or
            _PERSONAL_FINANCE.search(folded) or _UNSAFE.search(folded) or _FACT.search(folded) or
            _UNSAFE.search(unicodedata.normalize('NFKC', text)) or _CONTEXT.search(text) or
            _DEPENDENT.search(text) or _NEWS_POLITICS.search(folded) or
            not (_VIEW.search(folded) or _OPINION.search(text))):
        return ''
    return text


def _root_hash(root):
    return _digest(json.dumps(root, ensure_ascii=False, sort_keys=True, separators=(',', ':')))


def _root_allowed(root, now_s):
    if (not isinstance(root, dict) or not isinstance(root.get('id'), str) or
            not _NUMBER.fullmatch(root['id']) or root.get('url') != _item_url(root['id']) or
            root.get('language') != 'en' or not _root_title_allowed(root.get('title')) or
            root.get('titleHash') != _digest(root['title']) or
            type(root.get('publishedAt')) is not int or type(root.get('firstSeenAt')) is not int or
            not 0 < root['publishedAt'] <= root['firstSeenAt'] <= now_s or
            now_s - root['publishedAt'] > MAX_CONTEXT_AGE_S or
            not _story_url_allowed(root.get('storyUrl'), root['id'])):
        return False
    try:
        return _stamp(root.get('createdAtRaw')) == root['publishedAt']
    except (ValueError, TypeError, OverflowError):
        return False


def reaction_allowed(row, now_s):
    """Revalidate original HTML, exact account, root and clocks at restore/air."""
    if (not isinstance(row, dict) or type(now_s) is not int or now_s <= 0 or
            row.get('platform') != 'HackerNews' or row.get('sourceKind') != 'social-reaction' or
            row.get('social') is not True or row.get('language') != 'en' or row.get('summary') != '' or
            row.get('timeKind') != 'published' or row.get('clockBasis') != 'author-reported' or
            row.get('verification') != 'unverified-public-opinion' or
            not isinstance(row.get('title'), str) or not row['title'] or
            type(row.get('publishedAt')) is not int or type(row.get('firstSeenAt')) is not int or
            not 0 < row['publishedAt'] <= row['firstSeenAt'] <= now_s or
            now_s - row['publishedAt'] > MAX_AGE_S or opinion_text(row.get('title')) != row.get('title')):
        return False
    meta = row.get('reaction')
    if (not isinstance(meta, dict) or meta.get('screeningPolicy') != REACTION_POLICY_VERSION or
            meta.get('screeningKind') != 'bounded-discussion-opinion' or
            meta.get('screeningGuarantee') != 'rules-not-independent-fact-verification' or
            meta.get('collectorHost') != HOST or meta.get('unverified') is not True or
            meta.get('representative') is not False or type(meta.get('commentDepth')) is not int or
            meta['commentDepth'] != 0 or 'authorName' in meta or
            not isinstance(meta.get('authorId'), str) or not _USERNAME.fullmatch(meta['authorId']) or
            meta.get('authorHandle') != meta['authorId'] or meta.get('username') != meta['authorId'] or
            not isinstance(meta.get('statusId'), str) or not _NUMBER.fullmatch(meta['statusId']) or
            row.get('url') != _item_url(meta['statusId']) or
            row.get('id') != _digest('social-reaction:' + row['url'])[:32] or
            row.get('source') != 'Public comment @' + meta['authorId'] + ' on Hacker News' or
            meta.get('contentHash') != _digest(row['title']) or
            _comment_text(meta.get('rawCommentHtml')) != row['title'] or
            meta.get('rawCommentHash') != _digest(meta['rawCommentHtml'])):
        return False
    root = meta.get('root')
    if (not _root_allowed(root, now_s) or meta.get('rootHash') != _root_hash(root) or
            meta.get('parentId') != root['id'] or meta['statusId'] == root['id'] or
            not root['publishedAt'] <= row['publishedAt'] or root['firstSeenAt'] > row['firstSeenAt']):
        return False
    try:
        return _stamp(meta.get('createdAtRaw')) == row['publishedAt']
    except (ValueError, TypeError, OverflowError):
        return False


def context_parent(row):
    """Return the immutable fetched discussion title, never an inferred parent."""
    return deepcopy(row['reaction']['root']) if (isinstance(row, dict) and
        type(row.get('firstSeenAt')) is int and reaction_allowed(row, row['firstSeenAt'])) else None


def _page(body):
    if (not isinstance(body, bytes) or not 1 <= len(body) <= MAX_BYTES or b'\x00' in body or
            not body.rstrip().lower().endswith(b'</html>')):
        raise ValueError('Invalid bounded public discussion HTML')
    body.decode('utf-8', errors='strict')
    from scrapling.parser import Selector
    return Selector(content=body, url=ORIGIN, adaptive=False, huge_tree=False, keep_comments=True)


def _root_from_node(node, received_s):
    identity = str(node.attrib.get('id', ''))
    if not _NUMBER.fullmatch(identity) or len(node.css('.titleline > a')) != 1:
        return None
    title_node = node.css('.titleline > a')[0]
    # Text is whole; markup is not an invitation to read the linked article.
    title = ' '.join(str(title_node.get_all_text(separator='', strip=False)).split())
    age = node.xpath('following-sibling::tr[1]//span[@class="age"]')
    if len(age) != 1 or age[0].css('a::attr(href)').get() != 'item?id=' + identity:
        return None
    raw = str(age[0].attrib.get('title', ''))
    try:
        root = {'id': identity, 'url': _item_url(identity), 'title': title, 'language': 'en',
            'publishedAt': _stamp(raw), 'firstSeenAt': received_s, 'createdAtRaw': raw,
            'storyUrl': str(title_node.attrib.get('href', '')), 'titleHash': _digest(title)}
        return root if _root_allowed(root, received_s) else None
    except (ValueError, TypeError, OverflowError):
        return None


def parse_listing(body, received_s):
    if type(received_s) is not int or received_s <= 0:
        raise ValueError('Invalid public discussion receipt clock')
    page = _page(body)
    rows = page.css('tr.athing.submission')
    if len(rows) > 60:
        raise ValueError('Public discussion listing limit')
    roots, seen = [], set()
    for node in rows:
        root = _root_from_node(node, received_s)
        if not root or root['id'] in seen:
            continue
        links = node.xpath('following-sibling::tr[1]//a')
        # Only already-commented threads consume the bounded request budget.
        if not any(link.attrib.get('href') == 'item?id=' + root['id'] and
                   re.fullmatch(r'[1-9][0-9]{0,6} comments?', str(link.get_all_text()).replace('\xa0', ' '))
                   for link in links):
            continue
        seen.add(root['id'])
        roots.append(root)
    return roots


def parse_thread(body, root, received_s):
    if type(received_s) is not int or received_s <= 0 or not _root_allowed(root, received_s):
        raise ValueError('Invalid fetched discussion context')
    page = _page(body)
    originals = page.css('table.fatitem tr.athing')
    canonical = page.css('link[rel="canonical"]::attr(href)').get()
    if len(originals) != 1 or canonical != root['url']:
        raise ValueError('Unmatched public discussion page')
    fetched_root = _root_from_node(originals[0], received_s)
    if not fetched_root or any(fetched_root.get(key) != value for key, value in root.items()
                               if key != 'firstSeenAt'):
        raise ValueError('Changed public discussion context')
    comments = page.css('table.comment-tree tr.athing.comtr')
    if len(comments) > MAX_COMMENTS:
        raise ValueError('Public discussion comment limit')
    rows, seen = [], set()
    for node in comments:
        identity = str(node.attrib.get('id', ''))
        if (not _NUMBER.fullmatch(identity) or identity in seen or identity == root['id'] or
                set(node.attrib.get('class', '').split()) != {'athing', 'comtr'} or
                set(node.attrib) != {'class', 'id'} or
                node.xpath('.//*[@hidden or @aria-hidden="true" or contains(@style,"display:none") or '
                           'contains(@style,"display: none") or contains(@style,"visibility:hidden")]'
                           '[not(ancestor-or-self::*[contains(concat(" ",normalize-space(@class)," ")," navs ")])]')):
            continue
        indent = node.css('td.ind')
        if len(indent) != 1 or indent[0].attrib.get('indent') != '0' or indent[0].css('img::attr(width)').get() != '0':
            continue
        # Only a direct child of the original story is admitted. Nested parent
        # links are never fetched or guessed into missing context.
        if any(str(link.get_all_text()).strip().lower() == 'parent' for link in node.css('.navs a')):
            continue
        authors, ages, prose = node.css('a.hnuser'), node.css('span.age'), node.css('.commtext')
        if len(authors) != 1 or len(ages) != 1 or len(prose) != 1:
            continue
        author = str(authors[0].get_all_text(separator='', strip=False))
        if (not _USERNAME.fullmatch(author) or authors[0].attrib.get('href') != 'user?id=' + author or
                ages[0].css('a::attr(href)').get() != 'item?id=' + identity):
            continue
        raw, created = str(prose[0].html_content), str(ages[0].attrib.get('title', ''))
        text = opinion_text(_comment_text(raw))
        if not text:
            continue
        try:
            published = _stamp(created)
        except (ValueError, TypeError, OverflowError):
            continue
        metadata = {'authorId': author, 'authorHandle': author, 'username': author, 'statusId': identity,
            'parentId': root['id'], 'commentDepth': 0, 'root': deepcopy(root), 'rootHash': _root_hash(root),
            'rawCommentHtml': raw, 'rawCommentHash': _digest(raw), 'contentHash': _digest(text),
            'createdAtRaw': created, 'collectorHost': HOST, 'screeningPolicy': REACTION_POLICY_VERSION,
            'screeningKind': 'bounded-discussion-opinion',
            'screeningGuarantee': 'rules-not-independent-fact-verification',
            'unverified': True, 'representative': False}
        row = {'id': _digest('social-reaction:' + _item_url(identity))[:32], 'url': _item_url(identity),
            'title': text, 'summary': '', 'source': 'Public comment @' + author + ' on Hacker News',
            'language': 'en', 'publishedAt': published, 'firstSeenAt': received_s, 'social': True,
            'sourceKind': 'social-reaction', 'platform': 'HackerNews', 'timeKind': 'published',
            'clockBasis': 'author-reported', 'verification': 'unverified-public-opinion', 'reaction': metadata}
        if reaction_allowed(row, received_s):
            rows.append(row)
            seen.add(identity)
            if len(rows) >= MAX_ROWS:
                break
    return rows


def fetch_public(url, headers, timeout):
    if (not request_url_allowed(url) or not collection_url_allowed(url) or
            not isinstance(timeout, (int, float)) or isinstance(timeout, bool) or
            not 0 < timeout <= COLLECTION_BUDGET_S):
        raise ValueError('Unsupported public discussion request')
    from scrapling.fetchers import Fetcher
    deadline, chunks, size, aborted = time.monotonic() + timeout, [], 0, False

    def receive(block):
        nonlocal size, aborted
        if not isinstance(block, bytes) or time.monotonic() >= deadline or size + len(block) > MAX_BYTES:
            aborted = True
            return 0xFFFFFFFF  # CURL_WRITEFUNC_ERROR: stop before retaining excess.
        size += len(block)
        chunks.append(block)
        return len(block)

    response = Fetcher.get(url, timeout=timeout, retries=0, follow_redirects=False, max_redirects=0,
        impersonate=None, stealthy_headers=False, proxies={'all': ''}, proxy=None,
        headers={'User-Agent': 'PublicNewsReader/1.0',
                 'Accept': 'text/html', 'Accept-Encoding': 'identity'},
        # Scrapling 0.5's underlying synchronous request does not expose
        # curl_options. The callback enforces the limit even without a
        # Content-Length header and before retaining any excess bytes.
        content_callback=receive, accept_encoding='identity',
        selector_config={'adaptive': False, 'huge_tree': False, 'keep_comments': True})
    values = {str(key).lower(): str(value) for key, value in response.headers.items()}
    if aborted or response.url != url or response.history or time.monotonic() > deadline:
        raise ValueError('Redirected or expired public discussion response')
    length = values.get('content-length')
    if (values.get('content-encoding', 'identity').lower() != 'identity' or
            length is not None and (not length.isdecimal() or int(length) > MAX_BYTES)):
        raise ValueError('Public discussion response limit')
    return Response(response.status, values, b''.join(chunks), url)


class SocialScraplingCollector:
    def __init__(self, fetcher=None):
        self._fetcher = fetcher or fetch_public
        self._lock, self._collect_lock = threading.RLock(), threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix='hn-public-comments')
        self._pending, self._receipts = {}, {}
        self._thread_checks = {}
        self._next_poll_at = 0
        self._state = {'source': 'Hacker News public discussions', 'platform': 'HackerNews',
            'status': 'starting', 'checkedAt': 0, 'lastSuccessAt': 0, 'nextCheckAt': 0,
            'accepted': 0, 'failures': 0, 'httpStatus': None, 'error': None}

    def status(self):
        with self._lock:
            ready = int(self._state['status'] == 'ready')
            return {'enabled': True, 'status': self._state['status'], 'sourceCount': 1,
                'enabledSourceCount': 1, 'readySources': ready, 'sources': [deepcopy(self._state)],
                'checkedAt': self._state['checkedAt'], 'pendingRequests': len(self._pending),
                'nextCheckAt': self._next_poll_at, 'maxAgeSeconds': MAX_AGE_S,
                'maxContextAgeSeconds': MAX_CONTEXT_AGE_S, 'pollSeconds': POLL_SECONDS,
                'maxThreadsPerCycle': MAX_THREADS, 'maxWorkers': MAX_WORKERS,
                'screeningPolicy': REACTION_POLICY_VERSION,
                'transport': 'Scrapling static HTTP; fixed public Hacker News pages; no browser; no PC',
                'verification': 'Unverified individual comments; older discussion context is labelled; not representative'}

    def _request(self, url, deadline):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Public discussion deadline')
        response = self._fetcher(url, {}, min(COLLECTION_BUDGET_S, remaining))
        if (not isinstance(response, Response) or response.url != url or
                not isinstance(response.headers, dict) or not isinstance(response.body, bytes) or
                len(response.body) > MAX_BYTES or time.monotonic() > deadline):
            raise ValueError('Invalid public discussion response')
        headers = {str(key).lower(): str(value) for key, value in response.headers.items()}
        if response.status == 200 and 'text/html' not in headers.get('content-type', '').lower():
            raise ValueError('Unexpected public discussion content type')
        return response.status, headers, response.body

    def _batch(self, urls, deadline):
        with self._lock:
            self._pending = {url: job for url, job in self._pending.items() if not job.done()}
            available = max(0, MAX_WORKERS - len(self._pending))
            jobs = {self._pool.submit(self._request, url, deadline): url for url in urls[:available]}
            self._pending.update({url: job for job, url in jobs.items()})
        done, _ = wait(jobs, timeout=max(0, deadline - time.monotonic()))
        result = []
        for job, url in jobs.items():
            try:
                if job not in done:
                    job.cancel()
                    raise TimeoutError('Public discussion deadline')
                result.append((url, job.result(), None))
            except Exception:
                result.append((url, None, 'Public discussion source unavailable'))
            if job.done():
                with self._lock:
                    self._pending.pop(url, None)
        return result

    def collect(self, now_s=None):
        real_clock = now_s is None
        now_s = int(time.time()) if real_clock else now_s
        if type(now_s) is not int or now_s <= 0:
            raise ValueError('A valid public discussion clock is required')
        if not self._collect_lock.acquire(blocking=False):
            return []
        try:
            with self._lock:
                if now_s * 1000 < self._next_poll_at or any(not job.done() for job in self._pending.values()):
                    return []
                self._state['checkedAt'] = now_s * 1000
            deadline, roots, result = time.monotonic() + COLLECTION_BUDGET_S, {}, {}
            responses = self._batch(list(LISTING_URLS), deadline)
            failures, successes, restricted, delay, latest_status = 0, 0, None, POLL_SECONDS, None

            def consume(response):
                nonlocal failures, successes, restricted, delay, latest_status
                _url, value, error = response
                if error or value is None:
                    failures += 1
                    return None
                status, headers, body = value
                latest_status = status
                delay = max(delay, _next_delay(headers, now_s, self._state['failures'] + 1, status))
                if status in (401, 403, 429):
                    restricted = 'rate_limited' if status == 429 else 'access_denied'
                if status != 200:
                    failures += 1
                    return None
                successes += 1
                return body

            for response in responses:
                body = consume(response)
                if body is not None:
                    try:
                        received = int(time.time()) if real_clock else now_s
                        for root in parse_listing(body, received):
                            roots.setdefault(root['id'], root)
                    except Exception:
                        failures += 1
            # Freshest roots break initial ties; subsequent cycles visit the
            # least recently checked discussions first, without popularity or
            # engagement-based ranking or permanent front-page starvation.
            candidates = sorted(roots.values(), key=lambda root:
                (self._thread_checks.get(root['id'], 0), -root['publishedAt']))[:MAX_THREADS]
            for offset in range(0, len(candidates), MAX_WORKERS):
                if restricted or time.monotonic() >= deadline:
                    break
                group = candidates[offset:offset + MAX_WORKERS]
                self._thread_checks.update({root['id']: now_s for root in group})
                by_url = {root['url']: root for root in group}
                for response in self._batch(list(by_url), deadline):
                    body = consume(response)
                    if body is None:
                        continue
                    try:
                        received = int(time.time()) if real_clock else now_s
                        for row in parse_thread(body, by_url[response[0]], received):
                            old = self._receipts.get(row['id'])
                            if old:
                                # Freeze both first receipts before comparing the entire
                                # authored content, identity and original context.
                                row['firstSeenAt'] = old['firstSeenAt']
                                row['reaction']['root']['firstSeenAt'] = old['reaction']['root']['firstSeenAt']
                                row['reaction']['rootHash'] = _root_hash(row['reaction']['root'])
                                if row != old:
                                    continue
                            if reaction_allowed(row, received):
                                self._receipts[row['id']] = deepcopy(row)
                                result[row['id']] = row
                    except Exception:
                        failures += 1
            finished = int(time.time()) if real_clock else now_s
            with self._lock:
                count = self._state['failures'] + 1 if failures else 0
                if failures and not successes:
                    delay = max(delay, _next_delay({}, finished, count, latest_status))
                self._next_poll_at = (finished + delay) * 1000
                self._state.update(status=restricted or ('ready' if successes else 'unavailable'),
                    accepted=len(result), failures=count, httpStatus=latest_status,
                    error='Public discussion source unavailable' if failures else None,
                    nextCheckAt=self._next_poll_at)
                if successes:
                    self._state['lastSuccessAt'] = finished * 1000
                self._receipts = dict(sorted(((key, row) for key, row in self._receipts.items()
                    if reaction_allowed(row, finished)), key=lambda pair: pair[1]['firstSeenAt'],
                    reverse=True)[:MAX_RECEIPTS])
                self._thread_checks = {key: checked for key, checked in self._thread_checks.items()
                                       if finished - checked <= MAX_CONTEXT_AGE_S}
            return [row for row in result.values() if reaction_allowed(row, finished)]
        finally:
            self._collect_lock.release()


ScraplingSocialCollector = SocialScraplingCollector

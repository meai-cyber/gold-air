import unittest

from news_selection import select_news, normalized_title, relevance, MAX_INPUT_ROWS


class NewsSelectionTests(unittest.TestCase):
    now = 1792719000

    def story(self, index=1, title='Gold prices rise as Treasury yields decline', language='en', **changes):
        return {'id': format(index, '032x'), 'title': title, 'source': 'Public publisher',
                'url': 'https://news.example.org/story/' + str(index), 'language': language,
                'publishedAt': self.now - 25, 'firstSeenAt': self.now - 10, **changes}

    def test_top_seventy_percent_rounds_up_and_keeps_best_rules(self):
        rows = [self.story(i, f'Inflation report {i}') for i in range(1, 10)]
        rows.append(self.story(10, 'Gold prices rise on Federal Reserve news'))
        result = select_news(rows, 'en', self.now)
        self.assertEqual(len(result.selected), 7)
        self.assertEqual(result.selected[0]['id'], rows[-1]['id'])
        self.assertEqual(result.summary()['targetPercent'], 70)
        self.assertEqual(result.summary()['relevant'], 10)
        self.assertEqual(result.reasons[rows[-1]['id']], ('gold', 'central-banks'))
        for count, expected in ((0, 0), (1, 1), (2, 2), (3, 3), (4, 3), (5, 4), (10, 7)):
            with self.subTest(count=count):
                sample = [self.story(i + 1, f'Inflation report {i}') for i in range(count)]
                self.assertEqual(len(select_news(sample, 'en', self.now).selected), expected)

    def test_unrelated_headlines_do_not_pad_the_quota(self):
        rows = [self.story(1), self.story(2, 'Actor shares new film trailer'),
                self.story(3, 'Football team celebrates a gold medal'),
                self.story(4, 'Golden retriever wins local competition'),
                self.story(5, 'Scientists find a new distant star')]
        result = select_news(rows, 'en', self.now)
        self.assertEqual([r['id'] for r in result.selected], [rows[0]['id']])
        self.assertEqual((result.scannedFresh, result.relevant, result.rejected), (5, 1, 4))
        self.assertEqual(select_news(rows[1:], 'en', self.now).selected, ())
        self.assertEqual(relevance('I am fed up with the weather')[0], 0)

    def test_arabic_normalization_language_isolation_and_gold_verb(self):
        rows = [self.story(1, 'أَسْعَارُ الذَّهَبِ ترتفع مع خفض الفائدة', 'ar'),
                self.story(2, 'ذهب الوزير إلى المعرض الفني', 'ar'),
                self.story(3, 'المنتخب يفوز بالميدالية الذهبية', 'ar'),
                self.story(4, 'Gold prices drop after inflation report', 'en')]
        result = select_news(rows, 'ar', self.now)
        self.assertEqual([r['id'] for r in result.selected], [rows[0]['id']])
        self.assertEqual((result.scannedFresh, result.rejected, result.invalid), (3, 2, 0))
        self.assertIn('gold', result.reasons[rows[0]['id']])
        self.assertEqual(normalized_title('أَسْعَارُ الذَّهَبِ'), normalized_title('اسعار الذهب'))
        self.assertNotIn(rows[3]['id'], result.reasons)

    def test_explicit_english_market_headline_variants_are_relevant(self):
        cases = (('Dollar falls before policy decision', 'currencies'),
                 ('Dollar strengthens against peers', 'currencies'),
                 ('Stocks plunge after company results', 'financial-risk'),
                 ('Global shares are mixed in early trading', 'financial-risk'),
                 ('Asian shares rise as investors return', 'financial-risk'),
                 ('Treasury auction draws strong demand', 'rates-and-bonds'),
                 ('Treasury bonds edge higher', 'rates-and-bonds'),
                 ('Treasury secretary outlines borrowing plans', 'rates-and-bonds'))
        for title, reason in cases:
            with self.subTest(title=title):
                score, reasons = relevance(title)
                self.assertGreaterEqual(score, 25)
                self.assertIn(reason, reasons)

    def test_arabic_clitics_and_explicit_bare_gold_market_context(self):
        cases = (('والذهب يرتفع في التعاملات', 'gold'),
                 ('فأسعار الذهب تسجل ارتفاعاً', 'gold'),
                 ('ذهب عيار 21 يرتفع اليوم', 'gold'),
                 ('ذهب يرتفع إلى مستوى جديد', 'gold'),
                 ('سعر ذهب يرتفع في السوق المحلية', 'gold'),
                 ('وأسعار الفائدة تتراجع', 'rates-and-bonds'),
                 ('والأسواق العالمية تشهد تقلبات', 'financial-risk'),
                 ('الأسواق تتراجع في بداية الجلسة', 'financial-risk'))
        for title, reason in cases:
            with self.subTest(title=title):
                score, reasons = relevance(title)
                self.assertGreaterEqual(score, 25)
                self.assertIn(reason, reasons)

    def test_ordinary_uses_of_new_macro_words_remain_unrelated(self):
        for title in ('Dollar store opens another branch', 'Stocks of donated food arrive at school',
                      'Treasury museum returns an ancient sculpture', 'ذهب الوزير إلى المعرض الفني',
                      'وذهب الطفل إلى المدرسة', 'الأسواق الشعبية تبيع الفاكهة',
                      'وأسعار تذاكر الحفل تتغير'):
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_stale_invalid_and_future_clocks_cannot_be_selected(self):
        bad = [self.story(1, publishedAt=self.now - 601),
               self.story(2, publishedAt=True), self.story(3, firstSeenAt=self.now + 1),
               self.story(4, publishedAt=self.now - 1, firstSeenAt=self.now - 2),
               self.story(5, publishedAt='123'), self.story(6, url='http://127.0.0.1/news'),
               self.story(7, url='https://name:pass@example.org/news'),
               self.story(8, url='https://example.org:443/news'),
               self.story(9, title='Bad\x00gold'), self.story(10, id=None), None]
        result = select_news(bad, 'en', self.now)
        self.assertEqual(result.selected, ())
        self.assertEqual((result.stale, result.invalid), (1, 10))
        boundary = self.story(12, publishedAt=self.now - 600, firstSeenAt=self.now - 600)
        self.assertEqual(select_news([boundary], 'en', self.now).selected, (boundary,))

    def test_duplicate_titles_preserve_earliest_original_clocks_and_text(self):
        original = self.story(1, 'Gold prices: rise!', publishedAt=self.now - 200, firstSeenAt=self.now - 180)
        later = self.story(2, 'GOLD PRICES — RISE', publishedAt=self.now - 20, firstSeenAt=self.now - 5)
        result = select_news([later, original], 'en', self.now)
        self.assertEqual(result.selected, (original,))
        self.assertIsNot(result.selected[0], original)
        self.assertEqual(result.duplicates, 1)
        self.assertEqual((original['publishedAt'], original['firstSeenAt']), (self.now - 200, self.now - 180))
        self.assertEqual(select_news([original, later], 'en', self.now).selected, result.selected)

    def test_duplicate_id_and_arabic_diacritics_do_not_double_count(self):
        original = self.story(1, 'التَّضَخُّمُ يرتفع', 'ar', publishedAt=self.now - 40)
        same_title = self.story(2, 'التضخم يرتفع', 'ar')
        same_id = self.story(1, 'النفط ينخفض', 'ar')
        result = select_news([same_id, same_title, original], 'ar', self.now)
        self.assertEqual(result.selected, (original,))
        self.assertEqual(result.duplicates, 2)

    def test_syndicated_duplicate_does_not_refresh_a_stale_original(self):
        old = self.story(1, 'Gold prices rise', publishedAt=self.now - 601, firstSeenAt=self.now - 590)
        refreshed = self.story(2, 'Gold prices: rise!')
        result = select_news([refreshed, old], 'en', self.now)
        self.assertEqual(result.selected, ())
        self.assertEqual((result.stale, result.duplicates, result.scannedFresh), (1, 1, 0))

    def test_ties_are_stable_newer_then_id_and_receipts_are_not_mutated(self):
        rows = [self.story(i, f'Inflation headline {i}', publishedAt=self.now - i,
                           firstSeenAt=self.now - i + 1) for i in range(1, 5)]
        expected = [row['id'] for row in rows[:3]]
        result = select_news(list(reversed(rows)), 'en', self.now)
        self.assertEqual([row['id'] for row in result.selected], expected)
        same_time = [self.story(i, f'Inflation headline {i}') for i in (4, 3, 2, 1)]
        self.assertEqual([row['id'] for row in select_news(same_time, 'en', self.now).selected],
                         [format(i, '032x') for i in (1, 2, 3)])
        self.assertEqual(set(rows[0]), {'id', 'title', 'source', 'url', 'language', 'publishedAt', 'firstSeenAt'})

    def test_selection_is_computed_before_playback_receipts(self):
        rows = [self.story(i, f'Inflation headline {i}') for i in range(1, 11)]
        selected = select_news(rows, 'en', self.now)
        spoken = {row['id'] for row in selected.selected}
        still_selected = select_news(rows, 'en', self.now)
        self.assertEqual([row for row in still_selected.selected if row['id'] not in spoken], [])
        self.assertEqual(len(still_selected.selected), 7)

    def test_bounded_input_and_invalid_function_arguments(self):
        rows = (self.story(i + 1, f'Inflation report {i}') for i in range(MAX_INPUT_ROWS + 20))
        result = select_news(rows, 'en', self.now)
        self.assertTrue(result.truncated)
        self.assertEqual(result.scannedFresh, MAX_INPUT_ROWS)
        self.assertEqual(len(result.scores), MAX_INPUT_ROWS)
        for arguments in (([], 'fr', self.now), ([], 'en', True), (None, 'en', self.now),
                          ({}, 'en', self.now), ('headlines', 'en', self.now)):
            with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                select_news(*arguments)


if __name__ == '__main__':
    unittest.main()

import unittest

from news_selection import select_news, normalized_title, relevance, MAX_INPUT_ROWS


class NewsSelectionTests(unittest.TestCase):
    now = 1792719000

    def story(self, index=1, title='Gold prices rise as Treasury yields decline', language='en', **changes):
        return {'id': format(index, '032x'), 'title': title, 'source': 'Public publisher',
                'url': 'https://news.example.org/story/' + str(index), 'language': language,
                'publishedAt': self.now - 25, 'firstSeenAt': self.now - 10, **changes}

    def test_top_forty_percent_rounds_up_and_keeps_best_rules(self):
        rows = [self.story(i, f'Inflation report {i}') for i in range(1, 10)]
        rows.append(self.story(10, 'Gold prices rise on Federal Reserve news'))
        result = select_news(rows, 'en', self.now, target_percent=40)
        self.assertEqual(len(result.selected), 4)
        self.assertEqual(result.selected[0]['id'], rows[-1]['id'])
        self.assertEqual(result.summary()['targetPercent'], 40)
        self.assertEqual(result.summary()['method'], 'deterministic-gold-macro-top-40-v7')
        self.assertEqual(result.summary()['relevant'], 10)
        self.assertEqual(result.reasons[rows[-1]['id']], ('gold', 'central-banks'))
        for count, expected in ((0, 0), (1, 1), (2, 1), (3, 2), (4, 2), (5, 2), (10, 4)):
            with self.subTest(count=count):
                sample = [self.story(i + 1, f'Inflation report {i}') for i in range(count)]
                self.assertEqual(len(select_news(sample, 'en', self.now, target_percent=40).selected), expected)

    def test_default_selects_every_eligible_report_with_gold_priority(self):
        rows = [self.story(i, f'Inflation report {i}') for i in range(1, 10)]
        gold = self.story(10, 'Gold prices rise on Federal Reserve news')
        result = select_news([*rows, gold, self.story(11, 'Actor shares a film trailer')], 'en', self.now)
        self.assertEqual(len(result.selected), 10)
        self.assertEqual(result.selected[0], gold)
        self.assertEqual(result.summary()['targetPercent'], 100)
        self.assertEqual(result.summary()['method'], 'deterministic-gold-macro-top-100-v7')
        self.assertEqual(result.rejected, 1)
        for invalid in (0, 101, -1, True, 40.0, '100', None):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                select_news(rows, 'en', self.now, target_percent=invalid)

    def test_unrelated_headlines_do_not_pad_the_quota(self):
        rows = [self.story(1), self.story(2, 'Actor shares new film trailer'),
                self.story(3, 'Football team celebrates a gold medal'),
                self.story(4, 'Golden retriever wins local competition'),
                self.story(5, 'Scientists find a new distant star')]
        result = select_news(rows, 'en', self.now)
        self.assertEqual([r['id'] for r in result.selected], [rows[0]['id']])
        self.assertEqual((result.scannedFresh, result.relevant, result.rejected), (5, 1, 4))
        self.assertEqual(select_news(rows[1:], 'en', self.now).selected, ())
        self.assertEqual(relevance('I am fed up with the weather')[0], 0)

    def test_arabic_normalization_language_isolation_and_gold_verb(self):
        rows = [self.story(1, 'أَسْعَارُ الذَّهَبِ ترتفع مع خفض الفائدة', 'ar'),
                self.story(2, 'ذهب الوزير إلى المعرض الفني', 'ar'),
                self.story(3, 'المنتخب يفوز بالميدالية الذهبية', 'ar'),
                self.story(4, 'Gold prices drop after inflation report', 'en')]
        result = select_news(rows, 'ar', self.now)
        self.assertEqual([r['id'] for r in result.selected], [rows[0]['id']])
        self.assertEqual((result.scannedFresh, result.rejected, result.invalid), (3, 2, 0))
        self.assertIn('gold', result.reasons[rows[0]['id']])
        self.assertEqual(normalized_title('أَسْعَارُ الذَّهَبِ'), normalized_title('اسعار الذهب'))
        self.assertNotIn(rows[3]['id'], result.reasons)

    def test_explicit_english_market_headline_variants_are_relevant(self):
        cases = (('Dollar falls before policy decision', 'currencies'),
                 ('Dollar strengthens against peers', 'currencies'),
                 ('Stocks plunge after company results', 'financial-risk'),
                 ('Global shares are mixed in early trading', 'financial-risk'),
                 ('Asian shares rise as investors return', 'financial-risk'),
                 ('Treasury auction draws strong demand', 'rates-and-bonds'),
                 ('Treasury bonds edge higher', 'rates-and-bonds'),
                 ('Treasury secretary outlines borrowing plans', 'rates-and-bonds'))
        for title, reason in cases:
            with self.subTest(title=title):
                score, reasons = relevance(title)
                self.assertGreaterEqual(score, 25)
                self.assertIn(reason, reasons)

    def test_arabic_clitics_and_explicit_bare_gold_market_context(self):
        cases = (('والذهب يرتفع في التعاملات', 'gold'),
                 ('فأسعار الذهب تسجل ارتفاعاً', 'gold'),
                 ('ذهب عيار 21 يرتفع اليوم', 'gold'),
                 ('ذهب يرتفع إلى مستوى جديد', 'gold'),
                 ('سعر ذهب يرتفع في السوق المحلية', 'gold'),
                 ('وأسعار الفائدة تتراجع', 'rates-and-bonds'),
                 ('والأسواق العالمية تشهد تقلبات', 'financial-risk'),
                 ('الأسواق تتراجع في بداية الجلسة', 'financial-risk'))
        for title, reason in cases:
            with self.subTest(title=title):
                score, reasons = relevance(title)
                self.assertGreaterEqual(score, 25)
                self.assertIn(reason, reasons)

    def test_ordinary_uses_of_new_macro_words_remain_unrelated(self):
        for title in ('Dollar store opens another branch', 'Stocks of donated food arrive at school',
                      'Treasury museum returns an ancient sculpture', 'ذهب الوزير إلى المعرض الفني',
                      'وذهب الطفل إلى المدرسة', 'الأسواق الشعبية تبيع الفاكهة',
                      'وأسعار تذاكر الحفل تتغير'):
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_actual_geopolitical_misses_and_explicit_weapons_are_relevant(self):
        cases = ('كردستان العراق تكشف حقيقة "المسيرات الأوكرانية"',
                 'Photos: Scenes from the shooting of two Palestinians in Hebron',
                 'المسيّرات الأوكرانية تظهر في تقرير جديد',
                 'أطلقت القوات صواريخ خلال التدريبات',
                 'القوات المسلحة تعلن عمليات جديدة',
                 'Military drones deployed near the border',
                 'Armed attack closes a border crossing',
                 'Israeli troops clash with demonstrators')
        for title in cases:
            with self.subTest(title=title):
                score, reasons = relevance(title)
                self.assertGreaterEqual(score, 25)
                self.assertIn('geopolitics', reasons)

    def test_country_crime_health_animals_and_sports_do_not_imply_conflict(self):
        cases = ('كيف تتجنب حصوات الكلى في الصيف؟',
                 'Iranian researchers explain kidney stones',
                 'Russia announces a new art exhibition',
                 'Man arrested after a knife attack in London',
                 'Israeli tourist survives shark attack',
                 'Iranian football team attacks the goal in friendly match',
                 'الفريق الأوكراني يشن هجمات في مباراة كرة القدم',
                 'مسيرات سلمية في العراق للاحتفال بالمهرجان',
                 'Israeli man arrested after robbery',
                 'Delivery drones bring food to homes')
        for title in cases:
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_publisher_airstrike_and_sudan_targeting_misses_keep_conflict_gates(self):
        # Actual Euronews Arabic and BBC World RSS headlines from the live audit.
        positive = ('غزة: لحظة غارة إسرائيلية تصيب مبنى في النصيرات توثقها الكاميرا',
                    'غارات إسرائيلية تستهدف مواقع قرب الحدود',
                    "Hospitals deliberately targeted by Sudan's RSF fighters, BBC finds",
                    'قوات الدعم السريع تستهدف مستشفيات في السودان')
        for title in positive:
            with self.subTest(title=title):
                self.assertIn('geopolitics', relevance(title)[1])
        negative = ('Sudan opens a new hospital',
                    'Sudanese researchers publish cancer care study',
                    'Sudan targets higher school attendance',
                    'RSF fighters discuss a local exhibition in Sudan',
                    'Israeli advertisers targeted new customers',
                    'غارات من الكلمات في رواية جديدة',
                    'سودانية تفوز بجائزة علمية',
                    'إسرائيلية تفتتح معرضاً فنياً',
                    'فريق سوداني يهاجم في مباراة كرة القدم')
        for title in negative:
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_natural_disaster_rule_requires_explicit_supply_disruption(self):
        for title in ('Hurricane shuts refinery on the coast',
                      'Earthquake damages gold mines',
                      'Floods disrupt global supplies',
                      'الفيضانات تعطل المصافي وخطوط الأنابيب'):
            with self.subTest(title=title):
                self.assertIn('natural-supply-shock', relevance(title)[1])
        for title in ('Earthquake shakes an uninhabited island',
                      'Cyclone photos win a science prize',
                      'تقرير عن الزلازل في المدارس',
                      'Hurricane charity receives money from an oil company'):
            with self.subTest(title=title):
                self.assertNotIn('natural-supply-shock', relevance(title)[1])

    def test_current_publisher_conflict_wording_and_nuclear_exercises(self):
        # Current Arabic publisher titles missed by the previous literal rules.
        cases = ('الضفة الغربية المحتلة: اشتباك وإطلاق نار وإصابات حرجة وتطويق أمني في الخليل',
                 'الكرملين: مفاوضات روسية أوكرانية بوساطة أميركية في أبوظبي خلال نوفمبر',
                 'لأول مرة.. تدريب نووي مشترك فرنسي بريطاني',
                 'محادثات سلام في أوكرانيا بمشاركة دولية',
                 'Russian and Ukrainian negotiations resume with mediation',
                 'Britain and France begin joint nuclear exercises')
        for title in cases:
            with self.subTest(title=title):
                self.assertIn('geopolitics', relevance(title)[1])
        ordinary = ('اشتباك لفظي بين فريقين في مباراة كرة القدم',
                    'إطلاق نار في مشاجرة عائلية داخل بلدة أوروبية',
                    'روسيا تبدأ مفاوضات لافتتاح معرض فني جديد',
                    'أوكرانيا تعلن محادثات لتنظيم مهرجان موسيقي',
                    'مفاوضات روسية أوكرانية لتنظيم مباراة كرة القدم',
                    'تدريب نووي في برنامج الطب النووي للأطباء',
                    'Nuclear medicine training begins at a hospital',
                    'France announces a new art exhibition')
        for title in ordinary:
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_current_global_equity_fund_flows_are_market_news(self):
        for title in ('صناديق الأسهم العالمية تجذب تدفقات للأسبوع الخامس على التوالي',
                      'والصناديق تتجه إلى صناديق الأسهم العالمية',
                      'Global equity funds record another week of inflows',
                      'Investors withdraw from stock funds'):
            with self.subTest(title=title):
                self.assertIn('financial-risk', relevance(title)[1])
        for title in ('صناديق التبرعات تجمع مساعدات للمدارس',
                      'أطفال يصنعون صناديق خشبية في معرض فني',
                      'Charity funds a new school art exhibition',
                      'Stocks of donated food arrive at a charity'):
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_important_world_reports_have_a_lower_priority_radio_context_tier(self):
        # Exact currently collected social headlines; none asserts gold impact.
        cases = ('فرنسا تنشر 70 ألف عنصر أمن تحسبًا لاحتجاجات السبت',
                 'وزير داخلية فرنسا يترك حسم الاحتجاجات للسلطات المحلية',
                 'شاهد عيان يروي تفاصيل مجزرة كنيسة الكرك بالأردن: إطلاق النار استمر 4 دقائق',
                 'شاهد عيان يروي تفاصيل الهجوم على كنيسة الكرك بالأردن',
                 'عاجل | وسائل إعلام أردنية: 7 قتلى على الأقل في إطلاق نار داخل كنيسة في محافظة الكرك جنوبي المملكة',
                 'فيديو يوثق مهاجمة مسلحين لحاجز الخليل.. ونتنياهو يتوعد',
                 'الأردن.. قتلى وجرحى بإطلاق نار أمام كنيسة في الكرك',
                 'عاجل | وزير الدفاع الإسرائيلي: المخربون ومن يرسلهم ويوفر لهم الغطاء سيدفعون ثمنا باهظا للغاية',
                 'عاجل | وزير الدفاع الإسرائيلي: سنخلي الحي الذي خرج منه منفذا عملية الخليل وسنهدم كل البنى التحتية الإرهابية',
                 'عاجل | مراسل الجزيرة: مستوطنون يهاجمون منازل الفلسطينيين في بلدة بورين جنوبي نابلس شمال الضفة الغربية',
                 'موسكو وكييف تواصلان تبادل الأسرى رغم انسداد مسار السلام',
                 'تبادل 540 أسيرًا بين موسكو وكييف وسط تعثر التسوية',
                 'عاجل | قائد القوات البرية بالجيش الإيراني: على قادة الوحدات القتالية الحفاظ على الجاهزية في أعلى مستوياتها',
                 'عاجل | نتنياهو: عملنا على بناء أكثر من 100 مستوطنة وبؤرة استيطانية جديدة وسنبني المزيد',
                 'Unidentified gunmen open fire at church in Jordan, causing deaths and injuries, state TV says',
                 'Czech government fast-tracks public media revamp criticised as power grab',
                 'Ukraine plans independent satellite system as Starlink issues persist',
                 'Silicon Valley Democrats demand investigation into Starlink restrictions in Ukraine',
                 "China's foreign minister urges stronger governance of deep sea and outer space",
                 'Stocks making the biggest moves premarket: AT&T, SpaceX and more',
                 'Fewer people are flying as airfare soars')
        for title in cases:
            with self.subTest(title=title):
                score, reasons = relevance(title)
                self.assertEqual(score, 25)
                self.assertTrue(reasons)
        for title in ("EU ministers vow to tackle 'China Shock 2.0' through talks with Beijing",
                      'The price of food has been rising since the pandemic',
                      'A tanker carrying diesel left the Russian port of Primorsk'):
            with self.subTest(title=title):
                self.assertGreater(relevance(title)[0], 25)
        self.assertGreater(relevance('Gold prices rise on Federal Reserve news')[0],
                           relevance(cases[0])[0])

    def test_world_context_does_not_admit_generic_official_health_sport_or_promos(self):
        cases = ('France announces a new art exhibition',
                 'الرئيس يزور معرض الزهور في فرنسا',
                 'وزير داخلية فرنسا يفتتح مكتبة جديدة',
                 'احتجاجات على نهاية مسلسل تلفزيوني',
                 'وزير الدفاع الإسرائيلي يحضر معرضا فنيا',
                 'الجيش الإيراني يفتتح متحف صور تاريخية',
                 'موسكو وكييف تتبادلان وفودا ثقافية',
                 'موسكو وكييف تبحثان تبادل لاعبي كرة القدم',
                 'French football fans discuss premarket team merchandise',
                 'Church choir rehearses for a holiday concert',
                 'Heart attack patient recovers near a church',
                 'New nuclear medicine training improves cancer care',
                 'Join my premarket club for free signals and guaranteed profits',
                 'تابعوني للحصول على توصيات مجانية من وول ستريت')
        for title in cases:
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_broader_important_world_events_have_conditional_low_priority_gates(self):
        cases = (
            ('National election results show a new coalition', 'world-policy'),
            ('الحكومة تقرر اقرار قانون جديد بشأن الهجرة', 'world-policy'),
            ('Supreme Court reviews immigration policy', 'world-policy'),
            ('نتائج الانتخابات الرئاسية تظهر تقدم مرشح المعارضة', 'world-policy'),
            ('United Nations warns of famine affecting millions', 'humanitarian'),
            ('الامم المتحدة تحذر من مجاعة تهدد ملايين النازحين', 'humanitarian'),
            ('Earthquake forces evacuations and destroys homes', 'world-emergency'),
            ('الزلزال يتسبب في انقطاع الكهرباء واجلاء السكان', 'world-emergency'),
            ('World Health Organization declares an international health emergency', 'world-emergency'),
            ('منظمة الصحة العالمية تعلن حالة طوارئ دولية', 'world-emergency'),
            ('NASA prepares a moon mission', 'science-and-environment'),
            ('ناسا تعلن تفاصيل مهمة فضائية جديدة', 'science-and-environment'),
        )
        for title, topic in cases:
            with self.subTest(title=title):
                self.assertEqual(relevance(title)[0], 25)
                self.assertIn(topic, relevance(title)[1])
        for title in ('Local club holds an election for a new chair',
                      'NASA shares a pretty picture from a school visit',
                      'Earthquake shakes an uninhabited island',
                      'Doctor explains a routine health check',
                      'الرئيس يزور معرض الزهور في فرنسا',
                      'علماء يشرحون تجربة مدرسية بسيطة',
                      'Gold prices rise: subscribe now for guaranteed profits',
                      'اشترك الآن لتحصل على توصيات مجانية عن الذهب'):
            with self.subTest(title=title):
                self.assertEqual(relevance(title), (0, ()))

    def test_presentation_prefix_duplicates_preserve_original_story_and_clocks(self):
        original = self.story(1, 'أسعار الذهب ترتفع', 'ar',
                              publishedAt=self.now - 200, firstSeenAt=self.now - 180)
        copied = self.story(2, 'عاجل | أسعار الذهب ترتفع', 'ar')
        result = select_news([copied, original], 'ar', self.now)
        self.assertEqual(result.selected, (original,))
        self.assertEqual(result.duplicates, 1)
        self.assertEqual(copied['title'], 'عاجل | أسعار الذهب ترتفع')
        self.assertEqual(normalized_title('BREAKING NEWS: Gold prices rise'),
                         normalized_title('Gold prices rise'))
        self.assertNotEqual(normalized_title('عاجل: قتلى عددهم 3 في هجوم الخليل'),
                            normalized_title('قتلى عددهم 4 في هجوم الخليل'))

    def test_stale_invalid_and_future_clocks_cannot_be_selected(self):
        bad = [self.story(1, publishedAt=self.now - 601),
               self.story(2, publishedAt=True), self.story(3, firstSeenAt=self.now + 1),
               self.story(4, publishedAt=self.now - 1, firstSeenAt=self.now - 2),
               self.story(5, publishedAt='123'), self.story(6, url='http://127.0.0.1/news'),
               self.story(7, url='https://name:pass@example.org/news'),
               self.story(8, url='https://example.org:443/news'),
               self.story(9, title='Bad\x00gold'), self.story(10, id=None), None]
        result = select_news(bad, 'en', self.now)
        self.assertEqual(result.selected, ())
        self.assertEqual((result.stale, result.invalid), (1, 10))
        boundary = self.story(12, publishedAt=self.now - 600, firstSeenAt=self.now - 600)
        self.assertEqual(select_news([boundary], 'en', self.now).selected, (boundary,))

    def test_duplicate_titles_preserve_earliest_original_clocks_and_text(self):
        original = self.story(1, 'Gold prices: rise!', publishedAt=self.now - 200, firstSeenAt=self.now - 180)
        later = self.story(2, 'GOLD PRICES — RISE', publishedAt=self.now - 20, firstSeenAt=self.now - 5)
        result = select_news([later, original], 'en', self.now)
        self.assertEqual(result.selected, (original,))
        self.assertIsNot(result.selected[0], original)
        self.assertEqual(result.duplicates, 1)
        self.assertEqual((original['publishedAt'], original['firstSeenAt']), (self.now - 200, self.now - 180))
        self.assertEqual(select_news([original, later], 'en', self.now).selected, result.selected)

    def test_duplicate_id_and_arabic_diacritics_do_not_double_count(self):
        original = self.story(1, 'التَّضَخُّمُ يرتفع', 'ar', publishedAt=self.now - 40)
        same_title = self.story(2, 'التضخم يرتفع', 'ar')
        same_id = self.story(1, 'النفط ينخفض', 'ar')
        result = select_news([same_id, same_title, original], 'ar', self.now)
        self.assertEqual(result.selected, (original,))
        self.assertEqual(result.duplicates, 2)

    def test_syndicated_duplicate_does_not_refresh_a_stale_original(self):
        old = self.story(1, 'Gold prices rise', publishedAt=self.now - 601, firstSeenAt=self.now - 590)
        refreshed = self.story(2, 'Gold prices: rise!')
        result = select_news([refreshed, old], 'en', self.now)
        self.assertEqual(result.selected, ())
        self.assertEqual((result.stale, result.duplicates, result.scannedFresh), (1, 1, 0))

    def test_last_hour_context_boundaries_preserve_original_source_clocks(self):
        rows = [self.story(i, f'Inflation report {i}', publishedAt=self.now - age,
                           firstSeenAt=self.now - age + 1)
                for i, age in enumerate((600, 601, 3600, 3601), 1)]
        fresh = select_news(rows, 'en', self.now)
        earlier = select_news(rows, 'en', self.now, window_s=3600, minimum_age_s=601, target_percent=40)
        self.assertEqual(fresh.selected, (rows[0],))
        self.assertEqual(earlier.selected, (rows[1],))
        self.assertEqual((earlier.scannedFresh, earlier.stale, earlier.invalid), (2, 1, 0))
        self.assertEqual((earlier.summary()['windowSeconds'], earlier.summary()['minimumAgeSeconds']), (3600, 601))
        self.assertEqual((fresh.summary()['windowSeconds'], fresh.summary()['minimumAgeSeconds']), (600, 0))
        self.assertEqual((earlier.selected[0]['publishedAt'], earlier.selected[0]['firstSeenAt']),
                         (self.now - 601, self.now - 600))

    def test_last_hour_context_keeps_same_relevance_quota_and_receipts_policy(self):
        rows = [self.story(i, f'Inflation report {i}', publishedAt=self.now - 700 - i,
                           firstSeenAt=self.now - 600) for i in range(1, 11)]
        rows.append(self.story(11, 'Actor shares a new film', publishedAt=self.now - 800))
        result = select_news(rows, 'en', self.now, window_s=3600, minimum_age_s=601, target_percent=40)
        self.assertEqual((result.scannedFresh, result.relevant, result.rejected), (11, 10, 1))
        self.assertEqual(len(result.selected), 4)
        self.assertEqual(result.summary()['targetPercent'], 40)
        spoken = {row['id'] for row in result.selected}
        repeated = select_news(rows, 'en', self.now, window_s=3600, minimum_age_s=601, target_percent=40)
        self.assertEqual([row for row in repeated.selected if row['id'] not in spoken], [])
        self.assertEqual(result.selected, repeated.selected)

    def test_duplicate_deduplication_precedes_both_age_cohort_boundaries(self):
        # A fresh syndication cannot renew a retained ten-minute-old original.
        earlier = self.story(1, 'Gold prices rise', publishedAt=self.now - 700, firstSeenAt=self.now - 690)
        newer = self.story(2, 'GOLD PRICES: RISE!', publishedAt=self.now - 20)
        self.assertEqual(select_news([newer, earlier], 'en', self.now).selected, ())
        self.assertEqual(select_news([newer, earlier], 'en', self.now, window_s=3600,
                                     minimum_age_s=601).selected, (earlier,))
        # Likewise an out-of-hour original blocks a timestamp-refreshed copy
        # that would otherwise be eligible for the earlier-reporting cohort.
        old = self.story(3, 'Oil prices rise', publishedAt=self.now - 3601, firstSeenAt=self.now - 3590)
        refreshed = self.story(3, 'Oil prices are higher', publishedAt=self.now - 900)
        result = select_news([refreshed, old], 'en', self.now, window_s=3600, minimum_age_s=601)
        self.assertEqual(result.selected, ())
        self.assertEqual((result.stale, result.duplicates), (1, 1))

    def test_context_selection_rejects_unreviewed_or_invalid_age_cohorts(self):
        for window, minimum in ((True, 0), (3600.0, 0), (601, 0), (10800, 0),
                                (600, True), (600, -1), (600, 600),
                                (3600, 3600), (3600, '601'), (3600, 601.0)):
            with self.subTest(window=window, minimum=minimum), self.assertRaises(ValueError):
                select_news([], 'en', self.now, window_s=window, minimum_age_s=minimum)

    def test_two_hour_context_is_original_clocked_and_keeps_legacy_hour_support(self):
        rows = [self.story(index, f'Gold market report {index}', publishedAt=self.now - age,
                           firstSeenAt=self.now - age + 1)
                for index, age in enumerate((3600, 3601, 7200, 7201), 1)]
        hour = select_news(rows, 'en', self.now, window_s=3600, minimum_age_s=601)
        two_hours = select_news(rows, 'en', self.now, window_s=7200, minimum_age_s=3601)
        self.assertEqual([row['id'] for row in hour.selected], [rows[0]['id']])
        self.assertEqual([row['id'] for row in two_hours.selected], [rows[1]['id'], rows[2]['id']])
        self.assertEqual(two_hours.summary()['windowSeconds'], 7200)
        self.assertEqual(two_hours.selected[-1]['publishedAt'], self.now - 7200)
        refreshed = {**rows[3], 'publishedAt': self.now - 4000, 'firstSeenAt': self.now - 1}
        self.assertEqual(select_news([rows[3], refreshed], 'en', self.now,
                                    window_s=7200, minimum_age_s=601).selected, ())

    def test_ties_are_stable_newer_then_id_and_receipts_are_not_mutated(self):
        rows = [self.story(i, f'Inflation headline {i}', publishedAt=self.now - i,
                           firstSeenAt=self.now - i + 1) for i in range(1, 5)]
        expected = [row['id'] for row in rows[:2]]
        result = select_news(list(reversed(rows)), 'en', self.now, target_percent=40)
        self.assertEqual([row['id'] for row in result.selected], expected)
        same_time = [self.story(i, f'Inflation headline {i}') for i in (4, 3, 2, 1)]
        self.assertEqual([row['id'] for row in select_news(same_time, 'en', self.now, target_percent=40).selected],
                         [format(i, '032x') for i in (1, 2)])
        self.assertEqual(set(rows[0]), {'id', 'title', 'source', 'url', 'language', 'publishedAt', 'firstSeenAt'})

    def test_selection_is_computed_before_playback_receipts(self):
        rows = [self.story(i, f'Inflation headline {i}') for i in range(1, 11)]
        selected = select_news(rows, 'en', self.now, target_percent=40)
        spoken = {row['id'] for row in selected.selected}
        still_selected = select_news(rows, 'en', self.now, target_percent=40)
        self.assertEqual([row for row in still_selected.selected if row['id'] not in spoken], [])
        self.assertEqual(len(still_selected.selected), 4)

    def test_bounded_input_and_invalid_function_arguments(self):
        rows = (self.story(i + 1, f'Inflation report {i}') for i in range(MAX_INPUT_ROWS + 20))
        result = select_news(rows, 'en', self.now)
        self.assertTrue(result.truncated)
        self.assertEqual(result.scannedFresh, MAX_INPUT_ROWS)
        self.assertEqual(len(result.scores), MAX_INPUT_ROWS)
        for arguments in (([], 'fr', self.now), ([], 'en', True), (None, 'en', self.now),
                          ({}, 'en', self.now), ('headlines', 'en', self.now)):
            with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                select_news(*arguments)


if __name__ == '__main__':
    unittest.main()

"""Fixed public Mastodon financial opinions, never a factual news source.

Only four exact hashtag timelines are polled. Public, unedited local posts with
complete self-contained opinion text can pass the conservative financial gate.
Links, federation, boosts, private visibility, sensitive content and alleged new
facts do not acquire a broadcast route. No login, posting or arbitrary URL fetch.
API: https://docs.joinmastodon.org/methods/timelines/#tag
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import dataclass
from html.parser import HTMLParser
import hashlib
import json
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.request

from social_feedback import _safe_text, _NoRedirect, _author_name, _author_name_allowed
from social_sources import Response, _next_delay, _stamp
from source_policy import collection_url_allowed


REACTION_POLICY_VERSION = 'mastodon-financial-opinion-2026-10-25-v1'
MAX_AGE_S = 3600
MAX_BYTES = 1024 * 1024
MAX_ROWS = 20
MAX_RECEIPTS = 512
MAX_WORKERS = 2
COLLECTION_BUDGET_S = 8
POLL_SECONDS = 60
TAGS = ('gold', 'oil', 'inflation', 'economy')
_NUMBER = re.compile(r'[1-9][0-9]{0,23}')
_USERNAME = re.compile(r'[A-Za-z0-9_]{1,30}')


@dataclass(frozen=True)
class Source:
    tag: str

    @property
    def key(self):
        return 'mastodon-' + self.tag

    @property
    def url(self):
        return 'https://mastodon.social/api/v1/timelines/tag/' + self.tag + '?limit=20'


SOURCES = tuple(Source(tag) for tag in TAGS)
ALLOWED_URLS = frozenset(source.url for source in SOURCES)


class _PostText(HTMLParser):
    """Read plain authored text; never follow or voice an external link."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.valid = [], True
        self.paragraph, self.hashtag_depth = None, 0

    def handle_starttag(self, tag, attrs):
        if tag not in {'p', 'br', 'span', 'a', 'strong', 'em', 'b', 'i', 's', 'del', 'u', 'code'}:
            self.valid = False
        if tag == 'p':
            if self.paragraph is not None:
                self.valid = False
            self.paragraph = []
        if tag == 'br':
            self.handle_data(' ')
        if tag == 'a':
            attrs = dict(attrs)
            if (not re.fullmatch(r'https://mastodon\.social/tags/[A-Za-z0-9_]{1,80}', attrs.get('href', '')) or
                    'hashtag' not in attrs.get('class', '').split()):
                self.valid = False
            self.hashtag_depth += 1

    def handle_endtag(self, tag):
        if tag == 'a':
            self.hashtag_depth = max(0, self.hashtag_depth - 1)
        if tag == 'p':
            # Standalone hashtag footers are indexing annotations, not an
            # extra unhedged spoken sentence. Inline hashtag words stay in
            # their authored sentence; no prose or claim is truncated.
            if self.paragraph is not None and any(text.strip() and not hashtag
                                                 for text, hashtag in self.paragraph):
                self.parts.append(''.join(text for text, _hashtag in self.paragraph))
            self.paragraph = None

    def handle_data(self, data):
        if self.paragraph is None:
            self.parts.append(data)
        else:
            self.paragraph.append((data, bool(self.hashtag_depth)))


def _text(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 16000:
        return ''
    parser = _PostText()
    try:
        parser.feed(value)
        parser.close()
    except (ValueError, TypeError):
        return ''
    return _safe_text(' '.join(parser.parts)) if parser.valid and parser.paragraph is None else ''


def _language(text):
    arabic = sum('\u0600' <= c <= '\u06ff' and c.isalpha() for c in text)
    latin = sum('a' <= c.lower() <= 'z' for c in text)
    if arabic >= 8 and arabic > latin:
        return 'ar'
    if latin >= 12 and latin > arabic and not any(
            c.isalpha() and 'LATIN' not in unicodedata.name(c, '') for c in text):
        return 'en'
    return None


def _attribution(username, language):
    handle = username + '@mastodon.social'
    return 'رأي عام @' + handle if language == 'ar' else 'Public post @' + handle


def _uris(username, account_id, status_id):
    return ('https://mastodon.social/ap/users/' + account_id + '/statuses/' + status_id,
            'https://mastodon.social/users/' + username + '/statuses/' + status_id)


def reaction_allowed(row, now_s):
    """Recheck the typed original-clock/identity contract at restore and air time."""
    if (not isinstance(row, dict) or type(now_s) is not int or now_s <= 0 or
            row.get('social') is not True or row.get('sourceKind') != 'social-reaction' or
            row.get('platform') != 'Mastodon' or row.get('timeKind') != 'published' or
            row.get('language') not in ('ar', 'en') or
            row.get('clockBasis') != 'author-reported' or row.get('verification') != 'unverified-public-opinion' or
            type(row.get('publishedAt')) is not int or type(row.get('firstSeenAt')) is not int or
            not 0 < row['publishedAt'] <= row['firstSeenAt'] <= now_s or now_s - row['publishedAt'] > MAX_AGE_S or
            not isinstance(row.get('title'), str) or not row['title'] or _safe_text(row['title']) != row['title'] or
            row.get('language') != _language(row['title'])):
        return False
    metadata = row.get('reaction')
    if (not isinstance(metadata, dict) or metadata.get('screeningPolicy') != REACTION_POLICY_VERSION or
            metadata.get('screeningKind') != 'bounded-financial-opinion' or
            metadata.get('unverified') is not True or metadata.get('representative') is not False or
            metadata.get('sourceTag') not in TAGS):
        return False
    if not _author_name_allowed(metadata):
        return False
    username, account_id, status_id = (metadata.get(key) for key in ('username', 'authorId', 'statusId'))
    if (not isinstance(username, str) or not _USERNAME.fullmatch(username) or
            not isinstance(account_id, str) or not _NUMBER.fullmatch(account_id) or
            not isinstance(status_id, str) or not _NUMBER.fullmatch(status_id)):
        return False
    permalink = 'https://mastodon.social/@' + username + '/' + status_id
    return (row.get('url') == permalink and
            row.get('id') == hashlib.sha256(('social-reaction:' + permalink).encode()).hexdigest()[:32] and
            row.get('source') == _attribution(username, row['language']) and
            metadata.get('authorHandle') == username + '@mastodon.social' and
            metadata.get('accountUrl') == 'https://mastodon.social/@' + username and
            metadata.get('sourceUri') in _uris(username, account_id, status_id) and
            metadata.get('contentHash') == hashlib.sha256(row['title'].encode()).hexdigest())


def parse_mastodon(body, source, received_s):
    if (source not in SOURCES or type(received_s) is not int or received_s <= 0 or
            not isinstance(body, bytes) or len(body) > MAX_BYTES or b'\x00' in body):
        raise ValueError('Invalid bounded public reaction response')
    values = json.loads(body.decode('utf-8', errors='strict'))
    if not isinstance(values, list) or len(values) > MAX_ROWS:
        raise ValueError('Invalid public reaction timeline')
    rows, seen = [], set()
    for post in values:
        if (not isinstance(post, dict) or post.get('visibility') != 'public' or post.get('sensitive') is not False or
                post.get('spoiler_text') != '' or post.get('reblog') is not None or post.get('edited_at') is not None or
                post.get('quote') or post.get('poll') or post.get('card') or
                post.get('in_reply_to_id') is not None or post.get('in_reply_to_account_id') is not None or
                post.get('media_attachments', []) != []):
            # Parent threads and attachments were not retrieved. A complete
            # opinion cannot borrow their unseen context or be called original.
            continue
        account = post.get('account')
        if (not isinstance(account, dict) or account.get('bot') is not False or account.get('locked') is not False or
                account.get('suspended') or account.get('limited') or account.get('moved') or
                account.get('discoverable') is False):
            continue
        username, account_id, status_id = account.get('username'), account.get('id'), post.get('id')
        if (not isinstance(username, str) or not _USERNAME.fullmatch(username) or account.get('acct') != username or
                account.get('url') != 'https://mastodon.social/@' + username or
                not isinstance(account_id, str) or not _NUMBER.fullmatch(account_id) or
                not isinstance(status_id, str) or not _NUMBER.fullmatch(status_id)):
            continue
        permalink = 'https://mastodon.social/@' + username + '/' + status_id
        if (post.get('url') != permalink or post.get('uri') not in _uris(username, account_id, status_id) or
                permalink in seen or not isinstance(post.get('tags'), list) or
                not any(isinstance(tag, dict) and isinstance(tag.get('name'), str) and tag['name'].casefold() == source.tag
                        for tag in post['tags'])):
            continue
        try:
            published = _stamp(post.get('created_at'))
        except (ValueError, TypeError, OverflowError):
            continue
        if not 0 <= received_s - published <= MAX_AGE_S:
            continue
        text = _text(post.get('content'))
        language = _language(text)
        if not text or language is None:
            continue
        name = _author_name(account.get('display_name'))
        row = {'id': hashlib.sha256(('social-reaction:' + permalink).encode()).hexdigest()[:32],
            'url': permalink, 'title': text, 'summary': '', 'source': _attribution(username, language),
            'language': language, 'publishedAt': published, 'firstSeenAt': received_s,
            'social': True, 'sourceKind': 'social-reaction', 'platform': 'Mastodon',
            'timeKind': 'published', 'clockBasis': 'author-reported', 'verification': 'unverified-public-opinion',
            'reaction': {'authorHandle': username + '@mastodon.social', 'authorId': account_id,
                **({'authorName': name, 'authorNameKind': 'account-display-name'} if name else {}),
                'username': username, 'statusId': status_id, 'sourceTag': source.tag,
                'accountUrl': account['url'], 'sourceUri': post['uri'],
                'contentHash': hashlib.sha256(text.encode()).hexdigest(),
                'screeningPolicy': REACTION_POLICY_VERSION, 'screeningKind': 'bounded-financial-opinion',
                'screeningGuarantee': 'rules-not-independent-fact-verification',
                'unverified': True, 'representative': False}}
        if reaction_allowed(row, received_s):
            seen.add(permalink)
            rows.append(row)
    return rows


def fetch_public(url, headers, timeout):
    if (url not in ALLOWED_URLS or not collection_url_allowed(url) or
            not isinstance(timeout, (int, float)) or not 0 < timeout <= COLLECTION_BUDGET_S):
        raise ValueError('Unsupported public reaction request')
    safe = {'User-Agent': 'PublicNewsReader/1.0', 'Accept': 'application/json', 'Accept-Encoding': 'identity'}
    etag = headers.get('If-None-Match') if isinstance(headers, dict) else None
    if isinstance(etag, str) and len(etag) <= 256 and not re.search(r'[\x00-\x1f\x7f]', etag):
        safe['If-None-Match'] = etag
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    deadline = time.monotonic() + timeout
    try:
        response = opener.open(urllib.request.Request(url, headers=safe), timeout=timeout)
    except urllib.error.HTTPError as error:
        return Response(error.code, dict(error.headers.items()), b'', url)
    with response:
        values = {key.lower(): value for key, value in response.headers.items()}
        length = values.get('content-length')
        if (values.get('content-encoding', 'identity') != 'identity' or
                length and (not length.isdecimal() or int(length) > MAX_BYTES)):
            raise ValueError('Public reaction body limit')
        parts, size = [], 0
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Public reaction collection deadline')
            socket = getattr(getattr(response.fp, 'raw', None), '_sock', None)
            if socket is not None:
                socket.settimeout(max(.1, deadline - time.monotonic()))
            block = response.read1(min(65536, MAX_BYTES + 1 - size))
            if not block:
                break
            size += len(block)
            if size > MAX_BYTES:
                raise ValueError('Public reaction body limit')
            parts.append(block)
        return Response(response.status, values, b''.join(parts), response.url)


class SocialReactionCollector:
    def __init__(self, fetcher=None):
        self._fetcher = fetcher or fetch_public
        self._lock, self._collect_lock = threading.RLock(), threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix='public-reactions')
        self._pending, self._receipts = {}, {}
        self._next_poll_at = 0
        self._states = {source.key: {'source': 'Mastodon #' + source.tag, 'platform': 'Mastodon',
            'status': 'starting', 'checkedAt': 0, 'lastSuccessAt': 0, 'nextCheckAt': 0,
            'accepted': 0, 'failures': 0, 'httpStatus': None, 'etag': None} for source in SOURCES}

    def status(self):
        with self._lock:
            sources = [{key: value for key, value in self._states[source.key].items() if key != 'etag'} for source in SOURCES]
            ready = sum(source['status'] == 'ready' for source in sources)
            unavailable = next((source['status'] for source in sources
                                if source['status'] in ('access_denied', 'rate_limited')), None)
            phase = ('ready' if ready else unavailable if unavailable else 'starting' if
                     any(source['status'] == 'starting' for source in sources) else 'unavailable')
            return {'enabled': True, 'status': phase,
                'checkedAt': max(source['checkedAt'] for source in sources),
                'sourceCount': len(SOURCES), 'readySources': ready, 'sources': sources,
                'pendingRequests': len(self._pending), 'maxAgeSeconds': MAX_AGE_S,
                'pollSeconds': POLL_SECONDS,
                'nextCheckAt': max(self._next_poll_at, min(source['nextCheckAt'] for source in sources)),
                'screeningPolicy': REACTION_POLICY_VERSION,
                'transport': 'Four fixed public Mastodon hashtag timelines; no login; no PC',
                'verification': 'Unverified individual financial opinions, not a representative sample'}

    def _request(self, source, etag, deadline, now_s, real_clock):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Public reaction deadline')
        headers = {'If-None-Match': etag} if etag else {}
        response = self._fetcher(source.url, headers, min(COLLECTION_BUDGET_S, remaining))
        if (not isinstance(response, Response) or response.url != source.url or
                not isinstance(response.body, bytes) or len(response.body) > MAX_BYTES or time.monotonic() > deadline):
            raise ValueError('Invalid public reaction response')
        values = {key.lower(): value for key, value in response.headers.items()}
        if response.status == 200:
            if 'application/json' not in values.get('content-type', '').lower():
                raise ValueError('Unexpected public reaction content type')
            rows = parse_mastodon(response.body, source, int(time.time()) if real_clock else now_s)
        elif response.status == 304 and not etag:
            raise ValueError('Uncached public reaction response')
        else:
            rows = []
        return response.status, values, rows

    def collect(self, now_s=None):
        real_clock = now_s is None
        now_s = int(time.time()) if real_clock else now_s
        if type(now_s) is not int or now_s <= 0:
            raise ValueError('A valid public reaction clock is required')
        if not self._collect_lock.acquire(blocking=False):
            return []
        try:
            deadline, result = time.monotonic() + COLLECTION_BUDGET_S, {}
            with self._lock:
                if now_s * 1000 < self._next_poll_at:
                    return []
                self._pending = {key: future for key, future in self._pending.items() if not future.done()}
                due = [source for source in SOURCES if source.key not in self._pending and
                       now_s * 1000 >= self._states[source.key]['nextCheckAt']]
                due.sort(key=lambda source: self._states[source.key]['nextCheckAt'])
                due = due[:max(0, MAX_WORKERS - len(self._pending))]
                jobs = {}
                for source in due:
                    state = self._states[source.key]
                    state['checkedAt'] = now_s * 1000
                    future = self._pool.submit(self._request, source, state['etag'], deadline, now_s, real_clock)
                    self._pending[source.key] = future
                    jobs[future] = source
            done, _ = wait(jobs, timeout=max(0, deadline - time.monotonic()))
            finished = int(time.time()) if real_clock else now_s
            with self._lock:
                for future, source in jobs.items():
                    state, status, headers = self._states[source.key], None, {}
                    try:
                        if future not in done:
                            future.cancel()
                            raise TimeoutError('Public reaction deadline')
                        status, headers, rows = future.result()
                        if status not in (200, 304):
                            raise ValueError('Public reactions unavailable')
                        etag = headers.get('etag')
                        if etag is not None and (len(etag) > 256 or re.search(r'[\x00-\x1f\x7f]', etag)):
                            raise ValueError('Invalid public reaction cache validator')
                        state.update(status='ready', failures=0, httpStatus=status,
                            accepted=len(rows) if status == 200 else state['accepted'],
                            lastSuccessAt=finished * 1000,
                            nextCheckAt=(finished + max(POLL_SECONDS, _next_delay(headers, finished, status=status))) * 1000)
                        if status == 200:
                            state['etag'] = etag
                        for row in rows:
                            if not reaction_allowed(row, finished):
                                continue
                            old = self._receipts.get(row['id'])
                            fingerprint = (row['publishedAt'], row['reaction']['contentHash'], row['reaction']['sourceUri'])
                            if old:
                                if old[1:] != fingerprint:
                                    continue
                                row['firstSeenAt'] = old[0]
                            self._receipts[row['id']] = (row['firstSeenAt'], *fingerprint)
                            result[row['id']] = row
                    except Exception:
                        failures = state['failures'] + 1
                        state.update(status='access_denied' if status in (401, 403) else
                            'rate_limited' if status == 429 else 'unavailable',
                            httpStatus=status, failures=failures,
                            nextCheckAt=(finished + max(POLL_SECONDS, _next_delay(headers, finished, failures, status))) * 1000)
                        if status in (401, 403, 429):
                            # All four tags share one host and its request quota.
                            self._next_poll_at = max(self._next_poll_at, state['nextCheckAt'])
                    if future.done():
                        self._pending.pop(source.key, None)
                self._receipts = dict(sorted(((key, value) for key, value in self._receipts.items()
                    if finished - value[1] <= MAX_AGE_S), key=lambda pair: pair[1][0], reverse=True)[:MAX_RECEIPTS])
            return list(result.values())
        finally:
            self._collect_lock.release()

import hashlib
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

import cloud_llm_assets as assets


def gguf(architecture='lfm2', file_type=2, template='<|im_start|>assistant\n<|im_end|>'):
    def string(value):
        raw = value.encode('utf-8')
        return struct.pack('<Q', len(raw)) + raw
    values = [('general.architecture', 8, string(architecture)),
              ('general.file_type', 4, struct.pack('<I', file_type)),
              ('lfm2.context_length', 4, struct.pack('<I', 128000)),
              ('tokenizer.chat_template', 8, string(template))]
    return b'GGUF' + struct.pack('<IQQ', 3, 148, len(values)) + b''.join(
        string(key) + struct.pack('<I', kind) + data for key, kind, data in values)


class CloudAssetsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_public_model_is_exact_pinned_qad_350m_and_cpu_runtime_revision(self):
        self.assertEqual(assets.MODEL_FILENAME, 'LFM2.5-350M-QAD-Q4_0.gguf')
        self.assertEqual(assets.MODEL_BYTES, 219312832)
        self.assertEqual(len(assets.MODEL_REVISION), 40)
        self.assertEqual(len(assets.MODEL_SHA256), 64)
        self.assertIn('/resolve/' + assets.MODEL_REVISION + '/', assets.MODEL_URL)
        self.assertEqual(assets.LLAMA_RELEASE, 'b11869')
        self.assertIn('ar', assets.MODEL_LANGUAGES)

    def test_native_architecture_quantization_and_chat_template_are_verified(self):
        path = self.root / 'metadata.gguf'
        path.write_bytes(gguf())
        result = assets.metadata_info(path)
        self.assertEqual(result['architecture'], 'lfm2')
        self.assertEqual(result['nativeContextTokens'], 128000)
        self.assertTrue(result['nativeChatTemplate'])
        self.assertEqual(len(result['chatTemplateSha256']), 64)

    def test_metadata_mismatch_or_unbounded_value_fails_closed(self):
        path = self.root / 'bad.gguf'
        for data in (b'nope', gguf(architecture='llama'), gguf(file_type=17), gguf(template='no chat format'),
                     b'GGUF' + struct.pack('<IQQQ', 3, 148, 1, 2**40)):
            with self.subTest(data=data[:20]):
                path.write_bytes(data)
                with self.assertRaises((ValueError, UnicodeError)):
                    assets.metadata_info(path)

    def test_weight_size_and_checksum_cannot_be_silently_replaced(self):
        path = self.root / 'weight.gguf'
        data = gguf()
        path.write_bytes(data)
        with self.assertRaises(ValueError):
            assets.verify_model(path)
        with patch.object(assets, 'MODEL_BYTES', len(data)), patch.object(assets, 'MODEL_SHA256', '0' * 64):
            with self.assertRaisesRegex(ValueError, 'checksum'):
                assets.verify_model(path)
        with patch.object(assets, 'MODEL_BYTES', len(data)), patch.object(assets, 'MODEL_SHA256', hashlib.sha256(data).hexdigest()):
            self.assertEqual(assets.verify_model(path)['architecture'], 'lfm2')

    def test_existing_verified_asset_needs_no_network_and_gets_a_manifest(self):
        target = assets.model_path(self.root)
        target.parent.mkdir()
        target.write_bytes(b'local test fixture')
        with patch.object(assets, 'verify_model', return_value={'modelId': assets.MODEL_ID}) as verified, \
                patch.object(assets, 'ensure_license', return_value={'name': 'test license'}) as licensed, \
                patch.object(assets.urllib.request, 'urlopen', side_effect=AssertionError('unexpected network')):
            result = assets.ensure_assets(self.root)
        self.assertEqual(result['modelId'], assets.MODEL_ID)
        verified.assert_called_once_with(target)
        licensed.assert_called_once_with(target.parent)
        self.assertEqual(json.loads((target.parent / 'model-manifest.json').read_text('utf-8')), result)

    def test_oversized_download_is_removed_without_publishing_a_model(self):
        target = assets.model_path(self.root)
        with patch.object(assets, 'MODEL_BYTES', 10), \
                patch.object(assets.urllib.request, 'urlopen', return_value=io.BytesIO(b'x' * 11)):
            with self.assertRaisesRegex(ValueError, 'pinned size'):
                assets.ensure_assets(self.root)
        self.assertFalse(target.exists())
        self.assertFalse(target.with_suffix('.download').exists())

    def test_unfinished_existing_download_is_preserved_without_network(self):
        target = assets.model_path(self.root)
        target.parent.mkdir()
        temporary = target.with_suffix('.download')
        temporary.write_bytes(b'prior interrupted download')
        with patch.object(assets.urllib.request, 'urlopen', side_effect=AssertionError('unexpected network')):
            with self.assertRaises(ValueError):
                assets.ensure_assets(self.root)
        self.assertEqual(temporary.read_bytes(), b'prior interrupted download')

    def test_license_is_pinned_cached_and_invalid_existing_copy_is_preserved(self):
        data = b'unit test license'
        digest = hashlib.sha256(data).hexdigest()
        with patch.object(assets, 'LICENSE_BYTES', len(data)), patch.object(assets, 'LICENSE_SHA256', digest):
            with patch.object(assets.urllib.request, 'urlopen', return_value=io.BytesIO(data)):
                info = assets.ensure_license(self.root)
            self.assertEqual((self.root / info['file']).read_bytes(), data)
            with patch.object(assets.urllib.request, 'urlopen', side_effect=AssertionError('unexpected network')):
                self.assertEqual(assets.ensure_license(self.root), info)
                (self.root / info['file']).write_bytes(b'changed user file')
                with self.assertRaises(ValueError): assets.ensure_license(self.root)
            self.assertEqual((self.root / info['file']).read_bytes(), b'changed user file')


if __name__ == '__main__':
    unittest.main()

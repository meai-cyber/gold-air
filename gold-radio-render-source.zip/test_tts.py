"""Focused speech boundary/asset tests; no synthesis or network is performed."""
import hashlib
import io
from pathlib import Path
import unittest
import wave
import tempfile
import threading
from types import SimpleNamespace
from unittest.mock import Mock, patch

import bootstrap
from radio_arabic_tts import convert_wav
from radio_nabra_tts import pronunciation_text, prepare_pronunciation, validate_phoneme_response
from radio_nabra_tts import _local_path
from tts import ServerTts, Speech, pcm_wav, public_text


def wav_bytes(frames=2400):
    output = io.BytesIO()
    with wave.open(output, "wb") as audio:
        audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
        audio.writeframes(b"\x01\x00" * frames)
    return output.getvalue()


class SpeechBoundaryTests(unittest.TestCase):
    def native_fixture(self):
        value = ServerTts.__new__(ServerTts)
        value.root = Path('/test-assets')
        value.lock = threading.Lock()
        value.network_lock = threading.Lock()
        value.cast_arabic_lock = threading.Lock()
        value.engines = dict(ServerTts.engines)
        value.phonon_enabled = True
        value.english_disabled = False
        value.english_failure = None
        value.english = value.arabic = None
        value.ffmpeg = 'ffmpeg'
        return value

    def test_cast_has_distinct_genuine_female_and_male_voices_without_touching_news(self):
        value = self.native_fixture()
        value.phonon_enabled = False
        value.arabic = Mock()
        previous_arabic = value.arabic
        previous_engines = dict(value.engines)
        request = Mock(return_value=None)
        cases = [('en', 'host', 'Maia speaks this complete public paragraph.', 'en-US-AriaNeural', 'Female', '+0%'),
                 ('en', 'analyst', 'Omar speaks this complete public paragraph.', 'en-US-GuyNeural', 'Male', '+60%'),
                 ('ar', 'host', 'هذه فقرة عامة كاملة بصوت مايا.', 'ar-LB-LaylaNeural', 'Female', '+0%'),
                 ('ar', 'analyst', 'هذه فقرة عامة كاملة بصوت عمر.', 'ar-LB-RamiNeural', 'Male', '+60%')]
        with patch.object(value, '_edge_voice', new=request), \
                patch('tts.asyncio.run', return_value=b'encoded'), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())), \
                patch('phonon_runtime.PhononEnglishTts') as native:
            for language, role, text, voice, gender, rate in cases:
                speech = value.synthesize(text, language, voice_profile=role)
                self.assertEqual(request.call_args.args, (text, voice, rate))
                self.assertEqual((speech.language, speech.cast['voice'], speech.cast['gender']), (language, voice, gender))
                self.assertEqual(speech.cast['profile'], role)
                self.assertFalse(speech.cast['pitchShifted'])
                self.assertTrue(speech.cast['network'])
                self.assertEqual(speech.engine, 'edge-network-' + voice.lower())
            native.assert_not_called()
        self.assertIs(value.arabic, previous_arabic)
        previous_arabic.synthesize.assert_not_called()
        previous_arabic.close.assert_not_called()
        self.assertEqual(value.engines, previous_engines)

    def test_cast_outage_never_falls_back_to_the_wrong_person_or_language(self):
        value = self.native_fixture()
        value.arabic = Mock()
        request = Mock(return_value=None)
        with patch.object(value, '_edge_voice', new=request), \
                patch('tts.asyncio.run', side_effect=TimeoutError('test-only outage')), \
                patch.object(value, '_english_network') as default_english:
            with self.assertRaises(TimeoutError):
                value.synthesize('هذه فقرة عامة بصوت المتحدث الرجل.', 'ar', voice_profile='analyst')
            default_english.assert_not_called()
            value.arabic.synthesize.assert_not_called()
        self.assertFalse(value.english_disabled)
        self.assertIsNone(value.english_failure)

    def test_untrusted_voice_names_and_roles_fail_before_synthesis(self):
        value = self.native_fixture()
        with patch.object(value, '_edge_voice') as remote, patch.object(value, '_arabic') as native:
            for profile in ('', 'ar-LB-RamiNeural', 'https://example.org/voice', {'role': 'host'}):
                with self.assertRaises(ValueError):
                    value.synthesize('هذه فقرة عامة.', 'ar', voice_profile=profile)
            remote.assert_not_called()
            native.assert_not_called()

    def test_phonon_english_is_complete_resident_and_reports_actual_engine(self):
        value = self.native_fixture()
        with patch('phonon_runtime.PhononEnglishTts') as native:
            native.return_value.synthesize.return_value = SimpleNamespace(
                wav=wav_bytes(), duration_s=.1, inference_s=.05, first_chunk_s=.01)
            for _ in range(2):
                speech = value.synthesize('The complete English bulletin.', 'en')
                self.assertEqual(speech.engine, 'phonon40m-q8-native-cpu')
                self.assertEqual(speech.first_chunk_s, .01)
            native.assert_called_once_with(value.root / 'phonon40')
            self.assertEqual(native.return_value.synthesize.call_args.args, ('The complete English bulletin.',))
            value.close()
            native.return_value.close.assert_called_once()

    def test_failed_native_english_uses_working_fallback_without_reloading_each_story(self):
        value = self.native_fixture()
        with patch('phonon_runtime.PhononEnglishTts', side_effect=RuntimeError('private native details')) as native, \
                patch('tts.asyncio.run', return_value=b'encoded') as edge, \
                patch.object(value, '_edge', new=lambda _text: None), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            for _ in range(2):
                speech = value.synthesize('A full report survives a native outage.', 'en')
                self.assertEqual(speech.engine, 'edge-network-jenny')
            self.assertEqual(native.call_count, 1)
            self.assertEqual(edge.call_count, 2)
            self.assertTrue(value.english_disabled)

    def test_long_or_wordy_reports_bypass_native_without_losing_full_text(self):
        value = self.native_fixture()
        long_report = ('The publisher reports a major economic development. '
                       'This complete report includes all attributed facts and its final sentence explains the outcome.')
        wordy_report = ' '.join(['Gold'] * 23) + '.'
        self.assertGreater(len(long_report), 120)
        self.assertLessEqual(len(wordy_report), 120)
        edge_request = Mock(return_value=None)
        with patch('phonon_runtime.PhononEnglishTts') as native, \
                patch('tts.asyncio.run', return_value=b'encoded'), \
                patch.object(value, '_edge', new=edge_request), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            for report in (long_report, wordy_report):
                result = value.synthesize(report, 'en')
                self.assertEqual((result.language, result.engine), ('en', 'edge-network-jenny'))
                self.assertEqual(edge_request.call_args.args, (report,))
                self.assertFalse(value.english_disabled)
                self.assertIsNone(value.english_failure)
            native.assert_not_called()
        self.assertEqual(value.english_native_policy, 'short-complete-bulletins')
        with self.assertRaises(AttributeError):
            value.english_native_policy = 'different-policy'
        value.phonon_enabled = False
        self.assertEqual(value.english_native_policy, 'off')

    def test_short_complete_bulletin_still_uses_native_after_a_long_report(self):
        value = self.native_fixture()
        long_report = ('The full public report contains more details than the native free CPU deadline can handle. '
                       'Every sentence is sent to the working network voice without cutting its ending.')
        short_report = 'Gold prices hold steady as traders await policy news.'
        self.assertGreater(len(long_report), 120)
        edge_request = Mock(return_value=None)
        with patch('phonon_runtime.PhononEnglishTts') as native, \
                patch('tts.asyncio.run', return_value=b'encoded'), \
                patch.object(value, '_edge', new=edge_request), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            native.return_value.synthesize.return_value = SimpleNamespace(
                wav=wav_bytes(), duration_s=.1, inference_s=.05, first_chunk_s=.01)
            self.assertEqual(value.synthesize(long_report, 'en').engine, 'edge-network-jenny')
            self.assertEqual(value.synthesize(short_report, 'en').engine, 'phonon40m-q8-native-cpu')
            edge_request.assert_called_once_with(long_report)
            native.assert_called_once_with(value.root / 'phonon40')
            native.return_value.synthesize.assert_called_once_with(short_report)
            self.assertFalse(value.english_disabled)
            self.assertIsNone(value.english_failure)

    def test_off_configuration_sends_complete_short_and_long_english_directly_to_edge(self):
        value = self.native_fixture()
        value.phonon_enabled = False
        value.arabic = Mock()
        retained_arabic = value.arabic
        reports = ('Gold prices hold steady before the policy meeting.',
                   'The publisher reports an important economic development with full attributed details. '
                   'The final sentence completes the account and must remain present in the spoken report.')
        self.assertLessEqual(len(reports[0]), 120)
        self.assertGreater(len(reports[1]), 120)
        edge_request = Mock(return_value=None)
        with patch('phonon_runtime.PhononEnglishTts') as native, \
                patch('tts.asyncio.run', return_value=b'encoded'), \
                patch.object(value, '_edge', new=edge_request), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            for report in reports:
                result = value.synthesize(report, 'en')
                self.assertEqual((result.language, result.engine), ('en', 'edge-network-jenny'))
                self.assertEqual(edge_request.call_args.args, (report,))
                self.assertIs(value.arabic, retained_arabic)
                self.assertEqual(value.english_native_policy, 'off')
            self.assertEqual(edge_request.call_count, 2)
            native.assert_not_called()
        retained_arabic.close.assert_not_called()
        retained_arabic.synthesize.assert_not_called()
        self.assertFalse(value.english_disabled)
        self.assertIsNone(value.english_failure)

    def test_off_config_english_network_completes_while_arabic_cpu_lock_is_held(self):
        value = self.native_fixture()
        value.phonon_enabled = False
        arabic_entered, release_arabic, english_done = (threading.Event() for _ in range(3))
        results, failures = {}, []
        arabic_text = 'هذا الخبر العربي الكامل، وتبقى جملته الأخيرة محفوظة.'
        english_text = ('The complete English bulletin continues while Arabic inference is still running. '
                        'The final sentence is retained without changing any of the report.')
        def arabic(text):
            self.assertEqual(text, arabic_text)
            arabic_entered.set()
            if not release_arabic.wait(3):
                raise RuntimeError('Test did not release Arabic inference')
            return Speech(wav_bytes(), .1, value.engines['ar'], 'ar', .05)
        def produce(language, text):
            try:
                results[language] = value.synthesize(text, language)
            except Exception as error:
                failures.append(error)
            finally:
                if language == 'en':
                    english_done.set()
        edge_request = Mock(return_value=None)
        ar_worker = threading.Thread(target=produce, args=('ar', arabic_text))
        en_worker = threading.Thread(target=produce, args=('en', english_text))
        with patch.object(value, '_arabic', side_effect=arabic), \
                patch.object(value, '_edge', new=edge_request), \
                patch('tts.asyncio.run', return_value=b'encoded'), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            try:
                ar_worker.start()
                self.assertTrue(arabic_entered.wait(1))
                self.assertTrue(value.lock.locked(), 'Arabic owns the native CPU lock')
                en_worker.start()
                self.assertTrue(english_done.wait(1), 'English network work must finish without waiting for Arabic')
                self.assertNotIn('ar', results, 'the Arabic fixture is still deliberately blocked')
                self.assertEqual((results['en'].language, results['en'].engine), ('en', 'edge-network-jenny'))
                edge_request.assert_called_once_with(english_text)
            finally:
                release_arabic.set()
                ar_worker.join(2)
                if en_worker.ident is not None:
                    en_worker.join(2)
        self.assertFalse(ar_worker.is_alive())
        self.assertFalse(en_worker.is_alive())
        self.assertEqual(failures, [])
        self.assertEqual(results['ar'].language, 'ar')

    def test_tight_linux_budget_unloads_arabic_before_complete_native_english(self):
        value = self.native_fixture()
        events = []
        vowels = object()
        value.diacritizer = vowels
        value.arabic = Mock()
        old_arabic = value.arabic
        old_arabic.close.side_effect = lambda: events.append('close-arabic')
        bulletin = 'The complete English report. Its final sentence is retained.'
        def spoken(text):
            self.assertIsNone(value.arabic)
            self.assertIs(value.diacritizer, vowels)
            events.append(('english', text))
            return SimpleNamespace(wav=wav_bytes(), duration_s=.1, inference_s=.05, first_chunk_s=.01)
        with patch('tts.sys.platform', 'linux'), \
                patch('phonon_runtime.container_memory', return_value=(240 * 1024 ** 2, 512 * 1024 ** 2)), \
                patch('tts._release_model_memory', side_effect=lambda: events.append('release')), \
                patch('phonon_runtime.PhononEnglishTts') as native:
            native.return_value.synthesize.side_effect = spoken
            result = value.synthesize(bulletin, 'en')
        self.assertEqual(events, ['close-arabic', 'release', ('english', bulletin)])
        self.assertEqual((result.language, result.engine), ('en', 'phonon40m-q8-native-cpu'))
        old_arabic.synthesize.assert_not_called()
        native.return_value.synthesize.assert_called_once_with(bulletin)

    def test_tight_linux_budget_unloads_english_before_complete_arabic_without_disabling_it(self):
        value = self.native_fixture()
        events = []
        value.english = Mock()
        old_english = value.english
        old_english.close.side_effect = lambda: events.append('close-english')
        bulletin = 'هذا الخبر العربي الكامل. وهذه الجملة الأخيرة تكمل الخبر.'
        def spoken(text):
            self.assertIsNone(value.english)
            events.append(('arabic', text))
            return Speech(wav_bytes(), .1, value.engines['ar'], 'ar', .05)
        # 112 MiB headroom is above the previous 96 MiB limit but below 160.
        with patch('tts.sys.platform', 'linux'), \
                patch('phonon_runtime.container_memory', return_value=(400 * 1024 ** 2, 512 * 1024 ** 2)), \
                patch('tts._release_model_memory', side_effect=lambda: events.append('release')), \
                patch.object(value, '_arabic', side_effect=spoken):
            result = value.synthesize(bulletin, 'ar')
        self.assertEqual(events, ['close-english', 'release', ('arabic', bulletin)])
        self.assertEqual((result.language, result.engine), ('ar', 'nabra7m-fp32-native-cpu'))
        self.assertFalse(value.english_disabled, 'a deliberate model swap can reload English later')
        old_english.synthesize.assert_not_called()

    def test_bundled_g2p_is_exact_reviewed_source(self):
        data = (Path(__file__).parent / "vendor/g2p.mjs").read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(), bootstrap.G2P_HASH)

    def test_no_cloud_arabic_or_pc_route(self):
        self.assertEqual(ServerTts.available_languages, ("ar", "en"))
        self.assertEqual(ServerTts.engines["ar"], "nabra7m-fp32-native-cpu")
        self.assertEqual(ServerTts.engines["en"], "edge-network-jenny")

    def test_plain_language_and_private_path_bounds(self):
        self.assertEqual(public_text("أعزائي المستمعين، آخر الأخبار.", "ar"), "أعزائي المستمعين، آخر الأخبار.")
        self.assertEqual(public_text("Latest public market reports.", "en"), "Latest public market reports.")
        self.assertEqual(public_text("France's économie report, says José.", "en"), "France's économie report, says José.")
        for text, language in [("Latest news", "ar"), ("آخر الأخبار", "en"), ("<speak>news</speak>", "en"),
                               ("Read C:\\Users\\owner", "en"), ("See https://private.example", "en"),
                               ("News\x00report", "en"), ("a" * 1201, "en")]:
            with self.subTest(text=text[:25]), self.assertRaises(ValueError):
                public_text(text, language)

    def test_numeric_values_are_spoken_without_changing_facts(self):
        value = pronunciation_text("الذهب عند 4,188.60، والتغير -0.2%.")
        self.assertNotRegex(value, r"[\d%]")
        self.assertIn("فاصل ستة صفر", value)
        self.assertIn("ناقص صفر فاصل اثنان بالمئة", value)

    def test_vowels_must_preserve_base_words(self):
        class InvalidVowels:
            def diacritize(self, text): return "سعر مختلف"
        with self.assertRaises(ValueError):
            prepare_pronunciation("آخر الأخبار", InvalidVowels())

    def test_waveforms_and_finite_audio_bound(self):
        data = wav_bytes()
        self.assertEqual(convert_wav(data), (data, .1))
        self.assertEqual(pcm_wav(data), (data, .1))
        # ffmpeg writes open-ended RIFF/data lengths to stdout; the result must
        # be rewritten using actual decoded frames rather than trusting them.
        streamed = bytearray(data)
        streamed[4:8] = b"\xff" * 4
        streamed[40:44] = b"\xff" * 4
        self.assertEqual(pcm_wav(bytes(streamed)), (data, .1))
        with self.assertRaises(ValueError):
            convert_wav(b"not audio")
        with self.assertRaises(ValueError):
            pcm_wav(wav_bytes(24000 * 90 + 1))

    def test_asset_integrity_fails_closed(self):
        with self.assertRaises(ValueError):
            bootstrap.verified(b"changed", "0" * 64)

    def test_assets_outside_application_are_allowed(self):
        with tempfile.TemporaryDirectory() as directory:
            resource = Path(directory) / "model.bin"
            resource.write_bytes(b"public model fixture")
            self.assertEqual(_local_path(resource), resource.resolve())
        with self.assertRaises(ValueError):
            _local_path(Path(__file__).resolve())

    def test_phoneme_coverage_is_required(self):
        with self.assertRaises(ValueError):
            validate_phoneme_response({"ok": True, "chunks": []}, "آخر الأخبار")


if __name__ == "__main__":
    unittest.main()

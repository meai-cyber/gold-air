"""Focused speech boundary/asset tests; no synthesis or network is performed."""
import hashlib
import io
from pathlib import Path
import unittest
import wave
import tempfile

import bootstrap
from radio_arabic_tts import convert_wav
from radio_nabra_tts import pronunciation_text, prepare_pronunciation, validate_phoneme_response
from radio_nabra_tts import _local_path
from tts import ServerTts, pcm_wav, public_text


def wav_bytes(frames=2400):
    output = io.BytesIO()
    with wave.open(output, "wb") as audio:
        audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
        audio.writeframes(b"\x01\x00" * frames)
    return output.getvalue()


class SpeechBoundaryTests(unittest.TestCase):
    def test_bundled_g2p_is_exact_reviewed_source(self):
        data = (Path(__file__).parent / "vendor/g2p.mjs").read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(), bootstrap.G2P_HASH)

    def test_no_cloud_arabic_or_pc_route(self):
        self.assertEqual(ServerTts.available_languages, ("ar", "en"))
        self.assertEqual(ServerTts.engines["ar"], "nabra7m-fp32-native-cpu")
        self.assertEqual(ServerTts.engines["en"], "edge-network-jenny")

    def test_plain_language_and_private_path_bounds(self):
        self.assertEqual(public_text("أعزائي المستمعين، آخر الأخبار.", "ar"), "أعزائي المستمعين، آخر الأخبار.")
        self.assertEqual(public_text("Latest public market reports.", "en"), "Latest public market reports.")
        self.assertEqual(public_text("France's économie report, says José.", "en"), "France's économie report, says José.")
        for text, language in [("Latest news", "ar"), ("آخر الأخبار", "en"), ("<speak>news</speak>", "en"),
                               ("Read C:\\Users\\owner", "en"), ("See https://private.example", "en"),
                               ("News\x00report", "en"), ("a" * 1201, "en")]:
            with self.subTest(text=text[:25]), self.assertRaises(ValueError):
                public_text(text, language)

    def test_numeric_values_are_spoken_without_changing_facts(self):
        value = pronunciation_text("الذهب عند 4,188.60، والتغير -0.2%.")
        self.assertNotRegex(value, r"[\d%]")
        self.assertIn("فاصل ستة صفر", value)
        self.assertIn("ناقص صفر فاصل اثنان بالمئة", value)

    def test_vowels_must_preserve_base_words(self):
        class InvalidVowels:
            def diacritize(self, text): return "سعر مختلف"
        with self.assertRaises(ValueError):
            prepare_pronunciation("آخر الأخبار", InvalidVowels())

    def test_waveforms_and_finite_audio_bound(self):
        data = wav_bytes()
        self.assertEqual(convert_wav(data), (data, .1))
        self.assertEqual(pcm_wav(data), (data, .1))
        # ffmpeg writes open-ended RIFF/data lengths to stdout; the result must
        # be rewritten using actual decoded frames rather than trusting them.
        streamed = bytearray(data)
        streamed[4:8] = b"\xff" * 4
        streamed[40:44] = b"\xff" * 4
        self.assertEqual(pcm_wav(bytes(streamed)), (data, .1))
        with self.assertRaises(ValueError):
            convert_wav(b"not audio")
        with self.assertRaises(ValueError):
            pcm_wav(wav_bytes(24000 * 90 + 1))

    def test_asset_integrity_fails_closed(self):
        with self.assertRaises(ValueError):
            bootstrap.verified(b"changed", "0" * 64)

    def test_assets_outside_application_are_allowed(self):
        with tempfile.TemporaryDirectory() as directory:
            resource = Path(directory) / "model.bin"
            resource.write_bytes(b"public model fixture")
            self.assertEqual(_local_path(resource), resource.resolve())
        with self.assertRaises(ValueError):
            _local_path(Path(__file__).resolve())

    def test_phoneme_coverage_is_required(self):
        with self.assertRaises(ValueError):
            validate_phoneme_response({"ok": True, "chunks": []}, "آخر الأخبار")


if __name__ == "__main__":
    unittest.main()

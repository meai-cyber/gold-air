"""Focused speech boundary/asset tests; no synthesis or network is performed."""
import hashlib
import io
from pathlib import Path
import unittest
import wave
import tempfile
import threading
from types import SimpleNamespace
from unittest.mock import Mock, patch

import bootstrap
from radio_arabic_tts import convert_wav
from radio_nabra_tts import pronunciation_text, prepare_pronunciation, validate_phoneme_response
from radio_nabra_tts import _local_path
from tts import ServerTts, Speech, pcm_wav, public_text


def wav_bytes(frames=2400):
    output = io.BytesIO()
    with wave.open(output, "wb") as audio:
        audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(24000)
        audio.writeframes(b"\x01\x00" * frames)
    return output.getvalue()


class SpeechBoundaryTests(unittest.TestCase):
    def native_fixture(self):
        value = ServerTts.__new__(ServerTts)
        value.root = Path('/test-assets')
        value.lock = threading.Lock()
        value.engines = dict(ServerTts.engines)
        value.phonon_enabled = True
        value.english_disabled = False
        value.english_failure = None
        value.english = value.arabic = None
        value.ffmpeg = 'ffmpeg'
        return value

    def test_phonon_english_is_complete_resident_and_reports_actual_engine(self):
        value = self.native_fixture()
        with patch('phonon_runtime.PhononEnglishTts') as native:
            native.return_value.synthesize.return_value = SimpleNamespace(
                wav=wav_bytes(), duration_s=.1, inference_s=.05, first_chunk_s=.01)
            for _ in range(2):
                speech = value.synthesize('The complete English bulletin.', 'en')
                self.assertEqual(speech.engine, 'phonon40m-q8-native-cpu')
                self.assertEqual(speech.first_chunk_s, .01)
            native.assert_called_once_with(value.root / 'phonon40')
            self.assertEqual(native.return_value.synthesize.call_args.args, ('The complete English bulletin.',))
            value.close()
            native.return_value.close.assert_called_once()

    def test_failed_native_english_uses_working_fallback_without_reloading_each_story(self):
        value = self.native_fixture()
        with patch('phonon_runtime.PhononEnglishTts', side_effect=RuntimeError('private native details')) as native, \
                patch('tts.asyncio.run', return_value=b'encoded') as edge, \
                patch.object(value, '_edge', new=lambda _text: None), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            for _ in range(2):
                speech = value.synthesize('A full report survives a native outage.', 'en')
                self.assertEqual(speech.engine, 'edge-network-jenny')
            self.assertEqual(native.call_count, 1)
            self.assertEqual(edge.call_count, 2)
            self.assertTrue(value.english_disabled)

    def test_long_or_wordy_reports_bypass_native_without_losing_full_text(self):
        value = self.native_fixture()
        long_report = ('The publisher reports a major economic development. '
                       'This complete report includes all attributed facts and its final sentence explains the outcome.')
        wordy_report = ' '.join(['Gold'] * 23) + '.'
        self.assertGreater(len(long_report), 120)
        self.assertLessEqual(len(wordy_report), 120)
        edge_request = Mock(return_value=None)
        with patch('phonon_runtime.PhononEnglishTts') as native, \
                patch('tts.asyncio.run', return_value=b'encoded'), \
                patch.object(value, '_edge', new=edge_request), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            for report in (long_report, wordy_report):
                result = value.synthesize(report, 'en')
                self.assertEqual((result.language, result.engine), ('en', 'edge-network-jenny'))
                self.assertEqual(edge_request.call_args.args, (report,))
                self.assertFalse(value.english_disabled)
                self.assertIsNone(value.english_failure)
            native.assert_not_called()
        self.assertEqual(value.english_native_policy, 'short-complete-bulletins')
        with self.assertRaises(AttributeError):
            value.english_native_policy = 'different-policy'
        value.phonon_enabled = False
        self.assertEqual(value.english_native_policy, 'off')

    def test_short_complete_bulletin_still_uses_native_after_a_long_report(self):
        value = self.native_fixture()
        long_report = ('The full public report contains more details than the native free CPU deadline can handle. '
                       'Every sentence is sent to the working network voice without cutting its ending.')
        short_report = 'Gold prices hold steady as traders await policy news.'
        self.assertGreater(len(long_report), 120)
        edge_request = Mock(return_value=None)
        with patch('phonon_runtime.PhononEnglishTts') as native, \
                patch('tts.asyncio.run', return_value=b'encoded'), \
                patch.object(value, '_edge', new=edge_request), \
                patch('tts.subprocess.run', return_value=SimpleNamespace(stdout=wav_bytes())):
            native.return_value.synthesize.return_value = SimpleNamespace(
                wav=wav_bytes(), duration_s=.1, inference_s=.05, first_chunk_s=.01)
            self.assertEqual(value.synthesize(long_report, 'en').engine, 'edge-network-jenny')
            self.assertEqual(value.synthesize(short_report, 'en').engine, 'phonon40m-q8-native-cpu')
            edge_request.assert_called_once_with(long_report)
            native.assert_called_once_with(value.root / 'phonon40')
            native.return_value.synthesize.assert_called_once_with(short_report)
            self.assertFalse(value.english_disabled)
            self.assertIsNone(value.english_failure)

    def test_tight_linux_budget_unloads_arabic_before_complete_native_english(self):
        value = self.native_fixture()
        events = []
        vowels = object()
        value.diacritizer = vowels
        value.arabic = Mock()
        old_arabic = value.arabic
        old_arabic.close.side_effect = lambda: events.append('close-arabic')
        bulletin = 'The complete English report. Its final sentence is retained.'
        def spoken(text):
            self.assertIsNone(value.arabic)
            self.assertIs(value.diacritizer, vowels)
            events.append(('english', text))
            return SimpleNamespace(wav=wav_bytes(), duration_s=.1, inference_s=.05, first_chunk_s=.01)
        with patch('tts.sys.platform', 'linux'), \
                patch('phonon_runtime.container_memory', return_value=(240 * 1024 ** 2, 512 * 1024 ** 2)), \
                patch('tts._release_model_memory', side_effect=lambda: events.append('release')), \
                patch('phonon_runtime.PhononEnglishTts') as native:
            native.return_value.synthesize.side_effect = spoken
            result = value.synthesize(bulletin, 'en')
        self.assertEqual(events, ['close-arabic', 'release', ('english', bulletin)])
        self.assertEqual((result.language, result.engine), ('en', 'phonon40m-q8-native-cpu'))
        old_arabic.synthesize.assert_not_called()
        native.return_value.synthesize.assert_called_once_with(bulletin)

    def test_tight_linux_budget_unloads_english_before_complete_arabic_without_disabling_it(self):
        value = self.native_fixture()
        events = []
        value.english = Mock()
        old_english = value.english
        old_english.close.side_effect = lambda: events.append('close-english')
        bulletin = 'هذا الخبر العربي الكامل. وهذه الجملة الأخيرة تكمل الخبر.'
        def spoken(text):
            self.assertIsNone(value.english)
            events.append(('arabic', text))
            return Speech(wav_bytes(), .1, value.engines['ar'], 'ar', .05)
        # 112 MiB headroom is above the previous 96 MiB limit but below 160.
        with patch('tts.sys.platform', 'linux'), \
                patch('phonon_runtime.container_memory', return_value=(400 * 1024 ** 2, 512 * 1024 ** 2)), \
                patch('tts._release_model_memory', side_effect=lambda: events.append('release')), \
                patch.object(value, '_arabic', side_effect=spoken):
            result = value.synthesize(bulletin, 'ar')
        self.assertEqual(events, ['close-english', 'release', ('arabic', bulletin)])
        self.assertEqual((result.language, result.engine), ('ar', 'nabra7m-fp32-native-cpu'))
        self.assertFalse(value.english_disabled, 'a deliberate model swap can reload English later')
        old_english.synthesize.assert_not_called()

    def test_bundled_g2p_is_exact_reviewed_source(self):
        data = (Path(__file__).parent / "vendor/g2p.mjs").read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(), bootstrap.G2P_HASH)

    def test_no_cloud_arabic_or_pc_route(self):
        self.assertEqual(ServerTts.available_languages, ("ar", "en"))
        self.assertEqual(ServerTts.engines["ar"], "nabra7m-fp32-native-cpu")
        self.assertEqual(ServerTts.engines["en"], "edge-network-jenny")

    def test_plain_language_and_private_path_bounds(self):
        self.assertEqual(public_text("أعزائي المستمعين، آخر الأخبار.", "ar"), "أعزائي المستمعين، آخر الأخبار.")
        self.assertEqual(public_text("Latest public market reports.", "en"), "Latest public market reports.")
        self.assertEqual(public_text("France's économie report, says José.", "en"), "France's économie report, says José.")
        for text, language in [("Latest news", "ar"), ("آخر الأخبار", "en"), ("<speak>news</speak>", "en"),
                               ("Read C:\\Users\\owner", "en"), ("See https://private.example", "en"),
                               ("News\x00report", "en"), ("a" * 1201, "en")]:
            with self.subTest(text=text[:25]), self.assertRaises(ValueError):
                public_text(text, language)

    def test_numeric_values_are_spoken_without_changing_facts(self):
        value = pronunciation_text("الذهب عند 4,188.60، والتغير -0.2%.")
        self.assertNotRegex(value, r"[\d%]")
        self.assertIn("فاصل ستة صفر", value)
        self.assertIn("ناقص صفر فاصل اثنان بالمئة", value)

    def test_vowels_must_preserve_base_words(self):
        class InvalidVowels:
            def diacritize(self, text): return "سعر مختلف"
        with self.assertRaises(ValueError):
            prepare_pronunciation("آخر الأخبار", InvalidVowels())

    def test_waveforms_and_finite_audio_bound(self):
        data = wav_bytes()
        self.assertEqual(convert_wav(data), (data, .1))
        self.assertEqual(pcm_wav(data), (data, .1))
        # ffmpeg writes open-ended RIFF/data lengths to stdout; the result must
        # be rewritten using actual decoded frames rather than trusting them.
        streamed = bytearray(data)
        streamed[4:8] = b"\xff" * 4
        streamed[40:44] = b"\xff" * 4
        self.assertEqual(pcm_wav(bytes(streamed)), (data, .1))
        with self.assertRaises(ValueError):
            convert_wav(b"not audio")
        with self.assertRaises(ValueError):
            pcm_wav(wav_bytes(24000 * 90 + 1))

    def test_asset_integrity_fails_closed(self):
        with self.assertRaises(ValueError):
            bootstrap.verified(b"changed", "0" * 64)

    def test_assets_outside_application_are_allowed(self):
        with tempfile.TemporaryDirectory() as directory:
            resource = Path(directory) / "model.bin"
            resource.write_bytes(b"public model fixture")
            self.assertEqual(_local_path(resource), resource.resolve())
        with self.assertRaises(ValueError):
            _local_path(Path(__file__).resolve())

    def test_phoneme_coverage_is_required(self):
        with self.assertRaises(ValueError):
            validate_phoneme_response({"ok": True, "chunks": []}, "آخر الأخبار")


if __name__ == "__main__":
    unittest.main()

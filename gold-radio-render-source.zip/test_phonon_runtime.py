"""Offline native-boundary and transport tests; no weights or HTTP requests."""
import base64
import io
import json
import os
from pathlib import Path
import queue
import sys
import time
import types
import unittest
from unittest.mock import Mock, patch
import wave

import numpy as np

from phonon_runtime import (MAX_FRAMES, MAX_LINE_BYTES, PhononEnglishTts,
                            PhononUnavailable, _collect_stream, _load_model)


class Stream:
    def __init__(self, chunks, sample_rate=24000):
        self.chunks = chunks
        self.sample_rate = sample_rate
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.closed = True

    def __iter__(self):
        return iter(self.chunks)


class Model:
    sample_rate = 24000

    def __init__(self, chunks, stream_rate=24000):
        self.audio = Stream(chunks, stream_rate)
        self.calls = []

    def stream(self, text, **kwargs):
        self.calls.append((text, kwargs))
        return self.audio


def wav_bytes(frames=240, channels=1, sample_rate=24000):
    out = io.BytesIO()
    with wave.open(out, "wb") as audio:
        audio.setnchannels(channels)
        audio.setsampwidth(2)
        audio.setframerate(sample_rate)
        audio.writeframes(b"\x01\x00" * frames * channels)
    return out.getvalue()


def reply(request, **overrides):
    result = {"nonce": request["nonce"], "requestId": request["requestId"],
              "wavBase64": base64.b64encode(wav_bytes()).decode("ascii"),
              "durationSeconds": .01, "inferenceSeconds": .2, "firstChunkSeconds": .05}
    result.update(overrides)
    return result


class ReadPipe:
    def __init__(self):
        self.messages = queue.Queue()

    def readline(self, limit):
        return self.messages.get()[:limit]

    def close(self):
        self.messages.put(b"")


class WritePipe:
    def __init__(self, process):
        self.process = process

    def write(self, raw):
        request = json.loads(raw)
        self.process.requests.append(request)
        response = self.process.respond(request)
        if response is not None:
            encoded = response if isinstance(response, bytes) else (json.dumps(response) + "\n").encode("utf-8")
            self.process.stdout.messages.put(encoded)
        return len(raw)

    def flush(self):
        pass

    def close(self):
        pass


class Process:
    def __init__(self, respond=reply):
        self.respond = respond
        self.stdout = ReadPipe()
        self.stdin = WritePipe(self)
        self.requests = []
        self.returncode = None
        self.killed = 0

    def poll(self):
        return self.returncode

    def kill(self):
        self.killed += 1
        self.returncode = -9
        self.stdout.messages.put(b"")

    def wait(self, timeout):
        return self.returncode


class PhononNativeBoundaryTests(unittest.TestCase):
    def test_native_stream_preserves_complete_text_and_frames(self):
        text = "First sentence.  The final sentence is complete.\n"
        model = Model([np.ones(120, dtype=np.float32) * .25,
                       np.ones(240, dtype=np.float32) * -.125])
        speech = _collect_stream(model, text)
        self.assertEqual(model.calls, [(text, {"voice": "default"})])
        self.assertTrue(model.audio.closed)
        with wave.open(io.BytesIO(speech.wav), "rb") as audio:
            self.assertEqual((audio.getnchannels(), audio.getsampwidth(), audio.getframerate(), audio.getnframes()), (1, 2, 24000, 360))
            self.assertEqual(len(audio.readframes(999999)), 720)
        self.assertEqual(speech.duration_s, .015)
        self.assertGreaterEqual(speech.first_chunk_s, 0)
        self.assertGreaterEqual(speech.inference_s, speech.first_chunk_s)

    def test_invalid_empty_silent_and_nonfinite_native_chunks_fail_whole(self):
        for chunks in ([], [np.zeros(100, dtype=np.float32)],
                       [np.array([np.nan], dtype=np.float32)],
                       [np.array([np.inf], dtype=np.float32)],
                       [np.ones((1, 10), dtype=np.float32)],
                       [np.ones(10, dtype=np.float64)]):
            with self.subTest(chunks=repr(chunks)[:40]):
                model = Model(chunks)
                with self.assertRaises(PhononUnavailable):
                    _collect_stream(model, "Complete English news.")
                self.assertTrue(model.audio.closed)

    def test_overlong_native_stream_is_rejected_instead_of_cut(self):
        model = Model([np.ones(MAX_FRAMES + 1, dtype=np.float32)])
        with self.assertRaises(PhononUnavailable):
            _collect_stream(model, "This item exceeds the station duration limit.")
        self.assertTrue(model.audio.closed)

    def test_stream_rate_must_match_the_fixed_station_format(self):
        model = Model([np.ones(100, dtype=np.float32)], stream_rate=48000)
        with self.assertRaises(PhononUnavailable):
            _collect_stream(model, "A report.")
        self.assertTrue(model.audio.closed)

    def test_assets_are_verified_before_one_thread_pinned_cpu_model_load(self):
        order = []
        directory = Path("fixed-pinned-40m")
        fake_model = types.SimpleNamespace(sample_rate=24000, device="cpu", quant="q8_0")
        def construct(*args, **kwargs):
            order.append(("load", args, kwargs))
            return fake_model
        assets = types.SimpleNamespace(verify_assets=lambda root: order.append(("verify", root)))
        native = types.SimpleNamespace(__version__="0.4.1", set_num_threads=lambda count: order.append(("threads", count)), TTS=construct)
        with patch.dict(sys.modules, {"phonon_assets": assets, "ptts": native}):
            self.assertIs(_load_model(directory), fake_model)
        self.assertEqual(order[0], ("verify", directory))
        self.assertEqual(order[1], ("threads", 1))
        self.assertEqual(order[2], ("load", (str(directory),), {"lang": "en", "device": "cpu", "quant": "q8", "voice": "default"}))
        assets.verify_assets = Mock(side_effect=ValueError("Changed checkpoint"))
        native.TTS = Mock()
        with patch.dict(sys.modules, {"phonon_assets": assets, "ptts": native}), self.assertRaises(ValueError):
            _load_model(directory)
        native.TTS.assert_not_called()


class PhononTransportTests(unittest.TestCase):
    def test_resident_worker_reuses_process_and_receives_only_exact_text(self):
        process = Process()
        with patch("phonon_runtime.subprocess.Popen", return_value=process) as spawn, patch.dict(os.environ, {"HF_TOKEN": "must-not-propagate"}):
            adapter = PhononEnglishTts(Path("fixed-pinned-40m"))
            first = adapter.synthesize("The first complete news bulletin.")
            second = adapter.synthesize("The second bulletin.  Its last sentence survives.\n")
            self.assertEqual(spawn.call_count, 1)
            args, kwargs = spawn.call_args
            self.assertEqual(args[0][:2], [sys.executable, "-u"])
            self.assertEqual(args[0][-2], "--worker")
            self.assertNotIn("HF_TOKEN", kwargs["env"])
            self.assertEqual(kwargs["env"]["HF_HUB_OFFLINE"], "1")
            self.assertEqual(kwargs["env"]["OMP_NUM_THREADS"], "1")
            self.assertEqual(process.requests[1]["text"], "The second bulletin.  Its last sentence survives.\n")
            self.assertEqual(set(process.requests[0]), {"nonce", "requestId", "text"})
            self.assertEqual(process.requests[0]["nonce"], process.requests[1]["nonce"])
            self.assertNotEqual(process.requests[0]["requestId"], process.requests[1]["requestId"])
            self.assertEqual(first.wav, second.wav)
            self.assertEqual(first.duration_s, .01)
            self.assertEqual(first.first_chunk_s, .05)
            adapter.close()
            self.assertEqual(process.killed, 1)

    def test_failed_response_is_sanitized_and_worker_is_replaced(self):
        first = Process(lambda request: reply(request, nonce="0" * 32))
        second = Process()
        with patch("phonon_runtime.subprocess.Popen", side_effect=[first, second]) as spawn:
            adapter = PhononEnglishTts("fixed-pinned-40m")
            with self.assertRaisesRegex(PhononUnavailable, "^Local English speech is unavailable$"):
                adapter.synthesize("A complete report.")
            self.assertEqual(first.killed, 1)
            self.assertIsNone(adapter.process)
            self.assertEqual(adapter.synthesize("A later complete report.").duration_s, .01)
            self.assertEqual(spawn.call_count, 2)
            adapter.close()

    def test_timeout_kills_a_stalled_native_worker(self):
        process = Process(lambda _request: None)
        with patch("phonon_runtime.subprocess.Popen", return_value=process):
            adapter = PhononEnglishTts("fixed-pinned-40m", timeout=.03)
            started = time.monotonic()
            with self.assertRaisesRegex(PhononUnavailable, "^Local English speech is unavailable$"):
                adapter.synthesize("The native decoder stalled.")
            self.assertLess(time.monotonic() - started, 1)
            self.assertEqual(process.killed, 1)
            self.assertIsNone(adapter.process)

    def test_corrupt_unmatched_overlong_and_wrong_format_responses_fail_closed(self):
        bad = [lambda req: reply(req, requestId="0" * 32),
               lambda req: reply(req, wavBase64="not base64!"),
               lambda req: reply(req, wavBase64=base64.b64encode(wav_bytes(channels=2)).decode("ascii")),
               lambda req: reply(req, wavBase64=base64.b64encode(wav_bytes(sample_rate=48000)).decode("ascii")),
               lambda req: reply(req, durationSeconds=90.01),
               lambda req: reply(req, inferenceSeconds=float("nan")),
               lambda req: reply(req, firstChunkSeconds=.5),
               lambda _req: b"x" * (MAX_LINE_BYTES + 1)]
        for respond in bad:
            with self.subTest(response=repr(respond)):
                process = Process(respond)
                with patch("phonon_runtime.subprocess.Popen", return_value=process):
                    adapter = PhononEnglishTts("fixed-pinned-40m")
                    with self.assertRaisesRegex(PhononUnavailable, "^Local English speech is unavailable$"):
                        adapter.synthesize("Complete public English news.")
                    self.assertEqual(process.killed, 1)

    def test_public_text_cannot_choose_a_model_or_other_voice_and_bad_text_never_spawns(self):
        with patch("phonon_runtime.subprocess.Popen") as spawn:
            adapter = PhononEnglishTts("fixed-pinned-40m")
            for text in ("", " " * 10, "x" * 1201, "Arabic: مرحبا", "secret\x00command"):
                with self.assertRaises(PhononUnavailable):
                    adapter.synthesize(text)
            spawn.assert_not_called()
            for model in ("https://example.org/checkpoint", "hf://owner/other-model"):
                with self.assertRaises(PhononUnavailable):
                    PhononEnglishTts(model)
            for limit in (0, 46, float("inf"), True):
                with self.assertRaises(PhononUnavailable):
                    PhononEnglishTts("fixed-pinned-40m", timeout=limit)


if __name__ == "__main__":
    unittest.main()

"""Failed curve speech cannot monopolize a channel as quote IDs change.

All accounts, prices and WAVs below are deterministic offline fixtures. These
tests do not call a provider or establish actual Arabic speech availability.
"""
from datetime import datetime, timezone
from decimal import Decimal
import io
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server
from market_brief import parse_quote
from test_people_now import AR_OPINION, NOW, NOW_MS, reaction


class MarketRetryFairnessTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        with patch.dict('os.environ', {'RADIO_CLOUD_LLM': '0', 'RADIO_COMPETITION': '0'}), \
                patch('server.time.time', return_value=NOW - 1000):
            self.station = server.Station(self.directory.name)
        self.station.programmes = None
        self.station.languages = ('en', 'ar')
        self.post = reaction(key=2, text=AR_OPINION)
        self.station.stories[self.post['id']] = self.post
        for language in ('en', 'ar'):
            self.station.initial_price[language] = Decimal('4020.00')
            self.station.last_announced_price[language] = Decimal('4020.00')
            self.station.last_market_at[language] = NOW_MS - 30000
            self.station.last_analysis_at[language] = None
        self.observe()

    def tearDown(self):
        self.station.stop.set()
        self.directory.cleanup()

    def observe(self, offset=0, price='4020.00'):
        stamp = NOW + offset
        self.station.market.observe(parse_quote({'symbol': 'XAU', 'price': Decimal(price),
            'updatedAt': datetime.fromtimestamp(stamp, timezone.utc).isoformat()}, stamp))

    @staticmethod
    def speech(language, duration=2):
        data = io.BytesIO()
        with wave.open(data, 'wb') as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * (24000 * duration))
        return SimpleNamespace(wav=data.getvalue(), duration_s=duration,
            engine='synthetic-retry-fairness-only', language=language)

    def test_new_quote_id_does_not_bypass_channel_cooldown_or_block_english(self):
        station = self.station
        old = station._market_job('ar', NOW_MS, {})
        self.assertEqual(old['kind'], 'analysis')
        self.observe(10)
        new = station._market_job('ar', NOW_MS + 10000, {})
        self.assertEqual(new['kind'], 'analysis')
        self.assertNotEqual(old['id'], new['id'], 'a new provider clock really changes the job ID')
        retry = {old['id']: NOW_MS + 30000, '_analysisRetryAt:ar': NOW_MS + 30000}
        self.assertIsNone(station._market_job('ar', NOW_MS + 10000, retry))
        self.assertEqual(station._next_job('ar', NOW_MS + 10000, retry)['kind'], 'people-now')
        self.assertEqual(station._market_job('en', NOW_MS + 10000, retry)['kind'], 'analysis')
        self.assertIsNone(station._market_job('ar', NOW_MS + 29999, retry))
        self.assertEqual(station._market_job('ar', NOW_MS + 30000, retry)['kind'], 'analysis')
        self.assertIsNone(station.last_analysis_at['ar'])
        self.assertNotIn(self.post['id'], station.seen['ar'])

    def test_analysis_cooldown_keeps_genuine_changed_price_priority(self):
        self.observe(10, '4021.25')
        retry = {'_analysisRetryAt:ar': NOW_MS + 30000}
        job = self.station._market_job('ar', NOW_MS + 10000, retry)
        self.assertEqual((job['kind'], job['announcementReason']), ('market', 'changed'))
        self.assertEqual(self.station._next_job('ar', NOW_MS + 10000, retry)['kind'], 'market')
        self.assertNotIn(self.post['id'], self.station.seen['ar'])

    def produce_after_failed_analysis(self, *, expiry=False):
        station = self.station
        clock = [NOW]
        calls = []
        expected = station.people_now.candidate('ar', [self.post], NOW_MS)['speechText']
        initial = station._market_job('ar', NOW_MS, {})
        self.assertEqual(initial['kind'], 'analysis')
        case = self

        class Voice:
            def synthesize(self, text, language):
                calls.append(text)
                if len(calls) == 1:
                    case.assertEqual(text, initial['speechText'])
                    # A later provider observation gives the next analysis a
                    # different ID; only a channel-level backoff prevents it.
                    clock[0] = NOW + (100 if expiry else 10)
                    case.observe(clock[0] - NOW)
                    if not expiry:
                        raise ValueError('Synthetic analysis speech failure')
                    return case.speech(language, duration=8)
                station.stop.set()
                return case.speech(language)

        with patch('server.time.time', side_effect=lambda: clock[0]):
            station._produce(Voice(), ('ar',))
        self.assertEqual(calls, [initial['speechText'], expected],
            'ready compact speech must follow failure instead of another newly identified analysis')
        self.assertEqual([q['kind'] for q in station.queues['ar']], ['people-now'])
        self.assertIsNone(station.last_analysis_at['ar'])
        self.assertEqual(station.outlook.status()['retainedRecords'], 0)
        self.assertIn(self.post['id'], station.seen['ar'])
        self.assertNotIn(self.post['id'], station.seen['en'])
        self.assertEqual(station.people_now.status('ar', clock[0] * 1000)['emittedPosts'], 1)

    def test_analysis_synthesis_failure_yields_next_turn_to_ready_people(self):
        self.produce_after_failed_analysis()

    def test_analysis_expiry_during_synthesis_yields_next_turn_to_ready_people(self):
        self.produce_after_failed_analysis(expiry=True)


if __name__ == '__main__':
    unittest.main()

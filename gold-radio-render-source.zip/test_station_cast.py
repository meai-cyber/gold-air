import unittest
from dataclasses import FrozenInstanceError

from station_cast import CAST_VERSION, CAST_VOICES, NEWS_ENGLISH_VOICE
from station_cast import NEWS_ARABIC_VOICE, NEWS_ARABIC_ENGINE
from station_cast import cast_metadata, get_cast_voice, network_voice_allowed


class StationCastTests(unittest.TestCase):
    def test_host_and_analyst_are_distinct_catalogued_genders(self):
        for language in ('ar', 'en'):
            host = get_cast_voice(language, 'host')
            analyst = get_cast_voice(language, 'analyst')
            self.assertNotEqual(host.voice, analyst.voice)
            self.assertEqual((host.gender, analyst.gender), ('Female', 'Male'))
            self.assertEqual((host.rate, analyst.rate), ('+0%', '+60%'))
            self.assertEqual(host.language, analyst.language)
        self.assertNotEqual(get_cast_voice('en', 'host').voice, NEWS_ENGLISH_VOICE)
        self.assertNotEqual(get_cast_voice('ar', 'host').voice, NEWS_ARABIC_VOICE)
        self.assertNotEqual(get_cast_voice('ar', 'analyst').voice, NEWS_ARABIC_VOICE)
        self.assertEqual(NEWS_ARABIC_ENGINE, 'edge-network-ar-sa-zariyahneural')

    def test_metadata_declares_actual_network_voice_rate_and_config_version(self):
        metadata = cast_metadata('ar', 'analyst')
        self.assertEqual(metadata['version'], CAST_VERSION)
        self.assertEqual(metadata['voice'], 'ar-LB-RamiNeural')
        self.assertEqual(metadata['gender'], 'Male')
        self.assertEqual(metadata['requestedSpeedMultiplier'], 1.6)
        self.assertTrue(metadata['network'])
        self.assertFalse(metadata['pitchShifted'])
        metadata['voice'] = 'changed copy'
        self.assertEqual(cast_metadata('ar', 'analyst')['voice'], 'ar-LB-RamiNeural')

    def test_profiles_are_immutable_and_cannot_select_arbitrary_voices(self):
        with self.assertRaises(TypeError):
            CAST_VOICES['ar', 'host'] = 'changed'
        with self.assertRaises(FrozenInstanceError):
            get_cast_voice('ar', 'host').voice = 'changed'
        for language, role in (('fr', 'host'), ('ar', 'en-US-AriaNeural'), ('ar', []), (None, 'host')):
            with self.assertRaises(ValueError):
                get_cast_voice(language, role)
        for voice, rate in (('ar-LB-RamiNeural', '+0%'), ('en-US-JennyNeural', '+60%'),
                            ('https://example.org/voice', '+0%'), ([], '+0%')):
            self.assertFalse(network_voice_allowed(voice, rate))
        self.assertTrue(network_voice_allowed(NEWS_ENGLISH_VOICE, '+0%'))
        self.assertTrue(network_voice_allowed(NEWS_ARABIC_VOICE, '+0%'))
        self.assertFalse(network_voice_allowed(NEWS_ARABIC_VOICE, '+60%'))
        self.assertTrue(network_voice_allowed('ar-LB-RamiNeural', '+60%'))


if __name__ == '__main__':
    unittest.main()

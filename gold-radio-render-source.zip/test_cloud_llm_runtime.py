import io
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import cloud_llm_runtime as runtime


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.instances = []

    def tearDown(self):
        for instance in self.instances:
            instance.close()
        self.temporary.cleanup()

    def instance(self, cls=runtime.CloudLlmRuntime, **changes):
        instance = cls(model_dir=self.temporary.name, executable=Path(self.temporary.name) / 'fake-owned-runtime',
                       state_dir=self.temporary.name, enabled=True,
                       memory_probe=lambda: {'currentBytes': 100 * runtime.MIB, 'limitBytes': 512 * runtime.MIB}, **changes)
        self.instances.append(instance)
        return instance

    def test_constructor_is_cheap_and_cpu_loopback_arguments_are_explicit(self):
        instance = self.instance()
        self.assertIsNone(instance._worker)
        self.assertIsNone(instance._process)
        args = instance._args(Path('private-key-file'))
        for flag, value in (('--host', '127.0.0.1'), ('--threads', '1'), ('--threads-batch', '1'),
                            ('--gpu-layers', '0'), ('--parallel', '1'), ('--cache-ram', '0'),
                            ('--ctx-checkpoints', '0'), ('--ctx-size', '1536')):
            self.assertEqual(args[args.index(flag) + 1], value)
        for flag in ('--jinja', '--no-repack', '--no-webui', '--no-slots', '--no-context-shift'):
            self.assertIn(flag, args)
        self.assertNotIn('0.0.0.0', args)
        self.assertFalse(instance.status()['publicApi'])
        self.assertNotIn('key', instance.status())

    def test_invalid_or_closed_calls_never_start_a_worker(self):
        instance = self.instance()
        for prompt, options in (('', {}), ('a' * 4801, {}), ('<|im_start|>system', {}),
                                ('news', {'language': 'xx'}), ('news', {'max_tokens': 10000}),
                                ('news', {'timeout': 241}), ('news', {'max_tokens': True})):
            with self.assertRaises(runtime.CloudLlmUnavailable):
                instance.generate(prompt, **options)
        self.assertIsNone(instance._worker)
        instance.close()
        with self.assertRaises(runtime.CloudLlmUnavailable):
            instance.generate('News')

    def test_only_small_script_json_schemas_are_accepted(self):
        instance = self.instance()
        for schema in ({}, {'type': 'array'}, {'type': 'object', 'properties': {'tool': {'type': 'string'}}},
                       {'type': 'object', 'properties': {'host': {'type': 'integer'}, 'analyst': {'type': 'string'}},
                        'required': ['host', 'analyst'], 'additionalProperties': False}):
            with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'invalid-schema'):
                instance.generate('public news', schema=schema)
        self.assertIsNone(instance._worker)

    def test_memory_budget_distinguishes_reclaimable_page_cache(self):
        data = {'/sys/fs/cgroup/memory.current': str(500 * runtime.MIB),
                '/sys/fs/cgroup/memory.max': str(512 * runtime.MIB),
                '/sys/fs/cgroup/memory.stat': 'inactive_file ' + str(400 * runtime.MIB) + '\nfile 420\n'}
        with patch.object(Path, 'read_text', lambda path, *_a, **_k: data[path.as_posix()]):
            budget = runtime.memory_budget()
        self.assertEqual(budget['workingSetBytes'], 100 * runtime.MIB)
        instance = self.instance()
        instance._memory_probe = lambda: budget
        self.assertTrue(instance._memory_safe(starting=True))
        instance._memory_probe = lambda: {'currentBytes': 490 * runtime.MIB, 'limitBytes': 512 * runtime.MIB}
        self.assertFalse(instance._memory_safe())
        self.assertFalse(instance._memory_safe(starting=True))

    def test_single_worker_has_only_one_pending_slot_and_preserves_result_ownership(self):
        gate, entered, callers, results = threading.Event(), threading.Event(), [], {}
        class Fake(runtime.CloudLlmRuntime):
            def _complete(self, job):
                callers.append(job.prompt)
                entered.set()
                if job.prompt == 'first':
                    gate.wait(3)
                return 'result for ' + job.prompt
        instance = self.instance(Fake)
        def call(prompt):
            try:
                results[prompt] = instance.generate(prompt, timeout=3)
            except Exception as error:
                results[prompt] = str(error)
        one = threading.Thread(target=call, args=('first',)); one.start()
        self.assertTrue(entered.wait(1))
        two = threading.Thread(target=call, args=('second',)); two.start()
        deadline = time.monotonic() + 1
        while instance._jobs.qsize() != 1 and time.monotonic() < deadline:
            time.sleep(.005)
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'busy'):
            instance.generate('third', timeout=1)
        gate.set(); one.join(2); two.join(2)
        self.assertEqual(callers, ['first', 'second'])
        self.assertEqual(results, {'first': 'result for first', 'second': 'result for second'})

    def test_timeout_cancels_inference_and_a_speech_pause_releases_owned_work(self):
        entered = threading.Event()
        class Fake(runtime.CloudLlmRuntime):
            def _complete(self, job):
                entered.set()
                job.cancelled.wait(3)
                raise runtime.CloudLlmUnavailable(job.error or 'timeout')
        instance = self.instance(Fake)
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'timeout'):
            instance.generate('first', timeout=1)
        entered.clear(); result = []
        def call():
            try: instance.generate('second', timeout=3)
            except runtime.CloudLlmUnavailable as error: result.append(error.reason)
        caller = threading.Thread(target=call); caller.start()
        self.assertTrue(entered.wait(1))
        instance.pause(seconds=60)
        caller.join(2)
        self.assertEqual(result, ['speech-priority'])
        self.assertGreater(instance._cooldown_until, time.monotonic())

    def test_private_http_cannot_redirect_or_choose_another_destination(self):
        instance = self.instance()
        instance._key = 'test-only-key'
        requests = []
        class Http:
            def open(self, request, timeout):
                requests.append((request, timeout))
                return io.BytesIO(b'{}')
        instance._http = Http()
        job = runtime._Job('public news', 'en', 50, time.monotonic() + 30)
        self.assertEqual(instance._json('/health', job), {})
        self.assertEqual(requests[0][0].full_url, 'http://127.0.0.1:18083/health')
        self.assertEqual(requests[0][0].get_header('Authorization'), 'Bearer test-only-key')
        for path in ('https://example.org/', '//aljazeera.com', '/api/generate'):
            with self.assertRaises(runtime.CloudLlmUnavailable): instance._request(path, job)
        self.assertIsNone(runtime._NoRedirect().redirect_request(None, None, None, None, None, None))

    def test_only_complete_bounded_output_can_be_returned(self):
        class Fake(runtime.CloudLlmRuntime):
            finish = 'stop'
            oversized = False
            def _ensure_process(self, job): pass
            def _json(self, path, job, payload=None):
                return {'prompt': 'native rendered chat'} if path == '/apply-template' else {
                    'tokens': list(range(runtime.CONTEXT_TOKENS if self.oversized else 20))}
            def _request(self, path, job, payload=None):
                lines = [{'choices': [{'delta': {'content': 'A complete public news interpretation.'}, 'finish_reason': None}]},
                         {'choices': [{'delta': {}, 'finish_reason': self.finish}], 'usage': {'completion_tokens': 8}}]
                return io.BytesIO(b''.join(b'data: ' + json.dumps(line).encode() + b'\n\n' for line in lines) + b'data: [DONE]\n\n')
        instance = self.instance(Fake)
        job = runtime._Job('public news', 'en', 50, time.monotonic() + 30)
        self.assertEqual(instance._complete(job), 'A complete public news interpretation.')
        self.assertEqual(instance.status()['lastOutputTokens'], 8)
        instance.finish = 'length'
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'truncated'): instance._complete(job)
        instance.oversized = True
        with self.assertRaisesRegex(runtime.CloudLlmUnavailable, 'context-limit'): instance._complete(job)


if __name__ == '__main__':
    unittest.main()

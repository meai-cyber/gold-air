"""Offline Hacker News integration fixtures: fictional account, fake writer/audio.

These contracts establish source/queue behavior, never live supply, translation
quality, actual hosted inference or a sustained amount of public-opinion speech.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
from html import escape
import io
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server
from cloud_script_writer import CloudScriptWriter
from news_context_reports import build_news_context
from news_freshness import is_fresh_news
from people_now import PeopleNow, job_fresh, MAX_PARENT_AGE_SECONDS
from people_translation import TranslationUnavailable, translate_comment, translation_allowed
from social_scrapling import (MAX_CONTEXT_AGE_S, context_parent, parse_listing,
                             parse_thread, reaction_allowed, request_url_allowed)
from source_policy import collector_url_allowed, story_allowed as source_allowed
from test_people_now import NOW, NOW_MS, OPINION, reaction, reply
from test_people_translation import ARABIC, MODEL, Runtime


ROOT_ID = '47610001'
COMMENT_ID = '47610002'
AUTHOR = 'fixture_listener'
ROOT_URL = 'https://news.ycombinator.com/item?id=' + ROOT_ID
COMMENT_URL = 'https://news.ycombinator.com/item?id=' + COMMENT_ID
ROOT_TITLE = 'Gold and real yields in business planning.'
AR_ROOT_TITLE = 'الذهب والعوائد الحقيقية في تخطيط الأعمال.'


def _clock(stamp):
    # Replay HN's full original UTC title; relative display text is decorative.
    return datetime.fromtimestamp(stamp, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S') + ' ' + str(stamp)


def _root_html(stamp):
    return (f'<tr class="athing submission" id="{ROOT_ID}">'
        '<td class="title"><span class="titleline">'
        '<a href="https://fixture.example/business-planning">' + ROOT_TITLE + '</a>'
        '</span></td></tr><tr><td class="subtext">'
        f'<span class="age" title="{_clock(stamp)}"><a href="item?id={ROOT_ID}">2 hours ago</a></span>'
        f'<a href="item?id={ROOT_ID}">2 comments</a></td></tr>')


def html_fixture(root_age=100, comment_age=20, text=OPINION, *, comment_id=COMMENT_ID, author=AUTHOR):
    root_html = _root_html(NOW - root_age)
    listing = ('<html><body><table>' + root_html + '</table></body></html>').encode()
    thread = (f'<html><head><link rel="canonical" href="{ROOT_URL}"></head><body>'
        '<table class="fatitem">' + root_html + '</table>'
        f'<table class="comment-tree"><tr class="athing comtr" id="{comment_id}">'
        '<td class="ind" indent="0"><img width="0"></td><td class="default">'
        f'<a class="hnuser" href="user?id={author}">{author}</a>'
        f'<span class="age" title="{_clock(NOW - comment_age)}">'
        f'<a href="item?id={comment_id}">seconds ago</a></span>'
        '<div class="commtext c00">' + escape(text) + '</div>'
        '</td></tr></table></body></html>').encode()
    return listing, thread


def hn_post(root_age=100, comment_age=20, **fields):
    listing, thread = html_fixture(root_age, comment_age, **fields)
    roots = parse_listing(listing, NOW)
    assert len(roots) == 1, 'Synthetic listing must contain its exact original discussion.'
    rows = parse_thread(thread, roots[0], NOW)
    assert len(rows) == 1, 'Synthetic thread must contain one complete suitable opinion.'
    return rows[0]


class ScraplingStationTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        with patch.dict('os.environ', {'RADIO_CLOUD_LLM': '0', 'RADIO_COMPETITION': '0'}), \
                patch('server.time.time', return_value=NOW):
            self.station = server.Station(self.directory.name)
        self.station.programmes = None
        self.station.languages = ('en', 'ar')
        self.post = hn_post()
        self.station.ingest([self.post], NOW)

    def tearDown(self):
        self.station.stop.set()
        self.directory.cleanup()

    def produce(self, language='en', outcome='ok'):
        station = self.station
        wav = io.BytesIO()
        with wave.open(wav, 'wb') as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(24000)
            audio.writeframes(b'\x01\x00' * 48000)

        class Tts:
            def synthesize(self, _text, language):
                station.stop.set()
                if outcome == 'tts-error':
                    raise ValueError('Synthetic audio failure')
                if outcome == 'queue-filled':
                    # Another producer may fill the queue while synthesis runs.
                    station.queues[language].extend({'id': format(index, '032x'),
                        'kind': 'news', 'startsAt': NOW_MS + 1000,
                        'endsAt': NOW_MS + 20000} for index in range(server.MAX_QUEUE))
                return SimpleNamespace(wav=wav.getvalue(), duration_s=2.0,
                    engine='synthetic-test-only', language=language)

        self.station.stop.clear()
        with patch('server.time.time', return_value=NOW):
            self.station._produce(Tts(), (language,))

    def translate(self, runtime=None):
        runtime = runtime or Runtime(ARABIC, AR_ROOT_TITLE)
        self.station.cloud_llm = runtime
        self.station.people_translation_state['enabled'] = True
        with patch('server.time.time', return_value=NOW):
            self.assertTrue(self.station._translate_people_once(NOW))
        return runtime, self.station.stories[self.post['id']]['machineTranslations']['ar']

    def test_real_parser_shape_flows_through_ingest_to_exact_attributed_english_job(self):
        row = self.station.stories[self.post['id']]
        parent = context_parent(row)
        self.assertEqual(row['sourceKind'], 'social-reaction')
        self.assertEqual(row['platform'], 'HackerNews')
        self.assertEqual(row['url'], COMMENT_URL)
        self.assertEqual(row['title'], OPINION)
        self.assertEqual(row['reaction']['contentHash'], hashlib.sha256(OPINION.encode()).hexdigest())
        self.assertEqual(parent['url'], ROOT_URL)
        self.assertEqual(parent['publishedAt'], NOW - 100)
        self.assertTrue(source_allowed(row))
        self.assertTrue(is_fresh_news(row, NOW))
        self.assertFalse(source_allowed(parent))
        self.assertIsNone(self.station._candidate('en', NOW))
        job = self.station._next_job('en', NOW_MS, {})
        self.assertEqual(job['kind'], 'people-now')
        self.assertEqual(job['sources'], [row, parent])
        self.assertEqual(job['peopleNow']['authorHandle'], AUTHOR)
        self.assertEqual(job['peopleNow']['sourcePostId'], COMMENT_ID)
        self.assertEqual(job['peopleNow']['maxPostAgeSeconds'], 3600)
        self.assertEqual(job['peopleNow']['maxParentAgeSeconds'], MAX_PARENT_AGE_SECONDS)
        self.assertFalse(job['factualContextEligible'])
        self.assertEqual(job['speechText'], 'On this Hacker News headline: ' + ROOT_TITLE + ' ' + AUTHOR + ': “' + OPINION + '”')
        self.assertEqual(job['peopleNow']['topic']['kind'], 'news-discussion')
        self.assertEqual(job['peopleNow']['topic']['association'], 'reply-to-collected-post')
        self.assertTrue(job['peopleNow']['topic']['startsTopic'])
        original_clock = datetime.fromtimestamp(parent['publishedAt'], timezone.utc).strftime('%d %b %H:%M UTC')
        self.assertNotIn(original_clock, job['speechText'])
        self.assertEqual(job['speechText'].count(ROOT_TITLE), 1)
        self.assertNotIn('individual, unverified opinion', job['speechText'])
        self.assertNotIn('does not represent public opinion', job['speechText'])
        self.assertEqual(job['publishedAt'], row['publishedAt'])
        self.assertEqual(job['firstSeenAt'], row['firstSeenAt'])
        self.assertEqual(job['sources'][1], parent)
        self.assertEqual(job['sources'][1]['title'], ROOT_TITLE)
        self.assertTrue(job['peopleNow']['unverified'])
        self.assertFalse(job['peopleNow']['representative'])
        self.assertNotIn('on Mastodon', job['speechText'])
        self.assertTrue(job_fresh(job, NOW_MS + 2000))

    def test_opinion_and_older_context_never_enter_factual_roundup_or_writer(self):
        row = self.station.stories[self.post['id']]
        parent = context_parent(row)
        self.assertIsNone(build_news_context('en', [row, parent], NOW))
        self.assertIsNone(self.station._latest_news_job('en', NOW_MS, {}))
        writer = CloudScriptWriter(Runtime(), model_id=MODEL, clock=lambda: NOW)
        answer = ('Currency changes could affect the cost of gold in another currency. '
                  'Demand may respond differently under other market conditions.')
        question = 'How could currency conversion affect the cost of gold?'
        with patch.object(writer, '_turn', side_effect=[answer, question]) as turns:
            self.assertTrue(writer.prepare('en', [row, parent], now_s=NOW))
        self.assertEqual(len(turns.call_args_list), 2)
        for call in turns.call_args_list:
            self.assertEqual(call.args[2], [])
        job = writer.candidate('en', NOW)
        self.assertEqual(job['sources'], [])
        self.assertTrue(job['programme']['educational'])
        self.assertFalse(job['programme']['sourceGrounded'])
        self.assertNotIn(OPINION, job['speechText'])

    def test_complete_persisted_wav_consumes_english_only_and_retains_source_hashes(self):
        self.produce()
        segment = self.station.queues['en'][0]
        self.assertEqual(segment['kind'], 'people-now')
        self.assertEqual(segment['sources'][0], self.post)
        self.assertEqual(segment['sources'][1], context_parent(self.post))
        self.assertEqual(segment['audioSource'], 'exact-attributed-public-post')
        self.assertFalse(segment['factualContextEligible'])
        self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 2)
        self.assertEqual(self.station.airtime['en'].intervals[-1][2], 'people-now')
        self.assertIn(self.post['id'], self.station.seen['en'])
        self.assertNotIn(self.post['id'], self.station.seen['ar'])
        with patch('server.time.time', return_value=NOW):
            audio = self.station.audio(segment['id'])
        with wave.open(io.BytesIO(audio), 'rb') as wav:
            self.assertEqual((wav.getnchannels(), wav.getsampwidth(), wav.getframerate(), wav.getnframes()),
                             (1, 2, 24000, 48000))
            self.assertTrue(any(wav.readframes(wav.getnframes())))
        restored = {**segment, 'url': segment['sourceUrl'],
                    'publishedAt': segment['publishedAt'] // 1000,
                    'firstSeenAt': segment['firstSeenAt'] // 1000}
        self.assertTrue(self.station._job_fresh(restored, segment['endsAt']))

    def test_same_news_discussion_is_introduced_once_before_distinct_complete_accounts(self):
        other = hn_post(comment_id='47610003', author='another_listener', comment_age=30)
        self.station.ingest([other], NOW)
        self.produce()
        first = deepcopy(self.station.queues['en'][-1])
        self.produce()
        second = self.station.queues['en'][-1]
        self.assertEqual(first['peopleNow']['topic']['key'], second['peopleNow']['topic']['key'])
        self.assertTrue(first['peopleNow']['topic']['startsTopic'])
        self.assertFalse(second['peopleNow']['topic']['startsTopic'])
        self.assertEqual((first['speechText'] + second['speechText']).count(ROOT_TITLE), 1)
        self.assertEqual(second['speechText'], second['peopleNow']['authorHandle'] + ': “' + second['sources'][0]['title'] + '”')
        self.assertNotEqual(first['peopleNow']['authorHandle'], second['peopleNow']['authorHandle'])
        for segment in (first, second):
            self.assertEqual(segment['sources'][1]['url'], ROOT_URL)
            self.assertEqual(segment['sources'][1]['publishedAt'], NOW - 100)
            self.assertEqual(segment['sources'][1]['firstSeenAt'], NOW)
            self.assertEqual(segment['peopleNow']['topic']['association'], 'reply-to-collected-post')
            self.assertFalse(segment['factualContextEligible'])
            self.assertIn(segment['sources'][0]['id'], self.station.seen['en'])
        self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 4)

    def test_arabic_group_uses_one_translated_headline_before_complete_translated_quotes(self):
        other = hn_post(comment_id='47610003', author='another_listener', comment_age=30)
        self.station.ingest([other], NOW)
        runtime = Runtime(ARABIC, AR_ROOT_TITLE, ARABIC, AR_ROOT_TITLE)
        self.translate(runtime)
        self.translate(runtime)
        self.assertEqual(len(runtime.calls), 4)
        self.produce('ar')
        first = deepcopy(self.station.queues['ar'][-1])
        self.produce('ar')
        second = self.station.queues['ar'][-1]
        self.assertEqual(first['speechText'].count(AR_ROOT_TITLE), 1)
        self.assertNotIn(AR_ROOT_TITLE, second['speechText'])
        self.assertNotIn(ROOT_TITLE, first['speechText'] + second['speechText'])
        for index, segment in enumerate((first, second)):
            self.assertEqual(segment['peopleNow']['topic']['startsTopic'], index == 0)
            self.assertEqual(segment['peopleNow']['topic']['title'], AR_ROOT_TITLE)
            self.assertEqual(segment['sources'][0]['title'], OPINION)
            self.assertEqual(segment['sources'][1]['title'], ROOT_TITLE)
            self.assertEqual(segment['sources'][1]['publishedAt'], NOW - 100)
            self.assertTrue(segment['peopleNow']['machineTranslation'])
            self.assertFalse(segment['peopleNow']['translationVerified'])
            self.assertTrue(segment['speechText'].endswith(segment['peopleNow']['authorHandle'] + ': «' + ARABIC + '»'))
            self.assertIn(segment['sources'][0]['id'], self.station.seen['ar'])
            self.assertNotIn(segment['sources'][0]['id'], self.station.seen['en'])
        self.assertEqual(self.station.people_now.status('ar', NOW_MS)['scheduledSeconds'], 4)

    def test_tts_disk_or_queue_failure_does_not_consume_or_earn_speech(self):
        for outcome in ('tts-error', 'file-error', 'queue-filled'):
            with self.subTest(outcome=outcome):
                if outcome == 'file-error':
                    with patch('server.Path.write_bytes', side_effect=OSError('Synthetic disk failure')):
                        self.produce()
                else:
                    self.produce(outcome=outcome)
                self.assertFalse(any(q['kind'] == 'people-now' for q in self.station.queues['en']))
                self.assertNotIn(self.post['id'], self.station.seen['en'])
                self.assertEqual(self.station.people_now.status('en', NOW_MS)['scheduledSeconds'], 0)
                self.assertEqual(self.station.people_now.status('en', NOW_MS)['emittedPosts'], 0)
                self.station.queues['en'].clear()
                self.assertEqual(self.station._next_job('en', NOW_MS, {})['sourceIds'], [self.post['id']])

    def test_arabic_translates_comment_and_topic_keeps_english_metadata_and_independent_consumption(self):
        self.assertIsNone(self.station.people_now.candidate('ar', list(self.station.stories.values()), NOW_MS))
        runtime, artifact = self.translate()
        row = self.station.stories[self.post['id']]
        parent = context_parent(row)
        self.assertEqual(len(runtime.calls), 2)
        self.assertIn(OPINION, runtime.calls[0][0])
        self.assertNotIn(ROOT_TITLE, runtime.calls[0][0])
        self.assertIn(ROOT_TITLE, runtime.calls[1][0])
        self.assertNotIn('fixture.example', runtime.calls[0][0])
        self.assertEqual(artifact['originalText'], OPINION)
        self.assertEqual(artifact['parentTitle'], ROOT_TITLE)
        self.assertEqual(artifact['contextText'], AR_ROOT_TITLE)
        self.assertFalse(translation_allowed(artifact, row, at_s=NOW))
        self.assertTrue(translation_allowed(artifact, row, parent, at_s=NOW))
        job = self.station._next_job('ar', NOW_MS, {})
        self.assertEqual(job['sources'], [row, parent])
        self.assertEqual(job['title'], ARABIC)
        self.assertEqual(job['speechText'], 'حول هذا العنوان المتداول على Hacker News: ' + AR_ROOT_TITLE + ' ' + AUTHOR + ': «' + artifact['text'] + '»')
        self.assertNotIn('ترجمة آلية', job['speechText'])
        self.assertNotIn('هاكر نيوز بدأ أصلاً', job['speechText'])
        self.assertNotIn('عنوانه الأصلي بالإنجليزية', job['speechText'])
        self.assertNotIn(ROOT_TITLE, job['speechText'])
        self.assertNotIn(OPINION, job['speechText'])
        self.assertEqual(job['sources'][1], parent)
        self.assertEqual(job['sources'][0]['publishedAt'], row['publishedAt'])
        self.assertEqual(job['sources'][0]['firstSeenAt'], row['firstSeenAt'])
        self.assertNotIn('على ماستودون', job['speechText'])
        self.assertTrue(job['peopleNow']['machineTranslation'])
        self.assertFalse(job['peopleNow']['translationVerified'])
        self.assertTrue(job_fresh(job, NOW_MS + 2000))
        self.produce('ar')
        self.assertIn(self.post['id'], self.station.seen['ar'])
        self.assertNotIn(self.post['id'], self.station.seen['en'])
        self.assertIsNotNone(self.station._next_job('en', NOW_MS, {}))
        self.assertEqual(self.station.queues['ar'][0]['audioSource'], 'machine-translated-attributed-public-post')
        self.assertEqual(self.station.queues['ar'][0]['sources'][0]['title'], OPINION)

    def test_translation_failure_leaves_english_available_without_arabic_filler(self):
        self.station.cloud_llm = Runtime(error=ValueError('Synthetic provider failure'))
        self.station.people_translation_state['enabled'] = True
        with patch('server.time.time', return_value=NOW):
            self.assertFalse(self.station._translate_people_once(NOW))
        self.assertNotIn('machineTranslations', self.station.stories[self.post['id']])
        self.assertIsNone(self.station.people_now.candidate('ar', list(self.station.stories.values()), NOW_MS))
        self.assertIsNotNone(self.station.people_now.candidate('en', list(self.station.stories.values()), NOW_MS))
        self.assertEqual(self.station.people_translation_state['completed'], 0)
        self.assertEqual(self.station.people_now.status('ar', NOW_MS)['scheduledSeconds'], 0)

    def test_comment_and_context_expire_at_distinct_complete_audio_boundaries(self):
        for root_age, comment_age, ceiling in ((3500, 3500, 100), (MAX_PARENT_AGE_SECONDS - 180, 20, 180)):
            with self.subTest(root_age=root_age, comment_age=comment_age):
                row = hn_post(root_age, comment_age)
                planner = PeopleNow()
                job = planner.candidate('en', [row], NOW_MS)
                self.assertIsNotNone(job)
                expiry = NOW_MS + ceiling * 1000
                self.assertTrue(job_fresh(job, expiry))
                self.assertFalse(job_fresh(job, expiry + 1))
                self.assertIsNone(PeopleNow().candidate('en', [row], expiry))
                parent = context_parent(row)
                artifact = translate_comment(Runtime(ARABIC, AR_ROOT_TITLE), row, parent, now_s=NOW)
                self.assertTrue(translation_allowed(artifact, row, parent, at_s=expiry // 1000))
                if comment_age == 3500:
                    self.assertFalse(translation_allowed(artifact, row, parent, at_s=expiry // 1000 + 1))
                else:
                    # Raw translation provenance may retain older HN context;
                    # the news-introduced programme's stricter one-hour root
                    # guard above remains authoritative through audio end.
                    self.assertTrue(translation_allowed(artifact, row, parent, at_s=expiry // 1000 + 1))

    def test_old_collected_discussion_cannot_become_a_fresh_news_topic(self):
        row = hn_post(root_age=7200)
        self.assertTrue(reaction_allowed(row, NOW), 'The raw collector may retain typed older context')
        self.assertEqual(context_parent(row)['publishedAt'], NOW - 7200)
        self.assertIsNone(PeopleNow().candidate('en', [row], NOW_MS))
        self.station.stories = {row['id']: row}
        self.assertIsNone(self.station._next_job('en', NOW_MS, {}))

    def test_context_age_exception_cannot_relax_other_platforms_or_spoofed_rows(self):
        old_parent = context_parent(hn_post(root_age=7200))
        mastodon = reaction()
        bluesky, root = reply()
        root.update(publishedAt=NOW - 7200, firstSeenAt=NOW - 7199)
        bluesky['feedback']['rootPublishedAt'] = root['publishedAt']
        for row, parent in ((mastodon, old_parent), (bluesky, root)):
            runtime = Runtime(ARABIC)
            with self.subTest(platform=row['platform']), self.assertRaises(TranslationUnavailable):
                translate_comment(runtime, row, parent, now_s=NOW)
            self.assertEqual(runtime.calls, [])
        self.assertIsNone(PeopleNow().candidate('en', [bluesky, root], NOW_MS))
        for original, platform in ((self.post, 'Mastodon'), (self.post, 'Bluesky'),
                                   (mastodon, 'HackerNews'), (bluesky, 'HackerNews')):
            changed = deepcopy(original)
            changed['platform'] = platform
            with self.subTest(original=original['platform'], spoofed=platform):
                self.assertFalse(source_allowed(changed))
                self.assertIsNone(PeopleNow().candidate('en', [changed], NOW_MS))
                if platform == 'HackerNews':
                    runtime = Runtime(ARABIC)
                    with self.assertRaises(TranslationUnavailable):
                        translate_comment(runtime, changed, now_s=NOW)
                    self.assertEqual(runtime.calls, [])

    def test_frozen_job_and_translation_reject_comment_clock_hash_root_and_account_tampering(self):
        _runtime, artifact = self.translate()
        original = self.station._next_job('en', NOW_MS, {})
        row = self.station.stories[self.post['id']]
        parent = context_parent(row)
        self.assertTrue(translation_allowed(artifact, row, parent, at_s=NOW))
        mutations = [
            lambda post: post.update(title=OPINION + ' Another opinion.'),
            lambda post: post.update(publishedAt=NOW - 19),
            lambda post: post.update(firstSeenAt=NOW - 1),
            lambda post: post['reaction'].update(authorHandle='another_fixture'),
            lambda post: post['reaction'].update(authorId='another_fixture'),
            lambda post: post['reaction'].update(contentHash='0' * 64),
            lambda post: post['reaction'].update(rawCommentHtml='<div class="commtext c00">Changed text.</div>'),
            lambda post: post['reaction'].update(rootHash='0' * 64),
            lambda post: post['reaction']['root'].update(publishedAt=NOW - 99),
            lambda post: post['reaction']['root'].update(title=ROOT_TITLE + ' Changed.'),
            lambda post: post['reaction']['root'].update(url=COMMENT_URL),
        ]
        for index, mutate in enumerate(mutations):
            changed = deepcopy(row)
            mutate(changed)
            with self.subTest(mutation=index):
                job = deepcopy(original)
                job['sources'][0] = changed
                self.assertFalse(job_fresh(job, NOW_MS + 2000))
                self.assertFalse(translation_allowed(artifact, changed, parent, at_s=NOW))
        changed = deepcopy(original)
        changed['sources'][1]['title'] += ' Replacement context.'
        self.assertFalse(job_fresh(changed, NOW_MS + 2000))
        changed = deepcopy(original)
        changed['peopleNow']['authorHandle'] = 'another_fixture'
        self.assertFalse(job_fresh(changed, NOW_MS + 2000))

    def test_parser_original_clocks_and_immutable_receipt_block_stale_relabelled_comments(self):
        listing, thread = html_fixture()
        root = parse_listing(listing, NOW)[0]
        stale = thread.replace(_clock(NOW - 20).encode(), _clock(NOW - 3601).encode())
        self.assertEqual(parse_thread(stale, root, NOW), [])
        conflicting = thread.replace(_clock(NOW - 20).encode(),
            (_clock(NOW - 20).rsplit(' ', 1)[0] + ' ' + str(NOW - 19)).encode())
        self.assertEqual(parse_thread(conflicting, root, NOW), [])
        no_original_clock = thread.replace(_clock(NOW - 20).encode(), b'just now')
        self.assertEqual(parse_thread(no_original_clock, root, NOW), [])
        row = deepcopy(self.post)
        row['publishedAt'] = NOW - 3601
        row['firstSeenAt'] = NOW
        self.assertFalse(server.story_allowed(row, NOW))
        self.assertFalse(is_fresh_news(row, NOW))
        # Refreshing a listing/receipt cannot replace the first saved quote.
        changed = deepcopy(self.post)
        changed['title'] = OPINION + ' This is a later edit.'
        self.station.ingest([changed], NOW)
        self.assertEqual(self.station.stories[self.post['id']], self.post)
        with patch('server.time.time', return_value=NOW), \
                patch.dict('os.environ', {'RADIO_CLOUD_LLM': '0', 'RADIO_COMPETITION': '0'}):
            restored = server.Station(self.directory.name)
        restored.stop.set()
        self.assertEqual(restored.stories[self.post['id']], self.post)


class ScraplingDestinationIntegrationTests(unittest.TestCase):
    def test_only_fixed_hn_indexes_and_numeric_item_destinations_extend_source_policy(self):
        for url in ('https://news.ycombinator.com/', 'https://news.ycombinator.com/newest', ROOT_URL, COMMENT_URL):
            with self.subTest(allowed=url):
                self.assertTrue(request_url_allowed(url))
                self.assertTrue(collector_url_allowed(url))
        rejected = [
            'http://news.ycombinator.com/', 'https://news.ycombinator.com',
            'https://news.ycombinator.com:443/item?id=' + ROOT_ID,
            'https://news.ycombinator.com.evil.example/item?id=' + ROOT_ID,
            'https://fixture.example/business-planning',
            'https://news.ycombinator.com/user?id=' + AUTHOR,
            'https://news.ycombinator.com/login', 'https://news.ycombinator.com/submit',
            ROOT_URL + '&id=47610003', ROOT_URL + '&next=1', ROOT_URL + '#fragment',
            'https://news.ycombinator.com/item?id=0', 'https://news.ycombinator.com/item?id=-1',
            'https://news.ycombinator.com/item?id=abc', 'https://news.ycombinator.com/newest?p=2',
        ]
        for url in rejected:
            with self.subTest(rejected=url):
                self.assertFalse(request_url_allowed(url))
                self.assertFalse(collector_url_allowed(url))


if __name__ == '__main__':
    unittest.main()

"""Offline fictional-show contracts; fake timings do not prove aired audio."""
from copy import deepcopy
import unittest

from competition import (Competition, job_fresh, QUESTION_BANK, INTERVAL_SECONDS,
                         EPISODE_WALL_SECONDS, MAX_TURN_SECONDS, TURN_COUNT)


NOW = 1792936800000


def episode(planner, language='en', now=NOW):
    """Queue complete synthetic ten-second slots, without a TTS dependency."""
    jobs = []
    for _ in range(TURN_COUNT):
        job = planner.candidate(language, now)
        if job is None:
            raise AssertionError('Missing expected fictional quiz turn')
        if not planner.commit(job, now, now + 10000):
            raise AssertionError('Complete fixture slot rejected')
        jobs.append(job)
        now += 10000
    return jobs, now


class CompetitionScriptTests(unittest.TestCase):
    def test_exactly_five_questions_and_two_complete_answers_each_in_both_languages(self):
        for language in ('en', 'ar'):
            with self.subTest(language=language):
                jobs, end = episode(Competition(), language)
                self.assertEqual(len(jobs), 17)
                self.assertEqual(jobs[0]['competition']['stage'], 'intro')
                self.assertEqual(jobs[-1]['competition']['stage'], 'result')
                questions = [job for job in jobs if job['competition']['stage'] == 'question']
                self.assertEqual(len(questions), 5)
                self.assertEqual(len({job['competition']['questionId'] for job in questions}), 5)
                for number in range(1, 6):
                    round_jobs = [job for job in jobs if job['competition']['roundIndex'] == number
                                  and job['competition']['stage'] != 'result']
                    self.assertEqual([job['competition']['stage'] for job in round_jobs],
                                     ['question', 'player-a', 'player-b'])
                    self.assertEqual(len({job['competition']['questionId'] for job in round_jobs}), 1)
                    self.assertEqual(set(round_jobs[0]['competition']['choices']), {'A', 'B'})
                    self.assertTrue(all(job['competition']['answerChoice'] in ('A', 'B')
                                        for job in round_jobs[1:]))
                self.assertLess(end - NOW, EPISODE_WALL_SECONDS * 1000)

    def test_scoring_is_computed_from_answer_keys_and_winner_matches_each_deck(self):
        answer_key = {row['id']: row['correctChoice'] for row in QUESTION_BANK}
        for language in ('en', 'ar'):
            planner = Competition()
            start = NOW
            winners, decks = [], []
            for number in range(1, 11):
                jobs, _ = episode(planner, language, start)
                scores = {'player-a': 0, 'player-b': 0}
                for job in jobs:
                    metadata = job['competition']
                    if metadata['stage'] in scores:
                        scores[metadata['stage']] += int(
                            metadata['answerChoice'] == answer_key[metadata['questionId']])
                final = jobs[-1]['competition']
                self.assertEqual(final['scores'], scores)
                self.assertEqual(sorted(scores.values()), [3, 4])
                self.assertEqual(final['winnerRole'], max(scores, key=scores.get))
                expected_name = ({'player-a': 'Sam', 'player-b': 'Mia'} if language == 'en' else
                                 {'player-a': 'سامر', 'player-b': 'ميرا'})[final['winnerRole']]
                self.assertEqual(final['winner'], expected_name)
                self.assertIn(expected_name, jobs[-1]['speechText'])
                self.assertIn('Bravo' if language == 'en' else 'برافو', jobs[-1]['speechText'])
                winners.append(final['winnerRole'])
                decks.append(tuple(job['competition']['questionId'] for job in jobs
                                   if job['competition']['stage'] == 'question'))
                start += INTERVAL_SECONDS * 1000
            self.assertEqual(len(set(decks)), 10)
            self.assertEqual(winners[:4], ['player-a', 'player-b', 'player-a', 'player-b'])

    def test_fiction_synthetic_cast_and_imaginary_prize_are_clear_in_english_and_arabic(self):
        for language in ('en', 'ar'):
            jobs, _ = episode(Competition(), language)
            intro, final = jobs[0]['speechText'], jobs[-1]['speechText']
            if language == 'en':
                for wording in ('fictional', 'synthetic voices', 'Nadia', 'Sam', 'Mia',
                                'imaginary ounce of gold', 'no real prize'):
                    self.assertIn(wording, intro)
                self.assertIn('imaginary one-ounce gold trophy', final)
                self.assertIn('No actual gold changes hands', final)
            else:
                for wording in ('خيالية', 'اصطناعية', 'نادية', 'سامر', 'ميرا',
                                'أونصة ذهب خيالية', 'لا توجد جائزة حقيقية'):
                    self.assertIn(wording, intro)
                self.assertIn('لا ذهب حقيقيا ينتقل إلى أحد', final)
            for job in jobs:
                metadata = job['competition']
                for flag in ('fictional', 'scripted', 'syntheticCast'):
                    self.assertIs(metadata[flag], True)
                for flag in ('realParticipants', 'realPrize', 'currentNews', 'forecast', 'factualContextEligible'):
                    self.assertIs(metadata[flag], False)
                self.assertFalse(job['factualContextEligible'])
                self.assertEqual(metadata['mode'], 'fictional-quiz')
                self.assertEqual(metadata['prize'], 'imaginary-one-ounce-gold-trophy')
                self.assertEqual(job['sourceKind'], 'fictional-quiz')
                self.assertEqual(job['sources'], [])
                self.assertEqual(job['sourceIds'], [])
                self.assertEqual(metadata['questionCount'], 5)
                self.assertEqual(metadata['turnCount'], 17)
                if metadata['stage'] != 'result':
                    self.assertNotIn('scores', metadata)
                    self.assertNotIn('winner', metadata)

    def test_three_fixed_voice_roles_and_no_self_introductions_on_every_reply(self):
        for language in ('en', 'ar'):
            jobs, _ = episode(Competition(), language)
            self.assertEqual({job['voiceProfile'] for job in jobs},
                {'competition-host', 'competition-player-a', 'competition-player-b'})
            expected = {'host': 'Nadia', 'player-a': 'Sam', 'player-b': 'Mia'} if language == 'en' else {
                'host': 'نادية', 'player-a': 'سامر', 'player-b': 'ميرا'}
            for job in jobs:
                role = job['competition']['speakerRole']
                self.assertEqual(job['speaker'], expected[role])
                self.assertEqual(job['voiceProfile'], 'competition-' + role)
                if role != 'host':
                    self.assertNotIn(job['speaker'], job['speechText'])

    def test_each_answer_is_explained_by_next_host_turn_or_final_result(self):
        questions = {row['id']: row for row in QUESTION_BANK}
        for language in ('en', 'ar'):
            jobs, _ = episode(Competition(), language)
            for number in range(1, 6):
                question = next(job for job in jobs if job['competition']['stage'] == 'question'
                                and job['competition']['roundIndex'] == number)
                feedback = jobs[number * 3 + 1]
                self.assertEqual(feedback['competition']['speakerRole'], 'host')
                self.assertIn(questions[question['competition']['questionId']][language]['explanation'],
                              feedback['speechText'])

    def test_short_whole_turn_planning_and_total_target_are_bounded(self):
        for language in ('en', 'ar'):
            planner = Competition()
            for number in range(10):
                jobs, _ = episode(planner, language, NOW + number * INTERVAL_SECONDS * 1000)
                estimates = [job['estimatedSeconds'] for job in jobs]
                self.assertTrue(all(0 < value <= MAX_TURN_SECONDS for value in estimates))
                self.assertGreaterEqual(sum(estimates), 100)
                self.assertLessEqual(sum(estimates), 160)


class CompetitionSchedulingTests(unittest.TestCase):
    def test_first_show_immediately_due_but_candidate_and_preflight_never_consume_progress(self):
        planner = Competition()
        before = planner.status('en', NOW)
        first = planner.candidate('en', NOW)
        self.assertTrue(before['due'])
        self.assertIsNone(before['nextDueAt'])
        for _ in range(5):
            self.assertEqual(planner.candidate('en', NOW), first)
            self.assertTrue(planner.can_commit(first, NOW + 5000, NOW + 17000))
            self.assertEqual(planner.status('en', NOW), before)
        changed = deepcopy(first)
        changed['competition']['prize'] = 'real-gold'
        self.assertFalse(planner.commit(changed, NOW, NOW + 10000))
        self.assertEqual(planner.candidate('en', NOW), first)

    def test_returned_job_and_status_are_independent_copies(self):
        planner = Competition()
        first = planner.candidate('en', NOW)
        first['competition']['fictional'] = False
        first['sources'].append({'fake': True})
        self.assertTrue(planner.candidate('en', NOW)['competition']['fictional'])
        self.assertEqual(planner.candidate('en', NOW)['sources'], [])
        episode(planner)
        status = planner.status('en', NOW + 200000)
        status['scores']['player-a'] = 999
        self.assertEqual(planner.status('en', NOW + 200000)['scores']['player-a'], 4)

    def test_exclusion_blocks_only_next_turn_and_never_skips_to_a_later_one(self):
        planner = Competition()
        first = planner.candidate('en', NOW)
        for blocked in ([first['id']], [first['competition']['episodeId']]):
            self.assertIsNone(planner.candidate('en', NOW, excluded=blocked))
        self.assertEqual(planner.candidate('en', NOW)['id'], first['id'])
        self.assertEqual(planner.status('en', NOW)['emittedTurns'], 0)
        self.assertTrue(planner.commit(first, NOW, NOW + 10000))
        question = planner.candidate('en', NOW + 10000)
        self.assertIsNone(planner.candidate('en', NOW + 10000, excluded=[question['id']]))
        self.assertEqual(planner.candidate('en', NOW + 11000)['competition']['turnIndex'], 1)

    def test_actual_duration_not_planning_estimate_and_cadence_from_successful_first_start(self):
        planner = Competition()
        first = planner.candidate('en', NOW)
        start = NOW + 7000
        self.assertTrue(planner.commit(first, start, start + 12000))
        status = planner.status('en', start + 12000)
        self.assertEqual(status['scheduledSeconds'], 12)
        self.assertEqual(status['emittedTurns'], 1)
        self.assertEqual(status['nextDueAt'], start + INTERVAL_SECONDS * 1000)
        self.assertEqual(status['episodeStartedAt'], start)
        self.assertIsNone(planner.candidate('en', start + INTERVAL_SECONDS * 1000 - 1))
        new = planner.candidate('en', start + INTERVAL_SECONDS * 1000)
        self.assertEqual(new['competition']['turnIndex'], 0)
        self.assertNotEqual(new['competition']['episodeId'], first['competition']['episodeId'])
        self.assertTrue(planner.commit(new, start + INTERVAL_SECONDS * 1000,
                                       start + INTERVAL_SECONDS * 1000 + 9000))
        self.assertEqual(planner.status('en', start + INTERVAL_SECONDS * 1000)['scheduledSeconds'], 9)

    def test_completed_show_waits_for_twenty_minute_cadence(self):
        planner = Competition()
        jobs, end = episode(planner)
        status = planner.status('en', end)
        self.assertTrue(status['completed'])
        self.assertFalse(status['active'])
        self.assertFalse(status['due'])
        self.assertEqual(status['emittedTurns'], TURN_COUNT)
        self.assertEqual(status['scheduledSeconds'], 170)
        self.assertIsNone(planner.candidate('en', end))
        self.assertIsNone(planner.candidate('en', NOW + INTERVAL_SECONDS * 1000 - 1))
        self.assertEqual(planner.candidate('en', NOW + INTERVAL_SECONDS * 1000)['competition']['turnIndex'], 0)
        self.assertEqual(status['winner'], jobs[-1]['competition']['winner'])
        self.assertEqual(status['resultStartsAt'], end - 10000)
        self.assertEqual(status['resultEndsAt'], end)

    def test_old_duplicate_out_of_order_or_malformed_stage_never_advances(self):
        planner = Competition()
        first = planner.candidate('en', NOW)
        self.assertTrue(planner.commit(first, NOW, NOW + 10000))
        second = planner.candidate('en', NOW + 1000)
        before = planner.status('en', NOW + 1000)
        self.assertFalse(planner.commit(first, NOW + 10000, NOW + 20000))
        self.assertFalse(planner.commit(second, NOW + 9000, NOW + 19000))
        self.assertFalse(planner.commit(second, NOW + 10000, NOW + 10000))
        self.assertFalse(planner.commit(second, NOW + 10000, NOW + 101000))
        wrong = deepcopy(second)
        wrong['competition']['stage'] = 'result'
        self.assertFalse(planner.commit(wrong, NOW + 10000, NOW + 20000))
        self.assertEqual(planner.status('en', NOW + 1000), before)

    def test_incomplete_episode_expires_after_fifteen_minutes_without_resuming_next_cycle(self):
        planner = Competition()
        first = planner.candidate('en', NOW)
        self.assertTrue(planner.commit(first, NOW, NOW + 10000))
        last = planner.candidate('en', NOW + 880000)
        self.assertIsNotNone(last)
        self.assertFalse(planner.can_commit(last, NOW + 899000, NOW + 901000))
        self.assertIsNone(planner.candidate('en', NOW + EPISODE_WALL_SECONDS * 1000))
        status = planner.status('en', NOW + EPISODE_WALL_SECONDS * 1000)
        self.assertTrue(status['abandoned'])
        self.assertFalse(status['active'])
        self.assertFalse(status['completed'])
        self.assertNotIn('winner', status)
        new = planner.candidate('en', NOW + INTERVAL_SECONDS * 1000)
        self.assertEqual(new['competition']['stage'], 'intro')
        self.assertEqual(new['competition']['episodeNumber'], 2)

    def test_explicit_abandonment_preserves_clocks_and_never_resumes_or_creates_result(self):
        planner = Competition()
        intro = planner.candidate('en', NOW)
        self.assertTrue(planner.commit(intro, NOW + 5000, NOW + 15000))
        question = planner.candidate('en', NOW + 15000)
        self.assertTrue(planner.commit(question, NOW + 15000, NOW + 25000))
        answer = planner.candidate('en', NOW + 25000)
        at = NOW + 86000
        before = planner.status('en', at)
        self.assertTrue(before['active'])
        self.assertEqual(before['lastEndAt'], NOW + 25000)
        self.assertTrue(planner.abandon('en', at))
        status = planner.status('en', at)
        self.assertTrue(status['abandoned'])
        self.assertFalse(status['active'])
        self.assertFalse(status['due'])
        self.assertFalse(status['completed'])
        for field in ('scheduledSeconds', 'emittedTurns', 'episodeStartedAt', 'lastEndAt', 'nextDueAt'):
            self.assertEqual(status[field], before[field])
        self.assertNotIn('scores', status)
        self.assertNotIn('winner', status)
        self.assertIsNone(status['resultStartsAt'])
        self.assertIsNone(status['resultEndsAt'])
        self.assertFalse(planner.can_commit(answer, at, at + 10000))
        self.assertFalse(planner.commit(answer, at, at + 10000))
        self.assertFalse(planner.abandon('en', at + 1))
        self.assertIsNone(planner.candidate('en', at))
        self.assertIsNone(planner.candidate('en', status['nextDueAt'] - 1))
        self.assertEqual(planner.status('en', at), status)
        new = planner.candidate('en', status['nextDueAt'])
        self.assertEqual(new['competition']['stage'], 'intro')
        self.assertEqual(new['competition']['episodeNumber'], 2)
        self.assertTrue(planner.commit(new, status['nextDueAt'], status['nextDueAt'] + 10000))
        restarted = planner.status('en', status['nextDueAt'])
        self.assertFalse(restarted['abandoned'])
        self.assertTrue(restarted['active'])
        self.assertEqual(restarted['emittedTurns'], 1)
        self.assertEqual(restarted['scheduledSeconds'], 10)
        self.assertNotIn('winner', restarted)

    def test_abandonment_only_changes_an_enabled_active_incomplete_language(self):
        planner = Competition()
        self.assertFalse(planner.abandon('en', NOW))
        intro = planner.candidate('en', NOW)
        self.assertTrue(planner.commit(intro, NOW, NOW + 10000))
        before = planner.status('en', NOW + 10000)
        for language, stamp in (('fr', NOW), ([], NOW), ('en', True), ('en', None), ('en', 0)):
            self.assertFalse(planner.abandon(language, stamp))
        self.assertEqual(planner.status('en', NOW + 10000), before)
        self.assertTrue(planner.abandon('en', NOW + 10000))
        self.assertTrue(planner.status('ar', NOW + 10000)['due'])
        self.assertFalse(planner.status('ar', NOW + 10000)['abandoned'])
        self.assertFalse(Competition(enabled=False).abandon('en', NOW))
        completed = Competition()
        _jobs, end = episode(completed)
        result = completed.status('en', end)
        self.assertFalse(completed.abandon('en', end))
        self.assertEqual(completed.status('en', end), result)
        expired = Competition()
        self.assertTrue(expired.commit(expired.candidate('en', NOW), NOW, NOW + 10000))
        self.assertFalse(expired.abandon('en', NOW + EPISODE_WALL_SECONDS * 1000))

    def test_complete_clip_end_and_preparation_expiry_fail_closed(self):
        first = Competition().candidate('en', NOW)
        expiry = first['competition']['expiresAt']
        self.assertTrue(job_fresh(first, expiry))
        self.assertFalse(job_fresh(first, expiry + 1))
        self.assertFalse(job_fresh(first, NOW - 1))
        planner = Competition()
        self.assertFalse(planner.commit(first, NOW - 1, NOW + 10000))
        self.assertFalse(planner.commit(first, expiry - 1000, expiry + 1))
        self.assertEqual(planner.status('en', NOW)['emittedTurns'], 0)

    def test_language_schedules_and_localized_speakers_are_independent(self):
        planner = Competition()
        english = planner.candidate('en', NOW)
        arabic = planner.candidate('ar', NOW)
        self.assertNotEqual(english['id'], arabic['id'])
        self.assertTrue(planner.commit(english, NOW, NOW + 10000))
        self.assertEqual(planner.candidate('en', NOW + 10000)['competition']['turnIndex'], 1)
        self.assertEqual(planner.candidate('ar', NOW + 10000)['competition']['turnIndex'], 0)

    def test_priority_insertion_moves_complete_turns_preserving_first_start_and_actual_airtime(self):
        planner = Competition()
        first = planner.candidate('en', NOW)
        self.assertTrue(planner.commit(first, NOW + 10000, NOW + 20000))
        second = planner.candidate('en', NOW)
        self.assertTrue(planner.commit(second, NOW + 20000, NOW + 30000))
        third = planner.candidate('en', NOW)
        before = planner.status('en', NOW)
        self.assertTrue(planner.can_shift_future('en', NOW + 20000, 5000, NOW))
        self.assertEqual(planner.status('en', NOW), before)
        self.assertFalse(planner.can_shift_future('en', NOW + 15000, 5000, NOW))
        self.assertFalse(planner.can_shift_future('en', NOW + 10000, 5000, NOW))
        self.assertTrue(planner.shift_future('en', NOW + 20000, 5000, NOW))
        shifted = planner.status('en', NOW)
        self.assertEqual(shifted['nextDueAt'], before['nextDueAt'])
        self.assertEqual(shifted['episodeStartedAt'], before['episodeStartedAt'])
        self.assertEqual(shifted['scheduledSeconds'], before['scheduledSeconds'])
        self.assertFalse(planner.commit(third, NOW + 30000, NOW + 40000))
        self.assertTrue(planner.commit(third, NOW + 35000, NOW + 45000))

    def test_priority_shift_cannot_push_episode_beyond_original_wall(self):
        planner = Competition()
        first = planner.candidate('en', NOW)
        self.assertTrue(planner.commit(first, NOW, NOW + 10000))
        second = planner.candidate('en', NOW + 880000)
        self.assertTrue(planner.commit(second, NOW + 880000, NOW + 890000))
        self.assertFalse(planner.can_shift_future('en', NOW + 880000, 10001, NOW))
        self.assertFalse(planner.shift_future('en', NOW + 880000, 10001, NOW))
        self.assertTrue(planner.can_shift_future('en', NOW + 880000, 10000, NOW))

    def test_result_display_clocks_follow_safe_future_insertion(self):
        planner = Competition()
        _jobs, end = episode(planner)
        self.assertTrue(planner.shift_future('en', NOW + 10000, 5000, NOW))
        status = planner.status('en', NOW)
        self.assertEqual(status['resultStartsAt'], end - 10000 + 5000)
        self.assertEqual(status['resultEndsAt'], end + 5000)
        self.assertEqual(status['nextDueAt'], NOW + INTERVAL_SECONDS * 1000)

    def test_disabled_module_has_no_due_jobs_or_progress_and_valid_shift_is_noop(self):
        planner = Competition(enabled=False)
        job = Competition().candidate('en', NOW)
        self.assertIsNone(planner.candidate('en', NOW))
        self.assertFalse(planner.can_commit(job, NOW, NOW + 10000))
        self.assertFalse(planner.commit(job, NOW, NOW + 10000))
        self.assertFalse(planner.status('en', NOW)['enabled'])
        self.assertFalse(planner.status('en', NOW)['due'])
        self.assertTrue(planner.can_shift_future('en', NOW + 10000, 5000, NOW))
        self.assertTrue(planner.shift_future('en', NOW + 10000, 5000, NOW))
        self.assertEqual(planner.status('en', NOW)['emittedTurns'], 0)

    def test_changed_script_identity_voice_answer_score_or_labels_are_rejected(self):
        planner = Competition()
        jobs, _ = episode(planner)
        for job in jobs:
            self.assertTrue(job_fresh(job, job['competition']['generatedAt']))
            for key, value in (('speechText', 'A substituted script'), ('id', '0' * 32),
                               ('speaker', 'A real listener'), ('voiceProfile', 'news'),
                               ('sourceKind', 'publisher'), ('factualContextEligible', True)):
                changed = deepcopy(job)
                changed[key] = value
                self.assertFalse(job_fresh(changed, job['competition']['generatedAt']))
            for key, value in (('stage', 'result'), ('fictional', False), ('realPrize', True),
                               ('realParticipants', True), ('questionCount', 4), ('turnCount', 16),
                               ('currentNews', True), ('forecast', True), ('realPrize', 0),
                               ('expiresAt', job['competition']['expiresAt'] + 1)):
                if job['competition'][key] == value and type(job['competition'][key]) is type(value):
                    continue
                changed = deepcopy(job)
                changed['competition'][key] = value
                self.assertFalse(job_fresh(changed, job['competition']['generatedAt']))
        changed = deepcopy(jobs[-1])
        changed['competition']['scores']['player-a'] = 5
        self.assertFalse(job_fresh(changed, changed['competition']['generatedAt']))
        changed = deepcopy(jobs[2])
        changed['competition']['answerChoice'] = 'A' if changed['competition']['answerChoice'] == 'B' else 'B'
        self.assertFalse(job_fresh(changed, changed['competition']['generatedAt']))

    def test_bad_inputs_are_bounded_and_do_not_raise_or_advance(self):
        planner = Competition()
        for language in ('fr', '', None, [], {}):
            self.assertIsNone(planner.candidate(language, NOW))
            self.assertFalse(planner.status(language, NOW)['due'])
        for stamp in (0, -1, True, float(NOW), None, 'today', 253402300799001):
            self.assertIsNone(planner.candidate('en', stamp))
            self.assertFalse(job_fresh(planner.candidate('en', NOW), stamp))
        for value in (None, [], {}, True, 'fake'):
            self.assertFalse(planner.commit(value, NOW, NOW + 10000))
        self.assertIsNone(planner.candidate('en', NOW, excluded=None))
        self.assertFalse(planner.can_shift_future('en', NOW, 1000, NOW))
        self.assertFalse(planner.can_shift_future('en', NOW + 1000, True, NOW))
        self.assertEqual(planner.status('en', NOW)['emittedTurns'], 0)


if __name__ == '__main__':
    unittest.main()

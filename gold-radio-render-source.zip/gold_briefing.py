"""Short source-clocked gold curve readings and experimental statistical outlooks.

No remote model, API or headline rewriting is used here. The small local trend
recipe has no demonstrated edge. News supplies named topics only; its inclusion
does not establish price causation or enter the statistical forecast.
"""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import hashlib
import json
import math

from market_brief import MAX_QUOTE_AGE_S, SOURCE_URL
from news_selection import select_news
from market_outlook import compute_outlook
from news_freshness import publication_evidence


MAX_SPEECH_CHARS = 800
SPEECH_LIMITS = {'ar': 650, 'en': MAX_SPEECH_CHARS}
EDITORIAL_FORMATS = ('movement-first', 'range-first', 'curve-first')
MAX_NEWS_SOURCES = 3
_MACRO_TOPICS = {
    'gold': ('gold', 'الذهب'),
    'precious-metals': ('precious metals', 'المعادن الثمينة'),
    'central-banks': ('central banks', 'البنوك المركزية'),
    'rates-and-bonds': ('interest rates and bonds', 'الفائدة والسندات'),
    'inflation': ('inflation', 'التضخم'),
    'currencies': ('currencies', 'العملات'),
    'energy': ('energy markets', 'أسواق الطاقة'),
    'trade-and-supply': ('trade and supply chains', 'التجارة والإمدادات'),
    'jobs-and-growth': ('jobs and growth', 'الوظائف والنمو'),
    'financial-risk': ('financial markets', 'الأسواق المالية'),
    'geopolitics': ('geopolitical developments', 'التطورات الجيوسياسية'),
    'natural-supply-shock': ('supply disruptions', 'تعطل الإمدادات'),
}


def _number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
        raise ValueError('Invalid observed number')
    if not math.isfinite(value):
        raise ValueError('Invalid observed number')
    result = Decimal(str(value))
    if not result.is_finite() or abs(result) >= Decimal('1000000000'):
        raise ValueError('Invalid observed number')
    return result


def _clock(value):
    if type(value) is not int or value <= 0:
        raise ValueError('Invalid observed clock')
    return value


def _money(value):
    return format(Decimal(str(value)).quantize(Decimal('1'), rounding=ROUND_HALF_UP), '.0f')


def _observations(market, now_s):
    if (not isinstance(market, dict) or market.get('status') != 'ready' or
            market.get('provider') != 'Gold API' or market.get('asset') != 'XAU' or
            market.get('currency') != 'USD'):
        return None
    try:
        source = _clock(market.get('sourceAt'))
        received = _clock(market.get('receivedAt'))
        price = _number(market.get('price'))
        if 'priceText' in market:
            exact = _number(Decimal(market['priceText']))
            if abs(exact - price) > Decimal('.00000001'):
                return None
            price = exact
        if not (price > 0 and source <= received <= now_s * 1000 and
                0 <= now_s * 1000 - source <= MAX_QUOTE_AGE_S * 1000):
            return None
    except (ValueError, TypeError, InvalidOperation, OverflowError):
        return None

    changes = {}
    raw_changes = market.get('changes', {})
    for horizon in ('1', '5', '10'):
        row = raw_changes.get(horizon) if isinstance(raw_changes, dict) else None
        if not isinstance(row, dict):
            continue
        try:
            before, end = _clock(row.get('fromAt')), _clock(row.get('toAt'))
            usd = _number(row.get('usd'))
            expected = 'up' if usd > 0 else 'down' if usd < 0 else 'unchanged'
            span = (end - before) / 1000
            if (end != source or not int(horizon) * 60 <= span <= int(horizon) * 60 + 45 or
                    row.get('seconds') != span or row.get('direction') != expected):
                continue
            changes[horizon] = {'usd': usd, 'direction': expected,
                                'fromAt': before, 'toAt': end, 'seconds': int(span)}
        except (ValueError, TypeError, InvalidOperation, OverflowError):
            continue

    observed_range = None
    raw_range = market.get('observedRange')
    if isinstance(raw_range, dict):
        try:
            start, end = _clock(raw_range.get('fromAt')), _clock(raw_range.get('toAt'))
            low, high = _number(raw_range.get('low')), _number(raw_range.get('high'))
            count = raw_range.get('sampleCount')
            if (end == source and 60000 <= end - start <= 300000 and
                    type(count) is int and 2 <= count <= 96 and 0 < low <= price <= high):
                observed_range = {'low': low, 'high': high, 'fromAt': start,
                                  'toAt': end, 'sampleCount': count}
        except (ValueError, TypeError, InvalidOperation, OverflowError):
            pass
    return price, source, received, changes, observed_range


def _news_context(stories, language, now_s):
    if isinstance(stories, (str, bytes, dict)):
        return [], [], None
    try:
        # Bound materialization even if called with a generator.
        from itertools import islice
        rows = list(islice(iter(stories), 1000))
    except TypeError:
        return [], [], None
    for recency, window, minimum in (('fresh', 600, 0), ('earlier', 3600, 601)):
        selection = select_news(rows, language, now_s, window_s=window, minimum_age_s=minimum)
        sources, topics = [], []
        for row in selection.selected:
            # Commentary does not become verified market context by repeating it.
            # Publisher stories remain individually attributable in the manifest.
            if row.get('social') is True:
                continue
            matched = [topic for topic in selection.reasons[row['id']] if topic in _MACRO_TOPICS]
            if not matched:
                continue
            sources.append({key: row[key] for key in
                            ('id', 'source', 'url', 'publishedAt', 'firstSeenAt')})
            sources[-1].update(publication_evidence(row))
            sources[-1]['topics'] = matched
            sources[-1]['recency'] = recency
            for topic in matched:
                if topic not in topics:
                    topics.append(topic)
            if len(sources) == MAX_NEWS_SOURCES:
                break
        if sources:
            return sources, topics[:3], recency
    return [], [], None


def _trend(changes, language):
    if '1' not in changes or '5' not in changes:
        return None
    one, five = changes['1']['direction'], changes['5']['direction']
    if one == five == 'up':
        return ('The latest minute continues the observed five-minute rise.' if language == 'en'
                else 'الدقيقة الأخيرة تواصل الارتفاع المرصود خلال خمس دقائق.')
    if one == five == 'down':
        return ('The latest minute continues the observed five-minute decline.' if language == 'en'
                else 'الدقيقة الأخيرة تواصل الانخفاض المرصود خلال خمس دقائق.')
    if one == 'up' and five == 'down':
        return ('The last minute rebounded, while the five-minute balance remains lower.' if language == 'en'
                else 'ارتدت الدقيقة الأخيرة صعوداً، لكن المحصلة خلال خمس دقائق ما زالت منخفضة.')
    if one == 'down' and five == 'up':
        return ('The last minute retraced part of the observed five-minute gain.' if language == 'en'
                else 'تراجعت الدقيقة الأخيرة عن جزء من المكسب المرصود خلال خمس دقائق.')
    # The explicit change sentences already explain flat intervals clearly.
    return None


def _change_sentences(changes, language, editorial_format):
    """Describe observed net changes, without treating longer totals as speeds."""
    lines = []
    for horizon, row in changes.items():
        amount = _money(abs(row['usd']))
        if language == 'ar':
            period = {'1': 'الدقيقة الأخيرة', '5': 'خمس دقائق', '10': 'عشر دقائق'}[horizon]
            movement = ('دون تغيير' if row['direction'] == 'unchanged' else
                        ('ارتفاع' if row['direction'] == 'up' else 'انخفاض') + f' بنحو {amount} دولار')
            if horizon == '1':
                lines.append(f'محصلة {period} {movement}.')
            elif editorial_format == 'range-first':
                lines.append(f'أما محصلة {period} فهي {movement}.')
            else:
                lines.append(f'وخلال نحو {period}، المحصلة {movement}.')
        else:
            period = {'1': 'one minute', '5': 'five minutes', '10': 'ten minutes'}[horizon]
            movement = ('unchanged' if row['direction'] == 'unchanged' else
                        f'{row["direction"]} about {amount} dollars')
            if horizon == '1':
                lines.append(f'The latest minute was {movement}.')
            elif editorial_format == 'range-first':
                lines.append(f'The {period.replace(" minutes", "-minute")} net change was {movement}.')
            else:
                lines.append(f'Across about {period}, gold was {movement}.')
    return lines


def _range_sentence(observed_range, price, language):
    if observed_range is None:
        return None, None
    low, high = observed_range['low'], observed_range['high']
    position = None if high == low else float((price - low) / (high - low))
    if high - low < Decimal('.01'):
        return ('The available samples within five minutes stayed within one cent.' if language == 'en'
                else 'العينات المتاحة ضمن خمس دقائق بقيت ضمن فارق أقل من سنت واحد.'), position
    if language == 'ar':
        place = 'قرب أعلى' if position >= .75 else 'قرب أدنى' if position <= .25 else 'في وسط'
        return (f'تراوحت العينات المتاحة ضمن خمس دقائق بين {_money(low)} و{_money(high)} دولاراً؛ '
                f'والسعر الأخير {place} هذا النطاق.'), position
    place = 'near the top' if position >= .75 else 'near the bottom' if position <= .25 else 'in the middle'
    return (f'Available samples within five minutes span {_money(low)} to {_money(high)} dollars; '
            f'the latest is {place} of that range.'), position


def _context_sentence(sources, topics, recency, language):
    if not topics:
        return None
    names = [_MACRO_TOPICS[topic][0 if language == 'en' else 1] for topic in topics]
    publishers = list(dict.fromkeys(row['source'] for row in sources))
    attributed = ', '.join(publishers) if language == 'en' else '، و'.join(publishers)
    if language == 'ar':
        prefix = ('وفي الأخبار المختارة من آخر عشر دقائق، تناولت ' if recency == 'fresh' else
                  'وللسياق السابق من الساعة الأخيرة، تناولت ')
        return prefix + attributed + ' موضوعات ' + '، و'.join(names) + '.'
    prefix = ('Selected reports from the last ten minutes, from ' if recency == 'fresh' else
              'For earlier context from the last hour, selected reports from ')
    return prefix + attributed + ', cover ' + ', '.join(names) + '.'


def _amount(value, language):
    amount = abs(Decimal(str(value)))
    if 0 < amount < Decimal('.5'):
        return 'less than one dollar' if language == 'en' else 'أقل من دولار واحد'
    number = _money(amount)
    return number + (' dollar' if number == '1' else ' dollars') if language == 'en' else number


def _movement_sentence(changes, language):
    fragments = []
    for horizon in ('1', '5', '10'):
        if horizon not in changes or len(fragments) == 2:
            continue
        row = changes[horizon]
        if language == 'en':
            period = 'one minute' if horizon == '1' else horizon + ' minutes'
            movement = ('unchanged' if row['direction'] == 'unchanged' else
                        f'{row["direction"]} {_amount(row["usd"], language)}')
            fragments.append(f'{period}, {movement}')
        else:
            period = {'1': 'دقيقة', '5': 'خمس دقائق', '10': 'عشر دقائق'}[horizon]
            movement = ('دون تغير' if row['direction'] == 'unchanged' else
                        ('صعود ' if row['direction'] == 'up' else 'هبوط ') + _amount(row['usd'], language) +
                        ('' if 0 < abs(row['usd']) < Decimal('.5') else ' دولار'))
            fragments.append(period + '، ' + movement)
    if not fragments:
        return None
    return ('Observed net changes: ' + '; '.join(fragments) + '.' if language == 'en' else
            'المحصلة المرصودة خلال ' + '؛ '.join(fragments) + '.')


def _level_sentence(outlook, language):
    levels = outlook.get('levels')
    if not isinstance(levels, dict):
        return None
    support, resistance = _money(levels['supportText']), _money(levels['resistanceText'])
    if support == resistance:
        return ('The sampled range is too narrow for distinct whole-dollar support and resistance.' if language == 'en' else
                'النطاق المرصود ضيق لتمييز دعم ومقاومة مختلفين بعد تقريب الدولار.')
    return (f'Tentative support near {support} and resistance near {resistance} dollars reflect observed samples, not guaranteed barriers.'
            if language == 'en' else
            f'دعم مرجعي مؤقت نحو {support} ومقاومة نحو {resistance} دولار من العينات المرصودة، وليسا حدوداً مضمونة.')


def _projection_sentence(outlook, language):
    if outlook.get('status') == 'flat':
        return ('The samples are flat; they provide no clear direction or reliable support and resistance.' if language == 'en' else
                'العينات شبه ثابتة؛ لا تعطي اتجاهاً واضحاً أو نقاط دعم ومقاومة موثوقة.')
    forecasts = outlook.get('forecasts', [])
    projection = next((row for row in forecasts if row.get('horizonMinutes') == 3), None)
    if outlook.get('status') != 'ready' or projection is None:
        return ('The recent sample is insufficient for a near-term projection or reliable levels.' if language == 'en' else
                'العينات الحديثة غير كافية لإسقاط قريب أو نقاط دعم ومقاومة موثوقة.')
    clock = datetime.fromtimestamp(projection['targetAt'] / 1000, timezone.utc).strftime('%H:%M')
    price, low, high = (_money(projection[key]) for key in ('price', 'rangeLow', 'rangeHigh'))
    return (f'The experimental statistical target for {clock} UTC is near {price} dollars, with a rough {low} to {high} envelope. '
            'It is uncalibrated, with no demonstrated predictive edge.' if language == 'en' else
            f'الإسقاط الإحصائي التجريبي لهدف الساعة {clock} عالمياً نحو {price} دولار، بمجال تقريبي من {low} إلى {high}. '
            'المجال غير معاير ولا يثبت قدرة على التوقع.')


def _evaluation_sentence(outlook, now_s, language):
    evaluation = outlook.get('evaluation') or {}
    last = evaluation.get('latestMature')
    if (not isinstance(last, dict) or last.get('status') != 'matched' or
            type(last.get('targetAt')) is not int or type(last.get('actualReceivedAt')) is not int or
            not last['targetAt'] <= last['actualReceivedAt'] <= now_s * 1000 or
            last.get('horizonMinutes') not in (1, 3, 5) or type(last.get('directionCorrect')) is not bool):
        return None
    try:
        error = _number(last.get('absoluteErrorUSD'))
        if error < 0:
            return None
    except (ValueError, TypeError, InvalidOperation):
        return None
    amount = _amount(error, language)
    if language == 'en':
        result = 'matched' if last['directionCorrect'] else 'missed'
        return f'Previous {last["horizonMinutes"]}-minute trial: direction {result}; absolute error {amount}.'
    result = 'صحيح' if last['directionCorrect'] else 'خاطئ'
    return f'في الاختبار السابق لهدف {last["horizonMinutes"]} دقائق، الاتجاه {result} والخطأ المطلق {amount}' + ('' if 0 < error < Decimal('.5') else ' دولار') + '.'


def build_briefing(language, market_snapshot, stories, now_s, *, outlook_desk=None):
    """Fresh observed curve plus an explicitly experimental in-process outlook.

    Forecast issue/target clocks stay fixed through synthesis and queueing.
    Optional OutlookDesk must be committed by the owner ONLY after publication.
    Sparse/flat data gets an honest short explanation; stale/future quotes fail.
    """
    if language not in ('ar', 'en') or type(now_s) is not int or now_s <= 0:
        raise ValueError('Unsupported briefing language or clock')
    observations = _observations(market_snapshot, now_s)
    if observations is None:
        return None
    price, source, received, changes, observed_range = observations
    outlook = (outlook_desk.prepare(market_snapshot, now_s) if outlook_desk is not None else
               compute_outlook(market_snapshot, now_s))
    clock = datetime.fromtimestamp(source / 1000, timezone.utc).strftime('%H:%M')
    quote = (f'Gold API reference at {clock} UTC: near {_money(price)} dollars per troy ounce.' if language == 'en' else
             f'مرجع الذهب من Gold API عند {clock} عالمياً نحو {_money(price)} دولاراً للأونصة.')
    movement, trend = _movement_sentence(changes, language), _trend(changes, language)
    levels, projection = _level_sentence(outlook, language), _projection_sentence(outlook, language)
    review = _evaluation_sentence(outlook, now_s, language)
    programme_bucket = now_s // 180
    editorial_format = EDITORIAL_FORMATS[programme_bucket % len(EDITORIAL_FORMATS)]
    lead = trend if editorial_format == 'curve-first' and trend else levels if editorial_format == 'range-first' and levels else movement
    lines = [line for line in (review, lead, quote, movement if lead != movement else None,
                              levels if lead != levels else None, projection) if line]
    sources, topics, recency = _news_context(stories, language, now_s)
    context = _context_sentence(sources, topics[:1], recency, language)
    if context:
        lines.append(context)
    # Keep the source clock, observed levels and experimental/insufficiency
    # qualifier. Remove optional COMPLETE sentences rather than slicing speech.
    for optional in (context, trend if trend == lead else None, review, movement):
        if len(' '.join(lines)) > SPEECH_LIMITS[language] and optional in lines:
            lines.remove(optional)
    speech = ' '.join(lines)
    if len(speech) > SPEECH_LIMITS[language]:
        return None
    position = (float((price - observed_range['low']) / (observed_range['high'] - observed_range['low']))
                if observed_range and observed_range['high'] != observed_range['low'] else None)
    evidence = {'method': 'observed-gold-briefing-v3-statistical-outlook', 'issuedAt': now_s * 1000,
        'editorialFormat': editorial_format, 'sourceAt': source, 'receivedAt': received,
        'changes': {key: {**row, 'usd': float(row['usd'])} for key, row in changes.items()},
        'observedRange': ({**observed_range, 'low': float(observed_range['low']), 'high': float(observed_range['high'])}
                          if observed_range else None),
        'rangePosition': position, 'topics': topics, 'newsRecency': recency,
        'causalLinkAsserted': False, 'forecast': outlook.get('status') == 'ready',
        'spokenRounding': 'nearest-whole-USD-half-up', 'outlook': outlook}
    fingerprint = {'language': language, 'programmeBucket': programme_bucket, 'speech': speech,
        'marketSourceAt': source, 'changes': evidence['changes'], 'range': evidence['observedRange'],
        'outlookId': outlook.get('id'), 'sources': sources}
    identifier = hashlib.sha256(json.dumps(fingerprint, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:32]
    return {'id': identifier, 'kind': 'analysis', 'language': language,
        'title': 'Gold curve and experimental outlook' if language == 'en' else 'منحنى الذهب والإسقاط التجريبي',
        'source': 'Gold Pulse', 'url': SOURCE_URL, 'publishedAt': source // 1000, 'firstSeenAt': received // 1000,
        'speechText': speech, 'market': market_snapshot, 'sources': sources, 'analysis': evidence}

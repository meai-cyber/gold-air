"""Small, factual gold desk briefings from observations already held in memory.

No model, remote API or headline rewriting is used here. News supplies named
topics only; neither its timing nor its inclusion asserts a cause of a price
move. The caller schedules these separately from individual news readings.
"""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math

from market_brief import MAX_QUOTE_AGE_S, SOURCE_URL
from news_selection import select_news


MAX_SPEECH_CHARS = 800
SPEECH_LIMITS = {'ar': 650, 'en': MAX_SPEECH_CHARS}
EDITORIAL_FORMATS = ('movement-first', 'range-first', 'curve-first')
MAX_NEWS_SOURCES = 3
_MACRO_TOPICS = {
    'gold': ('gold', 'الذهب'),
    'precious-metals': ('precious metals', 'المعادن الثمينة'),
    'central-banks': ('central banks', 'البنوك المركزية'),
    'rates-and-bonds': ('interest rates and bonds', 'الفائدة والسندات'),
    'inflation': ('inflation', 'التضخم'),
    'currencies': ('currencies', 'العملات'),
    'energy': ('energy markets', 'أسواق الطاقة'),
    'trade-and-supply': ('trade and supply chains', 'التجارة والإمدادات'),
    'jobs-and-growth': ('jobs and growth', 'الوظائف والنمو'),
    'financial-risk': ('financial markets', 'الأسواق المالية'),
    'geopolitics': ('geopolitical developments', 'التطورات الجيوسياسية'),
    'natural-supply-shock': ('supply disruptions', 'تعطل الإمدادات'),
}


def _number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
        raise ValueError('Invalid observed number')
    if not math.isfinite(value):
        raise ValueError('Invalid observed number')
    result = Decimal(str(value))
    if not result.is_finite() or abs(result) >= Decimal('1000000000'):
        raise ValueError('Invalid observed number')
    return result


def _clock(value):
    if type(value) is not int or value <= 0:
        raise ValueError('Invalid observed clock')
    return value


def _money(value):
    return format(value.quantize(Decimal('.01')), '.2f')


def _observations(market, now_s):
    if (not isinstance(market, dict) or market.get('status') != 'ready' or
            market.get('provider') != 'Gold API' or market.get('asset') != 'XAU' or
            market.get('currency') != 'USD'):
        return None
    try:
        source = _clock(market.get('sourceAt'))
        received = _clock(market.get('receivedAt'))
        price = _number(market.get('price'))
        if not (price > 0 and source <= received <= now_s * 1000 and
                0 <= now_s * 1000 - source <= MAX_QUOTE_AGE_S * 1000):
            return None
    except (ValueError, TypeError, InvalidOperation, OverflowError):
        return None

    changes = {}
    raw_changes = market.get('changes', {})
    for horizon in ('1', '5', '10'):
        row = raw_changes.get(horizon) if isinstance(raw_changes, dict) else None
        if not isinstance(row, dict):
            continue
        try:
            before, end = _clock(row.get('fromAt')), _clock(row.get('toAt'))
            usd = _number(row.get('usd'))
            expected = 'up' if usd > 0 else 'down' if usd < 0 else 'unchanged'
            span = (end - before) / 1000
            if (end != source or not int(horizon) * 60 <= span <= int(horizon) * 60 + 45 or
                    row.get('seconds') != span or row.get('direction') != expected):
                continue
            changes[horizon] = {'usd': usd, 'direction': expected,
                                'fromAt': before, 'toAt': end, 'seconds': int(span)}
        except (ValueError, TypeError, InvalidOperation, OverflowError):
            continue

    observed_range = None
    raw_range = market.get('observedRange')
    if isinstance(raw_range, dict):
        try:
            start, end = _clock(raw_range.get('fromAt')), _clock(raw_range.get('toAt'))
            low, high = _number(raw_range.get('low')), _number(raw_range.get('high'))
            count = raw_range.get('sampleCount')
            if (end == source and 60000 <= end - start <= 300000 and
                    type(count) is int and 2 <= count <= 96 and 0 < low <= price <= high):
                observed_range = {'low': low, 'high': high, 'fromAt': start,
                                  'toAt': end, 'sampleCount': count}
        except (ValueError, TypeError, InvalidOperation, OverflowError):
            pass
    if not changes and observed_range is None:
        return None
    return price, source, received, changes, observed_range


def _news_context(stories, language, now_s):
    if isinstance(stories, (str, bytes, dict)):
        return [], [], None
    try:
        # Bound materialization even if called with a generator.
        from itertools import islice
        rows = list(islice(iter(stories), 1000))
    except TypeError:
        return [], [], None
    for recency, window, minimum in (('fresh', 600, 0), ('earlier', 3600, 601)):
        selection = select_news(rows, language, now_s, window_s=window, minimum_age_s=minimum)
        sources, topics = [], []
        for row in selection.selected:
            # Commentary does not become verified market context by repeating it.
            # Publisher stories remain individually attributable in the manifest.
            if row.get('social') is True:
                continue
            matched = [topic for topic in selection.reasons[row['id']] if topic in _MACRO_TOPICS]
            if not matched:
                continue
            sources.append({key: row[key] for key in
                            ('id', 'source', 'url', 'publishedAt', 'firstSeenAt')})
            sources[-1]['topics'] = matched
            sources[-1]['recency'] = recency
            for topic in matched:
                if topic not in topics:
                    topics.append(topic)
            if len(sources) == MAX_NEWS_SOURCES:
                break
        if sources:
            return sources, topics[:3], recency
    return [], [], None


def _trend(changes, language):
    if '1' not in changes or '5' not in changes:
        return None
    one, five = changes['1']['direction'], changes['5']['direction']
    if one == five == 'up':
        return ('The latest minute continues the observed five-minute rise.' if language == 'en'
                else 'الدقيقة الأخيرة تواصل الارتفاع المرصود خلال خمس دقائق.')
    if one == five == 'down':
        return ('The latest minute continues the observed five-minute decline.' if language == 'en'
                else 'الدقيقة الأخيرة تواصل الانخفاض المرصود خلال خمس دقائق.')
    if one == 'up' and five == 'down':
        return ('The last minute rebounded, while the five-minute balance remains lower.' if language == 'en'
                else 'ارتدت الدقيقة الأخيرة صعوداً، لكن المحصلة خلال خمس دقائق ما زالت منخفضة.')
    if one == 'down' and five == 'up':
        return ('The last minute retraced part of the observed five-minute gain.' if language == 'en'
                else 'تراجعت الدقيقة الأخيرة عن جزء من المكسب المرصود خلال خمس دقائق.')
    # The explicit change sentences already explain flat intervals clearly.
    return None


def _change_sentences(changes, language, editorial_format):
    """Describe observed net changes, without treating longer totals as speeds."""
    lines = []
    for horizon, row in changes.items():
        amount = _money(abs(row['usd']))
        if language == 'ar':
            period = {'1': 'الدقيقة الأخيرة', '5': 'خمس دقائق', '10': 'عشر دقائق'}[horizon]
            movement = ('دون تغيير' if row['direction'] == 'unchanged' else
                        ('ارتفاع' if row['direction'] == 'up' else 'انخفاض') + f' بنحو {amount} دولار')
            if horizon == '1':
                lines.append(f'محصلة {period} {movement}.')
            elif editorial_format == 'range-first':
                lines.append(f'أما محصلة {period} فهي {movement}.')
            else:
                lines.append(f'وخلال نحو {period}، المحصلة {movement}.')
        else:
            period = {'1': 'one minute', '5': 'five minutes', '10': 'ten minutes'}[horizon]
            movement = ('unchanged' if row['direction'] == 'unchanged' else
                        f'{row["direction"]} about {amount} dollars')
            if horizon == '1':
                lines.append(f'The latest minute was {movement}.')
            elif editorial_format == 'range-first':
                lines.append(f'The {period.replace(" minutes", "-minute")} net change was {movement}.')
            else:
                lines.append(f'Across about {period}, gold was {movement}.')
    return lines


def _range_sentence(observed_range, price, language):
    if observed_range is None:
        return None, None
    low, high = observed_range['low'], observed_range['high']
    position = None if high == low else float((price - low) / (high - low))
    if high - low < Decimal('.01'):
        return ('The available samples within five minutes stayed within one cent.' if language == 'en'
                else 'العينات المتاحة ضمن خمس دقائق بقيت ضمن فارق أقل من سنت واحد.'), position
    if language == 'ar':
        place = 'قرب أعلى' if position >= .75 else 'قرب أدنى' if position <= .25 else 'في وسط'
        return (f'تراوحت العينات المتاحة ضمن خمس دقائق بين {_money(low)} و{_money(high)} دولاراً؛ '
                f'والسعر الأخير {place} هذا النطاق.'), position
    place = 'near the top' if position >= .75 else 'near the bottom' if position <= .25 else 'in the middle'
    return (f'Available samples within five minutes span {_money(low)} to {_money(high)} dollars; '
            f'the latest is {place} of that range.'), position


def _context_sentence(sources, topics, recency, language):
    if not topics:
        return None
    names = [_MACRO_TOPICS[topic][0 if language == 'en' else 1] for topic in topics]
    publishers = list(dict.fromkeys(row['source'] for row in sources))
    attributed = ', '.join(publishers) if language == 'en' else '، و'.join(publishers)
    if language == 'ar':
        prefix = ('وفي الأخبار المختارة من آخر عشر دقائق، تناولت ' if recency == 'fresh' else
                  'وللسياق السابق من الساعة الأخيرة، تناولت ')
        return prefix + attributed + ' موضوعات ' + '، و'.join(names) + '.'
    prefix = ('Selected reports from the last ten minutes, from ' if recency == 'fresh' else
              'For earlier context from the last hour, selected reports from ')
    return prefix + attributed + ', cover ' + ', '.join(names) + '.'


def build_briefing(language, market_snapshot, stories, now_s):
    """Return a source-clocked analysis job, or None without usable observations.

    ``now_s`` is the issue clock. Evidence received after it, stale quotes,
    missing baselines and invented ranges cannot enter the spoken briefing.
    This is deterministic observation analysis, not a generative podcast.
    """
    if language not in ('ar', 'en') or type(now_s) is not int or now_s <= 0:
        raise ValueError('Unsupported briefing language or clock')
    observations = _observations(market_snapshot, now_s)
    if observations is None:
        return None
    price, source, received, changes, observed_range = observations
    clock = datetime.fromtimestamp(source / 1000, timezone.utc).strftime('%H:%M')
    range_sentence, position = _range_sentence(observed_range, price, language)
    trend = _trend(changes, language)
    # Rotate the editorial opening on the same three-minute clock used by the
    # station scheduler. A missing baseline must not create a fake curve/range.
    programme_bucket = now_s // 180
    editorial_format = EDITORIAL_FORMATS[programme_bucket % len(EDITORIAL_FORMATS)]
    if editorial_format == 'curve-first' and not trend:
        editorial_format = 'range-first' if range_sentence else 'movement-first'
    if editorial_format == 'range-first' and not range_sentence:
        editorial_format = 'movement-first'
    if editorial_format == 'movement-first' and not changes:
        editorial_format = 'range-first'
    if language == 'ar':
        quote = {
            'movement-first': f'عند الساعة {clock} بالتوقيت العالمي، بلغ السعر المرجعي للذهب نحو {_money(price)} دولاراً للأونصة.',
            'range-first': f'وسجل السعر المرجعي عند الساعة {clock} بالتوقيت العالمي نحو {_money(price)} دولاراً للأونصة.',
            'curve-first': f'أما آخر سعر مرجعي للذهب فهو نحو {_money(price)} دولاراً للأونصة، عند الساعة {clock} بالتوقيت العالمي.',
        }[editorial_format]
        title = {'movement-first': 'متابعة حركة الذهب', 'range-first': 'جولة في نطاق الذهب',
                 'curve-first': 'قراءة منحنى الذهب'}[editorial_format]
    else:
        quote = {
            'movement-first': f'At {clock} UTC, Gold API recorded gold near {_money(price)} US dollars per troy ounce.',
            'range-first': f'Gold API recorded {_money(price)} US dollars per troy ounce at {clock} UTC.',
            'curve-first': f'The latest Gold API reference is {_money(price)} US dollars per troy ounce, timed {clock} UTC.',
        }[editorial_format]
        title = {'movement-first': 'Gold movement update', 'range-first': 'Gold range check',
                 'curve-first': 'Gold curve reading'}[editorial_format]
    movements = _change_sentences(changes, language, editorial_format)
    if editorial_format == 'range-first':
        lines = [range_sentence, quote, *movements, trend]
    elif editorial_format == 'curve-first':
        lines = [trend, quote, *movements, range_sentence]
    else:
        # Lead with the shortest available observation, then the reference
        # clock and broader intervals. Each baseline is described once.
        lines = [*movements[:1], quote, *movements[1:], range_sentence, trend]
    lines = [line for line in lines if line]
    sources, topics, recency = _news_context(stories, language, now_s)
    context_sentence = _context_sentence(sources, topics, recency, language)
    if context_sentence:
        lines.append(context_sentence)
    limit = SPEECH_LIMITS[language]
    # Prefer all measured intervals and the range to an optional topic recap.
    # Drop only complete editorial units; a sentence is never cut mid-thought.
    if len(' '.join(lines)) > limit and context_sentence:
        lines.remove(context_sentence)
    if len(' '.join(lines)) > limit and trend:
        lines.remove(trend)
    speech = ' '.join(lines)
    if len(speech) > limit:
        return None
    evidence = {
        'method': 'observed-gold-briefing-v2', 'issuedAt': now_s * 1000,
        'editorialFormat': editorial_format,
        'sourceAt': source, 'receivedAt': received,
        'changes': {key: {**row, 'usd': float(row['usd'])} for key, row in changes.items()},
        'observedRange': ({**observed_range, 'low': float(observed_range['low']),
                           'high': float(observed_range['high'])} if observed_range else None),
        'rangePosition': position, 'topics': topics, 'newsRecency': recency,
        'causalLinkAsserted': False, 'forecast': False,
    }
    # A programme bucket avoids new IDs from polling the same observations. All
    # actual price/news evidence still participates, so new facts can be heard.
    fingerprint = {'language': language, 'programmeBucket': programme_bucket,
                   'editorialFormat': editorial_format, 'speech': speech,
                   'marketSourceAt': source, 'changes': evidence['changes'],
                   'range': evidence['observedRange'], 'sources': sources}
    ident = hashlib.sha256(json.dumps(fingerprint, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:32]
    return {'id': ident, 'kind': 'analysis', 'language': language,
            'title': title,
            'source': 'Gold Pulse', 'url': SOURCE_URL,
            'publishedAt': source // 1000, 'firstSeenAt': received // 1000,
            'speechText': speech, 'market': market_snapshot,
            'sources': sources, 'analysis': evidence}

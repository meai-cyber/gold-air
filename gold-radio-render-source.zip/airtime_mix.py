"""Bounded, per-channel station airtime accounting and a 20% music target.

Only explicit server clocks and scheduled, complete speech intervals enter this
module. Percentages describe elapsed station scheduling, not proof that an
individual listener's device played the audio. Future clips never count as
already spoken. The caller keeps music audible during every speech gap.
"""
from __future__ import annotations

import math


WINDOW_MS = 600_000
TARGET_MUSIC_PERCENT = 20
TARGET_SPEECH_PERCENT = 80
MAX_INTERVALS = 1600
MAX_CLIP_MS = 90_000
_KINDS = {'news', 'market', 'analysis', 'discussion', 'podcast'}


def _clock(value):
    if type(value) is not int or value < 0:
        raise ValueError('A nonnegative integer station clock is required')
    return value


def _milliseconds(seconds):
    if type(seconds) not in (int, float) or not math.isfinite(seconds) or not 0 < seconds <= 90:
        raise ValueError('A bounded complete speech duration is required')
    return max(1, round(seconds * 1000))


class AirtimeMix:
    """One owner-controlled channel; no wall clock, threads or listener state."""

    def __init__(self, start_ms):
        self.start_ms = _clock(start_ms)
        self.intervals = []
        self._last_end_ms = self.start_ms
        self._retired_spoken_ms = 0
        self._retired_through_ms = self.start_ms

    def _now(self, now_ms):
        now_ms = _clock(now_ms)
        if now_ms < self.start_ms or now_ms < self._retired_through_ms:
            raise ValueError('Station clock predates retained airtime history')
        return now_ms

    def _prune(self, now_ms):
        cutoff = now_ms - WINDOW_MS
        count = 0
        for start, end, _kind in self.intervals:
            if end > cutoff:
                break
            self._retired_spoken_ms += end - start
            self._retired_through_ms = end
            count += 1
        if count:
            del self.intervals[:count]

    def _speech_between(self, left_ms, right_ms):
        return sum(max(0, min(end, right_ms) - max(start, left_ms))
                   for start, end, _kind in self.intervals
                   if start < right_ms and end > left_ms)

    def next_start(self, queue, generated_ms, duration_s, prefetch_ms=6000):
        """Return a nonoverlapping start, with a bounded music-budget gap.

        Extra music is added only if prior committed speech has earned it at
        the candidate's start. A future clip never earns music before it airs.
        A warm schedule stops each optional break at 20% music or earlier.
        Existing
        startup, preparation or outage gaps are real music debt: in that case
        the next complete clip follows as soon as prefetch and prior audio allow.
        A projection never prunes history against its future clock.
        """
        generated_ms = self._now(generated_ms)
        _milliseconds(duration_s)  # Validate the complete clip without precharging it.
        if type(prefetch_ms) is not int or not 0 <= prefetch_ms <= 30_000:
            raise ValueError('A bounded integer prefetch interval is required')
        if not isinstance(queue, (list, tuple)) or len(queue) > MAX_INTERVALS:
            raise ValueError('A bounded station queue is required')
        tail = self._last_end_ms
        for row in queue:
            if not isinstance(row, dict):
                raise ValueError('Invalid station queue interval')
            end = _clock(row.get('endsAt'))
            if 'startsAt' in row and _clock(row['startsAt']) >= end:
                raise ValueError('Invalid station queue interval')
            tail = max(tail, end)
        self._prune(generated_ms)
        earliest = max(self.start_ms, generated_ms + prefetch_ms, tail)

        def excess(gap_ms):
            start = earliest + gap_ms
            left = max(self.start_ms, start - WINDOW_MS)
            spoken = self._speech_between(left, start)
            # Integer arithmetic avoids percentage/rounding drift in the rule.
            return spoken * 100 - (start - left) * TARGET_SPEECH_PERCENT

        if excess(0) <= 0:
            return earliest
        low, high = 0, WINDOW_MS
        # Old speech expires from the window as a music gap grows, so excess
        # decreases monotonically. At one whole window all prior speech is
        # outside the projection, so the search always has a bounded answer.
        while low < high:
            middle = (low + high) // 2
            if excess(middle) > 0:
                low = middle + 1
            else:
                high = middle
        # If the ideal boundary lies between whole milliseconds, stop before
        # it rather than spending even a fractional extra music millisecond.
        gap = low if excess(low) == 0 else max(0, low - 1)
        return earliest + gap

    def commit(self, start_ms, end_ms, kind):
        """Journal a successfully queued full clip once, in broadcast order."""
        start_ms, end_ms = _clock(start_ms), _clock(end_ms)
        if (start_ms < self.start_ms or start_ms < self._last_end_ms or
                not 0 < end_ms - start_ms <= MAX_CLIP_MS or
                not isinstance(kind, str) or kind not in _KINDS):
            raise ValueError('Invalid or overlapping complete speech interval')
        if self.intervals and self.intervals[-1][1] == start_ms and self.intervals[-1][2] == kind:
            # Adjacent same-kind turns have identical union coverage. Coalescing
            # preserves exact timing while bounding dense tiny synthetic cases.
            previous = self.intervals[-1]
            self.intervals[-1] = previous[0], end_ms, kind
        else:
            if len(self.intervals) >= MAX_INTERVALS:
                raise ValueError('Airtime history capacity exceeded')
            self.intervals.append((start_ms, end_ms, kind))
        self._last_end_ms = end_ms

    def total_music_ms(self, now_ms):
        """Exact cumulative music clock; it freezes only during elapsed speech.

        Retired speech remains in the cumulative offset even after its interval
        leaves the ten-minute reporting journal. Future queued clips do not
        freeze the clock until their actual station start.
        """
        now_ms = self._now(now_ms)
        self._prune(now_ms)
        spoken = self._retired_spoken_ms + self._speech_between(self.start_ms, now_ms)
        return now_ms - self.start_ms - spoken

    def snapshot(self, now_ms):
        now_ms = self._now(now_ms)
        self._prune(now_ms)
        left = max(self.start_ms, now_ms - WINDOW_MS)
        elapsed_ms = now_ms - left
        spoken_ms = self._speech_between(left, now_ms)
        music_ms = elapsed_ms - spoken_ms
        last_end = max(now_ms, self._last_end_ms)
        planned_spoken_ms = self._speech_between(now_ms, last_end)
        planned_music_ms = last_end - now_ms - planned_spoken_ms
        spoken_percent = round(100 * spoken_ms / elapsed_ms, 2) if elapsed_ms else None
        music_percent = round(100 * music_ms / elapsed_ms, 2) if elapsed_ms else None
        return {
            'targetMusicPercent': TARGET_MUSIC_PERCENT,
            'targetSpeechPercent': TARGET_SPEECH_PERCENT,
            'windowSeconds': WINDOW_MS // 1000,
            'elapsedSeconds': round(elapsed_ms / 1000, 3),
            'speechSeconds': round(spoken_ms / 1000, 3),
            'musicSeconds': round(music_ms / 1000, 3),
            'spokenPercent': spoken_percent,
            'speechPercent': spoken_percent,
            'musicPercent': music_percent,
            'speechShortfallSeconds': round(max(0, elapsed_ms * .8 - spoken_ms) / 1000, 3),
            'plannedSpeechSeconds': round(planned_spoken_ms / 1000, 3),
            'plannedMusicSeconds': round(planned_music_ms / 1000, 3),
            'fromAt': left,
            'throughAt': now_ms,
        }

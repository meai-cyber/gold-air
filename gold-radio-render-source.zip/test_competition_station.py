"""Competition integration uses synthetic audio, never real prizes or players."""
from copy import deepcopy
import io
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import wave

import server
from station_cast import cast_metadata

NOW = 1792960000


class CompetitionStationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.now = NOW
        with patch.dict('os.environ', {'RADIO_COMPETITION': '1'}), patch('server.time.time', return_value=NOW):
            self.station = server.Station(self.temporary.name)
        self.station.programmes = None
        self.station.languages = ('en', 'ar')
        self.calls = []

    def tearDown(self):
        self.station.stop.set()
        self.temporary.cleanup()

    def produce(self, language='en', failure=False):
        station, calls = self.station, self.calls
        data = io.BytesIO()
        with wave.open(data, 'wb') as wav:
            wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000)
            wav.writeframes(b'\x02\x00' * 48000)
        class Tts:
            def synthesize(self, text, language, voice_profile=None):
                station.stop.set()
                calls.append((text, language, voice_profile))
                if failure:
                    raise ValueError('synthetic voice failure')
                return SimpleNamespace(wav=data.getvalue(), duration_s=2.0,
                    engine='synthetic-test-only', language=language,
                    cast=cast_metadata(language, voice_profile))
        station.stop.clear()
        with patch('server.time.time', return_value=self.now):
            station._produce(Tts(), (language,))
        if station.queues[language]:
            self.now = station.queues[language][-1]['endsAt'] / 1000

    def test_full_show_has_five_rounds_two_players_correct_winner_and_three_voices(self):
        rows = []
        for _ in range(17):
            self.produce()
            rows.append(deepcopy(self.station.queues['en'][-1]))
        questions = [row for row in rows if row['competition']['stage'] == 'question']
        self.assertEqual(len(questions), 5)
        self.assertEqual({row['competition']['roundIndex'] for row in questions}, set(range(1, 6)))
        result = rows[-1]
        self.assertEqual(result['competition']['scores'], {'player-a': 4, 'player-b': 3})
        self.assertEqual(result['competition']['winner'], 'Sam')
        self.assertIn('Bravo, Sam!', result['speechText'])
        self.assertIn('imaginary one-ounce gold trophy', result['speechText'])
        self.assertFalse(result['competition']['realPrize'])
        self.assertEqual({call[2] for call in self.calls},
            {'competition-host', 'competition-player-a', 'competition-player-b'})
        self.assertEqual({row['cast']['gender'] for row in rows}, {'Female', 'Male'})
        self.assertTrue(all(row['sources'] == [] and row['factualContextEligible'] is False for row in rows))
        self.assertTrue(all(kind == 'competition' for _start, _end, kind in self.station.airtime['en'].intervals))

    def test_arabic_uses_its_own_host_voice_and_keeps_imaginary_prize_label(self):
        self.produce('ar')
        row = self.station.queues['ar'][0]
        self.assertEqual(row['speaker'], 'نادية')
        self.assertEqual(row['cast']['voice'], 'ar-EG-SalmaNeural')
        self.assertIn('خيالية', row['speechText'])
        self.assertFalse(row['competition']['realParticipants'])

    def test_failed_voice_or_file_write_never_advances_the_show(self):
        self.produce(failure=True)
        self.assertEqual(self.station.competition.status('en', NOW * 1000)['emittedTurns'], 0)
        with patch('server.Path.write_bytes', side_effect=OSError('synthetic file failure')):
            self.produce()
        self.assertEqual(self.station.queues['en'], [])
        self.assertEqual(self.station.competition.status('en', NOW * 1000)['emittedTurns'], 0)

    def test_manifest_reconstruction_preserves_script_and_prize_integrity(self):
        self.produce()
        q = deepcopy(self.station.queues['en'][0])
        restored = {**q, 'url': q['sourceUrl'], 'publishedAt': q['publishedAt'] // 1000,
                    'firstSeenAt': q['firstSeenAt'] // 1000}
        self.assertTrue(self.station._job_fresh(restored, q['endsAt']))
        restored['competition']['realPrize'] = True
        self.assertFalse(self.station._job_fresh(restored, q['endsAt']))

    def test_price_keeps_priority_and_quiz_continuation_prevents_unrelated_news_breaks(self):
        price = {'id': 'a' * 32, 'kind': 'market'}
        with patch.object(self.station, '_market_job', return_value=price):
            self.assertEqual(self.station._next_job('en', NOW * 1000, {}), price)
        self.produce()
        next_job = self.station._competition_continuation('en', int(self.now * 1000), {})
        self.assertEqual(next_job['competition']['turnIndex'], 1)
        self.assertTrue(next_job['_competitionContinuation'])
        self.assertIsNone(self.station._latest_news_job('en', int(self.now * 1000), {}))

    def test_retrying_answer_does_not_admit_news_and_prolonged_failure_abandons_without_award(self):
        self.produce()
        clock = int(self.now * 1000)
        pending = self.station.competition.candidate('en', clock)
        retry = {pending['id']: clock + 30000}
        with patch.object(self.station, '_candidate', return_value={'id': 'c' * 32}):
            self.assertIsNone(self.station._latest_news_job('en', clock, retry))
            self.assertIsNone(self.station._next_job('en', clock, retry))
        self.assertEqual(self.station.competition.status('en', clock)['emittedTurns'], 1)
        late = clock + 60001
        self.assertFalse(self.station._competition_in_progress('en', late))
        state = self.station.competition.status('en', late)
        self.assertTrue(state['abandoned'])
        self.assertFalse(state['completed'])
        self.assertNotIn('winner', state)
        self.assertIsNone(self.station.competition.candidate('en', late))


if __name__ == '__main__':
    unittest.main()

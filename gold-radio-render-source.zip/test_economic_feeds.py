from datetime import datetime, timezone
from email.utils import format_datetime
from html import escape
import unittest
from unittest.mock import patch

from economic_feeds import (ALLOWED_URLS, FEEDS, MAX_BYTES, MAX_AGE_S, EconomicFeedCollector,
                             fetch_public, parse_feed, story_id, _NoRedirect)
from social_sources import Response


NOW = 1792879500


def rss(feed=FEEDS[0], title='Gold rises after inflation data - Reuters', publisher='Reuters',
        source_url='https://www.reuters.com', age=30, link=None, description='<b>Do not read this teaser.</b>'):
    link = link or 'https://news.google.com/rss/articles/CBMi' + 'a' * 30 + '?oc=5'
    stamp = format_datetime(datetime.fromtimestamp(NOW - age, timezone.utc), usegmt=True)
    return ('<rss><channel><item><title>' + escape(title) + '</title><link>' + escape(link) +
            '</link><pubDate>' + stamp + '</pubDate><source url="' + escape(source_url, quote=True) + '">' +
            escape(publisher) + '</source><description>' + escape(description) +
            '</description></item></channel></rss>').encode()


class EconomicFeedParsingTests(unittest.TestCase):
    def test_six_fixed_queries_use_public_https_two_hour_searches(self):
        self.assertEqual(len(FEEDS), 6)
        self.assertEqual(len(ALLOWED_URLS), 6)
        for feed in FEEDS:
            self.assertTrue(feed.url.startswith('https://news.google.com/rss/search?'))
            self.assertIn('when%3A2h', feed.url)
        self.assertEqual(sum(feed.language == 'ar' for feed in FEEDS), 3)

    def test_exact_publisher_suffix_original_clocks_and_no_description(self):
        row = parse_feed(rss(), FEEDS[0], NOW)[0]
        self.assertEqual(row['title'], 'Gold rises after inflation data')
        self.assertEqual(row['source'], 'Reuters via Google News')
        self.assertEqual(row['publishedAt'], NOW - 30)
        self.assertEqual(row['firstSeenAt'], NOW)
        self.assertEqual(row['summary'], '')
        self.assertEqual(row['clockBasis'], 'aggregator-rss-publication')
        self.assertEqual(row['publisherDomain'], 'www.reuters.com')
        self.assertEqual(row['sourceKind'], 'publisher-aggregator')
        other = parse_feed(rss(title='Gold rises after inflation data - Another source'), FEEDS[0], NOW)[0]
        self.assertEqual(other['title'], 'Gold rises after inflation data - Another source')
        from server import story_id as existing_identity
        self.assertEqual(row['id'], existing_identity(row['title']))
        self.assertEqual(story_id('GOLD prices: rise!'), existing_identity('GOLD prices: rise!'))

    def test_only_allowlisted_source_domains_and_google_article_links(self):
        for change in ({'source_url': 'https://reuters.com.evil.example'},
                       {'source_url': 'https://unknown.example'}, {'source_url': 'http://www.reuters.com'},
                       {'source_url': 'https://user:password@reuters.com'},
                       {'link': 'https://news.google.com.evil.example/rss/articles/CBMi' + 'a' * 30},
                       {'link': 'https://example.com/news'},
                       {'link': 'http://127.0.0.1/private'},
                       {'link': 'https://news.google.com/rss/articles/CBMi' + 'a' * 30 + '?url=http://localhost'}):
            with self.subTest(change=change):
                self.assertEqual(parse_feed(rss(**change), FEEDS[0], NOW), [])

    def test_original_publication_boundary_future_and_entity_documents(self):
        self.assertEqual(len(parse_feed(rss(age=MAX_AGE_S), FEEDS[0], NOW)), 1)
        for age in (MAX_AGE_S + 1, -1):
            self.assertEqual(parse_feed(rss(age=age), FEEDS[0], NOW), [])
        for value in (b'x' * (MAX_BYTES + 1), b'<!DOCTYPE rss>' + rss(), b'<!ENTITY title "x">' + rss(), b'\x00' + rss()):
            with self.subTest(prefix=value[:20]), self.assertRaises(ValueError):
                parse_feed(value, FEEDS[0], NOW)

    def test_language_contract_keeps_arabic_and_accented_latin_not_mixed_english(self):
        ar = next(feed for feed in FEEDS if feed.key == 'ar-gold')
        title = 'أسعار الذهب تتراجع بعد بيانات التضخم - BBC'
        row = parse_feed(rss(ar, title, 'BBC', 'https://www.bbc.com/arabic'), ar, NOW)[0]
        self.assertEqual(row['title'], 'أسعار الذهب تتراجع بعد بيانات التضخم')
        self.assertEqual(parse_feed(rss(title='Gold rises after التضخم report - Reuters'), FEEDS[0], NOW), [])
        self.assertEqual(len(parse_feed(rss(title='Gold rises as café owners discuss inflation - Reuters'), FEEDS[0], NOW)), 1)

    def test_regional_publishers_are_rejected_even_inside_google_rss(self):
        for domain in ('aljazeera.com', 'aljazeera.net', 'aawsat.com', 'arabnews.com',
                       'asharqbusiness.com', 'skynewsarabia.com', 'cnnbusinessarabic.com'):
            with self.subTest(domain=domain):
                self.assertEqual(parse_feed(rss(source_url='https://' + domain), FEEDS[0], NOW), [])

    def test_evergreen_quote_pages_and_promotions_are_not_new_reports(self):
        for title in ('Gold Price Canada Today | Live Gold Price in CAD - Kitco',
                      'Gold live chart and live gold prices - Reuters',
                      'Gold sponsored promotion with guaranteed returns - Reuters'):
            with self.subTest(title=title):
                self.assertEqual(parse_feed(rss(title=title), FEEDS[0], NOW), [])
        self.assertEqual(len(parse_feed(rss(title='Gold price today rises after weaker inflation - Reuters'), FEEDS[0], NOW)), 1)


class EconomicFeedCollectorTests(unittest.TestCase):
    def collector(self, fetcher):
        collector = EconomicFeedCollector(fetcher)
        self.addCleanup(collector._pool.shutdown, wait=True, cancel_futures=True)
        return collector

    def test_four_request_bound_fair_initial_coverage_and_source_cadence(self):
        calls = []
        def fetch(url, headers, timeout):
            calls.append(url)
            self.assertNotIn('Authorization', headers)
            self.assertLessEqual(timeout, 8)
            feed = next(feed for feed in FEEDS if feed.url == url)
            content = rss(feed) if feed.language == 'en' else rss(feed, 'أسعار الذهب ترتفع بعد بيانات التضخم - Reuters')
            return Response(200, {'content-type': 'application/rss+xml'}, content, url)
        collector = self.collector(fetch)
        self.assertEqual(len(collector.collect(NOW)), 4)
        self.assertEqual(len(calls), 4)
        self.assertEqual(len(collector.collect(NOW)), 2)
        self.assertEqual(len(calls), 6)
        self.assertEqual(collector.collect(NOW + 59), [])
        status = collector.status()
        self.assertEqual((status['sourceCount'], status['readySources']), (6, 6))
        self.assertEqual(len(status['sources']), 6)

    def test_receipts_cannot_refresh_the_same_old_title(self):
        count = {'n': 0}
        def fetch(url, headers, timeout):
            count['n'] += 1
            return Response(200, {'content-type': 'application/rss+xml'}, rss(age=30 if count['n'] <= 4 else 10), url)
        collector = self.collector(fetch)
        first = collector.collect(NOW)
        self.assertTrue(first)
        second = collector.collect(NOW + 60)
        for row in second:
            self.assertEqual(row['publishedAt'], NOW - 30)
            self.assertEqual(row['firstSeenAt'], NOW)

    def test_denials_rate_limits_and_invalid_response_locations_back_off(self):
        for code, headers, expected in ((403, {}, 'access_denied'),
                                        (429, {'retry-after': '300'}, 'rate_limited')):
            collector = self.collector(lambda url, *_args: Response(code, headers, b'', url))
            self.assertEqual(collector.collect(NOW), [])
            states = collector.status()['sources'][:4]
            self.assertTrue(all(state['status'] == expected for state in states))
            self.assertTrue(all(state['nextCheckAt'] >= (NOW + 120) * 1000 for state in states))
        collector = self.collector(lambda *_args: Response(200, {'content-type': 'application/rss+xml'}, rss(), 'https://example.com'))
        self.assertEqual(collector.collect(NOW), [])
        self.assertEqual(collector.status()['readySources'], 0)

    def test_transport_rejects_other_urls_and_redirects_without_network(self):
        with patch('economic_feeds.urllib.request.build_opener') as opener:
            with self.assertRaises(ValueError):
                fetch_public('https://news.google.com/rss/search?q=arbitrary', {}, 1)
            with self.assertRaises(ValueError):
                fetch_public('http://127.0.0.1/private', {}, 1)
            opener.assert_not_called()
        self.assertIsNone(_NoRedirect().redirect_request(None, None, None, None, None, 'https://www.reuters.com'))


if __name__ == '__main__':
    unittest.main()

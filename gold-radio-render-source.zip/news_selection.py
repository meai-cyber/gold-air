"""Bounded, deterministic editorial selection of recent public-feed headlines.

This is a transparent topic filter, not an AI verdict or a price prediction.
Call it over *all* fresh stories, including already-spoken ones, before applying
playback receipts. An optional reduced quota must not drift as speech drains it.
The caller remains responsible for its fixed publisher/domain allowlist.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
import unicodedata
from urllib.parse import urlsplit
from news_speech import _clean as _clean_news_text


WINDOW_S = 600
MAX_INPUT_ROWS = 1000
TARGET_PERCENT = 100
MIN_RELEVANCE = 25


def normalized_title(value: str) -> str:
    """Normalize presentation differences, without rewriting source wording."""
    value = unicodedata.normalize('NFKC', value).casefold()
    value = re.sub(r'[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0640]', '', value)
    value = value.translate(str.maketrans('أإآٱى', 'ااااي'))
    value = re.sub(r'[^\w]+', ' ', value).strip()
    # Presentation prefixes do not create a new story or renew its clocks.
    # Keep every remaining word, including numbers and changed facts, exact.
    return re.sub(r'^(?:عاجل|breaking(?: news)?)(?:\s+|$)', '', value).strip()


def _pattern(english: str, arabic: str):
    # Arabic headlines commonly attach و / ف to the first word of a topic.
    return re.compile(r'(?<!\w)(?:' + english + '|[وف]?(?:' + arabic + r'))(?!\w)')


# Each topic contributes once. Scores rank editorial relevance; they are not
# probabilities, confidence, importance outside this service, or causal claims.
_TOPICS = (
    ('gold', 100, _pattern(
        r'gold(?:\s+(?:price|prices|bullion|futures|market|markets|demand|reserve|reserves))?|bullion|xau(?:usd)?',
        r'الذهب|للذهب|بالذهب|اسعار الذهب|سعر الذهب|اونصة الذهب|احتياطيات الذهب|'
        r'(?:اسعار|سعر|سوق|اونصة|اوقية|عقود|شراء|بيع|تداول|احتياطي) ذهب|'
        r'ذهب (?:عيار|يرتفع|ينخفض|يصعد|يتراجع|يقفز|يهبط)')),
    ('precious-metals', 65, _pattern(
        r'precious metals?|silver prices?|platinum prices?',
        r'المعادن الثمينة|اسعار الفضة|سعر الفضة|البلاتين')),
    ('central-banks', 60, _pattern(
        r'federal reserve|fed(?!\s+up\b)|fomc|ecb|bank of england|bank of japan|central banks?|monetary policy',
        r'الاحتياطي الفدرالي|الاحتياطي الفيدرالي|الفيدرالي|البنك المركزي|البنوك المركزية|السياسة النقدية')),
    ('rates-and-bonds', 45, _pattern(
        r'interest rates?|rate cuts?|rate hikes?|treasury (?:yields?|bonds?|debt|auctions?|borrowing|secretary)|bond yields?|government bonds?|treasuries',
        r'اسعار الفائدة|سعر الفائدة|خفض الفائدة|رفع الفائدة|عوائد السندات|سندات الخزانة|الفائدة')),
    ('inflation', 45, _pattern(
        r'inflation|deflation|consumer prices?|producer prices?|food prices?|price of food|grocery prices?|cpi|ppi|pce',
        r'التضخم|تضخم|انكماش الاسعار|اسعار المستهلك|اسعار المنتجين|اسعار الغذاء|اسعار المواد الغذائية')),
    ('currencies', 40, _pattern(
        r'us dollar|u s dollar|dollar index|dollar (?:falls?|rises?|slides?|slips?|gains?|drops?|climbs?|jumps?|rallies|surges?|weakens?|strengthens?|steadies|holds|edges?)|'
        r'dxy|euro|yen|sterling|exchange rates?|currency markets?',
        r'الدولار|للدولار|اليورو|الين|الجنيه الاسترليني|اسعار الصرف|سوق العملات')),
    ('energy', 40, _pattern(
        r'oil|crude|brent|wti|opec|diesel|natural gas|energy prices?',
        r'النفط|للنفط|نفطي|نفطية|النفطية|الخام|برنت|اوبك|الديزل|الغاز الطبيعي|اسعار الطاقة')),
    ('trade-and-supply', 35, _pattern(
        r'tariffs?|trade wars?|trade deals?|trade talks?|trade policy|china shock|export controls?|import restrictions?|sanctions?|supply chains?|shipping routes?|strait of hormuz|red sea',
        r'رسوم جمركية|الرسوم الجمركية|حرب تجارية|الحرب التجارية|المفاوضات التجارية|السياسة التجارية|قيود التصدير|حظر التصدير|العقوبات|عقوبات|سلاسل الامداد|مضيق هرمز|البحر الاحمر')),
    ('jobs-and-growth', 30, _pattern(
        r'nonfarm|payrolls?|unemployment|jobless claims?|labou?r markets?|job losses|layoffs?|hiring (?:freeze|freezes|slowdown|headwinds)|'
        r'gdp|recession|economic growth|economy|economies|manufacturing|retail sales|pmi',
        r'البطالة|بطالة|الوظائف|سوق العمل|تسريح العمال|تسريح الموظفين|تجميد التوظيف|تباطؤ التوظيف|خفض الوظائف|فقدان الوظائف|'
        r'الناتج المحلي|الركود|ركود|النمو الاقتصادي|الاقتصاد|الاقتصادي|الاقتصادية|التصنيع|مبيعات التجزية|مبيعات التجزئة')),
    ('financial-risk', 30, _pattern(
        r'financial crisis|banking crisis|sovereign debt|debt default|stock markets?|stock market crash|'
        r'margin debt|brokerage (?:firms?|borrowing|loans?)|borrowing.{0,60}(?:securities|portfolios)|'
        r'(?:stock|equity) funds?|(?:equity|equities|shares?) sell ?offs?|'
        r'(?:stocks|(?:global|world|asian|european|us|u s) shares) (?:are )?(?:fall|rise|slide|slip|gain|drop|climb|jump|rally|surge|plunge|tumble|sink|rebound|advance|retreat|mixed|flat|steady|wobble)|'
        r'safe havens?',
        r'ازمة مالية|الازمة المالية|ازمة مصرفية|الديون السيادية|التخلف عن السداد|اسواق الاسهم|صناديق الاسهم|موجة بيع (?:اسهم|الاسهم)|بيع مكثف للاسهم|'
        r'ديون الهامش|قروض الهامش|اقتراض المستثمرين|شركات الوساطة|'
        r'الاسواق (?:المالية|العالمية|الاوروبية|الامريكية|الاسيوية|ترتفع|تنخفض|تتراجع|تصعد|تهبط|تنتعش)|'
        r'الملاذ الامن|الملاذات الامنة')),
    ('geopolitics', 25, _pattern(
        r'war|ceasefire|geopolitical|missile strikes?|military strikes?|nuclear talks?|peace talks?|invasion',
        r'الحرب|حرب|وقف اطلاق النار|هدنة|جيوسياسية|جيوسياسي|ضربة عسكرية|ضربات عسكرية|ضربات صاروخية|مفاوضات نووية|غزو')),
)

_NONFINANCIAL_GOLD = re.compile(
    r'(?<!\w)(?:gold medals?|golden globes?|golden retrievers?|goldfish|golden goals?|'
    r'ميدالية ذهبية|الميدالية الذهبية|الميداليات الذهبية|الكرة الذهبية|جائزة الكرة الذهبية)(?!\w)')
_EXPLICIT_FINANCIAL_GOLD = _pattern(
    r'gold\s+(?:price|prices|bullion|futures|market|markets|demand|reserve|reserves)|bullion|xau(?:usd)?',
    r'اسعار الذهب|سعر الذهب|سوق الذهب|اونصة الذهب|احتياطيات الذهب')

# A country name alone is insufficient. Broader words such as "shooting" and
# Arabic مسيرات (which can also mean marches) require a conflict-region term.
_MILITARY_EVENT = _pattern(
    r'missiles?|airstrikes?|armed attacks?|armed forces|military drones?|combat drones?|drone strikes?|bombardment|shelling|artillery|warplanes?',
    r'صاروخ|الصاروخ|صواريخ|الصواريخ|هجوم مسلح|الهجوم المسلح|هجمات مسلحة|الهجمات المسلحة|القوات المسلحة|'
    r'قصف|القصف|المدفعية|طائرات حربية|المسيرات العسكرية|مسيرات عسكرية')
_CONFLICT_REGION = _pattern(
    r'ukraine|ukrainian|russia|russian|israel|israeli|palestine|palestinians?|iran|iranian|gaza|west bank|hebron|lebanon|lebanese|iraq|iraqi|yemen|yemeni|sudan|sudanese|'
    r'riyadh|saudi arabia|houthis?|tehran|taiz|aden|haiti|nigeria|nigerian',
    r'اوكرانيا|الاوكراني|الاوكرانية|اوكرانية|روسيا|الروسي|الروسية|روسية|اسرائيل|الاسرائيلي|الاسرائيلية|'
    r'اسرائيلي|اسرائيلية|فلسطين|فلسطيني|فلسطينيان|الفلسطينيين|فلسطينيين|الفلسطينية|ايران|الايراني|الايرانية|ايرانية|غزة|'
    r'الضفة الغربية|الخليل|لبنان|اللبنانية|العراق|العراقية|اليمن|اليمنية|السودان|السوداني|السودانية|'
    r'الرياض|بالرياض|السعودية|السعودي|بالسعودية|الحوثي|الحوثيون|الحوثيين|الحوثية|طهران|تعز|عدن|هايتي|نيجيريا')
_CONFLICT_ACTION = _pattern(
    r'shootings?|shot|attacks?|attacked|drones?|clashes|troops?|military|kill(?:s|ed)?|wounded|hostages?|strikes?|'
    r'soldiers?|ambush\w*|armed gangs?|demolish\w*|displac\w*|retaliat\w*',
    r'مسيرات|المسيرات|مسيرة|المسيرة|[ب]?اطلاق النار|[ب]?اطلاق نار|الرصاص|هجوم|الهجوم|هجمات|الهجمات|مهاجمة|يهاجم|يهاجمون|مسلحين|مسلحون|اشتباك|الاشتباك|اشتباكات|الاشتباكات|'
    r'عسكري|عسكرية|العسكري|العسكرية|المسلحة|جنود|الجنود|مقتل|قتل|قتلي|جرحي|رهائن|الرهائن|غارة|الغارة|غارات|الغارات|'
    r'انفجار|انفجارات|الانفجارات|تدمير|يدمر|اعتراض|الاعتراض|تهديد|تهديدهم|يهدد|بضرب|ضرب')
# Peace wording requires a conflict region; generic talks additionally require
# both sides of the Russia-Ukraine conflict, not a country name by itself.
_CONFLICT_DIPLOMACY = _pattern(
    r'peace talks?|ceasefire talks?|peace negotiations?|mediated talks?',
    r'مفاوضات سلام|محادثات سلام|مفاوضات وقف اطلاق النار|محادثات وقف اطلاق النار')
_DIPLOMATIC_ACTION = _pattern(
    r'talks|negotiations?|mediation',
    r'مفاوضات|المفاوضات|محادثات|المحادثات|بوساطة|وساطة')
_RUSSIA = _pattern(r'russia|russian|kremlin|moscow', r'روسيا|روسية|الروسية|روسي|الروسي|الكرملين|موسكو')
_UKRAINE = _pattern(r'ukraine|ukrainian|kyiv|kiev', r'اوكرانيا|اوكرانية|الاوكرانية|اوكراني|الاوكراني|كييف')
# Exact weapons-exercise wording avoids treating nuclear medicine, reactor
# science or a country's mere mention as a military development.
_NUCLEAR_EXERCISE = _pattern(
    r'nuclear (?:military )?(?:drills?|exercises?)|military nuclear training',
    r'(?:تدريب|تدريبات|مناورة|مناورات) نووي(?:ة)?')
_NUCLEAR_MEDICAL = _pattern(
    r'nuclear medicine|nuclear medical',
    r'الطب النووي|طب نووي|الطبية النووية')
# "Targeted" and "fighters" both have ordinary uses. Only their conjunction
# with an explicit armed actor and the named conflict-region gate qualifies.
_ARMED_ACTOR = _pattern(
    r'rsf fighters|rsf forces|paramilitary forces|armed groups?|armed fighters',
    r'قوات الدعم السريع|الدعم السريع|جماعات مسلحة|الجماعات المسلحة')
_HOSTILE_TARGETING = _pattern(
    r'targeted|targets|targeting',
    r'استهداف|الاستهداف|تستهدف|يستهدف|استهدفت|استهدف')
_ORDINARY_EVENT = _pattern(
    r'shark attacks?|dog attacks?|animal attacks?|heart attacks?|panic attacks?|knife attacks?|robbery|burglary|domestic dispute|'
    r'football|soccer|basketball|shooting team|shooting competition|peaceful marches',
    r'هجوم قرش|هجوم كلب|نوبة قلبية|ازمة قلبية|سرقة|السرقة|مشاجرة عائلية|كرة القدم|كرة السلة|فريق الرماية|مسيرات سلمية')

_NATURAL_DISASTER = _pattern(
    r'earthquakes?|hurricanes?|cyclones?|typhoons?|tsunamis?|wildfires?|floods?|volcanic eruption|'
    r'severe storms?|winter storms?|storm [a-z][a-z-]{2,}',
    r'زلزال|الزلزال|زلازل|الزلازل|اعصار|الاعصار|اعاصير|الاعاصير|فيضانات|الفيضانات|حرائق الغابات|تسونامي|ثوران بركاني')
_SUPPLY_ASSET = _pattern(
    r'gold|oil|crude|gas|energy|refiner(?:y|ies)|pipelines?|lng terminals?|shipping|ports?|supply chains?|global supplies',
    r'الذهب|النفط|الخام|الغاز|الطاقة|المصافي|مصفاة|خطوط الانابيب|الموانئ|ميناء|سلاسل الامداد|الامدادات العالمية')
_SUPPLY_DISRUPTION = _pattern(
    r'disrupts?|disrupted|disruption|closes?|closed|closures?|shuts?|shutdowns?|damages?|damaged|cuts?|halts?|stops?|threatens?|blocks?|blocked',
    r'تعطل|يعطل|تعطيل|توقف|يوقف|تغلق|يغلق|اغلاق|تقطع|قطع|تدمر|تدمير|يهدد|تهدد|تضرر|اضرار')

# Important world reporting is a separate low-priority radio tier. These rules
# do not assert an effect on gold, and no country/official's name alone admits a
# story. Direct gold/macro stories keep their higher topic scores above.
_MILITARY_POLICY_ACTOR = _pattern(
    r'defen[cs]e minister|army chief|combat units?|military units?',
    r'وزير الدفاع|قائد القوات|الوحدات القتالية|وحدات قتالية|الجيش')
_MILITARY_POLICY_ACTION = _pattern(
    r'threatens?|warns?|combat readiness|military readiness|evacuate|demolish',
    r'يتوعد|توعد|يهدد|تهدد|الجاهزية|جاهزية|سنخلي|سنهدم|سيدفعون ثمنا|عملية عسكرية|عملية واسعة')
_PRISONER_EXCHANGE = _pattern(
    r'prisoner exchanges?|exchange of prisoners|exchang\w* (?:\d+ )?prisoners',
    r'تبادل الاسري|تبادل (?:\d+ )?(?:اسيرا?|اسري)')
_SETTLEMENT_POLICY = _pattern(
    r'new settlements?|settlement expansion|settlement construction',
    r'مستوطنة|مستوطنات|المستوطنات|بؤرة استيطانية|بؤر استيطانية')
_SETTLEMENT_ACTION = _pattern(
    r'build|construction|approv\w*|expand\w*|annex\w*',
    r'بناء|بناء اكثر|سنبني|يبني|توسع|توسيع|اقرار|ضم')
_PUBLIC_PLACE = _pattern(
    r'church|mosque|synagogue|airport|railway station|train station|shopping cent(?:er|re)',
    r'كنيسة|الكنيسة|مسجد|المسجد|مطار|المطار|معبد|المعبد|محطة قطار|محطة القطارات')
_MASS_ATTACK = _pattern(
    r'gunmen|open(?:ed)? fire|shooting|bombing|terrorist attack|massacre',
    r'مسلحون|مسلحين|[ب]?اطلاق النار|[ب]?اطلاق نار|يطلقون النار|هجوم|الهجوم|مجزرة')
_PROTEST = _pattern(r'protests?|demonstrations?|civil unrest|rioters?|riots?', r'احتجاجات|الاحتجاجات|لاحتجاجات|مظاهرات|المظاهرات|للمظاهرات|شغب|الشغب')
_PROTEST_SECURITY = _pattern(
    r'security forces|police|interior minister|security officers|security deployment|arrests?|looting|loot shops|set fires',
    r'عنصر امن|عناصر الامن|قوات الامن|وزير داخلية|وزير الداخلية|الشرطة|قوات الشرطة|حظر الاحتجاجات|حظر المظاهرات')
_MASS_PROTEST = _pattern(
    r'mass protests?|mass demonstrations?|nationwide|countrywide|across (?:the )?country|hundreds|thousands|\d+ 000',
    r'احتجاجات حاشدة|مظاهرات حاشدة|احتجاجات واسعة|مظاهرات واسعة|انحاء البلاد|مئات|المئات|الاف|الالاف')
_PROTEST_ESCALATION = _pattern(
    r'arrested|clashes|detained',
    r'اعتقالات|الاعتقالات|اعتقال|الاعتقال|توقيف|التوقيف|توقيفات|اشتباكات|الاشتباكات')
_INSTITUTIONAL_ACTOR = _pattern(
    r'government|parliament|senate|congress|foreign minister|foreign ministry|united nations|security council',
    r'الحكومة|حكومة|البرلمان|مجلس النواب|مجلس الشيوخ|وزير الخارجية|وزارة الخارجية|الامم المتحدة|مجلس الامن')
_INSTITUTIONAL_POLICY = _pattern(
    r'legislation|state budget|public media|press independence|press freedom|election law|foreign policy|international law|governance of',
    r'تشريع|التشريع|ميزانية الدولة|الموازنة العامة|حرية الصحافة|استقلال الاعلام|قانون الانتخابات|السياسة الخارجية|القانون الدولي')
_DEFENCE_COMMUNICATIONS = _pattern(
    r'starlink restrictions|satellite system|military communications|defen[cs]e communications',
    r'الاتصالات العسكرية|اتصالات عسكرية|نظام اقمار صناعية|شبكة اقمار صناعية')
_SATELLITE_SYSTEM = _pattern(r'starlink|starshield', r'ستارلينك|ستارشيلد')
_SATELLITE_SERVICE = _pattern(
    r'services?|restor\w*|restrictions?|resum\w*|shutdown', r'تعود|عودة|العودة|العمل|خدمات|الخدمات|القيود|قيود|استئناف|توقف')
_MARKET_CONTEXT = _pattern(
    r'stocks (?:making|posting) (?:the )?(?:biggest|largest) moves|premarket|pre market|wall street|analyst calls|airfares?|airfare',
    r'تداولات ما قبل الافتتاح|وول ستريت|تكلفة الطيران|اسعار تذاكر الطيران')
_CONTEXT_PROMO = _pattern(
    r'free signals|follow me|join my|guaranteed profits?|guaranteed returns?|promo code|subscribe now|easy money|'
    r'buy now|shop now|discount code|sponsored promotion',
    r'تابعوني|اشتركوا الان|اشترك الان|توصيات مجانية|ربح مضمون|ارباح مضمونة|رمز ترويجي|كود الخصم|اشتر الان|اعلان ممول')
_NATIONAL_POLITICS = _pattern(
    r'(?:presidential|parliamentary|general|national) elections?|election results?|electoral commission|'
    r'coalition government|government (?:collapses|resigns|falls)|parliament dissolved|national referendum|'
    r'(?:presidential|parliamentary|national) runoffs?',
    r'انتخابات رئاسية|الانتخابات الرئاسية|انتخابات برلمانية|الانتخابات البرلمانية|الانتخابات العامة|'
    r'انتخابات تشريعية|الانتخابات التشريعية|جولة الاعادة للانتخابات الرئاسية|جولة الاعادة للانتخابات البرلمانية|'
    r'نتائج الانتخابات|لجنة الانتخابات|مفوضية الانتخابات|حكومة ائتلافية|استقالة الحكومة|حل البرلمان|استفتاء وطني')
_PUBLIC_POLICY_ACTOR = _pattern(
    r'supreme court|constitutional court|government|parliament|congress|european union|eu|united nations|security council',
    r'المحكمة العليا|المحكمة الدستورية|الحكومة|حكومة|البرلمان|الكونغرس|الاتحاد الاوروبي|الامم المتحدة|مجلس الامن')
_PUBLIC_POLICY_ACTION = _pattern(
    r'passes (?:a |the )?law|approves? (?:a |the )?bill|constitutional (?:reform|amendment)|'
    r'immigration policy|asylum rules|border policy|public spending|pension reform|pensions|freedom of movement|free movement|'
    r'emergency powers|diplomatic relations|recognises? (?:a |the )?state|international treaty',
    r'اقرار قانون|يقر قانونا|تمرير قانون|تعديل الدستور|اصلاح دستوري|سياسة الهجرة|قواعد اللجوء|'
    r'سياسة الحدود|الانفاق العام|اصلاح التقاعد|معاشات التقاعد|صلاحيات الطوار[ئي]|العلاقات الدبلوماسية|معاهدة دولية')
_HUMANITARIAN = _pattern(
    r'famine|humanitarian (?:aid|crisis|access)|forced displacement|refugees?|food insecurity|aid deliveries|aid convoy',
    r'مجاعة|المجاعة|مساعدات انسانية|المساعدات الانسانية|ازمة انسانية|الازمة الانسانية|النزوح القسري|'
    r'نازحين|النازحين|لاجئين|اللاجئين|انعدام الامن الغذائي|قافلة مساعدات')
_HUMANITARIAN_SCALE = _pattern(
    r'united nations|un agency|aid agency|thousands|millions|border|blockade|conflict|war zone',
    r'الامم المتحدة|وكالة اممية|منظمة اغاثة|الاف|ملايين|الحدود|حصار|الحصار|منطقة نزاع')
_DISASTER_IMPACT = _pattern(
    r'evacuat\w*|death toll|casualties|killed|destroyed homes|state of emergency|national emergency|'
    r'power outages?|transport disruption|travel disrupt\w*|weather warnings|thousands|millions',
    r'اجلاء|الاجلاء|ضحايا|الضحايا|قتلي|مقتل|تدمير منازل|حالة الطوار[ئي]|طوار[ئي] وطنية|انقطاع الكهرباء|الاف|ملايين')
_PUBLIC_HEALTH_ACTOR = _pattern(
    r'world health organi[sz]ation|health ministry|who',
    r'منظمة الصحة العالمية|وزارة الصحة')
_HEALTH_EMERGENCY = _pattern(
    r'global outbreak|international (?:health )?emergency|declares? (?:a |an )?epidemic|declares? (?:a |an )?pandemic',
    r'تفش عالمي|طوار[ئي] صحية دولية|حالة طوار[ئي] دولية|تعلن وباء|تعلن جائحة')
_SCIENCE_ACTOR = _pattern(
    r'nasa|esa|space agency|international atomic energy agency|iaea|climate agency|scientists',
    r'ناسا|وكالة الفضاء|الوكالة الدولية للطاقة الذرية|وكالة المناخ|علماء')
_SCIENCE_PUBLIC_EVENT = _pattern(
    r'nuclear safety|radiation leak|satellite launch|moon mission|space mission|global temperature|climate record',
    r'السلامة النووية|تسرب اشعاعي|اطلاق قمر صناعي|مهمة القمر|مهمة فضائية|حرارة العالم|حرارة عالمية|رقم قياسي مناخي')
_SILVER = _pattern(r'silver', r'الفضة|فضة|الفضه|فضه')
_SILVER_FINANCE = _pattern(
    r'prices?|demand|supply|bullion|futures|markets?|recover\w*|selloff|sell off|selling|buying|investors?|ubs',
    r'اسعار|سعر|الطلب|العرض|البيع|بيع|الشراء|شراء|السوق|الاسواق|المستثمرين|يتعافي|تتعافي|هبوط|ارتفاع')
_NONFINANCIAL_SILVER = _pattern(
    r'silver medals?|silver screen|silver anniversary|silver lining|silver fox',
    r'ميدالية فضية|الميدالية الفضية|ميداليات فضية|الشاشة الفضية|اليوبيل الفضي')
_INDUSTRIAL_METAL = _pattern(
    r'copper|alumini?um|nickel|zinc|iron ore|steel',
    r'النحاس|نحاس|الالمنيوم|النيكل|الزنك|خام الحديد|الصلب')
_MINING = _pattern(r'mines?|mining|smelters?', r'منجم|المنجم|مناجم|المناجم|التعدين|مصهر|المصاهر')
_MINING_SUPPLY_ACTION = _pattern(
    r'strikes?|walkout|labou?r dispute|shuts?|shutdown|halts? production|supply disruption',
    r'اضراب|الاضراب|اضرابات|الاضرابات|نزاع عمالي|اغلاق|الاغلاق|تعطل|توقف الانتاج|تعطل الامدادات')
_FINANCIAL_PUBLISHERS = frozenset({
    'reuters.com', 'bloomberg.com', 'ft.com', 'cnbc.com', 'kitco.com', 'fxstreet.com',
    'investing.com', 'businessinsider.com', 'asharqbusiness.com', 'cnnbusinessarabic.com',
    'cnbcarabia.com', 'aleqt.com',
})
_FINANCIAL_SOCIAL = {
    'did:plc:jbvnehrrdqoulco4rf5gxg5r': 'Reuters',
    'did:plc:uewxgchsjy4kmtu7dcxa77us': 'Bloomberg',
    'did:plc:m7ks2xhfuku7errrtfjux2lg': 'CNBC',
}
_INDUSTRIAL_INVESTMENT = _pattern(
    r'factory|assembly plant|manufacturing plant|industrial plant|auto plant',
    r'مصنع|المصنع|مصنع تجميع|منشاة صناعية|منشاة تصنيع')
_INVESTMENT_ACTION = _pattern(
    r'build|new|investment|invests?|expand\w*|production capacity',
    r'بناء|جديد|جديدة|استثمار|استثمارات|توسعة|توسع|طاقة انتاجية')
_REELECTION_CAMPAIGN = _pattern(r're election campaign|reelection campaign', r'حملة اعادة الانتخاب|حملة لاعادة انتخاب')
# These additional newsroom topics describe economic/public-policy context.
# They carry the low context score, never an asserted effect on the gold price.
_FISCAL_PLAN = _pattern(
    r'budget|public spending|government funding|state funding',
    r'الموازنة|موازنة|ميزانية الدولة|الميزانية العامة|الانفاق العام|التمويل الحكومي')
_PUBLIC_INVESTMENT = _pattern(
    r'social housing|affordable housing|public housing|public services',
    r'السكن الاجتماعي|الاسكان الاجتماعي|السكن الميسر|الاسكان الميسر|الخدمات العامة')
_COST_OF_LIVING = _pattern(
    r'cost of living|living costs?|purchasing power',
    r'تكلفة المعيشة|تكاليف المعيشة|غلاء المعيشة|القدرة الشرائية')
_HOUSEHOLD_PRESSURE = _pattern(
    r'rising|rise|higher|soar\w*|increas\w*|pressure|crisis|households?|families|wages?|public services|protests?|funding',
    r'ترتفع|ارتفاع|الارتفاع|ازمة|الاجور|اجور|الخدمات العامة|الاسر|الاحتجاجات|احتجاجات|مظاهرات|التمويل')
_NATIONAL_CAMPAIGN = _pattern(
    r'presidential campaign|parliamentary election campaign|national election campaign',
    r'حملة رئاسية|الحملة الرئاسية|حملته الرئاسية|حملتها الرئاسية|حملة الانتخابات الرئاسية|الحملة الانتخابية الرئاسية')
_CAMPAIGN_ACTION = _pattern(
    r'launch\w*|prepares?|candidates?|nomination|party congress',
    r'يطلق|تطلق|اطلاق|تدشين|يستعد|تستعد|مرشح|المرشح|مرشحة|المرشحة|ترشيح|مؤتمر الحزب')
_NON_PUBLIC_CONTEXT = _pattern(
    r'film|movie|television|tv show|entertainment|football|soccer|basketball|local club|wedding|family budget|household budget',
    r'فيلم|فيلما|الفيلم|افلام|الافلام|مسلسل|المسلسل|برنامج ترفيهي|كرة القدم|كرة السلة|ناد محلي|نادي محلي|حفل زفاف|ميزانية الاسرة')
_BUDGET_BILL = _pattern(r'budget bill', r'مشروع الموازنة|مشروع قانون الميزانية|مشروع الميزانية')
_DISASTER_RELIEF = _pattern(
    r'emergency aid|relief aid|disaster relief|earthquake relief|aid for (?:the )?victims',
    r'اغاثة المتضررين|لاغاثة المتضررين|مساعدات عاجلة|المساعدات العاجلة|مساعدات طارئة|المساعدات الطارئة')
_STOCK_SELLOFF = _pattern(r'stock sell ?offs?', r'موجة بيع في البورصة')
_EQUITY_MARKET_ACTOR = _pattern(
    r'kospi|nasdaq|s p 500|dow jones|stock markets?|equity markets?|investors?|goldman sachs|wall street',
    r'البورصة|مؤشر الاسهم|مؤشرات الاسهم|المستثمرين|المستثمرون|غولدمان ساكس|كوسبي|ناسداك')
_INVENTORY_CONTEXT = _pattern(
    r'warehouse|inventor(?:y|ies)|donated food|food stock|livestock',
    r'المخزون|مخزون|المستودع|مستودع|تبرعات الطعام|مخزون الطعام')


def _financial_source(row):
    try:
        host = (urlsplit(row['url']).hostname or '').lower()
        if (host == 'news.google.com' and row.get('sourceKind') == 'publisher-aggregator' and
                row.get('aggregator') == 'Google News'):
            host = str(row.get('publisherDomain', '')).lower()
        if host == 'bsky.app' and row.get('social') is True and row.get('platform') == 'Bluesky':
            for did, source in _FINANCIAL_SOCIAL.items():
                if (row.get('source') == source and re.fullmatch(
                        re.escape('https://bsky.app/profile/' + did + '/post/') + r'[a-zA-Z0-9]{1,32}', row['url'])):
                    return True
        return any(host == domain or host.endswith('.' + domain) for domain in _FINANCIAL_PUBLISHERS)
    except (TypeError, ValueError, KeyError):
        return False


def _world_context(text):
    if _ORDINARY_EVENT.search(text) or _CONTEXT_PROMO.search(text):
        return None
    regional = _CONFLICT_REGION.search(text) or (_RUSSIA.search(text) and _UKRAINE.search(text))
    if ((regional and _MILITARY_POLICY_ACTOR.search(text) and _MILITARY_POLICY_ACTION.search(text)) or
            (_PUBLIC_PLACE.search(text) and _MASS_ATTACK.search(text)) or
            (_PROTEST.search(text) and _PROTEST_SECURITY.search(text)) or
            (_PROTEST.search(text) and _MASS_PROTEST.search(text) and _PROTEST_ESCALATION.search(text)) or
            (regional and (_DEFENCE_COMMUNICATIONS.search(text) or
                           (_SATELLITE_SYSTEM.search(text) and _SATELLITE_SERVICE.search(text))))):
        return 'world-security'
    if ((regional and _PRISONER_EXCHANGE.search(text)) or
            (_SETTLEMENT_POLICY.search(text) and _SETTLEMENT_ACTION.search(text))):
        return 'world-diplomacy'
    if not _NON_PUBLIC_CONTEXT.search(text):
        if ((_FISCAL_PLAN.search(text) and _PUBLIC_INVESTMENT.search(text)) or
                (_COST_OF_LIVING.search(text) and _HOUSEHOLD_PRESSURE.search(text))):
            return 'economy-context'
        if _NATIONAL_CAMPAIGN.search(text) and _CAMPAIGN_ACTION.search(text):
            return 'world-policy'
        if _BUDGET_BILL.search(text) and _INSTITUTIONAL_ACTOR.search(text):
            return 'world-policy'
        if _NATURAL_DISASTER.search(text) and _DISASTER_RELIEF.search(text):
            return 'world-emergency'
    if _INSTITUTIONAL_ACTOR.search(text) and _INSTITUTIONAL_POLICY.search(text):
        return 'world-policy'
    if _MARKET_CONTEXT.search(text):
        return 'market-context'
    if (not _NON_PUBLIC_CONTEXT.search(text) and
            (_NATIONAL_POLITICS.search(text) or (regional and _REELECTION_CAMPAIGN.search(text)) or
             (_PUBLIC_POLICY_ACTOR.search(text) and _PUBLIC_POLICY_ACTION.search(text)))):
        return 'world-policy'
    if _HUMANITARIAN.search(text) and (_HUMANITARIAN_SCALE.search(text) or regional):
        return 'humanitarian'
    if _NATURAL_DISASTER.search(text) and _DISASTER_IMPACT.search(text):
        return 'world-emergency'
    if _PUBLIC_HEALTH_ACTOR.search(text) and _HEALTH_EMERGENCY.search(text):
        return 'world-emergency'
    if _SCIENCE_ACTOR.search(text) and _SCIENCE_PUBLIC_EVENT.search(text):
        return 'science-and-environment'
    return None


def relevance(title: str, *, financial_context: bool = False) -> tuple[int, tuple[str, ...]]:
    """Return a deterministic topic score and named matching rules."""
    text = normalized_title(title)
    # Promotion is not admitted merely because it contains a gold/rates word.
    if _CONTEXT_PROMO.search(text):
        return 0, ()
    reasons, score = [], 0
    for name, weight, pattern in _TOPICS:
        if pattern.search(text):
            if name == 'gold' and _NONFINANCIAL_GOLD.search(text) and not _EXPLICIT_FINANCIAL_GOLD.search(text):
                continue
            reasons.append(name)
            score += weight
    if ('precious-metals' not in reasons and _SILVER.search(text) and
            not _NONFINANCIAL_SILVER.search(text) and not _ORDINARY_EVENT.search(text) and
            (financial_context or _SILVER_FINANCE.search(text))):
        reasons.append('precious-metals')
        score += 65
    if (_INDUSTRIAL_METAL.search(text) and _MINING.search(text) and
            _MINING_SUPPLY_ACTION.search(text) and not _ORDINARY_EVENT.search(text)):
        reasons.append('industrial-supply')
        score += 25
    if (financial_context and _INDUSTRIAL_INVESTMENT.search(text) and _INVESTMENT_ACTION.search(text) and
            not _ORDINARY_EVENT.search(text) and 'jobs-and-growth' not in reasons):
        reasons.append('jobs-and-growth')
        score += 30
    if ('financial-risk' not in reasons and _STOCK_SELLOFF.search(text) and
            (financial_context or _EQUITY_MARKET_ACTOR.search(text)) and
            not _INVENTORY_CONTEXT.search(text) and not _ORDINARY_EVENT.search(text)):
        reasons.append('financial-risk')
        score += 30
    military_event = bool(_MILITARY_EVENT.search(text))
    diplomacy = (_CONFLICT_DIPLOMACY.search(text) or
                 (_DIPLOMATIC_ACTION.search(text) and _RUSSIA.search(text) and _UKRAINE.search(text)))
    regional_conflict = (_CONFLICT_REGION.search(text) and
                         (_CONFLICT_ACTION.search(text) or diplomacy or
                          (_ARMED_ACTOR.search(text) and _HOSTILE_TARGETING.search(text)))
                         and not _ORDINARY_EVENT.search(text))
    nuclear_exercise = _NUCLEAR_EXERCISE.search(text) and not _NUCLEAR_MEDICAL.search(text)
    if 'geopolitics' not in reasons and (military_event or regional_conflict or nuclear_exercise):
        reasons.append('geopolitics')
        score += 25
    if (_NATURAL_DISASTER.search(text) and _SUPPLY_ASSET.search(text) and
            _SUPPLY_DISRUPTION.search(text)):
        reasons.append('natural-supply-shock')
        score += 25
    if score < MIN_RELEVANCE:
        context = _world_context(text)
        if context:
            reasons.append(context)
            score = MIN_RELEVANCE
    return min(score, 250), tuple(reasons)


def _row_relevance(row):
    """Use only the title and bounded teaser actually collected with this row.

    Many publisher titles leave a material fact in their retrieved teaser. It
    is eligible context at the same receipt clock, not a fabricated full story.
    A promotional footer in a teaser cannot erase a valid nonpromotional title.
    """
    financial = _financial_source(row)
    baseline = relevance(row['title'], financial_context=financial)
    if _CONTEXT_PROMO.search(normalized_title(row['title'])):
        return baseline
    summary = row.get('summary')
    if not isinstance(summary, str) or not 1 <= len(summary) <= 400:
        return baseline
    try:
        summary = _clean_news_text(summary)
    except (TypeError, ValueError):
        return baseline
    if not summary:
        return baseline
    context = relevance(row['title'] + '. ' + summary, financial_context=financial)
    return context if context[0] > baseline[0] else baseline


def _valid(row, language, now_s):
    if not isinstance(row, dict) or row.get('language') != language:
        return False
    if not re.fullmatch(r'[a-f0-9]{32}', row.get('id', '') if isinstance(row.get('id'), str) else ''):
        return False
    for field, maximum in (('title', 400), ('source', 160), ('url', 2048)):
        value = row.get(field)
        if (not isinstance(value, str) or not value.strip() or len(value) > maximum or
                re.search(r'[\x00-\x1f\x7f]', value)):
            return False
    if any(type(row.get(key)) is not int for key in ('publishedAt', 'firstSeenAt')):
        return False
    if not 0 < row['publishedAt'] <= row['firstSeenAt'] <= now_s:
        return False
    try:
        url = urlsplit(row['url'])
        if (url.scheme != 'https' or not url.hostname or url.username or url.password or url.port or
                '\\' in row['url'] or any(ord(c) < 33 for c in row['url'])):
            return False
    except (TypeError, ValueError):
        return False
    return bool(normalized_title(row['title']))


@dataclass(frozen=True)
class NewsSelection:
    selected: tuple[dict, ...]
    scannedFresh: int
    relevant: int
    rejected: int
    invalid: int
    stale: int
    duplicates: int
    scores: dict[str, int]
    reasons: dict[str, tuple[str, ...]]
    truncated: bool = False
    windowSeconds: int = WINDOW_S
    minimumAgeSeconds: int = 0
    targetPercent: int = TARGET_PERCENT

    def summary(self) -> dict:
        """Bounded aggregate diagnostics safe for a public station manifest."""
        return {'method': f'deterministic-gold-macro-top-{self.targetPercent}-v9', 'windowSeconds': self.windowSeconds,
                'minimumAgeSeconds': self.minimumAgeSeconds,
                'targetPercent': self.targetPercent, 'scannedFresh': self.scannedFresh, 'relevant': self.relevant,
                'selected': len(self.selected), 'rejected': self.rejected,
                'invalid': self.invalid, 'stale': self.stale, 'duplicates': self.duplicates,
                'truncated': self.truncated}


def select_news(rows, language: str, now_s: int, *, window_s: int = WINDOW_S,
                minimum_age_s: int = 0, target_percent: int = TARGET_PERCENT) -> NewsSelection:
    """Select all relevant unique reports, or an explicitly reduced percentage.

    Rows are copied, source clocks and source text stay unchanged. Equal scores
    prefer newer publication, then newer receipt, then lexical ID. Duplicate
    titles/IDs retain their earliest original row so syndication cannot renew a
    clock. Deduplication includes valid rows outside the chosen cohort. The
    default remains the last ten minutes; a caller may separately select
    last-hour or last-two-hour context and label it earlier reporting.
    No row is quota padding.
    The result is independent of input order for the bounded input set.
    """
    if language not in ('ar', 'en') or type(now_s) is not int or now_s <= 0:
        raise ValueError('Unsupported selection language or clock')
    if type(target_percent) is not int or not 1 <= target_percent <= 100:
        raise ValueError('News selection percentage must be an integer from 1 to 100')
    if (type(window_s) is not int or window_s not in (WINDOW_S, 3600, 7200) or
            type(minimum_age_s) is not int or not 0 <= minimum_age_s < window_s):
        raise ValueError('Unsupported source-age cohort')
    if isinstance(rows, (str, bytes, dict)):
        raise ValueError('Expected headline rows')
    try:
        iterator = iter(rows)
    except TypeError as error:
        raise ValueError('Expected headline rows') from error
    valid, invalid, stale = [], 0, 0
    truncated = False
    for index, row in enumerate(iterator):
        if index >= MAX_INPUT_ROWS:
            truncated = True
            break
        # Other-language rows belong to the independent language selection and
        # are neither rejected nor counted as invalid in this one.
        if isinstance(row, dict) and row.get('language') in ('ar', 'en') and row['language'] != language:
            continue
        if not _valid(row, language, now_s):
            invalid += 1
            continue
        if now_s - row['publishedAt'] > window_s or now_s - row['firstSeenAt'] > window_s:
            stale += 1
        valid.append(dict(row))
    unique, seen_ids, seen_titles, duplicate_count = [], set(), set(), 0
    for row in sorted(valid, key=lambda r: (r['publishedAt'], r['firstSeenAt'], r['id'], r['title'])):
        key = normalized_title(row['title'])
        if row['id'] in seen_ids or key in seen_titles:
            duplicate_count += 1
            continue
        seen_ids.add(row['id'])
        seen_titles.add(key)
        # Deduplicate before testing either cohort boundary. A duplicate with a
        # newer publisher clock cannot move a retained old headline into it.
        if (not minimum_age_s <= now_s - row['publishedAt'] <= window_s or
                now_s - row['firstSeenAt'] > window_s):
            continue
        unique.append(row)
    ranked, scores, reasons = [], {}, {}
    for row in unique:
        score, matched = _row_relevance(row)
        scores[row['id']], reasons[row['id']] = score, matched
        if score >= MIN_RELEVANCE:
            ranked.append(row)
    ranked.sort(key=lambda row: (-scores[row['id']], -row['publishedAt'], -row['firstSeenAt'], row['id']))
    # Retain reproducible rounding for callers that explicitly choose a quota.
    count = (len(ranked) * target_percent + 99) // 100
    return NewsSelection(selected=tuple(ranked[:count]), scannedFresh=len(unique), relevant=len(ranked),
                         rejected=len(unique) - len(ranked), invalid=invalid, stale=stale,
                         duplicates=duplicate_count, scores=scores, reasons=reasons, truncated=truncated,
                         windowSeconds=window_s, minimumAgeSeconds=minimum_age_s, targetPercent=target_percent)

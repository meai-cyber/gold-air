"""Bounded, deterministic editorial selection of recent public-feed headlines.

This is a transparent topic filter, not an AI verdict or a price prediction.
Call it over *all* fresh stories, including already-spoken ones, before applying
playback receipts. Otherwise the omitted 30% would drift into the spoken quota.
The caller remains responsible for its fixed publisher/domain allowlist.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
import unicodedata
from urllib.parse import urlsplit


WINDOW_S = 600
MAX_INPUT_ROWS = 1000
TARGET_PERCENT = 70
MIN_RELEVANCE = 25


def normalized_title(value: str) -> str:
    """Normalize presentation differences, without rewriting source wording."""
    value = unicodedata.normalize('NFKC', value).casefold()
    value = re.sub(r'[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0640]', '', value)
    value = value.translate(str.maketrans('أإآٱى', 'ااااي'))
    return re.sub(r'[^\w]+', ' ', value).strip()


def _pattern(english: str, arabic: str):
    # Arabic headlines commonly attach و / ف to the first word of a topic.
    return re.compile(r'(?<!\w)(?:' + english + '|[وف]?(?:' + arabic + r'))(?!\w)')


# Each topic contributes once. Scores rank editorial relevance; they are not
# probabilities, confidence, importance outside this service, or causal claims.
_TOPICS = (
    ('gold', 100, _pattern(
        r'gold(?:\s+(?:price|prices|bullion|futures|market|markets|demand|reserve|reserves))?|bullion|xau(?:usd)?',
        r'الذهب|للذهب|بالذهب|اسعار الذهب|سعر الذهب|اونصة الذهب|احتياطيات الذهب|'
        r'(?:اسعار|سعر|سوق|اونصة|اوقية|عقود|شراء|بيع|تداول|احتياطي) ذهب|'
        r'ذهب (?:عيار|يرتفع|ينخفض|يصعد|يتراجع|يقفز|يهبط)')),
    ('precious-metals', 65, _pattern(
        r'precious metals?|silver prices?|platinum prices?',
        r'المعادن الثمينة|اسعار الفضة|سعر الفضة|البلاتين')),
    ('central-banks', 60, _pattern(
        r'federal reserve|fed(?!\s+up\b)|fomc|ecb|bank of england|bank of japan|central banks?|monetary policy',
        r'الاحتياطي الفدرالي|الاحتياطي الفيدرالي|الفيدرالي|البنك المركزي|البنوك المركزية|السياسة النقدية')),
    ('rates-and-bonds', 45, _pattern(
        r'interest rates?|rate cuts?|rate hikes?|treasury (?:yields?|bonds?|debt|auctions?|borrowing|secretary)|bond yields?|government bonds?|treasuries',
        r'اسعار الفائدة|سعر الفائدة|خفض الفائدة|رفع الفائدة|عوائد السندات|سندات الخزانة|الفائدة')),
    ('inflation', 45, _pattern(
        r'inflation|deflation|consumer prices?|producer prices?|cpi|ppi|pce',
        r'التضخم|تضخم|انكماش الاسعار|اسعار المستهلك|اسعار المنتجين')),
    ('currencies', 40, _pattern(
        r'us dollar|u s dollar|dollar index|dollar (?:falls?|rises?|slides?|slips?|gains?|drops?|climbs?|jumps?|rallies|surges?|weakens?|strengthens?|steadies|holds|edges?)|'
        r'dxy|euro|yen|sterling|exchange rates?|currency markets?',
        r'الدولار|للدولار|اليورو|الين|الجنيه الاسترليني|اسعار الصرف|سوق العملات')),
    ('energy', 40, _pattern(
        r'oil|crude|brent|wti|opec|natural gas|energy prices?',
        r'النفط|للنفط|الخام|برنت|اوبك|الغاز الطبيعي|اسعار الطاقة')),
    ('trade-and-supply', 35, _pattern(
        r'tariffs?|trade wars?|trade deals?|sanctions?|supply chains?|shipping routes?|strait of hormuz|red sea',
        r'رسوم جمركية|الرسوم الجمركية|حرب تجارية|الحرب التجارية|العقوبات|عقوبات|سلاسل الامداد|مضيق هرمز|البحر الاحمر')),
    ('jobs-and-growth', 30, _pattern(
        r'nonfarm|payrolls?|unemployment|jobless claims?|gdp|recession|economic growth|economy|economies|manufacturing|retail sales|pmi',
        r'البطالة|بطالة|الوظائف|الناتج المحلي|الركود|ركود|النمو الاقتصادي|الاقتصاد|الاقتصادي|الاقتصادية|التصنيع|مبيعات التجزية|مبيعات التجزئة')),
    ('financial-risk', 30, _pattern(
        r'financial crisis|banking crisis|sovereign debt|debt default|stock markets?|stock market crash|'
        r'(?:stocks|(?:global|world|asian|european|us|u s) shares) (?:are )?(?:fall|rise|slide|slip|gain|drop|climb|jump|rally|surge|plunge|tumble|sink|rebound|advance|retreat|mixed|flat|steady|wobble)|'
        r'safe havens?',
        r'ازمة مالية|الازمة المالية|ازمة مصرفية|الديون السيادية|التخلف عن السداد|اسواق الاسهم|'
        r'الاسواق (?:المالية|العالمية|الاوروبية|الامريكية|الاسيوية|ترتفع|تنخفض|تتراجع|تصعد|تهبط|تنتعش)|'
        r'الملاذ الامن|الملاذات الامنة')),
    ('geopolitics', 25, _pattern(
        r'war|ceasefire|geopolitical|missile strikes?|military strikes?|nuclear talks?|peace talks?|invasion',
        r'الحرب|حرب|وقف اطلاق النار|هدنة|جيوسياسية|جيوسياسي|ضربة عسكرية|ضربات عسكرية|ضربات صاروخية|مفاوضات نووية|غزو')),
)

_NONFINANCIAL_GOLD = re.compile(
    r'(?<!\w)(?:gold medals?|golden globes?|golden retrievers?|goldfish|golden goals?|'
    r'ميدالية ذهبية|الميدالية الذهبية|الميداليات الذهبية|الكرة الذهبية|جائزة الكرة الذهبية)(?!\w)')
_EXPLICIT_FINANCIAL_GOLD = _pattern(
    r'gold\s+(?:price|prices|bullion|futures|market|markets|demand|reserve|reserves)|bullion|xau(?:usd)?',
    r'اسعار الذهب|سعر الذهب|سوق الذهب|اونصة الذهب|احتياطيات الذهب')

# A country name alone is insufficient. Broader words such as "shooting" and
# Arabic مسيرات (which can also mean marches) require a conflict-region term.
_MILITARY_EVENT = _pattern(
    r'missiles?|airstrikes?|armed attacks?|armed forces|military drones?|combat drones?|drone strikes?|bombardment|shelling|artillery|warplanes?',
    r'صاروخ|الصاروخ|صواريخ|الصواريخ|هجوم مسلح|الهجوم المسلح|هجمات مسلحة|الهجمات المسلحة|القوات المسلحة|'
    r'قصف|القصف|المدفعية|طائرات حربية|المسيرات العسكرية|مسيرات عسكرية')
_CONFLICT_REGION = _pattern(
    r'ukraine|ukrainian|russia|russian|israel|israeli|palestine|palestinians?|iran|iranian|gaza|west bank|hebron|lebanon|lebanese|iraq|iraqi|yemen|yemeni',
    r'اوكرانيا|الاوكراني|الاوكرانية|اوكرانية|روسيا|الروسي|الروسية|روسية|اسرائيل|الاسرائيلي|الاسرائيلية|'
    r'فلسطين|فلسطيني|فلسطينيان|الفلسطينيين|فلسطينيين|الفلسطينية|ايران|الايراني|الايرانية|ايرانية|غزة|'
    r'الضفة الغربية|الخليل|لبنان|اللبنانية|العراق|العراقية|اليمن|اليمنية')
_CONFLICT_ACTION = _pattern(
    r'shootings?|shot|attacks?|attacked|drones?|clashes|troops?|military|killed|wounded|hostages?|strikes?',
    r'مسيرات|المسيرات|مسيرة|المسيرة|اطلاق النار|الرصاص|هجوم|الهجوم|هجمات|الهجمات|اشتباكات|الاشتباكات|'
    r'عسكري|عسكرية|العسكري|العسكرية|المسلحة|جنود|الجنود|مقتل|قتل|قتلي|جرحي|رهائن|الرهائن')
_ORDINARY_EVENT = _pattern(
    r'shark attacks?|dog attacks?|animal attacks?|heart attacks?|panic attacks?|knife attacks?|robbery|burglary|domestic dispute|'
    r'football|soccer|basketball|shooting team|shooting competition|peaceful marches',
    r'هجوم قرش|هجوم كلب|نوبة قلبية|ازمة قلبية|سرقة|السرقة|مشاجرة عائلية|كرة القدم|كرة السلة|فريق الرماية|مسيرات سلمية')

_NATURAL_DISASTER = _pattern(
    r'earthquakes?|hurricanes?|cyclones?|typhoons?|tsunamis?|wildfires?|floods?|volcanic eruption',
    r'زلزال|الزلزال|زلازل|الزلازل|اعصار|الاعصار|اعاصير|الاعاصير|فيضانات|الفيضانات|حرائق الغابات|تسونامي|ثوران بركاني')
_SUPPLY_ASSET = _pattern(
    r'gold|oil|crude|gas|energy|refiner(?:y|ies)|pipelines?|lng terminals?|shipping|ports?|supply chains?|global supplies',
    r'الذهب|النفط|الخام|الغاز|الطاقة|المصافي|مصفاة|خطوط الانابيب|الموانئ|ميناء|سلاسل الامداد|الامدادات العالمية')
_SUPPLY_DISRUPTION = _pattern(
    r'disrupts?|disrupted|disruption|closes?|closed|closures?|shuts?|shutdowns?|damages?|damaged|cuts?|halts?|stops?|threatens?|blocks?|blocked',
    r'تعطل|يعطل|تعطيل|توقف|يوقف|تغلق|يغلق|اغلاق|تقطع|قطع|تدمر|تدمير|يهدد|تهدد|تضرر|اضرار')


def relevance(title: str) -> tuple[int, tuple[str, ...]]:
    """Return a deterministic topic score and named matching rules."""
    text = normalized_title(title)
    reasons, score = [], 0
    for name, weight, pattern in _TOPICS:
        if pattern.search(text):
            if name == 'gold' and _NONFINANCIAL_GOLD.search(text) and not _EXPLICIT_FINANCIAL_GOLD.search(text):
                continue
            reasons.append(name)
            score += weight
    military_event = bool(_MILITARY_EVENT.search(text))
    regional_conflict = (_CONFLICT_REGION.search(text) and _CONFLICT_ACTION.search(text)
                         and not _ORDINARY_EVENT.search(text))
    if 'geopolitics' not in reasons and (military_event or regional_conflict):
        reasons.append('geopolitics')
        score += 25
    if (_NATURAL_DISASTER.search(text) and _SUPPLY_ASSET.search(text) and
            _SUPPLY_DISRUPTION.search(text)):
        reasons.append('natural-supply-shock')
        score += 25
    return min(score, 250), tuple(reasons)


def _valid(row, language, now_s):
    if not isinstance(row, dict) or row.get('language') != language:
        return False
    if not re.fullmatch(r'[a-f0-9]{32}', row.get('id', '') if isinstance(row.get('id'), str) else ''):
        return False
    for field, maximum in (('title', 400), ('source', 160), ('url', 2048)):
        value = row.get(field)
        if (not isinstance(value, str) or not value.strip() or len(value) > maximum or
                re.search(r'[\x00-\x1f\x7f]', value)):
            return False
    if any(type(row.get(key)) is not int for key in ('publishedAt', 'firstSeenAt')):
        return False
    if not 0 < row['publishedAt'] <= row['firstSeenAt'] <= now_s:
        return False
    try:
        url = urlsplit(row['url'])
        if (url.scheme != 'https' or not url.hostname or url.username or url.password or url.port or
                '\\' in row['url'] or any(ord(c) < 33 for c in row['url'])):
            return False
    except (TypeError, ValueError):
        return False
    return bool(normalized_title(row['title']))


@dataclass(frozen=True)
class NewsSelection:
    selected: tuple[dict, ...]
    scannedFresh: int
    relevant: int
    rejected: int
    invalid: int
    stale: int
    duplicates: int
    scores: dict[str, int]
    reasons: dict[str, tuple[str, ...]]
    truncated: bool = False

    def summary(self) -> dict:
        """Bounded aggregate diagnostics safe for a public station manifest."""
        return {'method': 'deterministic-gold-macro-top-70-v2', 'windowSeconds': WINDOW_S,
                'targetPercent': TARGET_PERCENT, 'scannedFresh': self.scannedFresh, 'relevant': self.relevant,
                'selected': len(self.selected), 'rejected': self.rejected,
                'invalid': self.invalid, 'stale': self.stale, 'duplicates': self.duplicates,
                'truncated': self.truncated}


def select_news(rows, language: str, now_s: int) -> NewsSelection:
    """Select ceil(70% of relevant unique fresh headlines), never quota padding.

    Rows are copied, source clocks and source text stay unchanged. Equal scores
    prefer newer publication, then newer receipt, then lexical ID. Duplicate
    titles/IDs retain their earliest original row so syndication cannot renew a
    clock. The result is independent of input order for the bounded input set.
    """
    if language not in ('ar', 'en') or type(now_s) is not int or now_s <= 0:
        raise ValueError('Unsupported selection language or clock')
    if isinstance(rows, (str, bytes, dict)):
        raise ValueError('Expected headline rows')
    try:
        iterator = iter(rows)
    except TypeError as error:
        raise ValueError('Expected headline rows') from error
    valid, invalid, stale = [], 0, 0
    truncated = False
    for index, row in enumerate(iterator):
        if index >= MAX_INPUT_ROWS:
            truncated = True
            break
        # Other-language rows belong to the independent language selection and
        # are neither rejected nor counted as invalid in this one.
        if isinstance(row, dict) and row.get('language') in ('ar', 'en') and row['language'] != language:
            continue
        if not _valid(row, language, now_s):
            invalid += 1
            continue
        if now_s - row['publishedAt'] > WINDOW_S or now_s - row['firstSeenAt'] > WINDOW_S:
            stale += 1
        valid.append(dict(row))
    unique, seen_ids, seen_titles, duplicate_count = [], set(), set(), 0
    for row in sorted(valid, key=lambda r: (r['publishedAt'], r['firstSeenAt'], r['id'], r['title'])):
        key = normalized_title(row['title'])
        if row['id'] in seen_ids or key in seen_titles:
            duplicate_count += 1
            continue
        seen_ids.add(row['id'])
        seen_titles.add(key)
        # Deduplicate before testing freshness. A duplicate reported with a
        # later publisher clock cannot make a retained old headline new again.
        if now_s - row['publishedAt'] > WINDOW_S or now_s - row['firstSeenAt'] > WINDOW_S:
            continue
        unique.append(row)
    ranked, scores, reasons = [], {}, {}
    for row in unique:
        score, matched = relevance(row['title'])
        scores[row['id']], reasons[row['id']] = score, matched
        if score >= MIN_RELEVANCE:
            ranked.append(row)
    ranked.sort(key=lambda row: (-scores[row['id']], -row['publishedAt'], -row['firstSeenAt'], row['id']))
    # Integer arithmetic makes 70% rounding reproducible, including 1/2/3 rows.
    count = (len(ranked) * TARGET_PERCENT + 99) // 100
    return NewsSelection(tuple(ranked[:count]), len(unique), len(ranked), len(unique) - len(ranked),
                         invalid, stale, duplicate_count, scores, reasons, truncated)

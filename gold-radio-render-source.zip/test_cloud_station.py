"""Cloud-writer integration contracts; public model downloads are not used."""
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import io
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import wave

import server
from market_brief import parse_quote
from station_cast import cast_metadata


NOW = 1792893000


def generated_job(language='ar', role='analyst'):
    return {'id':'e'*32, 'kind':'cloud-discussion','language':language,
        'title':'Generated discussion','source':'Gold Pulse cloud LLM',
        'url':'https://gold-air.onrender.com/','publishedAt':NOW-3,'firstSeenAt':NOW-3,
        'speechText':'قد تؤثر السيولة في طريقة تحرك السوق، ويمكن أن تختلف الاستجابة حسب الظروف.',
        'speaker':'Omar' if role=='analyst' else 'Maia','sources':[],
        'programme':{'mode':'cloud-llm','speakerRole':role,'forecast':False,'educational':True,
            'contextCapturedAt':(NOW-3)*1000,'generatedAt':(NOW-2)*1000,
            'expiresAt':(NOW+298)*1000,'modelId':'gold-radio-lfm25-350m'},
        'generationSeconds':2.0}


class CloudStationTests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory()
        with patch.dict(os.environ,{'RADIO_CLOUD_LLM':'0'}),patch('server.time.time',return_value=NOW-600):
            self.station=server.Station(self.folder.name)
        self.station.programmes=None

    def tearDown(self):
        self.station.stop.set();self.folder.cleanup()

    def pair(self, language, *, queued_analyst=False):
        episode = ('a' if language == 'ar' else 'b') * 32
        jobs = []
        for index, role in enumerate(('host', 'analyst')):
            job = generated_job(language, role)
            job['id'] = episode[:30] + str(index) + ('a' if language == 'ar' else 'b')
            job['programme'].update(episodeId=episode, turnIndex=index, turnCount=2)
            jobs.append(job)
        host = {**deepcopy(jobs[0]), 'publishedAt': jobs[0]['publishedAt'] * 1000,
            'firstSeenAt': jobs[0]['firstSeenAt'] * 1000,
            'startsAt': (NOW-1)*1000, 'endsAt': (NOW+20)*1000}
        self.station.queues[language].append(host)
        self.station.airtime[language].commit(host['startsAt'], host['endsAt'], 'podcast')
        if queued_analyst:
            analyst = {**deepcopy(jobs[1]), 'publishedAt': jobs[1]['publishedAt'] * 1000,
                'firstSeenAt': jobs[1]['firstSeenAt'] * 1000,
                'startsAt': host['endsAt'], 'endsAt': (NOW+30)*1000}
            self.station.queues[language].append(analyst)
            self.station.airtime[language].commit(analyst['startsAt'], analyst['endsAt'], 'podcast')
        return jobs

    def pending_writer(self, jobs):
        pending = {job['language']: deepcopy(job) for job in jobs}
        def candidate(language, now_s, exclude_ids=()):
            job = pending.get(language)
            return deepcopy(job) if job and job['id'] not in exclude_ids else None
        def consume(job, now_s):
            self.assertEqual(job, pending[job['language']])
            pending.pop(job['language'])
            return True
        self.station.cloud_writer = SimpleNamespace(candidate=candidate, consume=consume)
        return pending

    def news(self, language):
        row = {'id': ('c' if language == 'ar' else 'd')*32, 'language': language,
            'title': 'Gold market demand rises' if language == 'en' else 'الذهب يرتفع مع الطلب',
            'source': 'BBC', 'url': 'https://www.bbc.com/news/fresh-gold-report',
            'publishedAt': NOW-20, 'firstSeenAt': NOW-10}
        self.station.ingest([row], NOW)
        return row

    def observe(self, price, offset=0):
        stamp = NOW + offset
        self.station.market.observe(parse_quote({'symbol': 'XAU', 'price': Decimal(price),
            'updatedAt': datetime.fromtimestamp(stamp, timezone.utc).isoformat()}, stamp))

    def test_started_pair_answer_precedes_new_headlines_and_periodic_desks_on_both_channels(self):
        station = self.station
        answers = [self.pair(language)[1] for language in ('ar', 'en')]
        self.pending_writer(answers)
        self.observe('4020', -1)
        for language in ('ar', 'en'):
            self.news(language)
            self.assertEqual(station.news_streak[language], 0,
                'host publication resets the burst; that must not reopen news ahead of its answer')
            # A periodic quote/analysis is due, but only a genuine changed-price
            # call may split the already started conversation.
            offered = station._next_job(language, NOW*1000, {})
            self.assertEqual(offered['programme']['speakerRole'], 'analyst')
            self.assertTrue(offered['_cloudContinuation'])
        self.observe('4021')
        for language in ('ar', 'en'):
            urgent = station._next_job(language, NOW*1000, {})
            self.assertEqual((urgent['kind'], urgent['announcementReason']), ('market', 'changed'))

    def test_answer_priority_requires_its_own_channel_host_and_preserves_retry_expiry_and_source_guards(self):
        station = self.station
        answer = self.pair('ar')[1]
        orphan = generated_job('en')
        orphan['programme'].update(episodeId='b'*32, turnIndex=1, turnCount=2)
        pending = self.pending_writer([answer, orphan])
        for language in ('ar', 'en'):
            self.news(language)
        self.assertEqual(station._next_job('en', NOW*1000, {})['kind'], 'news')
        self.assertEqual(station._next_job('ar', NOW*1000, {})['kind'], 'cloud-discussion')
        self.assertEqual(station._next_job('ar', NOW*1000, {answer['id']:(NOW+30)*1000})['kind'], 'news')
        pending['ar']['programme']['expiresAt'] = (NOW+5)*1000
        self.assertEqual(station._next_job('ar', NOW*1000, {})['kind'], 'news')
        pending['ar'] = deepcopy(answer)
        pending['ar']['sources'] = [{'id':'f'*32, 'url':'https://www.aljazeera.com/news/excluded',
            'publishedAt':(NOW-20)*1000, 'firstSeenAt':(NOW-10)*1000}]
        self.assertEqual(station._next_job('ar', NOW*1000, {})['kind'], 'news')

    def test_producer_finishes_answer_without_music_quota_or_new_report_interleaving(self):
        station = self.station
        answer = self.pair('en')[1]
        self.pending_writer([answer])
        report = self.news('en')
        output = io.BytesIO()
        with wave.open(output, 'wb') as audio:
            audio.setnchannels(1);audio.setsampwidth(2);audio.setframerate(24000)
            audio.writeframes(b'\x01\x00'*24000)
        class Voice:
            def synthesize(self, text, language, voice_profile=None):
                station.stop.set()
                return SimpleNamespace(wav=output.getvalue(), duration_s=1.0,
                    language=language, engine='test-pair', cast=cast_metadata(language, voice_profile))
        with patch('server.time.time', return_value=NOW), \
                patch.object(station.airtime['en'], 'can_schedule_podcast', return_value=False), \
                patch.object(station, '_scheduled_start', side_effect=AssertionError('Music gap inserted inside pair')):
            station._produce(Voice(), ('en',))
        host, analyst = station.queues['en']
        self.assertEqual(analyst['programme']['speakerRole'], 'analyst')
        self.assertEqual(analyst['startsAt'], host['endsAt'])
        self.assertNotIn(report['id'], station.seen['en'])
        station.stop.clear()
        self.assertEqual(station._next_job('en', NOW*1000, {})['id'], report['id'],
            'ordinary news resumes once the complete pair has been published')

    def test_prepared_pair_protects_answer_from_routine_desks_but_allows_changed_price(self):
        station = self.station
        for language in ('ar', 'en'):
            self.pair(language, queued_analyst=True)
            self.assertEqual(station._priority_start(language, NOW*1000, 'market', 3), (NOW+30)*1000)
            self.assertEqual(station._priority_start(language, NOW*1000, 'analysis', 3), (NOW+30)*1000)
            self.assertEqual(station._priority_start(language, NOW*1000, 'market', 3, urgent=True), (NOW+20)*1000)

    def test_cloud_mode_constructs_no_recorded_archive_and_no_model_process(self):
        with patch.dict(os.environ,{'RADIO_CLOUD_LLM':'1'}),patch('server.time.time',return_value=NOW):
            station=server.Station(Path(self.folder.name)/'enabled')
        try:
            self.assertIsNone(station.programmes)
            self.assertIsNotNone(station.cloud_writer)
            self.assertFalse(station.cloud_llm.status()['resident'])
            self.assertTrue(station.manifest('ar',NOW*1000)['programmeMix']['cloudLlmPodcasts'])
            self.assertFalse(station.manifest('ar',NOW*1000)['programmeMix']['recordedEducationalPodcasts'])
        finally:
            station.cloud_llm.close()

    def test_background_inference_releases_station_lock_and_recaptures_each_language(self):
        station=self.station;calls=[];closed=[]
        station.languages=('ar','en')
        class Writer:
            def prepare(self,language,stories,market,outlook):
                self_test.assertFalse(station.lock._is_owned())
                calls.append((language,len(stories)))
                with station.lock:
                    station.stories['a']={'id':'a','title':'Latest public report'}
                if language=='en':station.stop.set()
        self_test=self
        station.cloud_writer=Writer();station.cloud_llm=SimpleNamespace(close=lambda:closed.append(True))
        station.collect_cloud_scripts()
        self.assertEqual(calls,[('ar',0),('en',1)])
        self.assertEqual(closed,[True])

    def test_remote_provider_is_selected_without_starting_native_model_or_archive(self):
        with patch.dict(os.environ,{'RADIO_CLOUD_LLM':'1','RADIO_CLOUD_PROVIDER':'cloudflare',
                'CF_API_TOKEN':'','CF_ACCOUNT_ID':'','RADIO_CF_FREE_PLAN_CONFIRMED':'0'}), \
                patch('cloud_llm_runtime.CloudLlmRuntime',side_effect=AssertionError('Native model selected')):
            station=server.Station(Path(self.folder.name)/'cloudflare')
        try:
            status=station.cloud_llm.status()
            self.assertEqual(status['modelId'],'@cf/qwen/qwen3-30b-a3b-fp8')
            self.assertFalse(status['available'])
            self.assertIsNone(station.programmes)
            self.assertEqual(station.cloud_writer.status('ar')['modelId'],status['modelId'])
            self.assertIn('no model-written podcasts are available yet', station.manifest('ar')['note'])
        finally:
            station.cloud_llm.close()

    def test_missing_owner_setup_does_not_retry_inference_or_block_news(self):
        station = self.station
        station.cloud_provider = 'cloudflare'
        station.cloud_llm = SimpleNamespace(status=lambda: {'available': False}, close=lambda: None)
        station.cloud_writer = SimpleNamespace(prepare=lambda *a: self.fail('Unconfigured inference attempted'))
        def finish(_seconds):
            station.stop.set()
        with patch.object(station.stop, 'wait', side_effect=finish):
            station.collect_cloud_scripts()
        station.stop.clear()
        row = {'id': 'a'*32, 'title': 'Gold market demand rises', 'source': 'BBC',
               'url': 'https://www.bbc.com/news/test', 'language': 'en',
               'publishedAt': NOW-20, 'firstSeenAt': NOW-10}
        station.ingest([row], NOW)
        self.assertEqual(station._candidate('en', NOW)['id'], row['id'])

    def test_cloud_turn_uses_actual_male_cast_and_consumes_only_after_publication(self):
        station=self.station;job=generated_job();consumed=[];calls=[]
        class Writer:
            def candidate(self,language,now_s,exclude_ids=()):return deepcopy(job)
            def consume(self,value,now_s):
                self_test.assertEqual(value,job)
                self_test.assertEqual(station.queues['ar'][-1]['kind'],'cloud-discussion')
                consumed.append(value['id']);return True
        data=io.BytesIO()
        with wave.open(data,'wb') as w:
            w.setnchannels(1);w.setsampwidth(2);w.setframerate(24000);w.writeframes(b'\x01\x00'*24000)
        class Tts:
            available_languages=('ar',);engines={'ar':'fake-cast-test'}
            def synthesize(self,text,language,voice_profile=None):
                calls.append(voice_profile);station.stop.set()
                return SimpleNamespace(wav=data.getvalue(),duration_s=1.0,engine='fake-cast-test',
                    language=language,cast=cast_metadata(language,voice_profile))
        self_test=self;station.cloud_writer=Writer();station.tts_factory=Tts
        with patch('server.time.time',return_value=NOW),patch.dict(os.environ,{'RADIO_STARTUP_SPEECH_CHECK':'0'}):
            station.generate()
        self.assertEqual(calls,['analyst']);self.assertEqual(consumed,[job['id']])
        queued=station.queues['ar'][0]
        self.assertEqual(queued['cast']['gender'],'Male')
        self.assertEqual(queued['audioSource'],'cloud-llm-script')
        self.assertNotIn('recordedAt',queued)
        self.assertEqual(station.podcast_cache,{})
        observed=station.airtime['ar'].snapshot(queued['endsAt'])
        self.assertEqual(observed['podcastSeconds'],1.0)
        self.assertEqual(observed['newsSeconds'],0.0)
        self.assertEqual(observed['otherSpeechSeconds'],0.0)

    def test_cloud_expiry_and_source_policy_are_rechecked_at_actual_speaking_start(self):
        job=generated_job()
        self.assertTrue(server.Station._job_fresh(job,(NOW+6)*1000))
        self.assertFalse(server.Station._job_fresh(job,(NOW+299)*1000))
        source={'id':'b'*32,'url':'https://www.bbc.com/arabic/test','language':'ar',
                'publishedAt':(NOW-20)*1000,'firstSeenAt':(NOW-10)*1000}
        job['sources']=[source];job['programme']['educational']=False
        self.assertTrue(server.Station._job_fresh(job,(NOW+6)*1000))
        job['sources']=[{**source,'url':'https://www.aljazeera.com/news/test'}]
        self.assertFalse(server.Station._job_fresh(job,(NOW+6)*1000))
        job['sources']=[{**source,'publishedAt':(NOW-7200)*1000}]
        self.assertFalse(server.Station._job_fresh(job,(NOW+6)*1000))

    def test_no_archive_is_selected_while_the_cloud_writer_is_not_ready(self):
        station=self.station
        station.cloud_writer=SimpleNamespace(candidate=lambda *args,**kwargs:None)
        self.assertIsNone(station._next_job('ar',NOW*1000,{}))

    def test_native_voice_releases_script_model_before_loading_its_weights(self):
        import tts
        value=object.__new__(tts.ServerTts);events=[]
        value.arabic=None;value.diacritizer=None;value.root=Path(self.folder.name);value.node='node'
        value.before_native=lambda:events.append('llm-released')
        def vowels(_root):
            self.assertEqual(events,['llm-released']);events.append('vowels-loaded');return object()
        def native(*args,**kwargs):
            self.assertEqual(events,['llm-released','vowels-loaded'])
            return SimpleNamespace(synthesize=lambda text:SimpleNamespace(wav=b'valid-test-pcm',duration_s=1,inference_s=.1))
        with patch('tts._vowels',side_effect=vowels),patch('tts.NabraNativeArabicTts',side_effect=native):
            value._arabic('خبر عربي')

    def test_recovered_network_voice_drops_native_arenas_so_script_model_can_resume(self):
        import tts
        value=object.__new__(tts.ServerTts);closed=[]
        value.cast_arabic_lock=threading.Lock();value.lock=threading.Lock()
        value.arabic_news_retry_at=0;value.arabic_news_failure='network-unavailable';value.engines={}
        value.arabic=SimpleNamespace(close=lambda:closed.append(True));value.diacritizer=object()
        async def edge(*args,**kwargs):return b'network-audio'
        value._edge_voice=edge;value._network_audio=lambda compressed:(b'valid-test-pcm',1)
        with patch('tts._release_model_memory') as release:
            value._arabic_news('خبر عربي',0)
        self.assertEqual(closed,[True]);self.assertIsNone(value.arabic);self.assertIsNone(value.diacritizer)
        release.assert_called_once()


if __name__=='__main__':unittest.main()

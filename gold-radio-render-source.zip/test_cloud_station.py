"""Cloud-writer integration contracts; public model downloads are not used."""
from copy import deepcopy
import io
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import wave

import server
from station_cast import cast_metadata


NOW = 1792893000


def generated_job(language='ar', role='analyst'):
    return {'id':'e'*32, 'kind':'cloud-discussion','language':language,
        'title':'Generated discussion','source':'Gold Pulse cloud LLM',
        'url':'https://gold-air.onrender.com/','publishedAt':NOW-3,'firstSeenAt':NOW-3,
        'speechText':'قد تؤثر السيولة في طريقة تحرك السوق، ويمكن أن تختلف الاستجابة حسب الظروف.',
        'speaker':'Omar' if role=='analyst' else 'Maia','sources':[],
        'programme':{'mode':'cloud-llm','speakerRole':role,'forecast':False,'educational':True,
            'contextCapturedAt':(NOW-3)*1000,'generatedAt':(NOW-2)*1000,
            'expiresAt':(NOW+298)*1000,'modelId':'gold-radio-lfm25-350m'},
        'generationSeconds':2.0}


class CloudStationTests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory()
        with patch.dict(os.environ,{'RADIO_CLOUD_LLM':'0'}),patch('server.time.time',return_value=NOW-600):
            self.station=server.Station(self.folder.name)
        self.station.programmes=None

    def tearDown(self):
        self.station.stop.set();self.folder.cleanup()

    def test_cloud_mode_constructs_no_recorded_archive_and_no_model_process(self):
        with patch.dict(os.environ,{'RADIO_CLOUD_LLM':'1'}),patch('server.time.time',return_value=NOW):
            station=server.Station(Path(self.folder.name)/'enabled')
        try:
            self.assertIsNone(station.programmes)
            self.assertIsNotNone(station.cloud_writer)
            self.assertFalse(station.cloud_llm.status()['resident'])
            self.assertTrue(station.manifest('ar',NOW*1000)['programmeMix']['cloudLlmPodcasts'])
            self.assertFalse(station.manifest('ar',NOW*1000)['programmeMix']['recordedEducationalPodcasts'])
        finally:
            station.cloud_llm.close()

    def test_background_inference_releases_station_lock_and_recaptures_each_language(self):
        station=self.station;calls=[];closed=[]
        station.languages=('ar','en')
        class Writer:
            def prepare(self,language,stories,market,outlook):
                self_test.assertFalse(station.lock._is_owned())
                calls.append((language,len(stories)))
                with station.lock:
                    station.stories['a']={'id':'a','title':'Latest public report'}
                if language=='en':station.stop.set()
        self_test=self
        station.cloud_writer=Writer();station.cloud_llm=SimpleNamespace(close=lambda:closed.append(True))
        station.collect_cloud_scripts()
        self.assertEqual(calls,[('ar',0),('en',1)])
        self.assertEqual(closed,[True])

    def test_cloud_turn_uses_actual_male_cast_and_consumes_only_after_publication(self):
        station=self.station;job=generated_job();consumed=[];calls=[]
        class Writer:
            def candidate(self,language,now_s,exclude_ids=()):return deepcopy(job)
            def consume(self,value,now_s):
                self_test.assertEqual(value,job)
                self_test.assertEqual(station.queues['ar'][-1]['kind'],'cloud-discussion')
                consumed.append(value['id']);return True
        data=io.BytesIO()
        with wave.open(data,'wb') as w:
            w.setnchannels(1);w.setsampwidth(2);w.setframerate(24000);w.writeframes(b'\x01\x00'*24000)
        class Tts:
            available_languages=('ar',);engines={'ar':'fake-cast-test'}
            def synthesize(self,text,language,voice_profile=None):
                calls.append(voice_profile);station.stop.set()
                return SimpleNamespace(wav=data.getvalue(),duration_s=1.0,engine='fake-cast-test',
                    language=language,cast=cast_metadata(language,voice_profile))
        self_test=self;station.cloud_writer=Writer();station.tts_factory=Tts
        with patch('server.time.time',return_value=NOW),patch.dict(os.environ,{'RADIO_STARTUP_SPEECH_CHECK':'0'}):
            station.generate()
        self.assertEqual(calls,['analyst']);self.assertEqual(consumed,[job['id']])
        queued=station.queues['ar'][0]
        self.assertEqual(queued['cast']['gender'],'Male')
        self.assertEqual(queued['audioSource'],'cloud-llm-script')
        self.assertNotIn('recordedAt',queued)
        self.assertEqual(station.podcast_cache,{})
        observed=station.airtime['ar'].snapshot(queued['endsAt'])
        self.assertEqual(observed['podcastSeconds'],1.0)
        self.assertEqual(observed['newsSeconds'],0.0)
        self.assertEqual(observed['otherSpeechSeconds'],0.0)

    def test_cloud_expiry_and_source_policy_are_rechecked_at_actual_speaking_start(self):
        job=generated_job()
        self.assertTrue(server.Station._job_fresh(job,(NOW+6)*1000))
        self.assertFalse(server.Station._job_fresh(job,(NOW+299)*1000))
        source={'id':'b'*32,'url':'https://www.bbc.com/arabic/test','language':'ar',
                'publishedAt':(NOW-20)*1000,'firstSeenAt':(NOW-10)*1000}
        job['sources']=[source];job['programme']['educational']=False
        self.assertTrue(server.Station._job_fresh(job,(NOW+6)*1000))
        job['sources']=[{**source,'url':'https://www.aljazeera.com/news/test'}]
        self.assertFalse(server.Station._job_fresh(job,(NOW+6)*1000))
        job['sources']=[{**source,'publishedAt':(NOW-7200)*1000}]
        self.assertFalse(server.Station._job_fresh(job,(NOW+6)*1000))

    def test_no_archive_is_selected_while_the_cloud_writer_is_not_ready(self):
        station=self.station
        station.cloud_writer=SimpleNamespace(candidate=lambda *args,**kwargs:None)
        self.assertIsNone(station._next_job('ar',NOW*1000,{}))

    def test_native_voice_releases_script_model_before_loading_its_weights(self):
        import tts
        value=object.__new__(tts.ServerTts);events=[]
        value.arabic=None;value.diacritizer=None;value.root=Path(self.folder.name);value.node='node'
        value.before_native=lambda:events.append('llm-released')
        def vowels(_root):
            self.assertEqual(events,['llm-released']);events.append('vowels-loaded');return object()
        def native(*args,**kwargs):
            self.assertEqual(events,['llm-released','vowels-loaded'])
            return SimpleNamespace(synthesize=lambda text:SimpleNamespace(wav=b'valid-test-pcm',duration_s=1,inference_s=.1))
        with patch('tts._vowels',side_effect=vowels),patch('tts.NabraNativeArabicTts',side_effect=native):
            value._arabic('خبر عربي')

    def test_recovered_network_voice_drops_native_arenas_so_script_model_can_resume(self):
        import tts
        value=object.__new__(tts.ServerTts);closed=[]
        value.cast_arabic_lock=threading.Lock();value.lock=threading.Lock()
        value.arabic_news_retry_at=0;value.arabic_news_failure='network-unavailable';value.engines={}
        value.arabic=SimpleNamespace(close=lambda:closed.append(True));value.diacritizer=object()
        async def edge(*args,**kwargs):return b'network-audio'
        value._edge_voice=edge;value._network_audio=lambda compressed:(b'valid-test-pcm',1)
        with patch('tts._release_model_memory') as release:
            value._arabic_news('خبر عربي',0)
        self.assertEqual(closed,[True]);self.assertIsNone(value.arabic);self.assertIsNone(value.diacritizer)
        release.assert_called_once()


if __name__=='__main__':unittest.main()

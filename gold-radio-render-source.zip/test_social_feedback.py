from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import unittest
from unittest.mock import patch

from social_sources import Response
from social_feedback import (COLLECTION_BUDGET_S, MAX_BYTES, MAX_AGE_S, PINNED,
                             SocialFeedbackCollector, fetch_public, parse_thread,
                             publisher_root, thread_url, _NoRedirect)


NOW = 1792878000
PUBLISHER = next(iter(PINNED.values()))
AUTHOR = 'did:plc:' + 'a' * 24


def iso(stamp):
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat()


def root_row(key='root123', source=PUBLISHER, age=100):
    url = 'https://bsky.app/profile/' + source.did + '/post/' + key
    return {'id': hashlib.sha256(('social:' + url).encode()).hexdigest()[:32],
            'url': url, 'source': source.source, 'title': 'Gold prices react to new inflation figures',
            'social': True, 'sourceKind': 'social', 'platform': 'Bluesky', 'language': 'en',
            'publishedAt': NOW - age, 'firstSeenAt': NOW - age + 1}


def reply(root, text='Gold and real yields deserve comparison before assigning a cause to this move.',
          key='reply123', age=20, **extra):
    record = {'$type': 'app.bsky.feed.post', 'createdAt': iso(NOW - age), 'text': text,
              'reply': {'root': {'uri': root['uri']}, 'parent': {'uri': root['uri']}}}
    post = {'uri': 'at://' + AUTHOR + '/app.bsky.feed.post/' + key,
            'author': {'did': AUTHOR, 'handle': 'listener.example'}, 'record': record,
            'indexedAt': iso(NOW - 1)}
    post.update(extra)
    return {'$type': 'app.bsky.feed.defs#threadViewPost', 'post': post}


def body(root, replies=None):
    source = root['source']
    return json.dumps({'thread': {'$type': 'app.bsky.feed.defs#threadViewPost',
        'post': {'uri': root['uri'], 'author': {'did': source.did, 'handle': source.actor},
                 'record': {'$type': 'app.bsky.feed.post', 'createdAt': iso(root['row']['publishedAt'])}},
        'replies': replies if replies is not None else [reply(root)]}}).encode()


class FeedbackParsingTests(unittest.TestCase):
    def setUp(self):
        self.row = root_row()
        self.root = publisher_root(self.row, NOW)

    def test_only_already_collected_exact_publisher_identities_form_roots(self):
        self.assertIsNotNone(self.root)
        for change in ({'sourceKind': 'social-feedback'}, {'source': 'Imposter'}, {'id': 'f' * 32},
                       {'url': self.row['url'] + '?url=http://127.0.0.1'},
                       {'url': 'https://bsky.app/profile/' + AUTHOR + '/post/root123'},
                       {'publishedAt': NOW - MAX_AGE_S - 1}, {'firstSeenAt': NOW + 1}):
            with self.subTest(change=change):
                self.assertIsNone(publisher_root({**self.row, **change}, NOW))
        with self.assertRaises(ValueError):
            thread_url('at://' + AUTHOR + '/app.bsky.feed.post/root123')
        url = thread_url(self.root['uri'])
        self.assertIn('depth=1', url)
        self.assertIn('parentHeight=0', url)

    def test_removed_regional_publisher_cannot_form_a_feedback_root(self):
        from social_sources import Source
        removed = Source('removed', 'Al Jazeera', 'Bluesky', 'aljazeera.com', 'en',
                         'did:plc:2lofqead276vtc5647ye7sl2')
        self.assertIsNone(publisher_root(root_row(source=removed), NOW))
        with self.assertRaises(ValueError):
            thread_url('at://' + removed.did + '/app.bsky.feed.post/root123')

    def test_reply_attribution_original_clock_and_nonrepresentative_label(self):
        row = parse_thread(body(self.root), self.root, NOW)[0]
        self.assertEqual(row['publishedAt'], NOW - 20)
        self.assertEqual(row['firstSeenAt'], NOW)
        self.assertEqual(row['sourceKind'], 'social-feedback')
        self.assertEqual(row['verification'], 'unverified-public-reply')
        self.assertEqual(row['clockBasis'], 'author-reported')
        self.assertIn('@listener.example', row['source'])
        self.assertIn(PUBLISHER.source, row['source'])
        self.assertEqual(row['feedback']['rootUrl'], self.row['url'])
        self.assertEqual(row['feedback']['rootPublishedAt'], self.row['publishedAt'])
        self.assertEqual(row['feedback']['authorDid'], AUTHOR)
        self.assertTrue(row['feedback']['unverified'])
        self.assertFalse(row['feedback']['representative'])
        self.assertRegex(row['id'], r'^[a-f0-9]{32}$')

    def test_arabic_response_is_retained_in_arabic_without_translation(self):
        text = 'مقارنة الذهب بالعوائد الحقيقية تحتاج إلى توقيت واضح قبل الجزم بسبب هذه الحركة في السوق.'
        row = parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW)[0]
        self.assertEqual(row['language'], 'ar')
        self.assertEqual(row['title'], text)
        self.assertTrue(row['source'].startswith('تعليق @listener.example'))

    def test_english_feedback_matches_latin_letter_speech_contract_without_rewriting(self):
        for text in ('Gold demand and real yields matter, but الذهب needs more context.',
                     'Gold demand and real yields matter, but золото needs more context.'):
            with self.subTest(text=text):
                self.assertEqual(parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW), [])
        text = 'Gold demand and real yields matter; café discussions need clearer evidence.'
        row = parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW)[0]
        self.assertEqual(row['language'], 'en')
        self.assertEqual(row['title'], text)

    def test_root_identity_blocked_nodes_labels_quotes_and_nested_replies_are_rejected(self):
        data = json.loads(body(self.root))
        data['thread']['post']['author']['did'] = AUTHOR
        with self.assertRaises(ValueError):
            parse_thread(json.dumps(data).encode(), self.root, NOW)
        for mutation in ('parent', 'root', 'labels', 'author-labels', 'embed', 'wrong-author', 'blocked'):
            node = reply(self.root)
            if mutation in ('parent', 'root'):
                node['post']['record']['reply'][mutation]['uri'] += 'other'
            elif mutation == 'labels':
                node['post']['labels'] = [{'val': 'spam'}]
            elif mutation == 'author-labels':
                node['post']['author']['labels'] = [{'val': 'spam'}]
            elif mutation == 'embed':
                node['post']['record']['embed'] = {'$type': 'app.bsky.embed.record'}
            elif mutation == 'wrong-author':
                node['post']['author']['did'] = PUBLISHER.did
            else:
                node = {'$type': 'app.bsky.feed.defs#blockedPost', 'blocked': True}
            with self.subTest(mutation=mutation):
                self.assertEqual(parse_thread(body(self.root, [node]), self.root, NOW), [])

    def test_short_irrelevant_ads_contacts_links_and_obvious_abuse_are_not_aired(self):
        texts = ('Absolutely agree!', 'This new film is really interesting and I enjoyed watching it.',
                 'Gold returns are guaranteed, join my signals channel for the best profits.',
                 'Gold demand matters, contact me at person@example.com to hear more.',
                 'Gold prices are discussed further at https://example.com/story for my customers.',
                 'Gold prices are discussed at example.com for more details and new clients.',
                 'Gold news is useful, call me at +1 202 555 0123 for the latest updates.',
                 'Gold will rise and everyone who disagrees is a fucking idiot.',
                 'أرباح مضمونة من الذهب اشترك الآن للحصول على جميع التوصيات المجانية.')
        for text in texts:
            with self.subTest(text=text):
                self.assertEqual(parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW), [])

    def test_old_future_pre_root_and_repeated_reply_nodes_cannot_create_freshness(self):
        for age in (MAX_AGE_S + 1, -1, 101):
            with self.subTest(age=age):
                self.assertEqual(parse_thread(body(self.root, [reply(self.root, age=age)]), self.root, NOW), [])
        node = reply(self.root)
        self.assertEqual(len(parse_thread(body(self.root, [node, node]), self.root, NOW)), 1)
        with self.assertRaises(ValueError):
            parse_thread(b'x' * (MAX_BYTES + 1), self.root, NOW)


class FeedbackCollectorTests(unittest.TestCase):
    def collector(self, fetcher):
        collector = SocialFeedbackCollector(fetcher)
        self.addCleanup(collector._pool.shutdown, wait=True, cancel_futures=True)
        return collector

    def test_two_requests_per_poll_no_login_and_receipts_preserve_first_seen(self):
        rows = [root_row('root' + str(index), age=100 + index) for index in range(3)]
        calls = []
        def fetch(url, headers, timeout):
            self.assertLessEqual(timeout, COLLECTION_BUDGET_S)
            self.assertNotIn('Authorization', headers)
            calls.append(url)
            root = next(publisher_root(row, NOW) for row in rows if thread_url(publisher_root(row, NOW)['uri']) == url)
            reply_key = root['uri'].rsplit('/', 1)[-1] + 'reply'
            return Response(200, {'content-type': 'application/json'}, body(root, [reply(root, key=reply_key)]), url)
        collector = self.collector(fetch)
        first = collector.collect(rows, NOW)
        self.assertEqual(len(calls), 2)
        self.assertEqual(len(first), 2)
        self.assertEqual(len({row['id'] for row in first}), 2)
        self.assertEqual(collector.collect(rows, NOW + 59), [])
        second = collector.collect(rows, NOW + 60)
        self.assertEqual(len(calls), 4)
        shared = {row['id']: row for row in second}
        for row in first:
            if row['id'] in shared:
                self.assertEqual(shared[row['id']]['firstSeenAt'], NOW)
                self.assertEqual(shared[row['id']]['publishedAt'], NOW - 20)
        status = collector.status()
        self.assertEqual(status['threadsChecked'], 4)
        self.assertEqual(status['publisherIdentities'], len(PINNED))
        self.assertEqual(status['pendingRequests'], 0)

    def test_denials_and_rate_limits_back_off_without_other_host_or_auth(self):
        row = root_row()
        for code, delay in ((403, 3600), (429, 300)):
            calls = []
            def fetch(url, headers, timeout):
                calls.append(url)
                return Response(code, {'retry-after': str(delay)}, b'', url)
            collector = self.collector(fetch)
            self.assertEqual(collector.collect([row], NOW), [])
            self.assertEqual(collector.collect([row], NOW + delay - 1), [])
            self.assertEqual(len(calls), 1)
            self.assertEqual(collector.status()['httpStatus'], code)
            self.assertGreaterEqual(collector.status()['nextCheckAt'], (NOW + delay) * 1000)

    def test_empty_or_unknown_root_set_never_causes_a_request(self):
        calls = []
        collector = self.collector(lambda *args: calls.append(args))
        self.assertEqual(collector.collect([{'url': 'https://localhost/private'}], NOW), [])
        self.assertEqual(calls, [])
        self.assertEqual(collector.status()['status'], 'waiting')

    def test_same_reply_identity_cannot_be_reassigned_to_a_different_publisher_root(self):
        rows = [root_row('root1'), root_row('root2')]
        def fetch(url, headers, timeout):
            root = next(publisher_root(row, NOW) for row in rows if thread_url(publisher_root(row, NOW)['uri']) == url)
            # An inconsistent upstream response cannot move one record URI to another parent.
            return Response(200, {'content-type': 'application/json'}, body(root), url)
        collector = self.collector(fetch)
        self.assertEqual(len(collector.collect(rows, NOW)), 1)

    def test_wrong_response_url_type_and_changed_reply_clock_fail_closed(self):
        row = root_row()
        root = publisher_root(row, NOW)
        for response in (Response(200, {'content-type': 'text/html'}, body(root), thread_url(root['uri'])),
                         Response(200, {'content-type': 'application/json'}, body(root), 'https://example.org/other')):
            collector = self.collector(lambda *_args: response)
            self.assertEqual(collector.collect([row], NOW), [])
            self.assertEqual(collector.status()['status'], 'unavailable')
        count = {'calls': 0}
        def fetch(url, headers, timeout):
            count['calls'] += 1
            age = 20 if count['calls'] == 1 else 10
            return Response(200, {'content-type': 'application/json'}, body(root, [reply(root, age=age)]), url)
        collector = self.collector(fetch)
        self.assertEqual(len(collector.collect([row], NOW)), 1)
        self.assertEqual(collector.collect([row], NOW + 60), [])

    def test_transport_rejects_arbitrary_url_and_redirects(self):
        with patch('social_feedback.urllib.request.build_opener') as opener:
            with self.assertRaises(ValueError):
                fetch_public('http://127.0.0.1/private', {}, 1)
            with self.assertRaises(ValueError):
                fetch_public(thread_url(publisher_root(root_row(), NOW)['uri']) + '&depth=100', {}, 1)
            opener.assert_not_called()
        self.assertIsNone(_NoRedirect().redirect_request(None, None, None, None, None, 'https://example.org'))

    def test_transport_does_not_forward_site_identity_or_authentication_headers(self):
        url = thread_url(publisher_root(root_row(), NOW)['uri'])
        class HttpResponse:
            status, headers, fp = 200, {'Content-Length': '0'}, None
            def __init__(self): self.url = url
            def __enter__(self): return self
            def __exit__(self, *_args): pass
            def read1(self, _count): return b''
        with patch('social_feedback.urllib.request.build_opener') as factory:
            factory.return_value.open.return_value = HttpResponse()
            fetch_public(url, {'User-Agent': 'GoldPulse/private-domain.example',
                               'Referer': 'https://gold-air.onrender.com/',
                               'Cookie': 'private=test', 'Authorization': 'private-test'}, 1)
            sent = {k.lower(): v for k, v in factory.return_value.open.call_args.args[0].header_items()}
        self.assertEqual(sent, {'user-agent': 'PublicNewsReader/1.0', 'accept': 'application/json',
                                'accept-encoding': 'identity'})


if __name__ == '__main__':
    unittest.main()

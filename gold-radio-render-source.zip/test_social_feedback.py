from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import unittest
from unittest.mock import patch

from social_sources import Response, clean_text, parse_bluesky
from social_feedback import (COLLECTION_BUDGET_S, MAX_BYTES, MAX_AGE_S, PINNED,
                             SocialFeedbackCollector, fetch_public, parse_thread,
                             publisher_root, thread_url, reaction_allowed, REACTION_POLICY_VERSION,
                             NEWS_OPINION_POLICY_VERSION, _safe_text, _NoRedirect)


NOW = 1792878000
PUBLISHER = next(iter(PINNED.values()))
AUTHOR = 'did:plc:' + 'a' * 24
# Public Bloomberg thread captured 25 October 2026 at 18:41:39 UTC. This is
# real collected wording/identity replayed offline, not synthetic live supply.
NEWS_NOW = 1792953699
NEWS_ROOT_AT = 1792953012
NEWS_REPLY_AT = 1792953245
BLOOMBERG = PINNED['did:plc:uewxgchsjy4kmtu7dcxa77us']
NEWS_AUTHOR = 'did:plc:fgwzoo32huozv22kfsxuxq3k'
NEWS_ROOT_TEXT = ('Netflix users are watching the streaming service less than they once did, the latest sign of '
    'engagement woes for the world’s most valuable entertainment company, according to people familiar with the matter. '
    'Read more: bloom.bg/4BIKChN\n\n📷: Mario Tama/Getty Images')
NEWS_QUOTE = ('They need to cut back on the ITV3 / Channel 5 style "true crime" series on stories which '
              'have been thoroughly covered already.')


def iso(stamp):
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat()


def root_row(key='root123', source=PUBLISHER, age=100):
    url = 'https://bsky.app/profile/' + source.did + '/post/' + key
    return {'id': hashlib.sha256(('social:' + url).encode()).hexdigest()[:32],
            'url': url, 'source': source.source, 'title': 'Gold prices react to new inflation figures',
            'social': True, 'sourceKind': 'social', 'platform': 'Bluesky', 'language': 'en',
            'publishedAt': NOW - age, 'firstSeenAt': NOW - age + 1}


def reply(root, text='Gold and real yields deserve comparison before assigning a cause to this move.',
          key='reply123', age=20, **extra):
    record = {'$type': 'app.bsky.feed.post', 'createdAt': iso(NOW - age), 'text': text,
              'reply': {'root': {'uri': root['uri']}, 'parent': {'uri': root['uri']}}}
    post = {'uri': 'at://' + AUTHOR + '/app.bsky.feed.post/' + key,
            'author': {'did': AUTHOR, 'handle': 'listener.example'}, 'record': record,
            'indexedAt': iso(NOW - 1)}
    post.update(extra)
    return {'$type': 'app.bsky.feed.defs#threadViewPost', 'post': post}


def body(root, replies=None):
    source = root['source']
    return json.dumps({'thread': {'$type': 'app.bsky.feed.defs#threadViewPost',
        'post': {'uri': root['uri'], 'author': {'did': source.did, 'handle': source.actor},
                 'record': {'$type': 'app.bsky.feed.post', 'createdAt': iso(root['row']['publishedAt'])}},
        'replies': replies if replies is not None else [reply(root)]}}).encode()


def news_fixture(source=BLOOMBERG, text=NEWS_QUOTE):
    root_uri = 'at://' + source.did + '/app.bsky.feed.post/3myptnqb4y32g'
    parent = {'uri': root_uri, 'author': {'did': source.did, 'handle': source.actor},
        'record': {'$type': 'app.bsky.feed.post', 'createdAt': iso(NEWS_ROOT_AT), 'text': NEWS_ROOT_TEXT,
                   'embed': {'$type': 'app.bsky.embed.images', 'images': []}}}
    row = parse_bluesky(json.dumps({'feed': [{'post': parent}]}).encode(), source, NEWS_NOW)[0]
    node = {'$type': 'app.bsky.feed.defs#threadViewPost', 'post': {
        'uri': 'at://' + NEWS_AUTHOR + '/app.bsky.feed.post/3myptuofszs2s',
        'author': {'did': NEWS_AUTHOR, 'handle': 'rktecture.bsky.social', 'displayName': 'rktecture'},
        'record': {'$type': 'app.bsky.feed.post', 'createdAt': iso(NEWS_REPLY_AT), 'text': text,
            'reply': {'root': {'uri': root_uri}, 'parent': {'uri': root_uri}}}}}
    return row, {'thread': {'$type': 'app.bsky.feed.defs#threadViewPost', 'post': parent, 'replies': [node]}}


def news_body(data):
    return json.dumps(data, ensure_ascii=False).encode()


class FeedbackParsingTests(unittest.TestCase):
    def setUp(self):
        self.row = root_row()
        self.root = publisher_root(self.row, NOW)

    def test_only_already_collected_exact_publisher_identities_form_roots(self):
        self.assertIsNotNone(self.root)
        for change in ({'sourceKind': 'social-feedback'}, {'source': 'Imposter'}, {'id': 'f' * 32},
                       {'url': self.row['url'] + '?url=http://127.0.0.1'},
                       {'url': 'https://bsky.app/profile/' + AUTHOR + '/post/root123'},
                       {'publishedAt': NOW - MAX_AGE_S - 1}, {'firstSeenAt': NOW + 1}):
            with self.subTest(change=change):
                self.assertIsNone(publisher_root({**self.row, **change}, NOW))
        with self.assertRaises(ValueError):
            thread_url('at://' + AUTHOR + '/app.bsky.feed.post/root123')
        url = thread_url(self.root['uri'])
        self.assertIn('depth=1', url)
        self.assertIn('parentHeight=0', url)

    def test_removed_regional_publisher_cannot_form_a_feedback_root(self):
        from social_sources import Source
        removed = Source('removed', 'Al Jazeera', 'Bluesky', 'aljazeera.com', 'en',
                         'did:plc:2lofqead276vtc5647ye7sl2')
        self.assertIsNone(publisher_root(root_row(source=removed), NOW))
        with self.assertRaises(ValueError):
            thread_url('at://' + removed.did + '/app.bsky.feed.post/root123')

    def test_reply_attribution_original_clock_and_nonrepresentative_label(self):
        row = parse_thread(body(self.root), self.root, NOW)[0]
        self.assertEqual(row['publishedAt'], NOW - 20)
        self.assertEqual(row['firstSeenAt'], NOW)
        self.assertEqual(row['sourceKind'], 'social-feedback')
        self.assertEqual(row['verification'], 'unverified-public-reply')
        self.assertEqual(row['clockBasis'], 'author-reported')
        self.assertIn('@listener.example', row['source'])
        self.assertIn(PUBLISHER.source, row['source'])
        self.assertEqual(row['feedback']['rootUrl'], self.row['url'])
        self.assertEqual(row['feedback']['rootPublishedAt'], self.row['publishedAt'])
        self.assertEqual(row['feedback']['authorDid'], AUTHOR)
        self.assertTrue(row['feedback']['unverified'])
        self.assertFalse(row['feedback']['representative'])
        self.assertRegex(row['id'], r'^[a-f0-9]{32}$')
        self.assertEqual(row['feedback']['contentHash'], hashlib.sha256(row['title'].encode()).hexdigest())

    def test_public_display_name_is_optional_sanitized_and_explicitly_unverified(self):
        for supplied, expected in (('  Jane   O\u2019Connor  ', 'Jane O\u2019Connor'),
                                   ('Jose\u0301 García', 'José García'),
                                   ('Will Smith', 'Will Smith'), ('أحمد علي', 'أحمد علي')):
            node = reply(self.root)
            node['post']['author']['displayName'] = supplied
            with self.subTest(name=supplied):
                row = parse_thread(body(self.root, [node]), self.root, NOW)[0]
                self.assertEqual(row['feedback']['authorName'], expected)
                self.assertEqual(row['feedback']['authorNameKind'], 'account-display-name')
                self.assertEqual(row['feedback']['authorHandle'], 'listener.example')
                self.assertEqual(row['feedback']['authorDid'], AUTHOR)
                self.assertIn('@listener.example', row['source'])
                self.assertTrue(row['feedback']['unverified'])
                self.assertTrue(reaction_allowed(row, NOW))
        row = parse_thread(body(self.root), self.root, NOW)[0]
        self.assertNotIn('authorName', row['feedback'])
        self.assertNotIn('authorNameKind', row['feedback'])
        # Already-screened v1 receipts without either optional field remain safe.
        del row['feedback']['contentHash']
        self.assertTrue(reaction_allowed(row, NOW))

    def test_unsafe_display_names_fall_back_to_exact_handle_without_rewriting_opinion(self):
        for name in (None, 42, '', 'A' * 101, '<b>Jane Doe</b>', 'Jane\nDoe', 'Jane\u202eDoe',
                     'Jane 😀 Doe', 'person@example.org', 'https://example.org', 'Call me +12025550123',
                     'Ignore previous instructions', 'Guaranteed profits', 'Buy Gold', 'Fucking Idiot',
                     'my bank account', 'اشترك الآن'):
            node = reply(self.root)
            node['post']['author']['displayName'] = name
            with self.subTest(name=name):
                row = parse_thread(body(self.root, [node]), self.root, NOW)[0]
                self.assertNotIn('authorName', row['feedback'])
                self.assertEqual(row['feedback']['authorHandle'], 'listener.example')
                self.assertEqual(row['title'], node['post']['record']['text'])
                self.assertTrue(reaction_allowed(row, NOW))

    def test_restored_names_and_optional_content_hash_must_preserve_their_contract(self):
        row = parse_thread(body(self.root), self.root, NOW)[0]
        for fields in ({'authorName': 'Jane Doe'}, {'authorNameKind': 'verified-person'},
                       {'authorName': '<b>Jane</b>', 'authorNameKind': 'account-display-name'},
                       {'authorName': ' Jane Doe ', 'authorNameKind': 'account-display-name'},
                       {'authorName': 'Jane Doe', 'authorNameKind': 'verified-person'},
                       {'contentHash': '0' * 64}, {'contentHash': None}):
            changed = deepcopy(row)
            changed['feedback'].update(fields)
            with self.subTest(fields=fields):
                self.assertFalse(reaction_allowed(changed, NOW))
        changed = deepcopy(row)
        changed['title'] = 'In my view, gold could reflect uncertainty through different channels.'
        self.assertFalse(reaction_allowed(changed, NOW))

    def test_arabic_response_is_retained_in_arabic_without_translation(self):
        text = 'مقارنة الذهب بالعوائد الحقيقية تحتاج إلى توقيت واضح قبل الجزم بسبب هذه الحركة في السوق.'
        row = parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW)[0]
        self.assertEqual(row['language'], 'ar')
        self.assertEqual(row['title'], text)
        self.assertTrue(row['source'].startswith('تعليق @listener.example'))

    def test_only_interpretive_financial_reactions_receive_the_new_screening_contract(self):
        texts = (
            'I think gold and real yields deserve a closer comparison before drawing a conclusion.',
            'In my view, oil uncertainty could matter for inflation expectations and gold demand.',
            'برأيي، مقارنة الذهب بالعوائد الحقيقية تحتاج إلى أدلة أوضح قبل الجزم بسبب حركة السوق.',
        )
        for text in texts:
            with self.subTest(text=text):
                rows = parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW)
                self.assertEqual(len(rows), 1)
                row = rows[0]
                self.assertEqual(row['title'], text)
                self.assertEqual(row['feedback']['screeningPolicy'], REACTION_POLICY_VERSION)
                self.assertEqual(row['feedback']['screeningKind'], 'bounded-financial-opinion')
                self.assertTrue(reaction_allowed(row, NOW))

    def test_opinion_hedges_do_not_admit_news_claims_allegations_or_trade_advice(self):
        texts = (
            'I think gold could reach 5000 dollars after this unexpected development.',
            'I think gold could react because Brazil is a corrupt criminal state.',
            'Gold may be important. The minister confirmed the bank collapsed today.',
            'I think gold could react because a secret group steals money from everyone.',
            'I think gold is important because my gold portfolio earned excellent returns.',
            'Gold might be worth watching, @privateperson says the bank is hiding deposits.',
            'Gold and real yields are different measures with recent economic conditions.',
            'I think gold has already collapsed after the central bank announcement.',
            'I think gold is secretly manipulated by a group of powerful investors.',
            'I think people should buy gold and sell bonds before the next market session.',
            'برأيي ارتفع الذهب اليوم بعد تصريحات مؤكدة من وزير الاقتصاد عن التضخم.',
            'أعتقد أن الذهب قد يتأثر لأن هناك مؤامرة وتلاعب في أسعار السوق.',
            'Will Brazil remain an independent sovereign nation or succumb to fascism and become a vassal state?',
            'Will they choose corruption again while gold prices matter to investors?',
        )
        for text in texts:
            with self.subTest(text=text):
                self.assertEqual(parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW), [])

    def test_reactions_and_their_publisher_roots_expire_after_one_hour_without_freshening(self):
        self.assertEqual(MAX_AGE_S, 3600)
        row = parse_thread(body(self.root), self.root, NOW)[0]
        self.assertTrue(reaction_allowed(row, NOW))
        self.assertFalse(reaction_allowed(row, NOW + 3601))
        for age in (3601, 15 * 3600):
            old = root_row(age=age)
            self.assertIsNone(publisher_root(old, NOW))
            self.assertFalse(reaction_allowed({**row, 'firstSeenAt': NOW + 15 * 3600}, NOW + 15 * 3600))
        # A fresh reply cannot renew its old publisher parent.
        row['feedback']['rootPublishedAt'] = NOW - 3601
        self.assertFalse(reaction_allowed(row, NOW))

    def test_legacy_and_changed_provenance_receipts_cannot_be_revived(self):
        row = parse_thread(body(self.root), self.root, NOW)[0]
        for key, value in (
            ('screeningPolicy', None), ('screeningKind', 'news'), ('rootSource', 'Imposter'),
            ('rootId', 'f' * 32), ('rootUri', None), ('replyUri', 4),
            ('authorDid', PUBLISHER.did), ('authorHandle', 'different.example'),
            ('rootUrl', 'https://bsky.app/profile/' + AUTHOR + '/post/root123'),
            ('unverified', False), ('representative', True),
        ):
            changed = deepcopy(row)
            changed['feedback'][key] = value
            with self.subTest(key=key):
                self.assertFalse(reaction_allowed(changed, NOW))
        for changed in ({**row, 'id': '0' * 32}, {**row, 'source': 'Public consensus'},
                        {**row, 'firstSeenAt': NOW + 1}, {**row, 'publishedAt': NOW - 15 * 3600},
                        {**row, 'title': 'I think gold has collapsed after a confirmed bank announcement.'}):
            self.assertFalse(reaction_allowed(changed, NOW))

    def test_english_feedback_matches_latin_letter_speech_contract_without_rewriting(self):
        for text in ('Gold demand and real yields matter, but الذهب needs more context.',
                     'Gold demand and real yields matter, but золото needs more context.'):
            with self.subTest(text=text):
                self.assertEqual(parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW), [])
        text = 'Gold demand and real yields matter; café discussions need clearer evidence.'
        row = parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW)[0]
        self.assertEqual(row['language'], 'en')
        self.assertEqual(row['title'], text)

    def test_root_identity_blocked_nodes_labels_quotes_and_nested_replies_are_rejected(self):
        data = json.loads(body(self.root))
        data['thread']['post']['author']['did'] = AUTHOR
        with self.assertRaises(ValueError):
            parse_thread(json.dumps(data).encode(), self.root, NOW)
        for mutation in ('parent', 'root', 'labels', 'author-labels', 'embed', 'wrong-author', 'blocked'):
            node = reply(self.root)
            if mutation in ('parent', 'root'):
                node['post']['record']['reply'][mutation]['uri'] += 'other'
            elif mutation == 'labels':
                node['post']['labels'] = [{'val': 'spam'}]
            elif mutation == 'author-labels':
                node['post']['author']['labels'] = [{'val': 'spam'}]
            elif mutation == 'embed':
                node['post']['record']['embed'] = {'$type': 'app.bsky.embed.record'}
            elif mutation == 'wrong-author':
                node['post']['author']['did'] = PUBLISHER.did
            else:
                node = {'$type': 'app.bsky.feed.defs#blockedPost', 'blocked': True}
            with self.subTest(mutation=mutation):
                self.assertEqual(parse_thread(body(self.root, [node]), self.root, NOW), [])

    def test_short_irrelevant_ads_contacts_links_and_obvious_abuse_are_not_aired(self):
        texts = ('Absolutely agree!', 'This new film is really interesting and I enjoyed watching it.',
                 'Gold returns are guaranteed, join my signals channel for the best profits.',
                 'Gold demand matters, contact me at person@example.com to hear more.',
                 'Gold prices are discussed further at https://example.com/story for my customers.',
                 'Gold prices are discussed at example.com for more details and new clients.',
                 'Gold news is useful, call me at +1 202 555 0123 for the latest updates.',
                 'Gold will rise and everyone who disagrees is a fucking idiot.',
                 'أرباح مضمونة من الذهب اشترك الآن للحصول على جميع التوصيات المجانية.')
        for text in texts:
            with self.subTest(text=text):
                self.assertEqual(parse_thread(body(self.root, [reply(self.root, text)]), self.root, NOW), [])

    def test_old_future_pre_root_and_repeated_reply_nodes_cannot_create_freshness(self):
        for age in (MAX_AGE_S + 1, -1, 101):
            with self.subTest(age=age):
                self.assertEqual(parse_thread(body(self.root, [reply(self.root, age=age)]), self.root, NOW), [])
        node = reply(self.root)
        self.assertEqual(len(parse_thread(body(self.root, [node, node]), self.root, NOW)), 1)
        with self.assertRaises(ValueError):
            parse_thread(b'x' * (MAX_BYTES + 1), self.root, NOW)


class FeedbackCollectorTests(unittest.TestCase):
    def collector(self, fetcher):
        collector = SocialFeedbackCollector(fetcher)
        self.addCleanup(collector._pool.shutdown, wait=True, cancel_futures=True)
        return collector

    def test_two_requests_per_poll_no_login_and_receipts_preserve_first_seen(self):
        rows = [root_row('root' + str(index), age=100 + index) for index in range(3)]
        calls = []
        def fetch(url, headers, timeout):
            self.assertLessEqual(timeout, COLLECTION_BUDGET_S)
            self.assertNotIn('Authorization', headers)
            calls.append(url)
            root = next(publisher_root(row, NOW) for row in rows if thread_url(publisher_root(row, NOW)['uri']) == url)
            reply_key = root['uri'].rsplit('/', 1)[-1] + 'reply'
            return Response(200, {'content-type': 'application/json'}, body(root, [reply(root, key=reply_key)]), url)
        collector = self.collector(fetch)
        first = collector.collect(rows, NOW)
        self.assertEqual(len(calls), 2)
        self.assertEqual(len(first), 2)
        self.assertEqual(len({row['id'] for row in first}), 2)
        self.assertEqual(collector.collect(rows, NOW + 59), [])
        second = collector.collect(rows, NOW + 60)
        self.assertEqual(len(calls), 4)
        shared = {row['id']: row for row in second}
        for row in first:
            if row['id'] in shared:
                self.assertEqual(shared[row['id']]['firstSeenAt'], NOW)
                self.assertEqual(shared[row['id']]['publishedAt'], NOW - 20)
        status = collector.status()
        self.assertEqual(status['threadsChecked'], 4)
        self.assertEqual(status['publisherIdentities'], len(PINNED))
        self.assertEqual(status['pendingRequests'], 0)

    def test_denials_and_rate_limits_back_off_without_other_host_or_auth(self):
        row = root_row()
        for code, delay in ((403, 3600), (429, 300)):
            calls = []
            def fetch(url, headers, timeout):
                calls.append(url)
                return Response(code, {'retry-after': str(delay)}, b'', url)
            collector = self.collector(fetch)
            self.assertEqual(collector.collect([row], NOW), [])
            self.assertEqual(collector.collect([row], NOW + delay - 1), [])
            self.assertEqual(len(calls), 1)
            self.assertEqual(collector.status()['httpStatus'], code)
            self.assertGreaterEqual(collector.status()['nextCheckAt'], (NOW + delay) * 1000)

    def test_empty_or_unknown_root_set_never_causes_a_request(self):
        calls = []
        collector = self.collector(lambda *args: calls.append(args))
        self.assertEqual(collector.collect([{'url': 'https://localhost/private'}], NOW), [])
        self.assertEqual(calls, [])
        self.assertEqual(collector.status()['status'], 'waiting')

    def test_same_reply_identity_cannot_be_reassigned_to_a_different_publisher_root(self):
        rows = [root_row('root1'), root_row('root2')]
        def fetch(url, headers, timeout):
            root = next(publisher_root(row, NOW) for row in rows if thread_url(publisher_root(row, NOW)['uri']) == url)
            # An inconsistent upstream response cannot move one record URI to another parent.
            return Response(200, {'content-type': 'application/json'}, body(root), url)
        collector = self.collector(fetch)
        self.assertEqual(len(collector.collect(rows, NOW)), 1)

    def test_wrong_response_url_type_and_changed_reply_clock_fail_closed(self):
        row = root_row()
        root = publisher_root(row, NOW)
        for response in (Response(200, {'content-type': 'text/html'}, body(root), thread_url(root['uri'])),
                         Response(200, {'content-type': 'application/json'}, body(root), 'https://example.org/other')):
            collector = self.collector(lambda *_args: response)
            self.assertEqual(collector.collect([row], NOW), [])
            self.assertEqual(collector.status()['status'], 'unavailable')
        count = {'calls': 0}
        def fetch(url, headers, timeout):
            count['calls'] += 1
            age = 20 if count['calls'] == 1 else 10
            return Response(200, {'content-type': 'application/json'}, body(root, [reply(root, age=age)]), url)
        collector = self.collector(fetch)
        self.assertEqual(len(collector.collect([row], NOW)), 1)
        self.assertEqual(collector.collect([row], NOW + 60), [])

    def test_same_reply_cannot_silently_change_its_screened_text(self):
        row = root_row()
        root = publisher_root(row, NOW)
        calls = []
        first_text = 'I think gold and real yields deserve a closer comparison before drawing a conclusion.'
        changed_text = 'In my view, gold could reflect uncertainty through different channels.'
        def fetch(url, headers, timeout):
            calls.append(url)
            text = first_text if len(calls) == 1 else changed_text
            return Response(200, {'content-type': 'application/json'}, body(root, [reply(root, text=text)]), url)
        collector = self.collector(fetch)
        first = collector.collect([row], NOW)
        self.assertEqual(len(first), 1)
        self.assertEqual(first[0]['feedback']['contentHash'], hashlib.sha256(first_text.encode()).hexdigest())
        self.assertEqual(collector.collect([row], NOW + 60), [])
        self.assertEqual(collector._receipts[first[0]['id']][0], NOW)

    def test_transport_rejects_arbitrary_url_and_redirects(self):
        with patch('social_feedback.urllib.request.build_opener') as opener:
            with self.assertRaises(ValueError):
                fetch_public('http://127.0.0.1/private', {}, 1)
            with self.assertRaises(ValueError):
                fetch_public(thread_url(publisher_root(root_row(), NOW)['uri']) + '&depth=100', {}, 1)
            opener.assert_not_called()
        self.assertIsNone(_NoRedirect().redirect_request(None, None, None, None, None, 'https://example.org'))

    def test_transport_does_not_forward_site_identity_or_authentication_headers(self):
        url = thread_url(publisher_root(root_row(), NOW)['uri'])
        class HttpResponse:
            status, headers, fp = 200, {'Content-Length': '0'}, None
            def __init__(self): self.url = url
            def __enter__(self): return self
            def __exit__(self, *_args): pass
            def read1(self, _count): return b''
        with patch('social_feedback.urllib.request.build_opener') as factory:
            factory.return_value.open.return_value = HttpResponse()
            fetch_public(url, {'User-Agent': 'GoldPulse/private-domain.example',
                               'Referer': 'https://gold-air.onrender.com/',
                               'Cookie': 'private=test', 'Authorization': 'private-test'}, 1)
            sent = {k.lower(): v for k, v in factory.return_value.open.call_args.args[0].header_items()}
        self.assertEqual(sent, {'user-agent': 'PublicNewsReader/1.0', 'accept': 'application/json',
                                'accept-encoding': 'identity'})


class BusinessNewsOpinionTests(unittest.TestCase):
    def parse(self, text=NEWS_QUOTE):
        row, data = news_fixture(text=text)
        return parse_thread(news_body(data), publisher_root(row, NEWS_NOW), NEWS_NOW)

    def test_real_public_programming_preference_preserves_whole_quote_and_complete_parent(self):
        root_row, data = news_fixture()
        root = publisher_root(root_row, NEWS_NOW)
        self.assertFalse(root['financialOpinionEligible'])
        self.assertTrue(root['newsOpinionEligible'])
        self.assertEqual(_safe_text(NEWS_QUOTE), '')
        row = parse_thread(news_body(data), root, NEWS_NOW)[0]
        feedback = row['feedback']
        self.assertEqual(row['title'], NEWS_QUOTE)
        self.assertEqual(row['publishedAt'], NEWS_REPLY_AT)
        self.assertEqual(row['firstSeenAt'], NEWS_NOW)
        self.assertEqual(feedback['authorHandle'], 'rktecture.bsky.social')
        self.assertEqual(feedback['authorName'], 'rktecture')
        self.assertEqual(feedback['authorNameKind'], 'account-display-name')
        self.assertEqual(feedback['authorDid'], NEWS_AUTHOR)
        self.assertEqual(feedback['rootTitle'], clean_text(NEWS_ROOT_TEXT))
        self.assertEqual(feedback['rootContentHash'], hashlib.sha256(root_row['title'].encode()).hexdigest())
        self.assertEqual(feedback['contentHash'], hashlib.sha256(NEWS_QUOTE.encode()).hexdigest())
        self.assertEqual(feedback['rootPublishedAt'], NEWS_ROOT_AT)
        self.assertEqual(feedback['rootFirstSeenAt'], NEWS_NOW)
        self.assertEqual(feedback['screeningPolicy'], NEWS_OPINION_POLICY_VERSION)
        self.assertEqual(feedback['screeningKind'], 'bounded-news-opinion')
        self.assertTrue(feedback['unverified'])
        self.assertFalse(feedback['representative'])
        self.assertTrue(reaction_allowed(row, NEWS_NOW))
        self.assertFalse(reaction_allowed(row, NEWS_ROOT_AT + MAX_AGE_S + 1))

    def test_business_parent_exception_is_limited_to_two_pinned_original_source_identities(self):
        for source in PINNED.values():
            row, _data = news_fixture(source)
            with self.subTest(source=source.source):
                root = publisher_root(row, NEWS_NOW)
                if source.did in (BLOOMBERG.did, 'did:plc:m7ks2xhfuku7errrtfjux2lg'):
                    self.assertTrue(root['newsOpinionEligible'])
                else:
                    self.assertIsNone(root)
        row, _data = news_fixture()
        for change in ({'clockBasis': 'aggregator-index'}, {'timeKind': 'updated'},
                       {'title': 'Protests follow the latest political news from a president.'},
                       {'publishedAt': NEWS_NOW - MAX_AGE_S - 1}):
            self.assertIsNone(publisher_root({**row, **change}, NEWS_NOW))

    def test_subjective_preferences_and_nonclaiming_consumer_questions_are_allowed(self):
        for text in ('I prefer Netflix documentaries to another Channel 5 style crime series.',
                     'Could Netflix make the streaming menus easier to navigate?',
                     'I think Netflix now needs better categories for its programmes.'):
            with self.subTest(text=text):
                rows = self.parse(text)
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]['title'], text)
                self.assertEqual(rows[0]['feedback']['screeningPolicy'], NEWS_OPINION_POLICY_VERSION)

    def test_hedges_cannot_admit_fresh_facts_allegations_advice_or_an_inconvenient_second_clause(self):
        for text in (
                'I think Netflix is a fraud and lies to its customers.',
                'I think Netflix has 500 new subscribers today.',
                'I think Netflix has new customers today.',
                'I think Netflix launched a new service today.',
                'I think Netflix needs better shows because subscriber numbers are up today.',
                'I think Netflix needs better menus. The company announced new layoffs today.',
                'I think Netflix needs better shows because the CEO is stealing money.',
                'I think Netflix needs better programmes because user data is leaking.',
                'I think everyone should buy Netflix shares before the next session.',
                'Netflix will definitely become more valuable after this development.',
                'Will they raise the price again or just cancel the entire company?',
                'Can confirm. In part because there are alternative services. Netflix also has an awful method of categorization.',
                'I prefer Netflix shows; join my signals channel for guaranteed returns.',
                'I think my Netflix stock portfolio earned excellent returns today.',
                'I prefer these shows, contact me at person@example.org for more information.',
                'I think Netflix needs better shows because everyone else is a fucking idiot.',
                NEWS_QUOTE + ' Netflix has increased prices today.',
                NEWS_QUOTE + ' https://example.org',
                NEWS_QUOTE[:-1], NEWS_QUOTE + ' unfinished clause',
                'I prefer ' + 'better ' * 65 + 'programmes.'):
            with self.subTest(text=text):
                self.assertEqual(self.parse(text), [])

    def test_matching_parent_content_original_clock_and_unedited_first_level_reply_are_required(self):
        for change in ('root-text', 'root-edited', 'reply-edited', 'reply-parent', 'reply-root',
                       'reply-embed', 'view-embed', 'reply-facet', 'root-quote'):
            row, data = news_fixture()
            parent = data['thread']['post']
            post = data['thread']['replies'][0]['post']
            if change == 'root-text':
                parent['record']['text'] = 'Netflix is introducing new programming changes to its streaming service.'
            elif change == 'root-edited':
                parent['record']['editedAt'] = iso(NEWS_NOW - 1)
            elif change == 'reply-edited':
                post['editedAt'] = iso(NEWS_NOW - 1)
            elif change in ('reply-parent', 'reply-root'):
                post['record']['reply'][change.split('-')[1]]['uri'] += 'other'
            elif change == 'reply-embed':
                post['record']['embed'] = {'$type': 'app.bsky.embed.record'}
            elif change == 'view-embed':
                post['embed'] = {'$type': 'app.bsky.embed.external'}
            elif change == 'reply-facet':
                post['record']['facets'] = [{'features': [{'$type': 'app.bsky.richtext.facet#link', 'uri': 'https://example.org'}]}]
            else:
                parent['record']['embed'] = {'$type': 'app.bsky.embed.record'}
            with self.subTest(change=change):
                self.assertEqual(parse_thread(news_body(data), publisher_root(row, NEWS_NOW), NEWS_NOW), [])
        for field, value in (('createdAt', iso(NEWS_ROOT_AT - 1)),):
            row, data = news_fixture()
            data['thread']['post']['record'][field] = value
            with self.assertRaises(ValueError):
                parse_thread(news_body(data), publisher_root(row, NEWS_NOW), NEWS_NOW)

    def test_v2_restores_require_both_hashes_matching_parent_title_and_known_version(self):
        row = self.parse()[0]
        for change in ({'rootTitle': 'Netflix programming needs a better menu for customers.'},
                       {'rootContentHash': '0' * 64}, {'rootTitle': None}, {'rootContentHash': None},
                       {'contentHash': None}, {'rootFirstSeenAt': NEWS_NOW + 1},
                       {'screeningPolicy': REACTION_POLICY_VERSION}, {'screeningPolicy': 'unknown-v3'},
                       {'screeningKind': 'bounded-financial-opinion'}):
            changed = deepcopy(row)
            changed['feedback'].update(change)
            with self.subTest(change=change):
                self.assertFalse(reaction_allowed(changed, NEWS_NOW))

    def test_collector_freezes_both_reply_text_and_the_matched_parent_title(self):
        for mutation in ('reply-text', 'root-text'):
            row, data = news_fixture()
            calls = []
            def fetch(url, headers, timeout):
                calls.append(url)
                return Response(200, {'content-type': 'application/json'}, news_body(data), url)
            collector = SocialFeedbackCollector(fetch)
            self.addCleanup(collector._pool.shutdown, wait=True, cancel_futures=True)
            first = collector.collect([row], NEWS_NOW)
            self.assertEqual(len(first), 1)
            if mutation == 'reply-text':
                data['thread']['replies'][0]['post']['record']['text'] = 'I prefer Netflix documentaries to another Channel 5 style crime series.'
            else:
                data['thread']['post']['record']['text'] = 'Netflix viewers are watching its streaming entertainment service less often.'
                row['title'] = clean_text(data['thread']['post']['record']['text'])
            with self.subTest(mutation=mutation):
                self.assertEqual(collector.collect([row], NEWS_NOW + 60), [])
                self.assertEqual(collector._receipts[first[0]['id']][0], NEWS_NOW)


if __name__ == '__main__':
    unittest.main()

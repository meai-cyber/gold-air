"""Pinned CC0 instrumentals and vocal songs on the shared music-only clock.

Instrumentals: HoliznaCC0. Vocal songs: Stefan Kartenberg featuring Orrisroot
and Asiansaints. Source and license evidence:
https://opengameart.org/content/relaxing-instrumentals-collection
https://ccmixter.org/files/JeffSpeed68/55917
https://ccmixter.org/files/orrisroot/55876
https://ccmixter.org/files/JeffSpeed68/55278
https://creativecommons.org/publicdomain/zero/1.0/

The build downloads the fixed, hash-pinned collection once and reads only the
three reviewed ZIP members; two fixed vocal MP3s additionally require the
publisher's SHA1/base32 identity and a recorded SHA256 pin. No weights, audio
or private data are stored in this source module. Runtime only reads
preverified local assets. A listener cannot choose a URL, file path, archive
member or external song.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import base64
import json
import os
from pathlib import Path
import random
import secrets
import stat
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

SOURCE_URL = 'https://opengameart.org/content/relaxing-instrumentals-collection'
LICENSE_URL = 'https://creativecommons.org/publicdomain/zero/1.0/'
ARCHIVE_URL = 'https://opengameart.org/sites/default/files/relaxing_instrumentals.zip'
ARCHIVE_BYTES = 65_584_101
ARCHIVE_SHA256 = 'ddfb641d51b82b72a0597985bf38da10cb820073c04703182b710b28f25f1db6'
MAX_ARCHIVE_BYTES = 80 * 1024 * 1024
MAX_DOWNLOAD_SECONDS = 180
ARTIST = 'HoliznaCC0'
MAX_TRACK_BYTES = 8 * 1024 * 1024
VOCAL_HOSTS = frozenset({'mixter.plus', 'ccmixter.org'})


@dataclass(frozen=True)
class Track:
    id: str
    title: str
    member: str
    bytes: int
    sha256: str
    duration_s: float
    artist: str = ARTIST
    source_url: str = SOURCE_URL
    download_url: str = ''
    publisher_sha1_base32: str = ''
    vocals: bool = False

    @property
    def duration_ms(self):
        return round(self.duration_s * 1000)


TRACKS = (
    Track('night-driving', 'Night Driving', 'Relaxing Instrumentals/02 HoliznaCC0 - Night Driving.mp3',
          5_255_245, 'a0ca6a568ad101fac8a12d94679f10b4011e8c05941b5dd7fc13770fcfae598d', 131.352),
    Track('boredom', 'Boredom', 'Relaxing Instrumentals/03 HoliznaCC0 - Boredom.mp3',
          6_826_765, '5fd746ad9665243a1d050fb40c9adddface6bc52c73aede8410b3c320b878e13', 170.640),
    Track('love', 'Love', 'Relaxing Instrumentals/05 HoliznaCC0 - Love.mp3',
          7_518_925, '78adb7112521fb23ace6ac2acb58d0b8586a9ba9c621916b74e76bf93aefe50c', 187.944),
    Track('missing-person', 'Missing Person', '', 3_509_568,
          '366874451891f2033d77d6ad7badd4f150a1399c3f6bc8c57368c90f7beed574', 219.072,
          artist='Stefan Kartenberg feat. Orrisroot',
          source_url='https://ccmixter.org/files/JeffSpeed68/55917',
          download_url='https://mixter.plus/content/JeffSpeed68/JeffSpeed68_-_Missing_Person.mp3',
          publisher_sha1_base32='OGNA3UWZNENJBTRUGVPGMEAHS7XTAPQM', vocals=True),
    Track('scintillating-love', 'Scintillating Love', '', 3_047_232,
          '6e6540aa57c74614af8134e209fe37b56396543f6dd64d891a8d8ae4d34e6d76', 190.176,
          artist='Stefan Kartenberg feat. Asiansaints',
          source_url='https://ccmixter.org/files/JeffSpeed68/55278',
          download_url='https://mixter.plus/content/JeffSpeed68/JeffSpeed68_-_Scintillating_Love.mp3',
          publisher_sha1_base32='54SDSSADXK6TMIZ3YHPDPCY6NZV2NBGV', vocals=True),
)


def _root(value):
    if not isinstance(value, (str, os.PathLike)) or '://' in str(value):
        raise ValueError('A local music asset directory is required')
    root = Path(value).resolve()
    here = Path(__file__).resolve().parent
    source = here.parents[1] if here.name == 'render-radio' and here.parent.name == 'deployment' else here
    if root == source or source in root.parents:
        raise ValueError('Music assets must remain outside the source directory')
    return root


def _metadata(track):
    return {'trackId': track.id, 'title': track.title, 'artist': track.artist,
            'durationSeconds': track.duration_s, 'license': 'CC0 1.0',
            'sourceUrl': track.source_url, 'licenseUrl': LICENSE_URL, 'vocals': track.vocals}


def _verified(path, track):
    try:
        if path.is_symlink() or path.parent.is_symlink() or not path.is_file() or path.stat().st_size != track.bytes:
            return False
        digest = hashlib.sha256()
        total = 0
        with path.open('rb') as source:
            while chunk := source.read(1024 * 1024):
                total += len(chunk)
                if total > track.bytes:
                    return False
                digest.update(chunk)
        return total == track.bytes and digest.hexdigest() == track.sha256
    except OSError:
        return False


class _PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        url = urllib.parse.urlsplit(new_url)
        if url.scheme != 'https' or url.netloc not in {'opengameart.org', 'www.opengameart.org'}:
            raise ValueError('Unexpected public music redirect')
        return super().redirect_request(request, fp, code, message, headers, new_url)


def _vocal_url(value):
    url = urllib.parse.urlsplit(value)
    if (url.scheme != 'https' or url.netloc not in VOCAL_HOSTS or url.query or url.fragment or
            not url.path.startswith('/content/') or not url.path.endswith('.mp3') or
            '\\' in value or any(ord(c) < 33 for c in value)):
        raise ValueError('Unexpected public vocal-song URL')
    return value


class _VocalRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        _vocal_url(new_url)
        return super().redirect_request(request, fp, code, message, headers, new_url)


def _matches_identity(total, digest, publisher_digest, track):
    return (total == track.bytes and digest.hexdigest() == track.sha256 and
            (not track.publisher_sha1_base32 or
             base64.b32encode(publisher_digest.digest()).decode('ascii') == track.publisher_sha1_base32))


@contextmanager
def _direct_source(track):
    # These fixed recordings are also identified by publisher-provided SHA1.
    # Their stronger SHA256 pins were derived only after that identity matched.
    if track not in TRACKS or not track.vocals or not track.publisher_sha1_base32 or not 0 < track.bytes <= MAX_TRACK_BYTES:
        raise ValueError('A pinned public vocal recording is required')
    request = urllib.request.Request(_vocal_url(track.download_url), headers={
        'User-Agent': 'GoldPulse-public-music-build/1', 'Accept-Encoding': 'identity'})
    opener = urllib.request.build_opener(_VocalRedirect())
    began = time.monotonic()
    with tempfile.TemporaryFile('w+b') as temporary:
        digest, publisher_digest, size = hashlib.sha256(), hashlib.sha1(), 0
        with opener.open(request, timeout=30) as response:
            _vocal_url(response.geturl())
            if (response.status != 200 or response.headers.get('Content-Type', '').split(';')[0].lower() != 'audio/mpeg' or
                    response.headers.get('Content-Encoding', 'identity') != 'identity'):
                raise ValueError('Public vocal recording is unavailable')
            declared = response.headers.get('Content-Length')
            if declared is not None and (not declared.isdecimal() or int(declared) != track.bytes):
                raise ValueError('Public vocal recording has an unexpected length')
            while True:
                if time.monotonic() - began > MAX_DOWNLOAD_SECONDS:
                    raise ValueError('Public vocal-song download timed out')
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > min(MAX_TRACK_BYTES, track.bytes):
                    raise ValueError('Public vocal recording exceeds its bound')
                digest.update(chunk)
                publisher_digest.update(chunk)
                temporary.write(chunk)
        if not _matches_identity(size, digest, publisher_digest, track):
            raise ValueError('The pinned public vocal recording changed')
        temporary.seek(0)
        yield temporary


@contextmanager
def _archive_source():
    request = urllib.request.Request(ARCHIVE_URL, headers={'User-Agent': 'GoldPulse-public-music-build/1'})
    opener = urllib.request.build_opener(_PublicRedirect())
    began = time.monotonic()
    with tempfile.TemporaryFile('w+b') as temporary:
        digest, size = hashlib.sha256(), 0
        with opener.open(request, timeout=30) as response:
            if response.status != 200:
                raise ValueError('Public music archive is unavailable')
            while True:
                if time.monotonic() - began > MAX_DOWNLOAD_SECONDS:
                    raise ValueError('Public music download timed out')
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > min(MAX_ARCHIVE_BYTES, ARCHIVE_BYTES):
                    raise ValueError('Public music archive exceeds its bound')
                digest.update(chunk)
                temporary.write(chunk)
        if size != ARCHIVE_BYTES or digest.hexdigest() != ARCHIVE_SHA256:
            raise ValueError('The pinned public music archive changed')
        temporary.seek(0)
        yield temporary


def _write_member(archive, directory, track):
    matches = [entry for entry in archive.infolist() if entry.filename == track.member]
    if len(matches) != 1:
        raise ValueError('A pinned music member is missing or ambiguous')
    info = matches[0]
    if (info.is_dir() or info.file_size != track.bytes or info.flag_bits & 1 or
            stat.S_ISLNK(info.external_attr >> 16) or info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}):
        raise ValueError('Invalid pinned music member')
    with archive.open(info, 'r') as source:
        _write_stream(source, directory, track)


def _write_stream(source, directory, track):
    target = directory / (track.id + '.mp3')
    if target.is_symlink():
        raise ValueError('Music asset aliases are unsupported')
    temporary_name = None
    try:
        with tempfile.NamedTemporaryFile('wb', dir=directory, prefix=track.id + '-', suffix='.tmp', delete=False) as output:
            temporary_name = output.name
            digest, publisher_digest, total = hashlib.sha256(), hashlib.sha1(), 0
            while chunk := source.read(1024 * 1024):
                total += len(chunk)
                if total > track.bytes:
                    raise ValueError('Pinned music member exceeds its bound')
                digest.update(chunk)
                publisher_digest.update(chunk)
                output.write(chunk)
            if not _matches_identity(total, digest, publisher_digest, track):
                raise ValueError('The pinned music recording changed')
        os.replace(temporary_name, target)
        temporary_name = None
        # These are public CC0 assets. Atomic temporary files start at 0600;
        # the non-root runtime must be able to read the completed recording.
        target.chmod(0o644)
    finally:
        if temporary_name is not None:
            Path(temporary_name).unlink(missing_ok=True)


def build(runtime_dir=None):
    root = _root(runtime_dir or os.environ.get('RADIO_MODEL_DIR', '/opt/gold-radio-assets'))
    directory = root / 'music'
    if directory.is_symlink():
        raise ValueError('Music asset aliases are unsupported')
    directory.mkdir(parents=True, exist_ok=True)
    directory.chmod(0o755)
    missing = [track for track in TRACKS if not _verified(directory / (track.id + '.mp3'), track)]
    archive_tracks = [track for track in missing if track.member]
    if archive_tracks:
        with _archive_source() as source, zipfile.ZipFile(source) as archive:
            for track in archive_tracks:
                _write_member(archive, directory, track)
    for track in missing:
        if not track.member:
            with _direct_source(track) as source:
                _write_stream(source, directory, track)
    if any(not _verified(directory / (track.id + '.mp3'), track) for track in TRACKS):
        raise ValueError('Pinned music verification failed')
    for track in TRACKS:
        (directory / (track.id + '.mp3')).chmod(0o644)
    attribution = {'artist': 'Various CC0 creators', 'artists': sorted({track.artist for track in TRACKS}),
                   'license': 'CC0 1.0', 'licenseUrl': LICENSE_URL,
                   'sourceUrl': SOURCE_URL, 'tracks': [_metadata(track) for track in TRACKS]}
    attribution_path = directory / 'ATTRIBUTION.json'
    if attribution_path.is_symlink():
        raise ValueError('Music asset aliases are unsupported')
    attribution_path.write_text(json.dumps(attribution, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    attribution_path.chmod(0o644)
    return tuple(_metadata(track) for track in TRACKS)


class MusicLibrary:
    def __init__(self, root, seed=None):
        self.root = _root(root)
        directory = self.root / 'music'
        self.tracks = tuple(track for track in TRACKS
                            if _verified(directory / (track.id + '.mp3'), track))
        self.available = tuple(_metadata(track) for track in self.tracks)
        if seed is None:
            seed = secrets.token_bytes(32)
        elif type(seed) is int and 0 <= seed < 2 ** 64:
            seed = str(seed).encode('ascii')
        elif isinstance(seed, str) and 1 <= len(seed) <= 256:
            seed = seed.encode('utf-8')
        elif isinstance(seed, bytes) and 1 <= len(seed) <= 256:
            pass
        else:
            raise ValueError('A bounded station music seed is required')
        self._seed = seed
        self._by_id = {track.id: track for track in self.tracks}
        self._round_ms = sum(track.duration_ms for track in self.tracks)

    def __len__(self):
        return len(self.tracks)

    def _base_order(self, round_index):
        order = list(self.tracks)
        digest = hashlib.sha256(self._seed + b':' + str(round_index).encode('ascii')).digest()
        random.Random(int.from_bytes(digest, 'big')).shuffle(order)
        return order

    def _order(self, round_index):
        if len(self.tracks) <= 2:
            # With two tracks the only no-repeat sequence is alternating.
            return self._base_order(0)
        current = self._base_order(round_index)
        if round_index and current[0].id == self._base_order(round_index - 1)[-1].id:
            current[0], current[1] = current[1], current[0]
        return current

    def asset(self, identifier):
        if not isinstance(identifier, str) or identifier not in self._by_id:
            return None
        track = self._by_id[identifier]
        path = self.root / 'music' / (identifier + '.mp3')
        try:
            if path.is_symlink() or path.parent.is_symlink() or not path.is_file() or path.stat().st_size != track.bytes:
                return None
        except OSError:
            return None
        return path

    def selection(self, elapsed_music_ms, now_ms, playing):
        if (type(elapsed_music_ms) is not int or not 0 <= elapsed_music_ms <= 10 ** 15 or
                type(now_ms) is not int or not 0 <= now_ms <= 10 ** 15 or type(playing) is not bool):
            raise ValueError('Invalid shared music clock')
        if not self.tracks:
            return None
        round_index, position = divmod(elapsed_music_ms, self._round_ms)
        for track in self._order(round_index):
            if position < track.duration_ms:
                return {**_metadata(track), 'audioUrl': '/music/' + track.id + '.mp3',
                        'epochMs': 0, 'gain': .35, 'positionSeconds': round(position / 1000, 3),
                        'asOfServerTime': now_ms, 'playing': playing}
            position -= track.duration_ms
        raise ValueError('Invalid shared music position')


if __name__ == '__main__':
    values = build()
    print(f'{len(values)} pinned CC0 music recordings are ready.')

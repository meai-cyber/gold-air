"""Three pinned CC0 instrumentals, selected by the shared elapsed-music clock.

Creator: HoliznaCC0. Source collection and license evidence:
https://opengameart.org/content/relaxing-instrumentals-collection
https://creativecommons.org/publicdomain/zero/1.0/

The build downloads the fixed, hash-pinned collection once and reads only the
three reviewed ZIP members. No weights, audio or private data are stored in
this source module. Runtime only reads preverified local assets. A listener
cannot choose a URL, file path, archive member or external song.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import random
import secrets
import stat
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

SOURCE_URL = 'https://opengameart.org/content/relaxing-instrumentals-collection'
LICENSE_URL = 'https://creativecommons.org/publicdomain/zero/1.0/'
ARCHIVE_URL = 'https://opengameart.org/sites/default/files/relaxing_instrumentals.zip'
ARCHIVE_BYTES = 65_584_101
ARCHIVE_SHA256 = 'ddfb641d51b82b72a0597985bf38da10cb820073c04703182b710b28f25f1db6'
MAX_ARCHIVE_BYTES = 80 * 1024 * 1024
MAX_DOWNLOAD_SECONDS = 180
ARTIST = 'HoliznaCC0'


@dataclass(frozen=True)
class Track:
    id: str
    title: str
    member: str
    bytes: int
    sha256: str
    duration_s: float

    @property
    def duration_ms(self):
        return round(self.duration_s * 1000)


TRACKS = (
    Track('night-driving', 'Night Driving', 'Relaxing Instrumentals/02 HoliznaCC0 - Night Driving.mp3',
          5_255_245, 'a0ca6a568ad101fac8a12d94679f10b4011e8c05941b5dd7fc13770fcfae598d', 131.352),
    Track('boredom', 'Boredom', 'Relaxing Instrumentals/03 HoliznaCC0 - Boredom.mp3',
          6_826_765, '5fd746ad9665243a1d050fb40c9adddface6bc52c73aede8410b3c320b878e13', 170.640),
    Track('love', 'Love', 'Relaxing Instrumentals/05 HoliznaCC0 - Love.mp3',
          7_518_925, '78adb7112521fb23ace6ac2acb58d0b8586a9ba9c621916b74e76bf93aefe50c', 187.944),
)


def _root(value):
    if not isinstance(value, (str, os.PathLike)) or '://' in str(value):
        raise ValueError('A local music asset directory is required')
    root = Path(value).resolve()
    here = Path(__file__).resolve().parent
    source = here.parents[1] if here.name == 'render-radio' and here.parent.name == 'deployment' else here
    if root == source or source in root.parents:
        raise ValueError('Music assets must remain outside the source directory')
    return root


def _metadata(track):
    return {'trackId': track.id, 'title': track.title, 'artist': ARTIST,
            'durationSeconds': track.duration_s, 'license': 'CC0 1.0',
            'sourceUrl': SOURCE_URL, 'licenseUrl': LICENSE_URL}


def _verified(path, track):
    try:
        if path.is_symlink() or path.parent.is_symlink() or not path.is_file() or path.stat().st_size != track.bytes:
            return False
        digest = hashlib.sha256()
        total = 0
        with path.open('rb') as source:
            while chunk := source.read(1024 * 1024):
                total += len(chunk)
                if total > track.bytes:
                    return False
                digest.update(chunk)
        return total == track.bytes and digest.hexdigest() == track.sha256
    except OSError:
        return False


class _PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        url = urllib.parse.urlsplit(new_url)
        if url.scheme != 'https' or url.netloc not in {'opengameart.org', 'www.opengameart.org'}:
            raise ValueError('Unexpected public music redirect')
        return super().redirect_request(request, fp, code, message, headers, new_url)


@contextmanager
def _archive_source():
    request = urllib.request.Request(ARCHIVE_URL, headers={'User-Agent': 'GoldPulse-public-music-build/1'})
    opener = urllib.request.build_opener(_PublicRedirect())
    began = time.monotonic()
    with tempfile.TemporaryFile('w+b') as temporary:
        digest, size = hashlib.sha256(), 0
        with opener.open(request, timeout=30) as response:
            if response.status != 200:
                raise ValueError('Public music archive is unavailable')
            while True:
                if time.monotonic() - began > MAX_DOWNLOAD_SECONDS:
                    raise ValueError('Public music download timed out')
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > min(MAX_ARCHIVE_BYTES, ARCHIVE_BYTES):
                    raise ValueError('Public music archive exceeds its bound')
                digest.update(chunk)
                temporary.write(chunk)
        if size != ARCHIVE_BYTES or digest.hexdigest() != ARCHIVE_SHA256:
            raise ValueError('The pinned public music archive changed')
        temporary.seek(0)
        yield temporary


def _write_member(archive, directory, track):
    matches = [entry for entry in archive.infolist() if entry.filename == track.member]
    if len(matches) != 1:
        raise ValueError('A pinned music member is missing or ambiguous')
    info = matches[0]
    if (info.is_dir() or info.file_size != track.bytes or info.flag_bits & 1 or
            stat.S_ISLNK(info.external_attr >> 16) or info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}):
        raise ValueError('Invalid pinned music member')
    target = directory / (track.id + '.mp3')
    if target.is_symlink():
        raise ValueError('Music asset aliases are unsupported')
    temporary_name = None
    try:
        with tempfile.NamedTemporaryFile('wb', dir=directory, prefix=track.id + '-', suffix='.tmp', delete=False) as output:
            temporary_name = output.name
            digest, total = hashlib.sha256(), 0
            with archive.open(info, 'r') as source:
                while chunk := source.read(1024 * 1024):
                    total += len(chunk)
                    if total > track.bytes:
                        raise ValueError('Pinned music member exceeds its bound')
                    digest.update(chunk)
                    output.write(chunk)
            if total != track.bytes or digest.hexdigest() != track.sha256:
                raise ValueError('The pinned music member changed')
        os.replace(temporary_name, target)
        temporary_name = None
    finally:
        if temporary_name is not None:
            Path(temporary_name).unlink(missing_ok=True)


def build(runtime_dir=None):
    root = _root(runtime_dir or os.environ.get('RADIO_MODEL_DIR', '/opt/gold-radio-assets'))
    directory = root / 'music'
    if directory.is_symlink():
        raise ValueError('Music asset aliases are unsupported')
    directory.mkdir(parents=True, exist_ok=True)
    missing = [track for track in TRACKS if not _verified(directory / (track.id + '.mp3'), track)]
    if missing:
        with _archive_source() as source, zipfile.ZipFile(source) as archive:
            for track in missing:
                _write_member(archive, directory, track)
    if any(not _verified(directory / (track.id + '.mp3'), track) for track in TRACKS):
        raise ValueError('Pinned music verification failed')
    attribution = {'artist': ARTIST, 'license': 'CC0 1.0', 'licenseUrl': LICENSE_URL,
                   'sourceUrl': SOURCE_URL, 'tracks': [_metadata(track) for track in TRACKS]}
    attribution_path = directory / 'ATTRIBUTION.json'
    if attribution_path.is_symlink():
        raise ValueError('Music asset aliases are unsupported')
    attribution_path.write_text(json.dumps(attribution, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    return tuple(_metadata(track) for track in TRACKS)


class MusicLibrary:
    def __init__(self, root, seed=None):
        self.root = _root(root)
        directory = self.root / 'music'
        self.tracks = tuple(track for track in TRACKS
                            if _verified(directory / (track.id + '.mp3'), track))
        self.available = tuple(_metadata(track) for track in self.tracks)
        if seed is None:
            seed = secrets.token_bytes(32)
        elif type(seed) is int and 0 <= seed < 2 ** 64:
            seed = str(seed).encode('ascii')
        elif isinstance(seed, str) and 1 <= len(seed) <= 256:
            seed = seed.encode('utf-8')
        elif isinstance(seed, bytes) and 1 <= len(seed) <= 256:
            pass
        else:
            raise ValueError('A bounded station music seed is required')
        self._seed = seed
        self._by_id = {track.id: track for track in self.tracks}
        self._round_ms = sum(track.duration_ms for track in self.tracks)

    def __len__(self):
        return len(self.tracks)

    def _base_order(self, round_index):
        order = list(self.tracks)
        digest = hashlib.sha256(self._seed + b':' + str(round_index).encode('ascii')).digest()
        random.Random(int.from_bytes(digest, 'big')).shuffle(order)
        return order

    def _order(self, round_index):
        if len(self.tracks) <= 2:
            # With two tracks the only no-repeat sequence is alternating.
            return self._base_order(0)
        current = self._base_order(round_index)
        if round_index and current[0].id == self._base_order(round_index - 1)[-1].id:
            current[0], current[1] = current[1], current[0]
        return current

    def asset(self, identifier):
        if not isinstance(identifier, str) or identifier not in self._by_id:
            return None
        track = self._by_id[identifier]
        path = self.root / 'music' / (identifier + '.mp3')
        try:
            if path.is_symlink() or path.parent.is_symlink() or not path.is_file() or path.stat().st_size != track.bytes:
                return None
        except OSError:
            return None
        return path

    def selection(self, elapsed_music_ms, now_ms, playing):
        if (type(elapsed_music_ms) is not int or not 0 <= elapsed_music_ms <= 10 ** 15 or
                type(now_ms) is not int or not 0 <= now_ms <= 10 ** 15 or type(playing) is not bool):
            raise ValueError('Invalid shared music clock')
        if not self.tracks:
            return None
        round_index, position = divmod(elapsed_music_ms, self._round_ms)
        for track in self._order(round_index):
            if position < track.duration_ms:
                return {**_metadata(track), 'audioUrl': '/music/' + track.id + '.mp3',
                        'epochMs': 0, 'gain': .35, 'positionSeconds': round(position / 1000, 3),
                        'asOfServerTime': now_ms, 'playing': playing}
            position -= track.duration_ms
        raise ValueError('Invalid shared music position')


if __name__ == '__main__':
    values = build()
    print(f'{len(values)} pinned CC0 instrumentals are ready.')

"""Offline contract fixtures; these accounts/posts are not live evidence."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import unittest
from unittest.mock import patch

from people_now import (PeopleNow, job_fresh, INTERVAL_SECONDS, TARGET_SECONDS,
                        MAX_POST_AGE_SECONDS, MAX_PARENT_AGE_SECONDS, MAX_TURN_SECONDS, MAX_INTRO_SECONDS)
from social_feedback import PINNED, publisher_root, parse_thread
from social_reactions import SOURCES, parse_mastodon


NOW = 1792936800
NOW_MS = NOW * 1000
OPINION = 'I think gold and real yields deserve a closer comparison before drawing a conclusion.'
AR_OPINION = 'برأيي، مقارنة الذهب بالعوائد الحقيقية تحتاج إلى أدلة أوضح قبل الجزم بسبب حركة السوق.'
AUTHOR_DID = 'did:plc:' + 'a' * 24


def _iso(stamp):
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat()


def reaction(key=1, username='listener', account_id='12345', age=20, text=OPINION, name=None):
    status = str(117000000000000000 + key)
    item = {'id': status, 'created_at': _iso(NOW - age),
        'url': f'https://mastodon.social/@{username}/{status}',
        'uri': f'https://mastodon.social/ap/users/{account_id}/statuses/{status}',
        'visibility': 'public', 'sensitive': False, 'spoiler_text': '', 'edited_at': None,
        'reblog': None, 'quote': None, 'poll': None, 'card': None,
        'media_attachments': [], 'tags': [{'name': 'gold'}], 'content': '<p>' + text + '</p>',
        'account': {'id': account_id, 'username': username, 'acct': username,
            'url': 'https://mastodon.social/@' + username, 'bot': False, 'locked': False,
            'discoverable': True}}
    if name is not None:
        item['account']['display_name'] = name
    return parse_mastodon(json.dumps([item], ensure_ascii=False).encode(), SOURCES[0], NOW)[0]


def reply(root_age=100, reply_age=20, text=OPINION, name=None, publisher=None, root_title=None,
          author_did=None, handle='listener.example', root_key='root123'):
    author_did = author_did or AUTHOR_DID
    publisher = publisher or next(iter(PINNED.values()))
    url = 'https://bsky.app/profile/' + publisher.did + '/post/' + root_key
    row = {'id': hashlib.sha256(('social:' + url).encode()).hexdigest()[:32],
        'url': url, 'source': publisher.source,
        'title': root_title or 'Gold prices react to new inflation figures',
        'social': True, 'sourceKind': 'social', 'platform': 'Bluesky', 'language': 'en',
        'publishedAt': NOW - root_age, 'firstSeenAt': NOW - root_age + 1,
        'timeKind': 'published', 'clockBasis': 'author-reported',
        'verification': 'unverified-public-post'}
    root = publisher_root(row, NOW)
    author = {'did': author_did, 'handle': handle}
    if name is not None:
        author['displayName'] = name
    record = {'$type': 'app.bsky.feed.post', 'createdAt': _iso(NOW - reply_age), 'text': text,
        'reply': {'root': {'uri': root['uri']}, 'parent': {'uri': root['uri']}}}
    body = {'thread': {'$type': 'app.bsky.feed.defs#threadViewPost',
        'post': {'uri': root['uri'], 'author': {'did': publisher.did, 'handle': publisher.actor},
                 'record': {'$type': 'app.bsky.feed.post', 'createdAt': _iso(row['publishedAt']),
                            'text': row['title']}},
        'replies': [{'$type': 'app.bsky.feed.defs#threadViewPost',
                     'post': {'uri': f'at://{author_did}/app.bsky.feed.post/reply123',
                              'author': author, 'record': record}}]}}
    return parse_thread(json.dumps(body, ensure_ascii=False).encode(), root, NOW)[0], row


class PeopleNowQuoteTests(unittest.TestCase):
    def test_full_exact_quote_and_handle_first_attribution_keep_original_provenance(self):
        for rows in ([reaction()], list(reply())):
            with self.subTest(kind=rows[0]['sourceKind']):
                job = PeopleNow().candidate('en', rows, NOW_MS)
                self.assertIsNotNone(job)
                self.assertEqual(job['kind'], 'people-now')
                self.assertTrue(job['speechText'].endswith(job['peopleNow']['authorHandle'] + ': “' + rows[0]['title'] + '”'))
                self.assertNotIn('individual, unverified opinion', job['speechText'])
                self.assertNotIn('does not represent public opinion', job['speechText'])
                clock = datetime.fromtimestamp(rows[0]['publishedAt'], timezone.utc).strftime('%H:%M UTC')
                self.assertNotIn(clock, job['speechText'])
                self.assertEqual(job['title'], rows[0]['title'])
                self.assertEqual(job['sources'], rows)
                self.assertEqual(job['publishedAt'], rows[0]['publishedAt'])
                self.assertEqual(job['firstSeenAt'], rows[0]['firstSeenAt'])
                self.assertEqual(job['peopleNow']['originalPublishedAt'], rows[0]['publishedAt'])
                self.assertTrue(job['peopleNow']['accountNameUnverified'])
                self.assertFalse(job['peopleNow']['representative'])
                self.assertTrue(job_fresh(job, NOW_MS + 30000))
                self.assertEqual(job['sources'][0]['sourceKind'], rows[0]['sourceKind'])
                if len(rows) == 2:
                    self.assertEqual(job['peopleNow']['rootUrl'], rows[1]['url'])
                    self.assertEqual(job['sources'][1]['publishedAt'], rows[1]['publishedAt'])
                    self.assertEqual(job['sources'][1]['firstSeenAt'], rows[1]['firstSeenAt'])

    def test_name_is_optional_guarded_account_display_name_never_verified_person(self):
        for rows in ([reaction(name='Jane Doe')], list(reply(name='Jane Doe'))):
            job = PeopleNow().candidate('en', rows, NOW_MS)
            self.assertEqual(job['peopleNow']['authorName'], 'Jane Doe')
            self.assertNotIn('Jane Doe', job['speechText'])
            self.assertTrue(job['speechText'].endswith(job['peopleNow']['authorHandle'] + ': “' + rows[0]['title'] + '”'))
            self.assertNotIn('verified person', job['speechText'])
            changed = deepcopy(job)
            changed['peopleNow']['authorName'] = 'Another Person'
            self.assertFalse(job_fresh(changed, NOW_MS))
        plain = PeopleNow().candidate('en', [reaction(name='<b>Jane Doe</b>')], NOW_MS)
        self.assertNotIn('authorName', plain['peopleNow'])
        tampered = reaction()
        tampered['reaction'].update(authorName='Jane Doe', authorNameKind='verified-person')
        self.assertIsNone(PeopleNow().candidate('en', [tampered], NOW_MS))

    def test_native_language_only_and_no_translation_or_rewriting(self):
        en, ar = reaction(), reaction(key=2, text=AR_OPINION)
        for language, row, opposite in (('en', en, ar), ('ar', ar, en)):
            planner = PeopleNow()
            self.assertIsNone(planner.candidate(language, [opposite], NOW_MS))
            job = planner.candidate(language, [opposite, row], NOW_MS)
            self.assertIn(row['title'], job['speechText'])
            self.assertNotIn(opposite['title'], job['speechText'])
            self.assertEqual(job['language'], language)
            clock = datetime.fromtimestamp(row['publishedAt'], timezone.utc).strftime('%H:%M UTC')
            self.assertNotIn(clock, job['speechText'])
            marks = ('«', '»') if language == 'ar' else ('“', '”')
            self.assertTrue(job['speechText'].endswith(job['peopleNow']['authorHandle'] + ': ' + marks[0] + row['title'] + marks[1]))
        changed = deepcopy(en)
        changed['language'] = 'ar'
        self.assertIsNone(PeopleNow().candidate('ar', [changed], NOW_MS))

    def test_v2_business_reply_keeps_exact_original_parent_context_and_quote(self):
        publisher = next(source for source in PINNED.values() if source.source == 'Bloomberg')
        root_title = 'Netflix plans more local entertainment programming for subscribers.'
        text = 'I wish Netflix focused more on better original programming.'
        row, root = reply(text=text, publisher=publisher, root_title=root_title, name='Jane Doe')
        self.assertEqual(row['feedback']['screeningKind'], 'bounded-news-opinion')
        job = PeopleNow().candidate('en', [row, root], NOW_MS)
        self.assertIsNotNone(job)
        self.assertIn(root_title.rstrip('.'), job['speechText'])
        self.assertNotIn('Jane Doe', job['speechText'])
        self.assertTrue(job['speechText'].endswith('listener.example: “' + text + '”'))
        self.assertEqual(job['sources'], [row, root])
        self.assertEqual(job['sources'][0]['feedback']['rootTitle'], root_title)
        self.assertTrue(job_fresh(job, NOW_MS + 60000))
        changed = deepcopy(root)
        changed['title'] = 'Netflix plans different local entertainment programming for subscribers.'
        self.assertIsNone(PeopleNow().candidate('en', [row, changed], NOW_MS))
        changed = deepcopy(job)
        changed['sources'][0]['feedback']['rootTitle'] = 'A replacement business headline.'
        self.assertFalse(job_fresh(changed, NOW_MS + 60000))
        # The complete native Arabic comment can air while its English parent
        # remains exact, source-bound context in metadata, outside the speech.
        ar_text = 'برأيي، نتفليكس تحتاج إلى برامج أصلية أفضل بدلا من المزيد من المنافسة.'
        ar_row, ar_root = reply(text=ar_text, publisher=publisher, root_title=root_title)
        ar_job = PeopleNow().candidate('ar', [ar_row, ar_root], NOW_MS)
        self.assertIsNotNone(ar_job)
        self.assertTrue(ar_job['speechText'].endswith('listener.example: «' + ar_text + '»'))
        self.assertNotIn(root_title, ar_job['speechText'])
        self.assertEqual(ar_job['sources'], [ar_row, ar_root])
        self.assertTrue(job_fresh(ar_job, NOW_MS + 60000))

    def test_missing_zero_or_untrusted_supply_creates_no_filler_or_progress(self):
        planner = PeopleNow()
        before = planner.status('en', NOW_MS)
        for rows in ([], [None], [{}], [reply()[1]], None, 'not a feed', {'items': []}):
            self.assertIsNone(planner.candidate('en', rows, NOW_MS))
            self.assertEqual(planner.status('en', NOW_MS), before)
        self.assertTrue(before['due'])
        self.assertFalse(before['active'])
        self.assertEqual(before['scheduledSeconds'], 0)
        self.assertEqual(before['emittedPosts'], 0)
        self.assertIsNone(before['nextDueAt'])
        row = reaction()
        row['reaction'].pop('screeningPolicy')
        self.assertIsNone(planner.candidate('en', [row], NOW_MS))

    def test_newer_posts_preferred_and_original_seen_excluded_ids_honored(self):
        newer = reaction(key=1, age=40)
        older = reaction(key=2, age=700, username='another', account_id='12346')
        planner = PeopleNow()
        first = planner.candidate('en', [older, newer], NOW_MS)
        self.assertEqual(first['sourceIds'], [newer['id']])
        for excluded in (newer['id'], newer['url'], first['id'], first['peopleNow']['sourcePostId']):
            job = planner.candidate('en', [older, newer], NOW_MS, excluded=[excluded])
            self.assertEqual(job['sourceIds'], [older['id']])
        self.assertEqual(planner.candidate('en', [older, newer], NOW_MS,
                         seen=[newer['id']])['sourceIds'], [older['id']])

    def test_short_complete_comments_take_priority_then_shorter_and_newer(self):
        short = reaction(key=1, age=700)
        long = reaction(key=2, age=20, text=' '.join([OPINION] * 4))
        short_job = PeopleNow().candidate('en', [short], NOW_MS)
        long_job = PeopleNow().candidate('en', [long], NOW_MS)
        self.assertLessEqual(short_job['estimatedSeconds'], 25)
        self.assertGreater(long_job['estimatedSeconds'], 25)
        selected = PeopleNow().candidate('en', [long, short], NOW_MS)
        self.assertEqual(selected['sourceIds'], [short['id']])
        self.assertEqual(selected['title'], OPINION)
        self.assertEqual(long_job['title'], long['title'])
        self.assertTrue(long_job['speechText'].endswith('listener@mastodon.social: “' + long['title'] + '”'))

        # Within the same freshness band the shorter complete quote wins;
        # original newness remains the tie-breaker for equal speech lengths.
        shorter = reaction(key=3, age=100, text='I think gold deserves a closer comparison before drawing a conclusion.')
        self.assertEqual(PeopleNow().candidate('en', [reaction(age=10), shorter], NOW_MS)['sourceIds'], [shorter['id']])
        older = reaction(key=4, age=100)
        newer = reaction(key=5, age=10)
        self.assertEqual(PeopleNow().candidate('en', [older, newer], NOW_MS)['sourceIds'], [newer['id']])

    def test_complete_audio_expiry_rechecks_parent_and_author_original_clocks(self):
        for rows, published, max_age in (([reaction(age=1700)], NOW - 1700, MAX_POST_AGE_SECONDS),
                                (list(reply(root_age=3500)), NOW - 3500, MAX_PARENT_AGE_SECONDS)):
            job = PeopleNow().candidate('en', rows, NOW_MS)
            self.assertIsNotNone(job)
            expiry = (published + max_age) * 1000
            self.assertTrue(job_fresh(job, expiry))
            self.assertFalse(job_fresh(job, expiry + 1))
            self.assertIsNone(PeopleNow().candidate('en', rows, expiry))
        row, root = reply()
        self.assertIsNone(PeopleNow().candidate('en', [row], NOW_MS))
        for key in ('publishedAt', 'clockBasis', 'timeKind', 'source', 'id'):
            changed = deepcopy(root)
            changed[key] = NOW if key == 'publishedAt' else 'wrong'
            self.assertIsNone(PeopleNow().candidate('en', [row, changed], NOW_MS))

    def test_fresh_reply_can_use_original_parent_from_last_hour_but_not_older(self):
        row, root = reply(root_age=31 * 60, reply_age=20)
        job = PeopleNow().candidate('en', [row, root], NOW_MS)
        self.assertIsNotNone(job)
        self.assertTrue(job_fresh(job, NOW_MS + 30000))
        self.assertEqual(job['peopleNow']['maxPostAgeSeconds'], 3600)
        self.assertEqual(job['peopleNow']['maxParentAgeSeconds'], 3600)
        planner = PeopleNow()
        self.assertEqual(planner.status('en', NOW_MS)['maxPostAgeSeconds'], 3600)
        stale = deepcopy(root)
        stale['publishedAt'] = NOW - MAX_PARENT_AGE_SECONDS - 1
        stale['firstSeenAt'] = stale['publishedAt'] + 1
        stale_reply = deepcopy(row)
        stale_reply['feedback']['rootPublishedAt'] = stale['publishedAt']
        if 'rootFirstSeenAt' in stale_reply['feedback']:
            stale_reply['feedback']['rootFirstSeenAt'] = stale['firstSeenAt']
        self.assertIsNone(planner.candidate('en', [stale_reply, stale], NOW_MS))

    def test_tampered_metadata_or_sources_and_bad_clocks_fail_closed(self):
        job = PeopleNow().candidate('en', list(reply()), NOW_MS)
        changes = (lambda j: j['peopleNow'].update(originalPublishedAt=NOW),
            lambda j: j['peopleNow'].update(authorHandle='other.example'),
            lambda j: j['peopleNow'].update(admittedAt=NOW_MS + 1),
            lambda j: j['peopleNow'].update(rootUrl='https://example.org/'),
            lambda j: j['peopleNow'].update(representative=True),
            lambda j: j['peopleNow'].update(sourceDigest='0' * 64),
            lambda j: j['sources'][0].update(publishedAt=NOW),
            lambda j: j['sources'][1].update(publishedAt=NOW),
            lambda j: j.update(speechText=j['speechText'] + ' Different words.'),
            lambda j: j.update(factualContextEligible=True))
        for change in changes:
            altered = deepcopy(job)
            change(altered)
            self.assertFalse(job_fresh(altered, NOW_MS))
        changed_admission = deepcopy(job)
        changed_admission['peopleNow']['admittedAt'] += 1
        self.assertFalse(job_fresh(changed_admission, NOW_MS + 30000))
        for at in (None, 0, True, -1, NOW, float('nan'), NOW_MS - 1):
            self.assertFalse(job_fresh(job, at))
            self.assertIsNone(PeopleNow().candidate('en', [reaction()], at))
        row = reaction()
        row['originalPublishedAt'] = NOW - 21
        self.assertIsNone(PeopleNow().candidate('en', [row], NOW_MS))

    def test_public_opinion_never_enters_the_factual_writer_prompt(self):
        from cloud_script_writer import CloudScriptWriter
        class Runtime:
            def __init__(self):
                self.calls = []
            def generate(self, prompt, **_kwargs):
                self.calls.append(prompt)
                raise RuntimeError('offline fixture')
        row = reaction()
        job = PeopleNow().candidate('en', [row], NOW_MS)
        self.assertFalse(job['factualContextEligible'])
        self.assertFalse(job['peopleNow']['factualContextEligible'])
        runtime = Runtime()
        writer = CloudScriptWriter(runtime, clock=lambda: NOW)
        self.assertFalse(writer.prepare('en', job['sources'], now_s=NOW))
        self.assertTrue(runtime.calls)
        self.assertNotIn(OPINION, json.dumps(runtime.calls))
        # Merely inspecting the planner does not invoke any writer/provider.
        with patch('urllib.request.build_opener', side_effect=AssertionError('no network')):
            self.assertIsNotNone(PeopleNow().candidate('en', [row], NOW_MS))

        publisher = next(source for source in PINNED.values() if source.source == 'Bloomberg')
        v2, _root = reply(text='I wish Netflix focused more on better original programming.',
            publisher=publisher, root_title='Netflix plans more local entertainment programming for subscribers.')
        runtime = Runtime()
        writer = CloudScriptWriter(runtime, clock=lambda: NOW)
        self.assertFalse(writer.prepare('en', [v2], now_s=NOW))
        self.assertTrue(runtime.calls)
        self.assertNotIn(v2['title'], json.dumps(runtime.calls))


class PeopleNowCadenceTests(unittest.TestCase):
    def test_ten_short_distinct_authors_fit_complete_turns_in_one_two_and_half_minute_session(self):
        # Parsed synthetic public accounts and synthetic durations only. This
        # proves planner capacity, never real supply or live 150-second speech.
        opinions = [
            'I think gold and real yields deserve a closer comparison before drawing a conclusion.',
            'I think gold and interest rates deserve a closer comparison before drawing a conclusion.',
            'I think gold and inflation deserve a closer comparison before drawing a conclusion.',
            'I think gold and currency changes deserve a closer comparison before drawing a conclusion.',
            'I think gold and market demand deserve a closer comparison before drawing a conclusion.',
            'I think gold and economic growth deserve a closer comparison before drawing a conclusion.',
            'I think gold and oil prices deserve a closer comparison before drawing a conclusion.',
            'I think gold and market uncertainty deserve a closer comparison before drawing a conclusion.',
            'I think gold and central banks deserve a closer comparison before drawing a conclusion.',
            'I think gold and bond yields deserve a closer comparison before drawing a conclusion.',
        ]
        rows = [reaction(key=index + 1, username='listener' + str(index),
            account_id=str(12345 + index), text=text, age=20 + index)
            for index, text in enumerate(opinions)]
        planner = PeopleNow()
        emitted = []
        for index in range(10):
            start = NOW_MS + index * 15000
            job = planner.candidate('en', rows, start)
            self.assertIsNotNone(job)
            self.assertLessEqual(job['estimatedSeconds'], 25)
            self.assertEqual(job['peopleNow']['turnIndex'], index)
            self.assertTrue(job['speechText'].endswith(job['peopleNow']['authorHandle'] + ': “' + job['sources'][0]['title'] + '”'))
            self.assertTrue(job_fresh(job, start + 15000))
            self.assertTrue(planner.commit(job, start, start + 15000))
            emitted.append(job['peopleNow']['authorHandle'])
        self.assertEqual(len(set(emitted)), 10)
        status = planner.status('en', NOW_MS + 150000)
        self.assertEqual(status['scheduledSeconds'], TARGET_SECONDS)
        self.assertEqual(status['emittedPosts'], 10)
        self.assertFalse(status['active'])
        self.assertEqual(status['nextDueAt'], NOW_MS + INTERVAL_SECONDS * 1000)
        self.assertIsNone(planner.candidate('en', rows, NOW_MS + 150000))

    def test_candidate_reads_and_failed_scheduling_never_advance_session(self):
        planner = PeopleNow()
        rows = [reaction()]
        before = planner.status('en', NOW_MS)
        first = planner.candidate('en', rows, NOW_MS)
        self.assertEqual(planner.candidate('en', rows, NOW_MS), first)
        self.assertEqual(planner.status('en', NOW_MS), before)
        for _ in range(3):
            self.assertTrue(planner.can_commit(first, NOW_MS, NOW_MS + 10000))
            self.assertEqual(planner.status('en', NOW_MS), before)
        self.assertFalse(planner.can_commit(first, NOW_MS, NOW_MS))
        self.assertFalse(planner.can_commit(first, NOW_MS, NOW_MS + (MAX_TURN_SECONDS + MAX_INTRO_SECONDS + 1) * 1000))
        self.assertFalse(planner.commit(first, NOW_MS, NOW_MS))
        self.assertFalse(planner.commit(first, NOW_MS, NOW_MS + (MAX_TURN_SECONDS + MAX_INTRO_SECONDS + 1) * 1000))
        self.assertFalse(planner.commit(first, NOW_MS - 1, NOW_MS + 10000))
        changed = deepcopy(first)
        changed['speechText'] += ' altered'
        self.assertFalse(planner.commit(changed, NOW_MS, NOW_MS + 10000))
        self.assertEqual(planner.status('en', NOW_MS), before)
        self.assertEqual(planner.candidate('en', rows, NOW_MS), first)

    def test_success_uses_actual_duration_and_preserves_the_fifteen_minute_start_cadence(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        start = NOW_MS + 7000
        self.assertTrue(planner.commit(first, start, start + MAX_TURN_SECONDS * 1000))
        status = planner.status('en', start + 100000)
        self.assertEqual(status['scheduledSeconds'], MAX_TURN_SECONDS)
        self.assertEqual(status['nextDueAt'], start + INTERVAL_SECONDS * 1000)
        self.assertEqual(status['emittedPosts'], 1)
        self.assertTrue(status['active'])
        self.assertFalse(planner.commit(first, start, start + MAX_TURN_SECONDS * 1000))
        second_rows = [reaction(key=2, username='another', account_id='12346')]
        at = start + 240000
        self.assertFalse(planner.status('en', at)['active'])
        self.assertFalse(planner.status('en', at)['due'])
        self.assertIsNone(planner.candidate('en', second_rows, start + 899999))
        new = planner.candidate('en', second_rows, start + 900000)
        self.assertIsNotNone(new)
        self.assertNotEqual(new['peopleNow']['sessionId'], first['peopleNow']['sessionId'])
        self.assertEqual(new['peopleNow']['turnIndex'], 0)
        self.assertTrue(planner.commit(new, start + 900000, start + 920000))
        self.assertEqual(planner.status('en', start + 920000)['scheduledSeconds'], 20)

    def test_distinct_posts_and_stable_author_identity_required_per_session(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        self.assertTrue(planner.commit(first, NOW_MS, NOW_MS + 10000))
        for row in (reaction(), reaction(key=2),
                    reaction(key=3, username='renamed', account_id='12345'),
                    reaction(key=4, username='listener', account_id='99999')):
            self.assertIsNone(planner.candidate('en', [row], NOW_MS + 10000))
        different = reaction(key=5, username='another', account_id='12346')
        job = planner.candidate('en', [different], NOW_MS + 10000)
        self.assertEqual(job['peopleNow']['turnIndex'], 1)
        self.assertTrue(planner.commit(job, NOW_MS + 10000, NOW_MS + 20000))
        self.assertEqual(planner.status('en', NOW_MS + 20000)['emittedPosts'], 2)

    def test_actual_session_budget_rejects_whole_overlong_final_quote_without_progress(self):
        planner = PeopleNow()
        elapsed = 0
        for index, duration in enumerate((35, 35, 30, 30)):
            job = planner.candidate('en', [reaction(key=index + 1,
                username='listener' + str(index), account_id=str(12345 + index))], NOW_MS + elapsed)
            self.assertTrue(planner.commit(job, NOW_MS + elapsed, NOW_MS + elapsed + duration * 1000))
            elapsed += duration * 1000
        final = planner.candidate('en', [reaction(key=5, username='another', account_id='12349')], NOW_MS + elapsed)
        self.assertIsNotNone(final)
        before = planner.status('en', NOW_MS + elapsed)
        self.assertFalse(planner.can_commit(final, NOW_MS + elapsed, NOW_MS + 150001))
        self.assertFalse(planner.commit(final, NOW_MS + elapsed, NOW_MS + 150001))
        self.assertEqual(planner.status('en', NOW_MS + elapsed), before)
        self.assertTrue(planner.commit(final, NOW_MS + elapsed, NOW_MS + 150000))
        status = planner.status('en', NOW_MS + 150000)
        self.assertEqual(status['scheduledSeconds'], TARGET_SECONDS)
        self.assertFalse(status['active'])
        self.assertFalse(status['due'])
        self.assertIsNone(planner.candidate('en', [reaction(key=3, username='third', account_id='12347')],
                                            NOW_MS + 150000))

    def test_wall_deadline_and_out_of_order_audio_reject_without_progress(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        self.assertTrue(planner.commit(first, NOW_MS, NOW_MS + 10000))
        second = planner.candidate('en', [reaction(key=2, username='another', account_id='12346')], NOW_MS + 1000)
        self.assertIsNotNone(second)
        before = planner.status('en', NOW_MS + 1000)
        self.assertFalse(planner.commit(second, NOW_MS + 9000, NOW_MS + 19000))
        self.assertFalse(planner.commit(second, NOW_MS + 239000, NOW_MS + 241000))
        self.assertEqual(planner.status('en', NOW_MS + 1000), before)
        self.assertIsNone(planner.candidate('en', [reaction(key=2)], NOW_MS + 240000))

    def test_language_sessions_are_independent(self):
        planner = PeopleNow()
        english = planner.candidate('en', [reaction()], NOW_MS)
        self.assertTrue(planner.commit(english, NOW_MS, NOW_MS + 10000))
        arabic = planner.candidate('ar', [reaction(key=2, text=AR_OPINION)], NOW_MS)
        self.assertEqual(arabic['peopleNow']['turnIndex'], 0)
        self.assertTrue(planner.commit(arabic, NOW_MS, NOW_MS + 15000))
        self.assertEqual(planner.status('en', NOW_MS)['scheduledSeconds'], 10)
        self.assertEqual(planner.status('ar', NOW_MS)['scheduledSeconds'], 15)

    def test_shift_before_first_future_slot_moves_actual_cadence_without_speech_credit(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        start = NOW_MS + 6000
        self.assertTrue(planner.commit(first, start, start + 10000))
        before = planner.status('en', NOW_MS)
        for _ in range(3):
            self.assertTrue(planner.can_shift_future('en', start, 10000, NOW_MS))
            self.assertEqual(planner.status('en', NOW_MS), before)
        self.assertTrue(planner.shift_future('en', start, 10000, NOW_MS))
        after = planner.status('en', NOW_MS)
        self.assertEqual(after['sessionStartedAt'], start + 10000)
        self.assertEqual(after['nextDueAt'], start + 10000 + 900000)
        self.assertEqual(after['scheduledSeconds'], before['scheduledSeconds'])
        self.assertEqual(after['emittedPosts'], before['emittedPosts'])
        next_rows = [reaction(key=2, username='another', account_id='12346')]
        self.assertIsNone(planner.candidate('en', next_rows, start + 900000))
        self.assertIsNotNone(planner.candidate('en', next_rows, after['nextDueAt']))

    def test_shift_between_quotes_preserves_first_start_and_updates_tail(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        self.assertTrue(planner.commit(first, NOW_MS, NOW_MS + 20000))
        second = planner.candidate('en', [reaction(key=2, username='another', account_id='12346')], NOW_MS + 1000)
        self.assertTrue(planner.commit(second, NOW_MS + 20000, NOW_MS + 40000))
        before = planner.status('en', NOW_MS + 1000)
        self.assertTrue(planner.shift_future('en', NOW_MS + 20000, 10000, NOW_MS + 1000))
        after = planner.status('en', NOW_MS + 1000)
        self.assertEqual(after['sessionStartedAt'], NOW_MS)
        self.assertEqual(after['nextDueAt'], before['nextDueAt'])
        self.assertEqual(after['scheduledSeconds'], 40)
        third = planner.candidate('en', [reaction(key=3, username='third', account_id='12347')], NOW_MS + 1000)
        self.assertFalse(planner.can_commit(third, NOW_MS + 40000, NOW_MS + 50000))
        self.assertTrue(planner.can_commit(third, NOW_MS + 50000, NOW_MS + 60000))

    def test_invalid_or_wall_overrun_shift_fails_without_mutation(self):
        planner = PeopleNow()
        first = planner.candidate('en', [reaction()], NOW_MS)
        self.assertTrue(planner.commit(first, NOW_MS, NOW_MS + 10000))
        second = planner.candidate('en', [reaction(key=2, username='another', account_id='12346')], NOW_MS + 1000)
        self.assertTrue(planner.commit(second, NOW_MS + 220000, NOW_MS + 240000))
        before = planner.status('en', NOW_MS + 1000)
        for language, start, delta, now in (('en', NOW_MS + 10000, 1, NOW_MS + 1000),
                ('en', NOW_MS + 5000, 1000, NOW_MS + 1000),
                ('en', NOW_MS, 1000, NOW_MS + 1000),
                ('en', NOW_MS + 10000, 0, NOW_MS + 1000),
                ('en', NOW_MS + 10000, -1, NOW_MS + 1000),
                ('en', NOW_MS + 10000, True, NOW_MS + 1000),
                ('en', NOW_MS + 10000, 90001, NOW_MS + 1000),
                ('fr', NOW_MS + 10000, 1000, NOW_MS + 1000)):
            self.assertFalse(planner.can_shift_future(language, start, delta, now))
            self.assertFalse(planner.shift_future(language, start, delta, now))
            self.assertEqual(planner.status('en', NOW_MS + 1000), before)
        # An insertion after the entire session is an honest no-op.
        self.assertTrue(planner.shift_future('en', NOW_MS + 241000, 10000, NOW_MS + 1000))
        self.assertEqual(planner.status('en', NOW_MS + 1000), before)
        self.assertTrue(PeopleNow().shift_future('ar', NOW_MS + 10000, 1000, NOW_MS))


if __name__ == '__main__':
    unittest.main()

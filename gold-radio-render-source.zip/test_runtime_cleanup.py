import json
import os
import stat
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from runtime_cleanup import clean_audio
import server


class RuntimeCleanupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.station = server.Station(self.temp.name)
        self.addCleanup(self.station.stop.set)
        self.root = self.station.directory
        self.now = int(time.time() * 1000)

    def file(self, name, age=600, body=b'old-audio', root=None):
        path = (root or self.root) / name
        path.write_bytes(body)
        stamp = self.now / 1000 - age
        os.utime(path, (stamp, stamp))
        return path

    def test_only_expired_unreferenced_generated_pairs_are_removed_and_counted(self):
        old = [self.file('a' * 32 + '.' + ext) for ext in ('wav', 'mp3')]
        active = self.file('b' * 32 + '.mp3')
        future = self.file('c' * 32 + '.wav')
        recent = self.file('d' * 32 + '.wav', age=30)
        self.station.queues['ar'] = [{'id': 'b' * 32, 'startsAt': self.now - 1000, 'endsAt': self.now + 60000}]
        self.station.queues['en'] = [{'id': 'c' * 32, 'startsAt': self.now + 60000, 'endsAt': self.now + 90000}]
        result = self.station.cleanup_once(self.now)
        self.assertTrue(all(not p.exists() for p in old))
        self.assertTrue(all(p.exists() for p in (active, future, recent)))
        self.assertEqual(result['filesDeleted'], 2)
        self.assertEqual(result['bytesDeleted'], 2 * len(b'old-audio'))
        self.assertEqual(result['lastRunAt'], self.now)
        self.assertEqual(self.station.cleanup_once(self.now)['filesDeleted'], 2, 'repeated passes do not count old deletions twice')

    def test_provider_ledgers_credentials_music_and_unknown_history_are_never_deleted(self):
        protected = [self.file(name) for name in ('budget.json', 'station-relax-v2.wav',
            'owner-recording.wav', 'provider.key', 'old-news.json', 'a' * 32 + '.txt')]
        provider = self.root / 'nvidia-llm'; provider.mkdir()
        ledger = self.file('budget.json', body=b'{"attempts":123}', root=provider)
        nested = provider / ('a' * 32 + '.wav'); nested.write_bytes(b'outside-owned-audio-scope')
        self.station.cleanup_once(self.now)
        self.assertTrue(all(p.exists() for p in protected))
        self.assertEqual(ledger.read_bytes(), b'{"attempts":123}')
        self.assertTrue(nested.exists())

    def test_recently_finished_audio_and_future_old_mtime_remain_readable(self):
        now = self.now
        for identifier in ('a' * 32, 'b' * 32):
            self.file(identifier + '.wav', body=b'RIFF' + b'0' * 64)
        self.station.queues['ar'] = [{'id': 'a' * 32, 'startsAt': now - 70000, 'endsAt': now - 10000},
            {'id': 'b' * 32, 'startsAt': now + 60000, 'endsAt': now + 70000}]
        self.station.cleanup_once(now)
        self.assertIsNotNone(self.station.audio('a' * 32))
        self.assertTrue((self.root / ('a' * 32 + '.wav')).exists())
        self.assertTrue((self.root / ('b' * 32 + '.wav')).exists())
        self.station.cleanup_once(now + 200000)
        self.assertFalse((self.root / ('a' * 32 + '.wav')).exists())
        self.assertFalse((self.root / ('b' * 32 + '.wav')).exists())

    def test_podcast_cache_expiration_and_unindexed_restart_orphans(self):
        cache = self.station.podcast_cache_directory
        old = self.file('a' * 64 + '.wav', age=90000, root=cache)
        orphan = self.file('b' * 64 + '.wav', root=cache)
        used = self.file('c' * 64 + '.wav', root=cache)
        fresh_orphan = self.file('d' * 64 + '.wav', age=30, root=cache)
        self.station.podcast_cache = {
            'a' * 64: {'bytes': old.stat().st_size, 'touchedAt': self.now - 90000000},
            'c' * 64: {'bytes': used.stat().st_size, 'touchedAt': self.now - 1000}}
        result = self.station.cleanup_once(self.now)
        self.assertFalse(old.exists()); self.assertFalse(orphan.exists())
        self.assertTrue(used.exists()); self.assertTrue(fresh_orphan.exists())
        self.assertNotIn('a' * 64, self.station.podcast_cache)
        self.assertIn('c' * 64, self.station.podcast_cache)
        self.assertEqual(result['filesDeleted'], 2)

    def test_cache_trims_by_last_use_to_existing_byte_budget(self):
        cache = self.station.podcast_cache_directory
        for index, key in enumerate(('a' * 64, 'b' * 64)):
            self.file(key + '.wav', body=b'old', root=cache)
            self.station.podcast_cache[key] = {'bytes': 3, 'touchedAt': self.now - (2 - index) * 1000}
        with patch.object(server, 'PODCAST_CACHE_BYTES', 4):
            self.station.cleanup_once(self.now)
        self.assertNotIn('a' * 64, self.station.podcast_cache)
        self.assertIn('b' * 64, self.station.podcast_cache)

    def test_expired_metadata_is_removed_without_relabelling_source_clocks(self):
        self.station.people_recent['ar'] = [{'id': 'old', 'generatedAt': self.now - 901000},
            {'id': 'recent', 'generatedAt': self.now - 1000}]
        original = self.now // 1000 - 3601
        self.station.stories = {'a' * 32: {'id': 'a' * 32, 'language': 'en', 'title': 'Gold prices',
            'source': 'BBC', 'url': 'https://www.bbc.com/news', 'publishedAt': original,
            'originalPublishedAt': original, 'firstSeenAt': original + 1,
            'sourceKind': 'publisher-rss', 'clockBasis': 'publisher-rss-publication',
            'publicationField': 'pubdate', 'originalPublicationVerified': True}}
        self.station.people_translation_retry = {'a' * 32: self.now // 1000 + 60}
        self.station.cleanup_once(self.now)
        self.assertEqual([q['id'] for q in self.station.people_recent['ar']], ['recent'])
        self.assertEqual(self.station.stories, {})
        self.assertEqual(self.station.people_translation_retry, {})
        self.assertEqual(json.loads((self.root / 'receipts.json').read_text('utf-8'))['stories'], [])

    def test_permission_error_is_reported_and_other_expired_files_are_still_cleaned(self):
        locked = self.file('a' * 32 + '.wav'); normal = self.file('b' * 32 + '.mp3')
        unlink = Path.unlink
        def remove(path, *args, **kwargs):
            if path == locked:
                raise PermissionError('test-only locked audio')
            return unlink(path, *args, **kwargs)
        with patch.object(Path, 'unlink', remove):
            result = self.station.cleanup_once(self.now)
        self.assertTrue(locked.exists()); self.assertFalse(normal.exists())
        self.assertEqual(result['errors'], 1)
        self.assertIsNotNone(result['lastError'])
        self.station.cleanup_once(self.now + 60000)
        self.assertFalse(locked.exists())
        self.assertIsNone(self.station.cleanup_state['lastError'])

    def test_root_alias_or_parent_alias_is_rejected(self):
        old = self.file('a' * 32 + '.wav')
        real_is_symlink = Path.is_symlink
        with patch.object(Path, 'is_symlink', lambda p: p == self.root or real_is_symlink(p)):
            result = clean_audio(self.root, set(), self.now / 1000)
        self.assertTrue(old.exists()); self.assertEqual(result['errors'], 1)

    def test_linked_children_and_subdirectories_cannot_escape_cleanup_scope(self):
        outside = self.file('outside.wav')
        link = self.root / ('a' * 32 + '.wav')
        try:
            link.symlink_to(outside)
        except OSError:
            self.skipTest('OS does not permit unprivileged symbolic links')
        nested = self.root / ('b' * 32 + '.wav'); nested.mkdir()
        (nested / 'private.txt').write_text('keep')
        self.station.cleanup_once(self.now)
        self.assertTrue(outside.exists()); self.assertTrue(link.is_symlink())
        self.assertTrue((nested / 'private.txt').exists())

    def test_nonregular_child_is_skipped_without_following_its_target(self):
        path = self.file('a' * 32 + '.wav')
        lstat = Path.lstat
        def inspect(p):
            if p == path:
                return SimpleNamespace(st_mode=stat.S_IFLNK | 0o777, st_mtime=self.now / 1000 - 600, st_size=9)
            return lstat(p)
        with patch.object(Path, 'lstat', inspect):
            result = clean_audio(self.root, set(), self.now / 1000)
        self.assertEqual(result['filesDeleted'], 0)
        self.assertTrue(path.exists())

    def test_maintenance_runs_without_tts_and_retries_at_the_regular_interval(self):
        class Stop:
            def __init__(self): self.waits = []
            def is_set(self): return len(self.waits) >= 2
            def wait(self, interval): self.waits.append(interval)
            def set(self): pass
        self.station.stop = Stop()
        with patch.object(self.station, 'cleanup_once', side_effect=[OSError('test'), {}]) as clean:
            self.station.maintain()
        self.assertEqual(clean.call_count, 2)
        self.assertEqual(self.station.stop.waits, [60, 60])

    def test_start_includes_independent_cleanup_worker(self):
        targets = []
        class Thread:
            def __init__(self, *, target, daemon): targets.append(target)
            def start(self): pass
        with patch.object(server.threading, 'Thread', Thread):
            self.station.start()
        self.assertIn(self.station.maintain, targets)
        self.assertIn(self.station.generate, targets)


if __name__ == '__main__':
    unittest.main()

"""Bounded public replies to already collected, pinned publisher posts.

Only first-level replies to the four existing Bluesky publisher identities are
read. No search, account login, arbitrary URL, private thread, engagement-based
ranking, or public-consensus inference is performed. Basic contact/link, abuse
and promotion screening is deliberately conservative; it is not a guarantee
that a public claim is true or that every personal detail can be recognised.
Protocol: https://bsky.network/docs/bluesky-api/viewing-threads/
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, wait
import hashlib
from itertools import islice
import json
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

from news_selection import relevance, normalized_title
from social_sources import SOURCES, Response, clean_text, _next_delay, _stamp


MAX_BYTES = 512 * 1024
MAX_ROOTS = 64
MAX_REPLIES = 100
MAX_RECEIPTS = 512
MAX_AGE_S = 7200
POLL_SECONDS = 60
COLLECTION_BUDGET_S = 8
MAX_WORKERS = 2
ENDPOINT = 'https://public.api.bsky.app/xrpc/app.bsky.feed.getPostThread'
PINNED = {source.did: source for source in SOURCES if source.platform == 'Bluesky'}
_DID = r'did:(?:plc:[a-z2-7]{24}|web:[a-z0-9.-]{1,96})'
_POST_URI = re.compile(r'at://(' + _DID + r')/app\.bsky\.feed\.post/([a-zA-Z0-9]{1,32})')
_HANDLE = re.compile(r'(?=.{3,96}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}')
_CONTACT = re.compile(
    r'https?://|www\.|[\w.+-]+@[\w.-]+\.[a-z]{2,}|(?<!\w)(?:[a-z0-9-]+\.)+[a-z]{2,}(?:/|\b)|'
    r'\+\d(?:[ ()-]?\d){7,14}|\b\d{3}[-. ]\d{3}[-. ]\d{4}\b|\b\d{10,15}\b|'
    r'\b\d{1,5}\s+\w+(?:\s+\w+){0,2}\s+(?:street|road|avenue|drive)\b|'
    r'my address|call me|text me|contact me|whatsapp|telegram|discord|direct message|'
    r'عنواني|رقم هاتفي|رقم جوالي|اتصل بي|راسلني|واتساب|تلغرام|تليجرام', re.I)
_ABUSE = re.compile(
    r'(?<!\w)(?:fuck\w*|shit\w*|cunt\w*|asshole\w*|morons?|idiots?|'
    r'kill them|kill all|death to|كس ام\w*|كسم\w*|ابن الكلب|ابن كلب|احمق|حمير)(?!\w)', re.I)
_PROMO = re.compile(
    r'giveaway|airdrop|promo code|discount code|guaranteed.{0,20}(?:profit|return)|'
    r'(?:join|follow|subscribe|message).{0,25}(?:me|my|our|channel|signals?)|'
    r'ارباح مضمونة|ربح مضمون|توصيات مجانية|اشترك الان|اشتركوا الان|كود خصم', re.I)


def publisher_root(row, now_s):
    """Derive one fixed publisher identity from an existing collector row."""
    if (not isinstance(row, dict) or row.get('platform') != 'Bluesky' or row.get('social') is not True or
            row.get('sourceKind') != 'social' or type(row.get('publishedAt')) is not int or
            type(row.get('firstSeenAt')) is not int or
            not 0 < row['publishedAt'] <= row['firstSeenAt'] <= now_s or
            now_s - row['publishedAt'] > MAX_AGE_S):
        return None
    url = row.get('url')
    if not isinstance(url, str):
        return None
    for did, source in PINNED.items():
        match = re.fullmatch(re.escape('https://bsky.app/profile/' + did + '/post/') + r'([a-zA-Z0-9]{1,32})', url)
        if match and row.get('source') == source.source:
            expected_id = hashlib.sha256(('social:' + url).encode()).hexdigest()[:32]
            if row.get('id') != expected_id:
                return None
            uri = f'at://{did}/app.bsky.feed.post/{match[1]}'
            return {'uri': uri, 'source': source, 'row': dict(row)}
    return None


def thread_url(uri):
    match = _POST_URI.fullmatch(uri) if isinstance(uri, str) else None
    if not match or match[1] not in PINNED:
        raise ValueError('Unsupported public feedback root')
    return ENDPOINT + '?' + urllib.parse.urlencode({'uri': uri, 'depth': 1, 'parentHeight': 0})


def _allowed_url(url):
    try:
        parsed = urllib.parse.urlsplit(url)
        query = urllib.parse.parse_qs(parsed.query, strict_parsing=True)
        if (parsed.scheme != 'https' or parsed.netloc != 'public.api.bsky.app' or
                parsed.path != '/xrpc/app.bsky.feed.getPostThread' or parsed.fragment or
                set(query) != {'uri', 'depth', 'parentHeight'} or
                query['depth'] != ['1'] or query['parentHeight'] != ['0'] or len(query['uri']) != 1):
            return False
        return url == thread_url(query['uri'][0])
    except (ValueError, TypeError, KeyError):
        return False


def _safe_text(raw):
    if not isinstance(raw, str) or not 40 <= len(raw) <= 400 or _CONTACT.search(raw):
        return ''
    text = clean_text(raw)
    folded = normalized_title(text)
    if (len(text) < 40 or len(text.split()) < 6 or _ABUSE.search(folded) or
            _PROMO.search(folded) or relevance(text)[0] < 25):
        return ''
    return text


def parse_thread(body, root, received_s):
    if not isinstance(body, bytes) or len(body) > MAX_BYTES or b'\x00' in body:
        raise ValueError('Public feedback body limit')
    data = json.loads(body.decode('utf-8', errors='strict'))
    thread = data.get('thread') if isinstance(data, dict) else None
    if not isinstance(thread, dict) or thread.get('$type') not in (None, 'app.bsky.feed.defs#threadViewPost'):
        raise ValueError('Public thread is blocked or missing')
    post = thread.get('post')
    source, row = root['source'], root['row']
    if (not isinstance(post, dict) or post.get('uri') != root['uri'] or post.get('labels') or
            not isinstance(post.get('author'), dict) or post['author'].get('did') != source.did or
            post['author'].get('handle') != source.actor or post['author'].get('labels') or
            not isinstance(post.get('record'), dict) or
            _stamp(post['record'].get('createdAt')) != row['publishedAt']):
        raise ValueError('Public feedback root identity changed')
    replies = thread.get('replies', [])
    if not isinstance(replies, list):
        raise ValueError('Invalid public feedback replies')
    rows, seen = [], set()
    for reply in replies[:MAX_REPLIES]:
        if (not isinstance(reply, dict) or reply.get('$type') not in (None, 'app.bsky.feed.defs#threadViewPost') or
                not isinstance(reply.get('post'), dict)):
            continue
        post = reply['post']
        author, record = post.get('author'), post.get('record')
        if (post.get('labels') or not isinstance(author, dict) or author.get('labels') or
                not isinstance(record, dict) or record.get('$type') != 'app.bsky.feed.post' or record.get('embed')):
            continue
        did, handle = author.get('did'), author.get('handle')
        uri = post.get('uri')
        match = _POST_URI.fullmatch(uri) if isinstance(uri, str) else None
        if (not match or did != match[1] or not isinstance(handle, str) or not _HANDLE.fullmatch(handle) or
                did in PINNED or uri in seen):
            continue
        relation = record.get('reply')
        if (not isinstance(relation, dict) or not isinstance(relation.get('root'), dict) or
                not isinstance(relation.get('parent'), dict) or relation['root'].get('uri') != root['uri'] or
                relation['parent'].get('uri') != root['uri']):
            continue
        try:
            published = _stamp(record.get('createdAt'))
        except (ValueError, TypeError, OverflowError):
            continue
        if not row['publishedAt'] <= published <= received_s or received_s - published > MAX_AGE_S:
            continue
        text = _safe_text(record.get('text'))
        if not text:
            continue
        arabic = sum('\u0600' <= character <= '\u06ff' and character.isalpha() for character in text)
        latin = sum('a' <= character.lower() <= 'z' for character in text)
        language = 'ar' if arabic >= 8 and arabic > latin else 'en' if latin >= 12 and latin > arabic else None
        if language is None:
            continue
        if language == 'en' and any(character.isalpha() and 'LATIN' not in unicodedata.name(character, '')
                                    for character in text):
            # Match the English speech contract; never rewrite an author's
            # mixed-script statement into a different claim to make it speak.
            continue
        attribution = (f'تعليق @{handle} على {source.source}' if language == 'ar' else
                       f'Reply @{handle} to {source.source}')
        if len(attribution) > 160:
            continue
        seen.add(uri)
        rows.append({'id': hashlib.sha256(('social-feedback:' + uri).encode()).hexdigest()[:32],
            'title': text, 'summary': '', 'source': attribution, 'language': language,
            'url': 'https://bsky.app/profile/' + did + '/post/' + match[2],
            'publishedAt': published, 'firstSeenAt': received_s,
            'social': True, 'sourceKind': 'social-feedback', 'platform': 'Bluesky', 'timeKind': 'published',
            'clockBasis': 'author-reported', 'verification': 'unverified-public-reply',
            'feedback': {'authorHandle': handle, 'authorDid': did, 'rootSource': source.source,
                         'rootUrl': row['url'], 'rootId': row['id'], 'rootPublishedAt': row['publishedAt'],
                         'rootUri': root['uri'], 'replyUri': uri, 'unverified': True, 'representative': False}})
    return rows


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        return None


def fetch_public(url, _headers, timeout):
    if not _allowed_url(url) or not isinstance(timeout, (int, float)) or not 0 < timeout <= COLLECTION_BUDGET_S:
        raise ValueError('Unsupported public feedback request')
    headers = {'User-Agent': 'GoldPulse/1.0 public-feedback-reader', 'Accept': 'application/json',
               'Accept-Encoding': 'identity'}
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    deadline = time.monotonic() + timeout
    try:
        response = opener.open(urllib.request.Request(url, headers=headers), timeout=timeout)
    except urllib.error.HTTPError as error:
        return Response(error.code, dict(error.headers.items()), b'', url)
    with response:
        values = {key.lower(): value for key, value in response.headers.items()}
        size = values.get('content-length')
        if (values.get('content-encoding', 'identity') != 'identity' or
                size and (not size.isdecimal() or int(size) > MAX_BYTES)):
            raise ValueError('Public feedback body limit')
        parts, total = [], 0
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Public feedback deadline')
            socket = getattr(getattr(response.fp, 'raw', None), '_sock', None)
            if socket is not None:
                socket.settimeout(max(.1, deadline - time.monotonic()))
            block = response.read1(min(65536, MAX_BYTES + 1 - total))
            if not block:
                break
            total += len(block)
            if total > MAX_BYTES:
                raise ValueError('Public feedback body limit')
            parts.append(block)
        return Response(response.status, values, b''.join(parts), response.url)


class SocialFeedbackCollector:
    def __init__(self, fetcher=None):
        self._fetcher = fetcher or fetch_public
        self._lock, self._collect_lock = threading.RLock(), threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix='public-feedback')
        self._states, self._receipts, self._pending = {}, {}, {}
        self._next_poll = 0
        self._status = {'status': 'starting', 'checkedAt': 0, 'lastSuccessAt': 0,
                        'rootsAvailable': 0, 'threadsChecked': 0, 'acceptedReplies': 0,
                        'errors': 0, 'httpStatus': None}

    def status(self):
        with self._lock:
            return {**self._status, 'nextCheckAt': self._next_poll * 1000,
                    'pendingRequests': len(self._pending), 'publisherIdentities': len(PINNED),
                    'transport': 'Public Bluesky direct replies; no login; no PC',
                    'verification': 'Unverified individual replies, not a representative opinion sample'}

    def _request(self, root, now_s, real_clock, deadline):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Public feedback deadline')
        url = thread_url(root['uri'])
        response = self._fetcher(url, {}, min(COLLECTION_BUDGET_S, remaining))
        if (not isinstance(response, Response) or response.url != url or not isinstance(response.body, bytes) or
                len(response.body) > MAX_BYTES or time.monotonic() > deadline):
            raise ValueError('Invalid public feedback response')
        headers = {key.lower(): value for key, value in response.headers.items()}
        if response.status == 200:
            if 'application/json' not in headers.get('content-type', '').lower():
                raise ValueError('Unexpected public feedback type')
            received = int(time.time()) if real_clock else now_s
            rows = parse_thread(response.body, root, received)
        else:
            rows = []
        return response.status, headers, rows

    def collect(self, stories, now_s=None):
        real_clock = now_s is None
        now_s = int(time.time()) if real_clock else now_s
        if type(now_s) is not int or now_s <= 0 or isinstance(stories, (str, bytes, dict)):
            raise ValueError('A valid public-story sample and clock are required')
        if not self._collect_lock.acquire(blocking=False):
            return []
        try:
            with self._lock:
                if now_s < self._next_poll:
                    return []
                self._next_poll = now_s + POLL_SECONDS
            try:
                material = list(islice(iter(stories), 1000))
            except TypeError:
                raise ValueError('Expected collected public stories') from None
            roots = [root for row in material if (root := publisher_root(row, now_s))]
            roots.sort(key=lambda root: (-root['row']['publishedAt'], root['uri']))
            roots = list({root['uri']: root for root in roots}.values())[:MAX_ROOTS]
            deadline, result = time.monotonic() + COLLECTION_BUDGET_S, []
            with self._lock:
                self._pending = {uri: future for uri, future in self._pending.items() if not future.done()}
                current = {root['uri'] for root in roots}
                self._states = {uri: state for uri, state in self._states.items() if uri in current or uri in self._pending}
                self._status.update(checkedAt=now_s * 1000, rootsAvailable=len(roots), acceptedReplies=0,
                                    status='waiting' if not roots else 'ready')
                due = [root for root in roots if root['uri'] not in self._pending and
                       now_s >= self._states.get(root['uri'], {}).get('nextAt', 0)]
                due.sort(key=lambda root: self._states.get(root['uri'], {}).get('nextAt', 0))
                due = due[:max(0, MAX_WORKERS - len(self._pending))]
                jobs = {}
                for root in due:
                    future = self._pool.submit(self._request, root, now_s, real_clock, deadline)
                    jobs[future] = root
                    self._pending[root['uri']] = future
            done, _ = wait(jobs, timeout=max(0, deadline - time.monotonic()))
            finished = int(time.time()) if real_clock else now_s
            with self._lock:
                for future, root in jobs.items():
                    status, headers = None, {}
                    previous = self._states.get(root['uri'], {})
                    failures = previous.get('failures', 0)
                    try:
                        if future not in done:
                            future.cancel()
                            raise TimeoutError('Public feedback deadline')
                        status, headers, rows = future.result()
                        if status != 200:
                            raise ValueError('Public feedback unavailable')
                        self._states[root['uri']] = {'nextAt': finished + _next_delay(headers, finished, status=status), 'failures': 0}
                        self._status.update(status='ready', lastSuccessAt=finished * 1000, httpStatus=status,
                                            threadsChecked=self._status['threadsChecked'] + 1)
                        for row in rows:
                            old = self._receipts.get(row['id'])
                            if old and (old[1] != row['publishedAt'] or old[2] != row['feedback']['rootUri']):
                                continue
                            if old:
                                row['firstSeenAt'] = old[0]
                            self._receipts[row['id']] = (row['firstSeenAt'], row['publishedAt'], row['feedback']['rootUri'])
                            result.append(row)
                    except Exception:
                        delay = _next_delay(headers, finished, failures + 1, status)
                        self._states[root['uri']] = {'nextAt': finished + delay, 'failures': failures + 1}
                        self._status.update(status='access_denied' if status in (401, 403) else
                                            'rate_limited' if status == 429 else 'unavailable',
                                            httpStatus=status, errors=self._status['errors'] + 1,
                                            threadsChecked=self._status['threadsChecked'] + 1)
                        if status in (401, 403, 429):
                            self._next_poll = max(self._next_poll, finished + delay)
                    if future.done():
                        self._pending.pop(root['uri'], None)
                self._receipts = dict(sorted(((key, value) for key, value in self._receipts.items()
                    if finished - value[1] <= MAX_AGE_S), key=lambda pair: pair[1][0], reverse=True)[:MAX_RECEIPTS])
                self._status['acceptedReplies'] = len(result)
            return result
        finally:
            self._collect_lock.release()

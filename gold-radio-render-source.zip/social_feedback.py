"""Bounded public replies to already collected, pinned publisher posts.

Only first-level replies to the five approved worldwide publisher identities are
read. Fresh financial opinions pass the original conservative rule gate. A
separately versioned gate admits bounded consumer/business opinions on matching
Bloomberg/CNBC business posts; it does not admit purported news or allegations. No search,
account login, arbitrary URL, private thread, engagement-based ranking, or
public-consensus inference is performed. This screening is not independent fact
verification or a guarantee that every personal detail can be recognised.
Protocol: https://bsky.network/docs/bluesky-api/viewing-threads/
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, wait
import hashlib
from itertools import islice
import json
import re
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

from news_selection import relevance, normalized_title
from social_sources import SOURCES, Response, clean_text, _next_delay, _stamp
from source_policy import collection_url_allowed


MAX_BYTES = 512 * 1024
MAX_ROOTS = 64
MAX_REPLIES = 100
MAX_RECEIPTS = 512
MAX_AGE_S = 3600
POLL_SECONDS = 60
COLLECTION_BUDGET_S = 8
MAX_WORKERS = 2
ENDPOINT = 'https://public.api.bsky.app/xrpc/app.bsky.feed.getPostThread'
REACTION_POLICY_VERSION = 'financial-opinion-only-2026-10-25-v1'
NEWS_OPINION_POLICY_VERSION = 'bounded-news-opinion-2026-10-25-v2'
PINNED = {source.did: source for source in SOURCES if source.platform == 'Bluesky'}
BUSINESS_PUBLISHERS = frozenset({
    'did:plc:uewxgchsjy4kmtu7dcxa77us',  # Existing pinned Bloomberg account.
    'did:plc:m7ks2xhfuku7errrtfjux2lg',  # Existing pinned CNBC account.
})
_DID = r'did:(?:plc:[a-z2-7]{24}|web:[a-z0-9.-]{1,96})'
_POST_URI = re.compile(r'at://(' + _DID + r')/app\.bsky\.feed\.post/([a-zA-Z0-9]{1,32})')
_HANDLE = re.compile(r'(?=.{3,96}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}')
_CONTACT = re.compile(
    r'https?://|www\.|[\w.+-]+@[\w.-]+\.[a-z]{2,}|(?<!\w)(?:[a-z0-9-]+\.)+[a-z]{2,}(?:/|\b)|'
    r'\+\d(?:[ ()-]?\d){7,14}|\b\d{3}[-. ]\d{3}[-. ]\d{4}\b|\b\d{10,15}\b|'
    r'\b\d{1,5}\s+\w+(?:\s+\w+){0,2}\s+(?:street|road|avenue|drive)\b|'
    r'my address|call me|text me|contact me|whatsapp|telegram|discord|direct message|'
    r'عنواني|رقم هاتفي|رقم جوالي|اتصل بي|راسلني|واتساب|تلغرام|تليجرام', re.I)
_ABUSE = re.compile(
    r'(?<!\w)(?:fuck\w*|shit\w*|cunt\w*|asshole\w*|morons?|idiots?|'
    r'kill them|kill all|death to|كس ام\w*|كسم\w*|ابن الكلب|ابن كلب|احمق|حمير)(?!\w)', re.I)
_PROMO = re.compile(
    r'giveaway|airdrop|promo code|discount code|guaranteed.{0,20}(?:profit|return)|'
    r'(?:join|follow|subscribe|message).{0,25}(?:me|my|our|channel|signals?)|'
    r'ارباح مضمونة|ربح مضمون|توصيات مجانية|اشترك الان|اشتركوا الان|كود خصم', re.I)

_FINANCIAL_TOPIC = re.compile(
    r'(?<!\w)(?:gold|bullion|oil|crude|inflation|real yields?|interest rates?|central banks?|'
    r'dollar|currenc(?:y|ies)|bonds?|[وف]?(?:ال)?(?:ذهب|نفط|تضخم|فائدة|فوائد|عوائد|دولار|عملات))(?!\w)', re.I)
_OPINION_CUE = re.compile(
    r'(?<!\w)(?:i think|i feel|i wonder|i would|i m (?:concerned|unsure|watching)|'
    r'in my view|for me|my (?:view|concern|worry)|seems? to me|could|might|may|'
    r'deserves?|needs?|worth watching|matter(?:s)?|uncertain(?:ty)?|'
    r'[وف]?(?:اري|برايي|اعتقد|اتساءل|ربما|قد|يحتاج|تحتاج|ينبغي|افضل|مقارنة|عدم اليقين))(?!\w)', re.I)
# A first-person hedge does not turn a purported new fact, allegation or
# financial recommendation into an eligible public reaction.
_CLAIM_OR_ADVICE = re.compile(
    r'(?<!\w)(?:breaking|announc\w*|confirm\w*|report(?:s|ed|edly)?|according|said|says|'
    r'proves?|proof|guarantee\w*|certainly|definitely|everyone|consensus|always|never|will|'
    r'buy|sell|short|long position|leverage|target price|price target|'
    r'fraud\w*|corrupt\w*|scam\w*|criminal\w*|terrorist\w*|fascis\w*|rigged|stolen|'
    r'steals?|bribes?|bribery|collud\w*|conspir\w*|manipulat\w*|false flag|'
    r'president|minister|missiles?|bomb\w*|killed|murder\w*|genocide|'
    r'million|billion|trillion|'
    r'[وف]?(?:اعلن|اكد|قال|صرح|يزعم|عاجل|مضمون|حتما|بالتاكيد|الجميع|الخبراء|'
    r'اشتر|اشتري|بيع|بع|توصية|توصيات|فساد|فاسد|سرقة|يسرق|رشوة|مجرم|ارهابي|'
    r'مؤامرة|مؤامرات|تلاعب|رئيس|وزير|صواريخ|قصف|مقتل|ابادة|مليون|مليار|تريليون))(?!\w)', re.I)
_PERSONAL_FINANCE = re.compile(
    r'(?<!\w)(?:i (?:own|hold|bought|sold|lost|earned)|my(?:\s+\w+){0,2}\s+(?:portfolio|positions?|bank|account|salary|income)|'
    r'passport|social security|credit card|'
    r'محفظتي|حسابي|راتبي|دخلي|جواز سفري|بطاقتي الائتمانية)(?!\w)', re.I)
_CURRENT_FACT_TENSE = re.compile(
    r'(?<!\w)(?:has|have|had|just|already|today|yesterday|now|rose|fell|surged|dropped|'
    r'collapsed|rallied|jumped|soared|plunged|halted|'
    r'[وف]?(?:ارتفع|ارتفعت|انخفض|انخفضت|هبط|صعد|انهار|سجل|اليوم|امس|البارحة|الان|حاليا))(?!\w)', re.I)
_CAPITAL_COMMON = frozenset(word.casefold() for word in (
    'A An And As At But Can Could For From Gold Oil Crude Bullion Inflation Interest Real '
    'Rates Yields Dollar Currency Currencies Bonds Central Banks I If In It Its My May '
    'Maybe Might Our Personally That The Their There These This To We What When Which '
    'Why Would You Your Watching Higher Lower However Still Yet Uncertainty').split())
_NAME_STATEMENT = re.compile(
    r'(?<!\w)(?:ignore|instructions?|prompts?|passwords?|secrets?|'
    r'buy|sell|subscribe|signals?|profits?|guarantee\w*|'
    r'fraud\w*|corrupt\w*|scam\w*|criminal\w*|terrorist\w*|'
    r'تجاهل|تعليمات|اشترك|اشتري|ارباح|مضمون|فساد|مجرم)(?!\w)', re.I)
_BUSINESS_ROOT_TOPIC = re.compile(
    r'(?<!\w)(?:business|compan(?:y|ies)|consumers?|customers?|products?|services?|'
    r'retail(?:er|ers)?|subscription|subscribers?|streaming|viewing|viewers?|entertainment|'
    r'netflix|television|programming|shopping|airlines?|automakers?|earnings|revenue|'
    r'شركات|شركة|مستهلكين|مستهلك|مشاهدين|مشاهدة|اشتراكات|اشتراك|نتفليكس|خدمات|منتجات)(?!\w)', re.I)
_NEWS_POLITICS = re.compile(
    r'(?<!\w)(?:president|minister|elections?|politic\w*|war|military|missiles?|bomb\w*|'
    r'killed|murder\w*|genocide|terror\w*|رئيس|وزير|انتخابات|سياسي|حرب|عسكري|قصف|مقتل|ابادة)(?!\w)', re.I)
_NEWS_UNSAFE = re.compile(
    r'(?<!\w)(?:breaking|announc\w*|confirm\w*|report(?:s|ed|edly)?|according|said|says|'
    r'proves?|proof|guarantee\w*|certainly|definitely|everyone|consensus|always|never|'
    r'buy|sell|short|long position|leverage|target price|price target|'
    r'fraud\w*|corrupt\w*|scam\w*|criminal\w*|fascis\w*|rigged|stolen|stole|'
    r'steal\w*|bribes?|bribery|collud\w*|conspir\w*|manipulat\w*|false flag|'
    r'liars?|lies?|lied|cheat\w*|deceiv\w*|launder\w*|'
    r'rose|fell|surged|dropped|collapsed|rallied|jumped|soared|plunged|halted|'
    r'launched|released|acquired|bankrupt\w*|layoffs?|fired|hired|sacked|lost|gained|'
    r'hack\w*|breach\w*|leak\w*|illegal\w*|mislead\w*|million|billion|trillion|'
    r'اعلن|اكد|قال|صرح|يزعم|عاجل|مضمون|حتما|بالتاكيد|الجميع|الخبراء|'
    r'اشتر|اشتري|بيع|بع|توصية|توصيات|فساد|فاسد|سرقة|يسرق|رشوة|مجرم|'
    r'مؤامرة|مؤامرات|تلاعب|كاذب|كذب|احتيال|ارتفع|انخفض|انهار|مليون|مليار|تريليون)(?!\w)', re.I)
_NEWS_FACT = re.compile(
    r'(?<!\w)(?:(?:rais\w*|increas\w*|reduc\w*|cut|cuts|cutting)\s+(?:its\s+|the\s+)?prices?|'
    r'(?:has|have|had|is|are)\s+(?:just\s+|now\s+|already\s+)?\d+|'
    r'(?:has|have|had)\s+(?:new|more|fewer|less)|'
    r'\d+\s+(?:new\s+)?(?:subscribers?|customers?|users?|viewers?|employees?|jobs?|staff|dollars?|euros?)|'
    r'(?:more|fewer|less)\s+(?:subscribers?|customers?|users?|employees?)|'
    r'(?:subscribers?|customers?|users?|revenue|earnings|profits?|sales|shares?|stock)\s+'
    r'(?:numbers?\s+)?(?:is|are|was|were|has|have)\s+(?:now\s+)?(?:up|down|higher|lower)|'
    r'commits?\s+crimes?|hid(?:es|ing)?\s+(?:money|losses|profits|funds))(?!\w)', re.I)
_NEWS_SUBJECTIVE = re.compile(
    r'(?<!\w)(?:i think|i feel|i wonder|in my (?:view|opinion)|for me|'
    r'should|needs?|deserves?|would|prefer\w*|wish|hope|enjoy\w*|likes?|love|dislike\w*|hate|'
    r'better|worse|boring|interesting|awful|expensive|cheap|confusing|useful|'
    r'برايي|اعتقد|اري|اتساءل|ينبغي|يحتاج|تحتاج|افضل|احب|اتمنى|ممل|مفيد)(?!\w)', re.I)
_NEWS_QUESTION = re.compile(r'^(?:will|would|could|can|should|why|what|how|when|is|are|do|does|هل|لماذا|كيف|ماذا)\b', re.I)


def _news_root_title(title):
    """A bounded collected business title, not an expanded article or fact check."""
    return (isinstance(title, str) and 20 <= len(title) <= 400 and clean_text(title) == title and
            bool(_BUSINESS_ROOT_TOPIC.search(normalized_title(title))) and
            not _NEWS_POLITICS.search(normalized_title(title)))


def _safe_news_opinion(raw):
    """Keep an entire short subjective reply; never remove an unsafe clause.

    This v2 gate deliberately permits ordinary brand names, brand digits and
    present-tense consumer preferences. It still excludes alleged news, trade
    instructions, private details and promotion; it is not fact verification.
    """
    if (not isinstance(raw, str) or not 20 <= len(raw) <= 400 or raw != raw.strip() or
            not 4 <= len(raw.split()) <= 65 or _CONTACT.search(raw) or
            any(unicodedata.category(character).startswith('C') or
                unicodedata.category(character) in {'So', 'Sk'} for character in raw) or
            re.search(r'[<>@#$€£¥%٪{}\\]|\[|\]', raw) or
            not re.search(r'[.!?؟]["\u201d\u2019\')]*$', raw)):
        return ''
    folded = normalized_title(raw)
    if (_ABUSE.search(folded) or _PROMO.search(folded) or _PERSONAL_FINANCE.search(folded) or
            _NEWS_UNSAFE.search(folded) or _NEWS_POLITICS.search(folded) or _NEWS_FACT.search(folded)):
        return ''
    sentences = [part.strip() for part in re.findall(r'.+?(?:[.!?؟]+["\u201d\u2019\')]*(?=\s|$)|$)', raw) if part.strip()]
    for sentence in sentences:
        question = bool(re.search(r'[?؟]["\u201d\u2019\')]*$', sentence) and _NEWS_QUESTION.search(sentence))
        if not question and re.search(r'(?<!\w)will(?!\w)', sentence, re.I):
            return ''
        if not question and not _NEWS_SUBJECTIVE.search(normalized_title(sentence)):
            return ''
    return raw if sentences else ''


def _author_name(raw):
    """Return a bounded public account display name, never a verified identity.

    Names are optional: unsafe profile decorations, contact details and prose
    are omitted without changing the exact account handle or authored opinion.
    Do not strip embedded markup, controls or symbols into a different name.
    """
    if (not isinstance(raw, str) or not 2 <= len(raw) <= 100 or
            any(unicodedata.category(character).startswith('C') for character in raw)):
        return ''
    name = ' '.join(unicodedata.normalize('NFC', raw).split())
    if (not 2 <= len(name) <= 80 or len(name.split()) > 8 or
            not name[0].isalpha() or not name[-1].isalpha() or
            any(not (character.isalpha() or unicodedata.category(character).startswith('M') or
                     character in " '.\u2019-") for character in name) or
            _CONTACT.search(name)):
        return ''
    folded = normalized_title(name)
    if (_ABUSE.search(folded) or _PROMO.search(folded) or
            _PERSONAL_FINANCE.search(folded) or _NAME_STATEMENT.search(folded)):
        return ''
    return name


def _author_name_allowed(metadata):
    # Old v1 records carry only their exact account handle. Newly collected
    # optional names must retain their explicit account-display-name meaning.
    if 'authorName' not in metadata:
        return 'authorNameKind' not in metadata
    name = metadata['authorName']
    return (isinstance(name, str) and bool(name) and _author_name(name) == name and
            metadata.get('authorNameKind') == 'account-display-name')


def _opinion_text(text):
    """Narrow heuristic for commentary, never a publisher/news truth verdict."""
    folded = normalized_title(text)
    if (not _FINANCIAL_TOPIC.search(folded) or not _OPINION_CUE.search(folded) or
            _CLAIM_OR_ADVICE.search(folded) or _PERSONAL_FINANCE.search(folded) or _CURRENT_FACT_TENSE.search(folded) or
            any(character.isdecimal() for character in text) or re.search(r'[$€£¥%٪]', text) or
            re.search(r'(?<!\w)@[\w.-]+', text) or len(text.split()) > 65):
        return False
    # Unknown named actors are unnecessary to a brief general financial
    # opinion. Keep the conservative English rule separate from Arabic cues.
    if any(match.group().casefold() not in _CAPITAL_COMMON
           for match in re.finditer(r'\b[A-Z][A-Za-z-]+\b', text)):
        return False
    # Each complete sentence must be interpretive, rather than attaching a
    # single hedge to an otherwise factual multi-sentence claim.
    sentences = [part.strip() for part in re.split(r'[.!?؟;؛]+', text) if part.strip()]
    return bool(sentences) and all(_OPINION_CUE.search(normalized_title(part)) for part in sentences)


def publisher_root(row, now_s):
    """Derive one fixed publisher identity from an existing collector row."""
    if (not isinstance(row, dict) or row.get('platform') != 'Bluesky' or row.get('social') is not True or
            row.get('sourceKind') != 'social' or type(row.get('publishedAt')) is not int or
            type(row.get('firstSeenAt')) is not int or
            not 0 < row['publishedAt'] <= row['firstSeenAt'] <= now_s or
            now_s - row['publishedAt'] > MAX_AGE_S or
            not isinstance(row.get('title'), str)):
        return None
    url = row.get('url')
    if not isinstance(url, str):
        return None
    for did, source in PINNED.items():
        match = re.fullmatch(re.escape('https://bsky.app/profile/' + did + '/post/') + r'([a-zA-Z0-9]{1,32})', url)
        if match and row.get('source') == source.source:
            financial = relevance(row['title'])[0] >= 25
            business = (did in BUSINESS_PUBLISHERS and _news_root_title(row['title']) and
                        row.get('clockBasis') == 'author-reported' and row.get('timeKind') == 'published')
            if not financial and not business:
                return None
            expected_id = hashlib.sha256(('social:' + url).encode()).hexdigest()[:32]
            if row.get('id') != expected_id:
                return None
            uri = f'at://{did}/app.bsky.feed.post/{match[1]}'
            return {'uri': uri, 'source': source, 'row': dict(row),
                    'financialOpinionEligible': financial, 'newsOpinionEligible': bool(business)}
    return None


def thread_url(uri):
    match = _POST_URI.fullmatch(uri) if isinstance(uri, str) else None
    if not match or match[1] not in PINNED:
        raise ValueError('Unsupported public feedback root')
    return ENDPOINT + '?' + urllib.parse.urlencode({'uri': uri, 'depth': 1, 'parentHeight': 0})


def _allowed_url(url):
    try:
        parsed = urllib.parse.urlsplit(url)
        query = urllib.parse.parse_qs(parsed.query, strict_parsing=True)
        if (parsed.scheme != 'https' or parsed.netloc != 'public.api.bsky.app' or
                parsed.path != '/xrpc/app.bsky.feed.getPostThread' or parsed.fragment or
                set(query) != {'uri', 'depth', 'parentHeight'} or
                query['depth'] != ['1'] or query['parentHeight'] != ['0'] or len(query['uri']) != 1):
            return False
        return url == thread_url(query['uri'][0])
    except (ValueError, TypeError, KeyError):
        return False


def _safe_text(raw):
    if not isinstance(raw, str) or not 40 <= len(raw) <= 400 or _CONTACT.search(raw):
        return ''
    text = clean_text(raw)
    folded = normalized_title(text)
    if (len(text) < 40 or len(text.split()) < 6 or _ABUSE.search(folded) or
            _PROMO.search(folded) or relevance(text)[0] < 25 or not _opinion_text(text)):
        return ''
    return text


def reaction_allowed(row, now_s):
    """Validate a newly screened reaction again at restore/selection/air time.

    Legacy reply receipts have no policy marker and cannot be silently revived.
    Only the current parser can establish the parent/author identity contract;
    this guard keeps that contract and the one-hour clocks intact afterwards.
    """
    if (not isinstance(row, dict) or type(now_s) is not int or now_s <= 0 or
            row.get('sourceKind') != 'social-feedback' or row.get('social') is not True or
            row.get('platform') != 'Bluesky' or row.get('language') not in ('ar', 'en') or
            type(row.get('publishedAt')) is not int or type(row.get('firstSeenAt')) is not int or
            not 0 < row['publishedAt'] <= row['firstSeenAt'] <= now_s or
            now_s - row['publishedAt'] > MAX_AGE_S or
            row.get('verification') != 'unverified-public-reply' or
            row.get('clockBasis') != 'author-reported' or
            not isinstance(row.get('title'), str)):
        return False
    feedback = row.get('feedback')
    if (not isinstance(feedback, dict) or
            feedback.get('unverified') is not True or feedback.get('representative') is not False or
            not isinstance(feedback.get('rootUri'), str) or not isinstance(feedback.get('replyUri'), str) or
            type(feedback.get('rootPublishedAt')) is not int or
            not 0 < feedback['rootPublishedAt'] <= row['publishedAt'] or
            now_s - feedback['rootPublishedAt'] > MAX_AGE_S):
        return False
    if (not _author_name_allowed(feedback) or 'contentHash' in feedback and
            feedback['contentHash'] != hashlib.sha256(row['title'].encode()).hexdigest()):
        return False
    root = _POST_URI.fullmatch(feedback.get('rootUri', ''))
    reply = _POST_URI.fullmatch(feedback.get('replyUri', ''))
    handle = feedback.get('authorHandle')
    if (not root or root[1] not in PINNED or not reply or reply[1] in PINNED or
            feedback.get('authorDid') != reply[1] or not isinstance(handle, str) or not _HANDLE.fullmatch(handle)):
        return False
    if feedback.get('screeningPolicy') == REACTION_POLICY_VERSION:
        if (feedback.get('screeningKind') != 'bounded-financial-opinion' or
                _safe_text(row['title']) != row['title']):
            return False
    elif feedback.get('screeningPolicy') == NEWS_OPINION_POLICY_VERSION:
        root_title, root_seen = feedback.get('rootTitle'), feedback.get('rootFirstSeenAt')
        if (feedback.get('screeningKind') != 'bounded-news-opinion' or root[1] not in BUSINESS_PUBLISHERS or
                _safe_news_opinion(row['title']) != row['title'] or not _news_root_title(root_title) or
                feedback.get('rootContentHash') != hashlib.sha256(root_title.encode()).hexdigest() or
                feedback.get('contentHash') != hashlib.sha256(row['title'].encode()).hexdigest() or
                type(root_seen) is not int or not feedback['rootPublishedAt'] <= root_seen <= row['firstSeenAt']):
            return False
    else:
        return False
    root_url = 'https://bsky.app/profile/' + root[1] + '/post/' + root[2]
    reply_url = 'https://bsky.app/profile/' + reply[1] + '/post/' + reply[2]
    source = PINNED[root[1]]
    attribution = (f'تعليق @{handle} على {source.source}' if row['language'] == 'ar' else
                   f'Reply @{handle} to {source.source}')
    return (row.get('url') == reply_url and row.get('source') == attribution and
            feedback.get('rootSource') == source.source and feedback.get('rootUrl') == root_url and
            feedback.get('rootId') == hashlib.sha256(('social:' + root_url).encode()).hexdigest()[:32] and
            row.get('id') == hashlib.sha256(('social-feedback:' + feedback['replyUri']).encode()).hexdigest()[:32])


def _edited(post, record):
    return any(value.get(field) is not None for value in (post, record)
               for field in ('editedAt', 'edited_at', 'updatedAt', 'updated_at'))


def _matching_news_root(post, source, row):
    """Verify the exact collected title against this same original parent post."""
    record = post['record']
    embed = record.get('embed')
    return (source.did in BUSINESS_PUBLISHERS and _news_root_title(row['title']) and
            row.get('clockBasis') == 'author-reported' and row.get('timeKind') == 'published' and
            record.get('$type') == 'app.bsky.feed.post' and not record.get('reply') and
            not _edited(post, record) and
            (not embed or isinstance(embed, dict) and embed.get('$type') in
             {'app.bsky.embed.images', 'app.bsky.embed.video', 'app.bsky.embed.external'}) and
            isinstance(record.get('text'), str) and clean_text(record['text']) == row['title'])


def parse_thread(body, root, received_s):
    if not isinstance(body, bytes) or len(body) > MAX_BYTES or b'\x00' in body:
        raise ValueError('Public feedback body limit')
    data = json.loads(body.decode('utf-8', errors='strict'))
    thread = data.get('thread') if isinstance(data, dict) else None
    if not isinstance(thread, dict) or thread.get('$type') not in (None, 'app.bsky.feed.defs#threadViewPost'):
        raise ValueError('Public thread is blocked or missing')
    post = thread.get('post')
    source, row = root['source'], root['row']
    if (not isinstance(post, dict) or post.get('uri') != root['uri'] or post.get('labels') or
            not isinstance(post.get('author'), dict) or post['author'].get('did') != source.did or
            post['author'].get('handle') != source.actor or post['author'].get('labels') or
            not isinstance(post.get('record'), dict) or
            _stamp(post['record'].get('createdAt')) != row['publishedAt']):
        raise ValueError('Public feedback root identity changed')
    financial_root = relevance(row['title'])[0] >= 25
    news_root = _matching_news_root(post, source, row)
    replies = thread.get('replies', [])
    if not isinstance(replies, list):
        raise ValueError('Invalid public feedback replies')
    rows, seen = [], set()
    for reply in replies[:MAX_REPLIES]:
        if (not isinstance(reply, dict) or reply.get('$type') not in (None, 'app.bsky.feed.defs#threadViewPost') or
                not isinstance(reply.get('post'), dict)):
            continue
        post = reply['post']
        author, record = post.get('author'), post.get('record')
        if (post.get('labels') or not isinstance(author, dict) or author.get('labels') or
                not isinstance(record, dict) or record.get('$type') != 'app.bsky.feed.post' or record.get('embed')):
            continue
        did, handle = author.get('did'), author.get('handle')
        uri = post.get('uri')
        match = _POST_URI.fullmatch(uri) if isinstance(uri, str) else None
        if (not match or did != match[1] or not isinstance(handle, str) or not _HANDLE.fullmatch(handle) or
                did in PINNED or uri in seen):
            continue
        relation = record.get('reply')
        if (not isinstance(relation, dict) or not isinstance(relation.get('root'), dict) or
                not isinstance(relation.get('parent'), dict) or relation['root'].get('uri') != root['uri'] or
                relation['parent'].get('uri') != root['uri']):
            continue
        try:
            published = _stamp(record.get('createdAt'))
        except (ValueError, TypeError, OverflowError):
            continue
        if not row['publishedAt'] <= published <= received_s or received_s - published > MAX_AGE_S:
            continue
        text = _safe_text(record.get('text')) if financial_root else ''
        news_opinion = False
        if not text and news_root and not _edited(post, record) and not post.get('embed') and not record.get('facets'):
            text = _safe_news_opinion(record.get('text'))
            news_opinion = bool(text)
        if not text:
            continue
        arabic = sum('\u0600' <= character <= '\u06ff' and character.isalpha() for character in text)
        latin = sum('a' <= character.lower() <= 'z' for character in text)
        language = 'ar' if arabic >= 8 and arabic > latin else 'en' if latin >= 12 and latin > arabic else None
        if language is None:
            continue
        if language == 'en' and any(character.isalpha() and 'LATIN' not in unicodedata.name(character, '')
                                    for character in text):
            # Match the English speech contract; never rewrite an author's
            # mixed-script statement into a different claim to make it speak.
            continue
        attribution = (f'تعليق @{handle} على {source.source}' if language == 'ar' else
                       f'Reply @{handle} to {source.source}')
        if len(attribution) > 160:
            continue
        seen.add(uri)
        name = _author_name(author.get('displayName'))
        rows.append({'id': hashlib.sha256(('social-feedback:' + uri).encode()).hexdigest()[:32],
            'title': text, 'summary': '', 'source': attribution, 'language': language,
            'url': 'https://bsky.app/profile/' + did + '/post/' + match[2],
            'publishedAt': published, 'firstSeenAt': received_s,
            'social': True, 'sourceKind': 'social-feedback', 'platform': 'Bluesky', 'timeKind': 'published',
            'clockBasis': 'author-reported', 'verification': 'unverified-public-reply',
            'feedback': {'authorHandle': handle, 'authorDid': did, 'rootSource': source.source,
                         **({'authorName': name, 'authorNameKind': 'account-display-name'} if name else {}),
                         'contentHash': hashlib.sha256(text.encode()).hexdigest(),
                         'rootUrl': row['url'], 'rootId': row['id'], 'rootPublishedAt': row['publishedAt'],
                         **({'rootTitle': row['title'], 'rootContentHash': hashlib.sha256(row['title'].encode()).hexdigest(),
                             'rootFirstSeenAt': row['firstSeenAt']} if news_opinion else {}),
                         'rootUri': root['uri'], 'replyUri': uri, 'unverified': True, 'representative': False,
                         'screeningPolicy': NEWS_OPINION_POLICY_VERSION if news_opinion else REACTION_POLICY_VERSION,
                         'screeningKind': 'bounded-news-opinion' if news_opinion else 'bounded-financial-opinion',
                         'screeningGuarantee': 'rules-not-independent-fact-verification'}})
    return rows


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        return None


def fetch_public(url, _headers, timeout):
    if (not _allowed_url(url) or not collection_url_allowed(url) or
            not isinstance(timeout, (int, float)) or not 0 < timeout <= COLLECTION_BUDGET_S):
        raise ValueError('Unsupported public feedback request')
    headers = {'User-Agent': 'PublicNewsReader/1.0', 'Accept': 'application/json',
               'Accept-Encoding': 'identity'}
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    deadline = time.monotonic() + timeout
    try:
        response = opener.open(urllib.request.Request(url, headers=headers), timeout=timeout)
    except urllib.error.HTTPError as error:
        return Response(error.code, dict(error.headers.items()), b'', url)
    with response:
        values = {key.lower(): value for key, value in response.headers.items()}
        size = values.get('content-length')
        if (values.get('content-encoding', 'identity') != 'identity' or
                size and (not size.isdecimal() or int(size) > MAX_BYTES)):
            raise ValueError('Public feedback body limit')
        parts, total = [], 0
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Public feedback deadline')
            socket = getattr(getattr(response.fp, 'raw', None), '_sock', None)
            if socket is not None:
                socket.settimeout(max(.1, deadline - time.monotonic()))
            block = response.read1(min(65536, MAX_BYTES + 1 - total))
            if not block:
                break
            total += len(block)
            if total > MAX_BYTES:
                raise ValueError('Public feedback body limit')
            parts.append(block)
        return Response(response.status, values, b''.join(parts), response.url)


class SocialFeedbackCollector:
    def __init__(self, fetcher=None):
        self._fetcher = fetcher or fetch_public
        self._lock, self._collect_lock = threading.RLock(), threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix='public-feedback')
        self._states, self._receipts, self._pending = {}, {}, {}
        self._next_poll = 0
        self._status = {'status': 'starting', 'checkedAt': 0, 'lastSuccessAt': 0,
                        'rootsAvailable': 0, 'threadsChecked': 0, 'acceptedReplies': 0,
                        'errors': 0, 'httpStatus': None}

    def status(self):
        with self._lock:
            return {**self._status, 'nextCheckAt': self._next_poll * 1000,
                    'pendingRequests': len(self._pending), 'publisherIdentities': len(PINNED),
                    'transport': 'Public Bluesky direct replies; no login; no PC',
                    'verification': 'Unverified individual financial opinions, not a representative sample',
                    'screeningPolicy': REACTION_POLICY_VERSION, 'maxAgeSeconds': MAX_AGE_S}

    def _request(self, root, now_s, real_clock, deadline):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Public feedback deadline')
        url = thread_url(root['uri'])
        response = self._fetcher(url, {}, min(COLLECTION_BUDGET_S, remaining))
        if (not isinstance(response, Response) or response.url != url or not isinstance(response.body, bytes) or
                len(response.body) > MAX_BYTES or time.monotonic() > deadline):
            raise ValueError('Invalid public feedback response')
        headers = {key.lower(): value for key, value in response.headers.items()}
        if response.status == 200:
            if 'application/json' not in headers.get('content-type', '').lower():
                raise ValueError('Unexpected public feedback type')
            received = int(time.time()) if real_clock else now_s
            rows = parse_thread(response.body, root, received)
        else:
            rows = []
        return response.status, headers, rows

    def collect(self, stories, now_s=None):
        real_clock = now_s is None
        now_s = int(time.time()) if real_clock else now_s
        if type(now_s) is not int or now_s <= 0 or isinstance(stories, (str, bytes, dict)):
            raise ValueError('A valid public-story sample and clock are required')
        if not self._collect_lock.acquire(blocking=False):
            return []
        try:
            with self._lock:
                if now_s < self._next_poll:
                    return []
                self._next_poll = now_s + POLL_SECONDS
            try:
                material = list(islice(iter(stories), 1000))
            except TypeError:
                raise ValueError('Expected collected public stories') from None
            roots = [root for row in material if (root := publisher_root(row, now_s))]
            roots.sort(key=lambda root: (-root['row']['publishedAt'], root['uri']))
            roots = list({root['uri']: root for root in roots}.values())[:MAX_ROOTS]
            deadline, result = time.monotonic() + COLLECTION_BUDGET_S, []
            with self._lock:
                self._pending = {uri: future for uri, future in self._pending.items() if not future.done()}
                current = {root['uri'] for root in roots}
                self._states = {uri: state for uri, state in self._states.items() if uri in current or uri in self._pending}
                self._status.update(checkedAt=now_s * 1000, rootsAvailable=len(roots), acceptedReplies=0,
                                    status='waiting' if not roots else 'ready')
                due = [root for root in roots if root['uri'] not in self._pending and
                       now_s >= self._states.get(root['uri'], {}).get('nextAt', 0)]
                due.sort(key=lambda root: self._states.get(root['uri'], {}).get('nextAt', 0))
                due = due[:max(0, MAX_WORKERS - len(self._pending))]
                jobs = {}
                for root in due:
                    future = self._pool.submit(self._request, root, now_s, real_clock, deadline)
                    jobs[future] = root
                    self._pending[root['uri']] = future
            done, _ = wait(jobs, timeout=max(0, deadline - time.monotonic()))
            finished = int(time.time()) if real_clock else now_s
            with self._lock:
                for future, root in jobs.items():
                    status, headers = None, {}
                    previous = self._states.get(root['uri'], {})
                    failures = previous.get('failures', 0)
                    try:
                        if future not in done:
                            future.cancel()
                            raise TimeoutError('Public feedback deadline')
                        status, headers, rows = future.result()
                        if status != 200:
                            raise ValueError('Public feedback unavailable')
                        self._states[root['uri']] = {'nextAt': finished + _next_delay(headers, finished, status=status), 'failures': 0}
                        self._status.update(status='ready', lastSuccessAt=finished * 1000, httpStatus=status,
                                            threadsChecked=self._status['threadsChecked'] + 1)
                        for row in rows:
                            if not reaction_allowed(row, finished):
                                continue
                            old = self._receipts.get(row['id'])
                            fingerprint = (row['publishedAt'], row['feedback']['rootUri'], row['feedback']['contentHash'],
                                           row['feedback'].get('rootContentHash'), row['feedback']['rootPublishedAt'])
                            if old and old[1:] != fingerprint:
                                continue
                            if old:
                                row['firstSeenAt'] = old[0]
                            self._receipts[row['id']] = (row['firstSeenAt'], *fingerprint)
                            result.append(row)
                    except Exception:
                        delay = _next_delay(headers, finished, failures + 1, status)
                        self._states[root['uri']] = {'nextAt': finished + delay, 'failures': failures + 1}
                        self._status.update(status='access_denied' if status in (401, 403) else
                                            'rate_limited' if status == 429 else 'unavailable',
                                            httpStatus=status, errors=self._status['errors'] + 1,
                                            threadsChecked=self._status['threadsChecked'] + 1)
                        if status in (401, 403, 429):
                            self._next_poll = max(self._next_poll, finished + delay)
                    if future.done():
                        self._pending.pop(root['uri'], None)
                self._receipts = dict(sorted(((key, value) for key, value in self._receipts.items()
                    if finished - value[1] <= MAX_AGE_S), key=lambda pair: pair[1][0], reverse=True)[:MAX_RECEIPTS])
                self._status['acceptedReplies'] = len(result)
            return result
        finally:
            self._collect_lock.release()

"""Build-time, fixed public downloads only. Runtime never downloads a model."""
from __future__ import annotations
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import urllib.request
import zipfile

SOURCE_REVISION = "16b5281ce61993df3526740990cf845a3f3036f4"
MODEL_REVISION = "bbac0f1e6b001bfae89871be366a4b000180deb2"
G2P_HASH = "8f00bba1b4b97eaa9342dc68cf6b11e2c926d714052c035228d10ad69ad93d0c"
MODEL_BASE = f"https://huggingface.co/oddadmix/Nabra-7M-Distill-ONNX/resolve/{MODEL_REVISION}/"
MODEL_FILES = {
    "model/model.onnx": (30_542_978, "08c1df048f2decbff3f86dc8e625e10ff3c8d5f66dfc97881c6974272f41ca5e"),
    "model/af_msa.bin": (522_240, "129d447a7c9bdce1d5b6cb5ecb789bbfd9f427b7775131a97dfa5638583b3b92"),
}
MODEL_REMOTE_FILES = {"model/model.onnx": "onnx/model.onnx", "model/af_msa.bin": "voices/af_msa.bin"}
PIPER_WHEEL_URL = "https://files.pythonhosted.org/packages/84/81/0112a7d510911f33018dc24023d1655bb772f84a4e95fe7f0180f66bbd17/piper_tts-1.8.0-cp39-abi3-manylinux_2_17_x86_64.manylinux2014_x86_64.manylinux_2_28_x86_64.whl"
PIPER_WHEEL_HASH = "25b4d3f31ff70c8fa7151908e00aaa5650cbdf16bca8fcf21299f3941b89a7d3"
VOWEL_FILES = {
    "__init__.py": "1517463424d069a8bd5f4efbbe5361e2d14ebd6826d54da521482740a3b9ab4b",
    "model.onnx": "52c40d42ca094ff9ff07a091d0a1eafd7baa5cf2388e60a9cc89bacd8e5e955f",
    "hint_id_map.json": "80931db53b1f1031609a66f23b64a1c37d79ae4a8a4c785023728636a7fa93e5",
    "input_id_map.json": "727a49aa3c7e939dc06f32b27c2e06c4c4bbef596dce4bf51276261ca736c3c3",
    "target_id_map.json": "6da34024bfd4c0ff54f7598bb74d5a00405144d746afe72c141fceeaba21ed30",
}


def verified(data, digest, size=None):
    if (size is not None and len(data) != size) or hashlib.sha256(data).hexdigest() != digest:
        raise ValueError("A pinned public speech asset changed")
    return data


def fetch(url, digest, size=None, limit=40_000_000):
    request = urllib.request.Request(url, headers={"User-Agent": "GoldPulse-model-build/1"})
    with urllib.request.urlopen(request, timeout=120) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError("Public speech download exceeds its bound")
    return verified(data, digest, size)


def write_asset(root, name, data):
    target = root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


def build(runtime_dir=None):
    root = Path(runtime_dir or os.environ.get("RADIO_MODEL_DIR", "/opt/gold-radio-assets")).resolve()
    if Path(__file__).resolve().parent == root or Path(__file__).resolve().parent in root.parents:
        raise ValueError("Speech assets must be outside the application source")
    root.mkdir(parents=True, exist_ok=True)
    from station_music import compose, MUSIC_FILE
    write_asset(root, MUSIC_FILE, compose())
    local = Path(__file__).resolve().parent / "vendor"
    write_asset(root, "g2p.mjs", verified((local / "g2p.mjs").read_bytes(), G2P_HASH))
    for name, (size, digest) in MODEL_FILES.items():
        target = root / name
        data = target.read_bytes() if target.is_file() else fetch(MODEL_BASE + MODEL_REMOTE_FILES[name], digest, size)
        write_asset(root, name, verified(data, digest, size))
    # Only the tiny, reviewed tashkeel module/resources are extracted. No wheel
    # entrypoint, native library or package installation is executed here.
    wheel = fetch(PIPER_WHEEL_URL, PIPER_WHEEL_HASH)
    with zipfile.ZipFile(io.BytesIO(wheel)) as archive:
        for name, digest in VOWEL_FILES.items():
            write_asset(root, "tashkeel/" + name, verified(archive.read("piper/tashkeel/" + name), digest))
        for member in archive.namelist():
            if ".dist-info/licenses/" in member and member.endswith(("LICENSE", "COPYING", "LICENSE.md", "LICENSE.txt")):
                data = archive.read(member)
                if len(data) < 100_000:
                    write_asset(root, "licenses/PIPER-" + Path(member).name, data)
    # Keep corresponding pinned source/build instructions beside the G2P.
    source_url = f"https://codeload.github.com/Oddadmix/nabra-tts/zip/{SOURCE_REVISION}"
    source = fetch(source_url, "057180ceaa16e0a5c32427592d0dcf3f9a14eaf42d0920401092e5961b6e67e5", limit=3_000_000)
    write_asset(root, "licenses/nabra-source-pinned.zip", source)
    for filename in ("NABRA-LICENSE", "THIRD_PARTY_NOTICES.md"):
        shutil.copyfile(local / filename, root / "licenses" / filename)
    manifest = {"sourceRevision": SOURCE_REVISION, "modelRevision": MODEL_REVISION,
        "ortVersion": "1.30.0", "engine": "nabra7m-fp16-wasm-local-v1",
        "modelFile": "model/model_fp16.onnx", "voiceFile": "model/af_msa.bin",
        "nativeFp32File": "model/model.onnx", "nativeOrtVersion": "1.30.0",
        "artifacts": {**{name: info[1] for name, info in MODEL_FILES.items()}, "g2p.mjs": G2P_HASH}}
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("Pinned Nabra FP32 and Arabic vowels are ready; Arabic inference is CPU only.")


if __name__ == "__main__":
    build()
